<think>
The user wants an immersive underwater scene with:
1. Light rays/caustics
2. Bubbles rising
3. Aquatic plant life swaying

I'll create a comprehensive fragment shader that includes:
- Deep blue-green water coloring with depth gradient
- Volumetric light rays from above
- Animated caustic patterns on the "floor"
- Rising bubbles with varying sizes and speeds
- Swaying seaweed/kelp using sine wave displacement
- Subtle particle effects for sediment
- Fish or creature silhouettes for atmosphere

Let me structure this carefully:

1. Noise functions for organic variation
2. Light ray calculations
3. Caustic patterns using layered noise
4. Bubble system with proper animation
5. Swaying plants using time-based displacement
6. Depth fog for atmosphere
7. Fish silhouettes for additional interest

I'll use these key techniques:
- Layered FBM noise for caustics
- Ray marching for light shafts
- Sin waves for plant swaying
- Random functions for bubble placement
- Smooth color gradients for underwater feel

Let me write this shader:
</think>

precision highp float;

#define u_resolution vec2(800.0, 600.0)
#define u_time 0.0

uniform vec2 u_resolution;
uniform float u_time;
uniform vec2 u_mouse;

// Simplex noise functions
vec3 mod289(vec3 x) { return x - floor(x * (1.0 / 289.0)) * 289.0; }
vec2 mod289(vec2 x) { return x - floor(x * (1.0 / 289.0)) * 289.0; }
vec3 permute(vec3 x) { return mod289(((x*34.0)+1.0)*x); }

float snoise(vec2 v) {
    const vec4 C = vec4(0.211324865405187, 0.366025403784439, -0.577350269189626, 0.024390243902439);
    vec2 i = floor(v + dot(v, C.yy));
    vec2 x0 = v - i + dot(i, C.xx);
    vec2 i1 = (x0.x > x0.y) ? vec2(1.0, 0.0) : vec2(0.0, 1.0);
    vec4 x12 = x0.xyxy + C.xxzz;
    x12.xy -= i1;
    i = mod289(i);
    vec3 p = permute(permute(i.y + vec3(0.0, i1.y, 1.0)) + i.x + vec3(0.0, i1.x, 1.0));
    vec3 m = max(0.5 - vec3(dot(x0,x0), dot(x12.xy,x12.xy), dot(x12.zw,x12.zw)), 0.0);
    m = m*m; m = m*m;
    vec3 x = 2.0 * fract(p * C.www) - 1.0;
    vec3 h = abs(x) - 0.5;
    vec3 ox = floor(x + 0.5);
    vec3 a0 = x - ox;
    m *= 1.79284291400159 - 0.85373472095314 * (a0*a0 + h*h);
    vec3 g;
    g.x = a0.x * x0.x + h.x * x0.y;
    g.yz = a0.yz * x12.xz + h.yz * x12.yw;
    return 130.0 * dot(m, g);
}

float fbm(vec2 p) {
    float f = 0.0;
    float w = 0.5;
    for (int i = 0; i < 5; i++) {
        f += w * snoise(p);
        p *= 2.0;
        w *= 0.5;
    }
    return f;
}

// Hash for randomness
float hash(float n) { return fract(sin(n) * 43758.5453123); }
float hash2(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }

// Caustics pattern
float caustics(vec2 uv, float time) {
    vec2 p = uv * 8.0;
    float c = 0.0;
    float scale = 1.0;
    for (int i = 0; i < 4; i++) {
        vec2 anim = vec2(sin(time * 0.5 + float(i)), cos(time * 0.3 + float(i) * 2.0));
        c += snoise(p * scale + anim) / scale;
        scale *= 2.0;
    }
    return pow(abs(sin(c * 3.14159)), 2.0);
}

// Light rays
float lightRays(vec2 uv, float time) {
    float rays = 0.0;
    for (int i = 0; i < 8; i++) {
        float fi = float(i);
        float x = 0.1 + fi * 0.12 + sin(time * 0.2 + fi) * 0.05;
        float width = 0.02 + sin(time * 0.3 + fi * 1.5) * 0.01;
        float ray = smoothstep(width, 0.0, abs(uv.x - x));
        ray *= smoothstep(0.0, 0.3, uv.y);
        ray *= (1.0 - uv.y * 0.5);
        rays += ray * 0.3;
    }
    return rays;
}

// Bubble
float bubble(vec2 uv, vec2 pos, float radius) {
    float d = length(uv - pos);
    float b = smoothstep(radius, radius * 0.8, d);
    float highlight = smoothstep(radius * 0.3, radius * 0.1, length(uv - pos - vec2(radius * 0.3, radius * 0.3)));
    return b + highlight * 0.5;
}

// Swaying plant
float plant(vec2 uv, float x, float height, float time, float phase) {
    float sway = sin(time * 1.5 + phase + uv.y * 3.0) * 0.03 * (height - uv.y);
    float px = x + sway;
    float width = 0.01 * (1.0 - uv.y / height) * (1.0 + sin(uv.y * 10.0 + time + phase) * 0.3);
    float leaf = smoothstep(width, width * 0.5, abs(uv.x - px));
    leaf *= step(0.0, uv.y) * step(uv.y, height);
    float leaves = 0.0;
    for (int i = 0; i < 4; i++) {
        float ly = height * 0.2 + float(i) * height * 0.2;
        float lw = 0.03 + sin(time * 2.0 + float(i) + phase) * 0.01;
        float lx = px + sin(time + float(i) + phase) * 0.02;
        leaves += smoothstep(lw, 0.0, abs(uv.x - lx)) * step(ly, uv.y) * step(uv.y, ly + 0.1);
    }
    return clamp(leaf + leaves * 0.5, 0.0, 1.0);
}

void mainImage(out vec4 fragColor, in vec2 fragCoord) {
    vec2 uv = fragCoord / u_resolution;
    vec2 uvNorm = (fragCoord - 0.5 * u_resolution) / u_resolution.y;
    float time = u_time;
    
    // Deep water gradient
    vec3 shallowColor = vec3(0.1, 0.4, 0.5);
    vec3 deepColor = vec3(0.02, 0.08, 0.15);
    float depth = 1.0 - uv.y;
    vec3 waterColor = mix(shallowColor, deepColor, depth * depth);
    
    // Caustics on floor
    float floorMask = smoothstep(0.3, 0.0, uv.y);
    float caust = caustics(uv * 3.0 + vec2(time * 0.1, 0.0), time) * floorMask;
    vec3 caustColor = vec3(0.3, 0.6, 0.7) * caust * 0.5;
    
    // Light rays
    float rays = lightRays(uv, time);
    vec3 rayColor = vec3(0.4, 0.7, 0.8) * rays;
    
    // Bubbles
    float bubbles = 0.0;
    for (int i = 0; i < 15; i++) {
        float fi = float(i);
        float seed = hash(fi * 123.456);
        float seed2 = hash(fi *