glsl
precision highp float;

#define u_resolution resolution
#define u_time time

uniform vec2 u_resolution;
uniform float u_time;
uniform vec2 u_mouse;

// Hash functions for noise
float hash(float n) { return fract(sin(n) * 43758.5453123); }
float hash(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }

// Value noise
float noise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    
    float a = hash(i);
    float b = hash(i + vec2(1.0, 0.0));
    float c = hash(i + vec2(0.0, 1.0));
    float d = hash(i + vec2(1.0, 1.0));
    
    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}

// Fractal Brownian Motion for layered noise
float fbm(vec2 p) {
    float value = 0.0;
    float amplitude = 0.5;
    float frequency = 1.0;
    
    for (int i = 0; i < 4; i++) {
        value += amplitude * noise(p * frequency);
        amplitude *= 0.5;
        frequency *= 2.0;
    }
    
    return value;
}

// Caustics pattern
float caustics(vec2 uv, float time) {
    vec2 p = uv * 8.0;
    float c = 0.0;
    
    for (int i = 0; i < 3; i++) {
        float t = time * (0.5 + float(i) * 0.1);
        c += noise(p + vec2(sin(t), cos(t))) * 0.5;
        p *= 1.5;
    }
    
    return pow(c, 2.0) * 2.0;
}

// God rays
float godRays(vec2 uv, float time) {
    float rays = 0.0;
    float angle = 0.0;
    
    for (int i = 0; i < 8; i++) {
        angle = float(i) * 3.14159 * 2.0 / 8.0 + time * 0.1;
        vec2 dir = vec2(cos(angle), sin(angle));
        float ray = smoothstep(0.0, 1.0, abs(dot(uv, dir)));
        rays += pow(ray, 4.0) * 0.1;
    }
    
    return rays;
}

// Rising bubbles
float bubbles(vec2 uv, float time) {
    float b = 0.0;
    
    for (int i = 0; i < 12; i++) {
        float fi = float(i);
        float seed = hash(fi * 127.1);
        vec2 pos = vec2(
            fract(seed * 43758.5453 + time * 0.1 * (0.5 + seed)),
            fract(seed * 311.7 + time * 0.15 * (1.0 + seed))
        );
        
        // Wobble effect
        pos.x += sin(time * 2.0 + seed * 10.0) * 0.02;
        pos.y += cos(time * 1.5 + seed * 15.0) * 0.02;
        
        float size = 0.01 + hash(seed) * 0.02;
        float dist = length(uv - pos);
        float bubble = smoothstep(size, size * 0.8, dist);
        
        // Highlight
        float highlight = smoothstep(size * 0.5, size * 0.3, dist);
        bubble += highlight * 0.5;
        
        b += bubble;
    }
    
    return b;
}

// Swaying underwater plants
float plants(vec2 uv, float time) {
    float p = 0.0;
    
    for (int i = 0; i < 5; i++) {
        float fi = float(i);
        float x = 0.15 + fi * 0.18;
        float sway = sin(time * 0.8 + fi * 1.5) * 0.05;
        
        // Plant stem
        float stem = smoothstep(0.02, 0.0, abs(uv.x - x - sway * (1.0 - uv.y)));
        
        // Plant leaves
        for (int j = 0; j < 3; j++) {
            float fj = float(j);
            float leafY = 0.3 + fj * 0.2;
            float leafSway = sin(time * 1.2 + fi * 2.0 + fj) * 0.03;
            float leaf = smoothstep(0.08, 0.0, abs(uv.x - x - sway * (1.0 - leafY) - leafSway - 0.05 * (1.0 - uv.y - leafY)));
            stem += leaf * 0.5;
        }
        
        p += stem * smoothstep(0.0, 0.2, uv.y) * smoothstep(1.0, 0.8, uv.y);
    }
    
    return p;
}

// Final composition with color grading
void main() {
    vec2 uv = fragCoord.xy / u_resolution.xy;
    vec2 aspect = vec2(u_resolution.x / u_resolution.y, 1.0);
    uv = (uv - 0.5) * aspect + 0.5;
    
    float time = u_time;
    
    // Layer effects
    float causticsVal = caustics(uv, time);
    float godRaysVal = godRays(uv, time);
    float bubblesVal = bubbles(uv, time);
    float plantsVal = plants(uv, time);
    
    // Underwater color palette
    vec3 deepBlue = vec3(0.02, 0.1, 0.3);
    vec3 midBlue = vec3(0.05, 0.2, 0.4);
    vec3 surfaceLight = vec3(0.4, 0.6, 0.8);
    
    // Gradient based on vertical position
    vec3 bg = mix(deepBlue, midBlue, smoothstep(0.0, 0.5, uv.y));
    bg = mix(bg, surfaceLight, smoothstep(0.5, 1.0, uv.y));
    
    // Apply effects
    bg += vec3(causticsVal * 0.3, causticsVal * 0.5, causticsVal * 0.7);
    bg += vec3(godRaysVal * 0.2, godRaysVal * 0.3, godRaysVal * 0.4);
    bg += vec3(bubblesVal * 0.5);
    bg += vec3(0.1, 0.3, 0.2) * plantsVal;
    
    fragColor = vec4(bg, 1.0);
}