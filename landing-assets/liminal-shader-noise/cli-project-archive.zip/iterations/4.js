<think>
The user wants a GLSL fragment shader featuring concentric circles and color gradients. This is a classic shader programming exercise that can be made visually interesting with smooth color transitions and animated effects.

Let me create a shader that:
1. Uses concentric circles based on distance from center
2. Has beautiful color gradients
3. Includes animation using u_time
4. Optionally responds to mouse input
5. Uses smooth transitions between colors

I'll create something visually appealing with:
- Multiple concentric rings with varying thickness
- Smooth color gradients cycling through the color spectrum
- Animation based on time
- Optional mouse interaction for additional effects

Let me write this as a single fragment shader without any wrapping or markdown.
</think>

precision highp float;

uniform vec2 u_resolution;
uniform float u_time;
uniform vec2 u_mouse;

#define PI 3.14159265359
#define TAU 6.28318530718

// Smooth noise function
float hash(vec2 p) {
    return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
}

float noise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    
    float a = hash(i);
    float b = hash(i + vec2(1.0, 0.0));
    float c = hash(i + vec2(0.0, 1.0));
    float d = hash(i + vec2(1.0, 1.0));
    
    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}

// HSV to RGB conversion
vec3 hsv2rgb(vec3 c) {
    vec4 K = vec4(1.0, 2.0 / 3.0, 1.0 / 3.0, 3.0);
    vec3 p = abs(fract(c.xxx + K.xyz) * 6.0 - K.www);
    return c.z * mix(K.xxx, clamp(p - K.xxx, 0.0, 1.0), c.y);
}

// Concentric circle pattern with soft edges
float concentricCircles(vec2 uv, float numRings, float thickness, float offset) {
    float dist = length(uv);
    float rings = sin(dist * numRings * TAU + offset);
    return smoothstep(1.0 - thickness, 1.0, rings);
}

// Radial gradient
vec3 radialGradient(vec2 uv, vec3 innerColor, vec3 outerColor) {
    float dist = length(uv);
    return mix(innerColor, outerColor, dist);
}

// Angular gradient (conic)
vec3 angularGradient(vec2 uv, float time) {
    float angle = atan(uv.y, uv.x);
    float normalizedAngle = (angle + PI) / TAU;
    float hue = fract(normalizedAngle + time * 0.1);
    return hsv2rgb(vec3(hue, 0.8, 1.0));
}

void main() {
    vec2 uv = (gl_FragCoord.xy - 0.5 * u_resolution.xy) / min(u_resolution.x, u_resolution.y);
    vec2 center = vec2(0.0);
    
    float dist = length(uv);
    float angle = atan(uv.y, uv.x);
    
    // Animated time variables
    float t1 = u_time * 0.5;
    float t2 = u_time * 0.3;
    float t3 = u_time * 0.7;
    
    // Layer 1: Primary concentric circles with smooth animation
    float numRings1 = 8.0 + sin(t1) * 2.0;
    float thickness1 = 0.15 + sin(t2) * 0.05;
    float rings1 = concentricCircles(uv, numRings1, thickness1, t1 * 2.0);
    
    // Layer 2: Secondary concentric circles (different frequency)
    float numRings2 = 12.0 + cos(t2) * 3.0;
    float thickness2 = 0.1;
    float rings2 = concentricCircles(uv, numRings2, thickness2, -t2 * 1.5);
    
    // Layer 3: Finer concentric detail
    float numRings3 = 24.0;
    float thickness3 = 0.08;
    float rings3 = concentricCircles(uv, numRings3, thickness3, t3);
    
    // Color gradients based on distance
    float hue1 = fract(dist * 0.5 + t1 * 0.1);
    float hue2 = fract(dist * 0.3 + t2 * 0.15);
    float hue3 = fract(angle / TAU + t3 * 0.2);
    
    vec3 color1 = hsv2rgb(vec3(hue1, 0.7, 0.9));
    vec3 color2 = hsv2rgb(vec3(hue2 + 0.33, 0.8, 1.0));
    vec3 color3 = angularGradient(uv, t3);
    
    // Combine layers with different blend modes
    vec3 baseColor = radialGradient(uv, 
        hsv2rgb(vec3(t1 * 0.05, 0.3, 0.2)), 
        hsv2rgb(vec3(t1 * 0.05 + 0.5, 0.5, 0.3)));
    
    // Blend the ring layers
    vec3 finalColor = baseColor;
    finalColor = mix(finalColor, color1, rings1 * 0.6);
    finalColor = mix(finalColor, color2, rings2 * 0.4);
    finalColor = mix(finalColor, color3, rings3 * 0.25);
    
    // Add pulsing center glow
    float centerGlow = 1.0 - smoothstep(0.0, 0.3, dist);
    centerGlow *= 0.5 + 0.5 * sin(t1 * 3.0);
    vec3 glowColor = hsv2rgb(vec3(fract(t1 * 0.1), 0.5, 1.0));
    finalColor += glowColor * centerGlow * 0.4;
    
    // Add outer vignette
    float vignette = 1.0 - smoothstep(0.5, 1.2, dist);
    finalColor *= vignette;
    
    // Subtle noise overlay for texture
    float noiseVal = noise(uv * 20.0 + t1) * 0.05;
    finalColor += noiseVal;
    
    // Mouse interaction - create ripple effect
    if (u_mouse.x > 0.0 || u_mouse.y > 0.0) {
        vec2 mouseUV = u_mouse * 2.0 - 1.0;
        mouseUV.x *= u_resolution.x / u_resolution.y;
        float mouseDist = length(uv - mouseUV);
        float mouseRipple = sin(mouseDist * 30.0 - t1 * 5.0) * 0.5 + 0.5;
        mouseRipple *= smoothstep(0.5, 0.0, mouseDist);
        finalColor += vec3(0.2, 0.3, 0.4) * mouseRipple * 0.3;
    }
    
    // Ensure colors stay in valid range
    finalColor = clamp(finalColor, 0.0, 1.0);
    
    gl_FragColor = vec4(finalColor, 1.0);
}