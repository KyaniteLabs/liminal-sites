<think>
The user wants a creative fragment shader with noise patterns. Let me create an interesting visual shader using various noise techniques like value noise, fractal noise, and perhaps some layered effects.

I'll create something visually interesting with:
1. Multiple noise functions (value noise, gradient noise)
2. Fractal Brownian motion for natural-looking patterns
3. Smooth color gradients based on noise
4. Time-based animation for dynamic movement
5. Mouse interaction for interactivity

Let me design something creative and visually appealing.
</think>

precision highp float;

#define PI 3.14159265359
#define TAU 6.28318530718
#define NOISE_ITERATIONS 5

uniform vec2 u_resolution;
uniform float u_time;
uniform vec2 u_mouse;

float hash(vec2 p) {
    p = fract(p * vec2(123.34, 456.21));
    p += dot(p, p + 45.32);
    return fract(p.x * p.y);
}

float hash3(vec3 p) {
    p = fract(p * vec3(123.34, 456.21, 789.63));
    p += dot(p, p + 45.32);
    return fract(p.x * p.y * p.z);
}

float valueNoise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    vec2 u = f * f * (3.0 - 2.0 * f);
    
    float a = hash(i);
    float b = hash(i + vec2(1.0, 0.0));
    float c = hash(i + vec2(0.0, 1.0));
    float d = hash(i + vec2(1.0, 1.0));
    
    return mix(mix(a, b, u.x), mix(c, d, u.x), u.y);
}

float gradientNoise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    vec2 u = f * f * (3.0 - 2.0 * f);
    
    float n00 = hash(i) * TAU;
    float n10 = hash(i + vec2(1.0, 0.0)) * TAU;
    float n01 = hash(i + vec2(0.0, 1.0)) * TAU;
    float n11 = hash(i + vec2(1.0, 1.0)) * TAU;
    
    vec2 g00 = vec2(cos(n00), sin(n00));
    vec2 g10 = vec2(cos(n10), sin(n10));
    vec2 g01 = vec2(cos(n01), sin(n01));
    vec2 g11 = vec2(cos(n11), sin(n11));
    
    float v00 = dot(g00, f);
    float v10 = dot(g10, f - vec2(1.0, 0.0));
    float v01 = dot(g01, f - vec2(0.0, 1.0));
    float v11 = dot(g11, f - vec2(1.0, 1.0));
    
    return 0.5 + 0.5 * mix(mix(v00, v10, u.x), mix(v01, v11, u.x), u.y);
}

float simplexNoise(vec2 p) {
    const float K1 = 0.366025404;
    const float K2 = 0.211324865;
    
    vec2 i = floor(p + (p.x + p.y) * K1);
    vec2 a = p - i + (i.x + i.y) * K2;
    vec2 o = a.x > a.y ? vec2(1.0, 0.0) : vec2(0.0, 1.0);
    vec2 b = a - o + K2;
    vec2 c = a - 1.0 + 2.0 * K2;
    
    vec3 h = max(0.5 - vec3(dot(a, a), dot(b, b), dot(c, c)), 0.0);
    vec3 n = h * h * h * h * vec3(dot(a, vec2(cos(hash(i) * TAU), sin(hash(i) * TAU))),
                                   dot(b, vec2(cos(hash(i + o) * TAU), sin(hash(i + o) * TAU))),
                                   dot(c, vec2(cos(hash(i + 1.0) * TAU), sin(hash(i + 1.0) * TAU))));
    
    return dot(n, vec3(70.0));
}

float fbm(vec2 p, int octaves) {
    float value = 0.0;
    float amplitude = 0.5;
    float frequency = 1.0;
    float maxValue = 0.0;
    
    for(int i = 0; i < NOISE_ITERATIONS; i++) {
        if(i >= octaves) break;
        value += amplitude * valueNoise(p * frequency);
        maxValue += amplitude;
        amplitude *= 0.5;
        frequency *= 2.0;
    }
    
    return value / maxValue;
}

float turbulence(vec2 p, int octaves) {
    float value = 0.0;
    float amplitude = 0.5;
    float frequency = 1.0;
    float maxValue = 0.0;
    
    for(int i = 0; i < NOISE_ITERATIONS; i++) {
        if(i >= octaves) break;
        value += amplitude * abs(valueNoise(p * frequency) * 2.0 - 1.0);
        maxValue += amplitude;
        amplitude *= 0.5;
        frequency *= 2.0;
    }
    
    return value / maxValue;
}

vec3 palette(float t, vec3 a, vec3 b, vec3 c, vec3 d) {
    return a + b * cos(TAU * (c * t + d));
}

vec3 domainWarp(vec2 p, float time) {
    vec2 q = vec2(
        fbm(p + vec2(0.0, 0.0), 4),
        fbm(p + vec2(5.2, 1.3), 4)
    );
    
    vec2 r = vec2(
        fbm(p + 4.0 * q + vec2(1.7, 9.2) + 0.15 * time, 4),
        fbm(p + 4.0 * q + vec2(8.3, 2.8) + 0.126 * time, 4)
    );
    
    float f = fbm(p + 4.0 * r, 6);
    
    return palette(f, vec3(0.5), vec3(0.5), vec3(1.0), vec3(0.0, 0.33, 0.67));
}

void main() {
    vec2 uv = (gl_FragCoord.xy - 0.5 * u_resolution.xy) / min(u_resolution.x, u_resolution.y);
    vec2 mouse = u_mouse - 0.5;
    
    float time = u_time * 0.3;
    vec2 p = uv * 3.0;
    
    float mouseInfluence = length(mouse) * 2.0;
    p += mouse * 0.5 * mouseInfluence;
    
    vec3 color = vec3(0.0);
    
    float mode = mod(floor(u_time * 0.1), 4.0);
    
    if(mode < 1.0) {
        float n1 = valueNoise(p * 4.0 + time);
        float n2 = fbm(p * 2.0 + time * 0.5, 6);
        float n3 = simplexNoise(p * 3.0 - time * 0.3);
        
        color = palette(n1 * n2, vec3(0.5), vec3(0.5), vec3(1.0), vec3(0.3, 0.2, 0.1));
        color *= 0.8 + 0.2 * n3;
        color += vec3(n1 * 0.2, n2 * 0.3, n3 * 0.4);
        
    } else if(mode < 2.0) {
        vec2 q = vec2(fbm(p, 5), fbm(p + vec2(10.0), 5));
        vec2 r = vec2(fbm(p + 4.0 * q + vec2(1.7, 9.2), 5),
                      fbm(p + 4.0 * q + vec2(8.3, 2.8), 5));
        
        float f = fbm(p + 4.0 * r, 7);
        
        color = palette(f, vec3(0.5), vec3(0.5), vec3(1.0, 1.0, 0.5), vec3(0.8, 0.9, 0.3));
        color = mix(color, vec3(1.0), f * f);
        
    } else if(mode < 3.0) {
        float t = turbulence(p * 2.0 + time, 6);
        float n = simplexNoise(p * 3.0 - time * 0.5);
        
        vec3 c1 = palette(t, vec3(0.5), vec3(0.5), vec3(2.0, 1.0, 0.0), vec3(0.5, 0.2, 0.25));
        vec3 c2 = palette(n, vec3(0.5), vec3(0.5), vec3(0.5, 1.0, 0.0), vec3(0.0, 0.25, 0.25));
        
        color = mix(c1, c2, t);
        
        float wave = sin(p.x * 10.0 + time * 2.0) * 0.5 + 0.5;
        color = mix(color, color.brg, wave * 0.3);
        
    } else {
        float n1 = gradientNoise(p * 4.0 + time);
        float n2 = valueNoise(p * 8.0 - time * 0.7);
        float n3 = fbm(p * 2.0 + vec2(sin(time), cos(time)) * 0.5, 5);
        
        vec3 c1 = palette(n1, vec3(0.5), vec3(0.5), vec3(1.0, 0.7, 0.4), vec3(0.0, 0.15, 0.2));
        vec3 c2 = palette(n2, vec3(0.5), vec3(0.5), vec3(0.5, 0.2, 1.0), vec3(0.3, 0.0, 0.0));
        vec3 c3 = palette(n3, vec3(0.5), vec3(0.5), vec3(0.0, 0.7, 0.9), vec3(0.2, 0.0, 0.5));
        
        color = mix(c1, c2, n2);
        color = mix(color, c3, n3 * 0.5);
        
        float ripple = sin(length(p) * 20.0 - time * 5.0) * 0.5 + 0.5;
        color += ripple * 0.1 * n1;
    }
    
    float vignette = 1.0 - length(uv) * 0.5;
    color *= vignette;
    
    color = pow(color, vec3(0.9));
    color = mix(color, vec3(dot(color, vec3(0.299, 0.587, 0.114))), -0.2);
    
    gl_FragColor = vec4(color, 1.0);
}