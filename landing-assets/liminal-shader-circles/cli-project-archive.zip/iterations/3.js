<think>
The user wants a creative GLSL fragment shader with concentric circles and color gradients. Let me design something visually appealing that incorporates:

1. Concentric circles with smooth edges
2. Color gradients that evolve over time
3. Mouse interaction for interactivity
4. Smooth animation using u_time
5. A cohesive color palette

I'll create a shader that:
- Uses distance fields to create circles
- Applies smooth color gradients based on distance and time
- Has subtle animation and mouse interaction
- Uses a nice color palette (maybe a vibrant gradient)

Let me write this as a single GLSL fragment shader with proper uniforms and animation.
</think>

precision highp float;

#define PI 3.14159265359
#define TWO_PI 6.28318530718

uniform vec2 u_resolution;
uniform float u_time;
uniform vec2 u_mouse;

float sdCircle(vec2 p, float r) {
    return length(p) - r;
}

float sdRing(vec2 p, float r, float thickness) {
    float d = abs(length(p) - r);
    return d - thickness * 0.5;
}

vec3 hsv2rgb(vec3 c) {
    vec4 K = vec4(1.0, 2.0 / 3.0, 1.0 / 3.0, 3.0);
    vec3 p = abs(fract(c.xxx + K.xyz) * 6.0 - K.www);
    return c.z * mix(K.xxx, clamp(p - K.xxx, 0.0, 1.0), c.y);
}

float easeInOut(float t) {
    return t < 0.5 ? 2.0 * t * t : -1.0 + (4.0 - 2.0 * t) * t;
}

void main() {
    vec2 uv = (gl_FragCoord.xy - 0.5 * u_resolution.xy) / min(u_resolution.x, u_resolution.y);
    vec2 mouse = (u_mouse - 0.5) * 2.0;
    
    float time = u_time * 0.3;
    
    vec3 color = vec3(0.0);
    
    float numRings = 12.0;
    float maxRadius = 0.9;
    
    for (float i = 0.0; i < 12.0; i++) {
        if (i >= numRings) break;
        
        float t = i / numRings;
        
        float baseRadius = t * maxRadius;
        float radius = baseRadius + sin(time * 2.0 + i * 0.5) * 0.02;
        
        float ringThickness = 0.015 + 0.01 * sin(time + i * 1.2);
        
        float d = sdRing(uv, radius, ringThickness);
        
        float ringMask = 1.0 - smoothstep(0.0, 0.008, abs(d));
        
        float hue = t + time * 0.1 + sin(uv.x * 3.0 + time) * 0.1;
        float sat = 0.7 + 0.3 * sin(time * 0.5 + i);
        float val = 0.8 + 0.2 * cos(time + i * 0.7);
        
        vec3 ringColor = hsv2rgb(vec3(hue, sat, val));
        
        float pulse = 0.5 + 0.5 * sin(time * 3.0 + i * 0.8);
        ringColor *= 0.6 + 0.4 * pulse;
        
        color += ringColor * ringMask;
    }
    
    float centerDist = length(uv);
    vec3 bgGradient = hsv2rgb(vec3(time * 0.05, 0.4, 0.1 - centerDist * 0.1));
    color += bgGradient * (1.0 - length(color));
    
    float dotPattern = 0.0;
    for (float i = 0.0; i < 8.0; i++) {
        if (i >= numRings) break;
        float angle = i * (TWO_PI / numRings) + time * 0.2;
        float r = (i / numRings) * maxRadius * 0.95;
        vec2 dotPos = vec2(cos(angle), sin(angle)) * r;
        float dotDist = length(uv - dotPos);
        float dotSize = 0.008 + 0.005 * sin(time * 2.0 + i);
        dotPattern += smoothstep(dotSize, dotSize * 0.5, dotDist) * 0.3;
    }
    
    vec3 dotColor = hsv2rgb(vec3(time * 0.15 + 0.5, 0.8, 1.0));
    color += dotColor * dotPattern;
    
    vec2 mouseOffset = uv - mouse * 0.5;
    float mouseRing = abs(length(mouseOffset) - 0.3 + sin(time * 4.0) * 0.05);
    float mouseRingMask = 1.0 - smoothstep(0.0, 0.006, mouseRing);
    vec3 mouseColor = hsv2rgb(vec3(time * 0.2 + 0.8, 0.9, 0.7));
    color = mix(color, mouseColor, mouseRingMask * 0.6);
    
    float centerGlow = 1.0 - smoothstep(0.0, 0.15, length(uv));
    vec3 centerColor = hsv2rgb(vec3(time * 0.1, 0.5, 1.0));
    color += centerColor * centerGlow * 0.3;
    
    float scanline = sin(uv.y * 200.0 + time * 5.0) * 0.03;
    color += scanline;
    
    color = pow(color, vec3(0.9));
    
    color = clamp(color, 0.0, 1.0);
    
    gl_FragColor = vec4(color, 1.0);
}