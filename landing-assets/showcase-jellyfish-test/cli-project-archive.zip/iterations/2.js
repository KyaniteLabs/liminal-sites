let jellyfish = [];
let time = 0;
const NUM_JELLYFISH = 5;
const TENTACLES_PER_JELLYFISH = 12;

class Tentacle {
  constructor(x, y, length, hue, noiseOffset) {
    this.baseX = x;
    this.baseY = y;
    this.length = length;
    this.hue = hue;
    this.noiseOffset = noiseOffset;
    this.segments = 20;
  }
  
  update(time) {
    this.points = [];
    let x = this.baseX;
    let y = this.baseY;
    
    for (let i = 0; i < this.segments; i++) {
      let t = i / this.segments;
      let noiseVal = noise(
        this.noiseOffset + t * 2,
        time * 0.3 + i * 0.1
      );
      let wave = map(noiseVal, 0, 1, -30, 30);
      
      let segmentLength = this.length / this.segments;
      x += cos(HALF_PI + wave * 0.1) * segmentLength;
      y += sin(HALF_PI + wave * 0.1) * segmentLength + 0.5;
      
      this.points.push({x, y});
    }
  }
  
  draw() {
    noFill();
    for (let i = 1; i < this.points.length; i++) {
      let t = i / this.points.length;
      let alpha = map(t, 0, 1, 100, 20);
      let strokeWeight = map(t, 0, 1, 3, 0.5);
      
      stroke(this.hue, 150, 255, alpha);
      strokeWeight(strokeWeight);
      line(this.points[i - 1].x, this.points[i - 1].y, this.points[i].x, this.points[i].y);
    }
  }
}