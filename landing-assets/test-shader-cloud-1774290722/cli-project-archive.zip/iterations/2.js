<think>
The user wants a colorful wave and distortion shader. I'll create a fragment shader with:

1. Colorful waves using sine functions with different frequencies and phases
2. Distortion effects using noise functions
3. Smooth animation with u_time
4. Colorful palette with hue variations
5. Some mouse interaction for additional dynamism

Let me create a visually striking shader with:
- Multiple layered sine waves
- Distortion based on noise
- HSV/RGB color cycling
- Smooth transitions
- Normalized mouse input

I'll avoid:
- Texture lookups without fallback
- Unbounded loops
- Deprecated features that aren't necessary
- Magic numbers (using #defines)

Let me write this shader:
</think>

precision highp float;

#define PI 3.14159265359
#define TAU 6.28318530718

uniform vec2 u_resolution;
uniform float u_time;
uniform vec2 u_mouse;

float hash(vec2 p) {
    return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
}

float noise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    
    float a = hash(i);
    float b = hash(i + vec2(1.0, 0.0));
    float c = hash(i + vec2(0.0, 1.0));
    float d = hash(i + vec2(1.0, 1.0));
    
    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}

float fbm(vec2 p) {
    float value = 0.0;
    float amplitude = 0.5;
    for(int i = 0; i < 4; i++) {
        value += amplitude * noise(p);
        p *= 2.0;
        amplitude *= 0.5;
    }
    return value;
}

vec3 hsv2rgb(vec3 c) {
    vec4 K = vec4(1.0, 2.0 / 3.0, 1.0 / 3.0, 3.0);
    vec3 p = abs(fract(c.xxx + K.xyz) * 6.0 - K.www);
    return c.z * mix(K.xxx, clamp(p - K.xxx, 0.0, 1.0), c.y);
}

void main() {
    vec2 uv = (gl_FragCoord.xy - 0.5 * u_resolution.xy) / min(u_resolution.x, u_resolution.y);
    vec2 mouse = u_mouse;
    float time = u_time * 0.5;
    
    vec2 distortedUV = uv;
    
    float noiseVal = fbm(uv * 3.0 + time * 0.3);
    float distortionAmount = 0.15 + 0.1 * sin(time * 0.7);
    
    distortedUV.x += sin(uv.y * 8.0 + time * 1.5) * distortionAmount * noiseVal;
    distortedUV.y += cos(uv.x * 6.0 + time * 1.2) * distortionAmount * noiseVal;
    
    float wave1 = sin(distortedUV.x * 10.0 + time * 2.0) * 0.5 + 0.5;
    float wave2 = sin(distortedUV.y * 8.0 - time * 1.5) * 0.5 + 0.5;
    float wave3 = sin(length(distortedUV) * 12.0 - time * 2.5) * 0.5 + 0.5;
    
    float combinedWave = (wave1 + wave2 + wave3) / 3.0;
    
    float ripple = sin(length(distortedUV) * 15.0 - time * 3.0) * 0.5 + 0.5;
    ripple *= exp(-length(distortedUV) * 2.0);
    
    float hue = time * 0.1 + combinedWave * 0.3 + distortionAmount + noiseVal * 0.2;
    float saturation = 0.7 + 0.3 * sin(time + length(uv) * 5.0);
    float value = 0.6 + 0.4 * ripple;
    
    vec3 color1 = hsv2rgb(vec3(hue, saturation, value));
    vec3 color2 = hsv2rgb(vec3(hue + 0.3, saturation * 0.8, value * 0.9));
    vec3 color3 = hsv2rgb(vec3(hue + 0.6, saturation * 0.6, value * 0.8));
    
    float blendFactor1 = wave1 * (1.0 - abs(wave2 - 0.5) * 2.0);
    float blendFactor2 = wave2 * (1.0 - abs(wave3 - 0.5) * 2.0);
    float blendFactor3 = wave3 * (1.0 - abs(wave1 - 0.5) * 2.0);
    
    vec3 finalColor = color1 * blendFactor1 + color2 * blendFactor2 + color3 * blendFactor3;
    
    float glow = 0.5 + 0.5 * sin(time * 4.0 + uv.x * 10.0 + uv.y * 10.0);
    glow *= exp(-length(uv) * 1.5);
    finalColor += vec3(glow * 0.3, glow * 0.2, glow * 0.4);
    
    float mouseInfluence = smoothstep(0.3, 0.0, length(uv - (mouse - 0.5) * 2.0));
    finalColor += vec3(0.2, 0.3, 0.4) * mouseInfluence * sin(time * 5.0) * 0.5 + 0.5;
    
    float vignette = 1.0 - length(uv) * 0.5;
    finalColor *= vignette;
    
    finalColor = pow(finalColor, vec3(0.9));
    
    gl_FragColor = vec4(finalColor, 1.0);
}