<think>
The user wants a colorful wave shader with distortion effects. Let me create a visually appealing fragment shader with:

1. Multiple wave layers with different colors
2. Distortion effects using sine waves
3. Time-based animation
4. Smooth color gradients
5. Organic variation using noise

I'll create something with:
- Multiple colorful wave layers
- Horizontal and vertical distortion
- Rainbow/gradient colors
- Subtle noise for organic feel
- Smooth animation based on u_time

Let me write the shader code without any markdown fences or explanatory text.
</think>

precision highp float;

#define PI 3.14159265359
#define TAU 6.28318530718

uniform vec2 u_resolution;
uniform float u_time;
uniform vec2 u_mouse;

float hash(vec2 p) {
    return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
}

float noise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    
    float a = hash(i);
    float b = hash(i + vec2(1.0, 0.0));
    float c = hash(i + vec2(0.0, 1.0));
    float d = hash(i + vec2(1.0, 1.0));
    
    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}

float fbm(vec2 p) {
    float value = 0.0;
    float amplitude = 0.5;
    float frequency = 1.0;
    
    for(int i = 0; i < 4; i++) {
        value += amplitude * noise(p * frequency);
        amplitude *= 0.5;
        frequency *= 2.0;
    }
    return value;
}

vec3 hsv2rgb(vec3 c) {
    vec4 K = vec4(1.0, 2.0 / 3.0, 1.0 / 3.0, 3.0);
    vec3 p = abs(fract(c.xxx + K.xyz) * 6.0 - K.www);
    return c.z * mix(K.xxx, clamp(p - K.xxx, 0.0, 1.0), c.y);
}

void main() {
    vec2 uv = gl_FragCoord.xy / u_resolution.xy;
    vec2 aspect = vec2(u_resolution.x / u_resolution.y, 1.0);
    vec2 st = uv * aspect;
    
    float t = u_time * 0.8;
    
    vec2 distortion = vec2(
        sin(uv.y * 8.0 + t * 1.2) * 0.03,
        cos(uv.x * 6.0 + t * 0.9) * 0.03
    );
    
    distortion += vec2(
        sin(uv.y * 15.0 + t * 2.0) * 0.01,
        cos(uv.x * 12.0 + t * 1.5) * 0.01
    );
    
    float n = fbm(uv * 3.0 + t * 0.3) * 0.05;
    distortion += vec2(n, n * 0.7);
    
    vec2 distortedUV = uv + distortion;
    
    float wave1 = sin(distortedUV.x * 8.0 + t * 1.5) * 0.5 + 0.5;
    wave1 = smoothstep(0.3, 0.7, wave1);
    
    float wave2 = sin(distortedUV.x * 12.0 - t * 1.8 + cos(distortedUV.y * 4.0) * 2.0) * 0.5 + 0.5;
    wave2 = smoothstep(0.35, 0.65, wave2);
    
    float wave3 = sin(distortedUV.x * 5.0 + t * 1.2 + sin(distortedUV.y * 6.0 + t * 0.7) * 2.0) * 0.5 + 0.5;
    wave3 = smoothstep(0.4, 0.6, wave3);
    
    float wave4 = cos(distortedUV.x * 20.0 - t * 2.5) * 0.5 + 0.5;
    wave4 *= sin(distortedUV.y * 15.0 + t * 1.8) * 0.5 + 0.5;
    wave4 = smoothstep(0.45, 0.55, wave4);
    
    vec3 color1 = hsv2rgb(vec3(fract(uv.x * 0.5 + t * 0.1), 0.8, 1.0));
    vec3 color2 = hsv2rgb(vec3(fract(uv.y * 0.7 + t * 0.15 + 0.3), 0.85, 1.0));
    vec3 color3 = hsv2rgb(vec3(fract((uv.x + uv.y) * 0.3 + t * 0.12 + 0.6), 0.9, 1.0));
    vec3 color4 = hsv2rgb(vec3(fract(distortedUV.x * 0.4 - t * 0.08 + 0.15), 0.75, 1.0));
    
    vec3 bgColor = hsv2rgb(vec3(fract(t * 0.05), 0.6, 0.15));
    bgColor += vec3(0.05, 0.02, 0.1) * (1.0 - uv.y);
    
    vec3 finalColor = bgColor;
    
    finalColor = mix(finalColor, color1, wave1 * 0.7);
    finalColor = mix(finalColor, color2, wave2 * 0.6);
    finalColor = mix(finalColor, color3, wave3 * 0.5);
    finalColor = mix(finalColor, color4, wave4 * 0.4);
    
    float glow1 = exp(-abs(distortedUV.y - 0.5 - sin(distortedUV.x * 8.0 + t * 1.5) * 0.2) * 8.0);
    vec3 glowColor1 = hsv2rgb(vec3(fract(distortedUV.x * 0.3 + t * 0.1), 0.5, 1.0));
    finalColor += glowColor1 * glow1 * 0.3;
    
    float glow2 = exp(-abs(distortedUV.y - 0.5 - cos(distortedUV.x * 12.0 - t * 1.8) * 0.15) * 10.0);
    vec3 glowColor2 = hsv2rgb(vec3(fract(distortedUV.x * 0.4 - t * 0.12 + 0.5), 0.5, 1.0));
    finalColor += glowColor2 * glow2 * 0.25;
    
    float ripple = sin(length(uv - 0.5) * 30.0 - t * 3.0) * 0.5 + 0.5;
    ripple *= exp(-length(uv - 0.5) * 2.0);
    finalColor += vec3(ripple * 0.1, ripple * 0.05, ripple * 0.15);
    
    float scanline = sin(uv.y * u_resolution.y * 1.5) * 0.02;
    finalColor += scanline;
    
    float vignette = 1.0 - length((uv - 0.5) * 1.2);
    vignette = smoothstep(0.0, 0.7, vignette);
    finalColor *= vignette;
    
    finalColor = pow(finalColor, vec3(0.95));
    finalColor = clamp(finalColor, 0.0, 1.0);
    
    gl_FragColor = vec4(finalColor, 1.0);
}