let noiseScale = 0.003;
let noiseStrength = 150;
let hueOffset = 0;
let curves = [];
let numCurves = 12;

function setup() {
  createCanvas(800, 600);
  colorMode(HSB, 360, 100, 100, 100);
  pixelDensity(1);
  
  for (let i = 0; i < numCurves; i++) {
    curves.push({
      offset: i * (360 / numCurves),
      noiseOffset: random(1000),
      thickness: map(i, 0, numCurves, 2, 6),
      alpha: map(i, 0, numCurves, 80, 40)
    });
  }
}

function draw() {
  background(0, 0, 5);
  
  hueOffset += 0.5;
  
  let mx = mouseX;
  let my = mouseY;
  
  for (let c = 0; c < curves.length; c++) {
    let curve = curves[c];
    let baseHue = (hueOffset + curve.offset) % 360;
    
    stroke(baseHue, 70, 90, curve.alpha);
    strokeWeight(curve.thickness);
    noFill();
    
    beginShape();
    for (let t = 0; t <= 1; t += 0.02) {
      let x = noise(t * noiseScale + curve.noiseOffset) * width;
      let y = noise(t * noiseScale + curve.noiseOffset + 1000) * height;
      curve(x, y, t, mx, my, baseHue, curve.thickness);
    }
    endShape();
  }
}

function curve(x, y, t, mx, my, hue, weight) {
  let n = noise(x * 0.005, y * 0.005, frameCount * 0.01);
  
  let px = x + (mx - width/2) * n * 0.3;
  let py = y + (my - height/2) * n * 0.3;
  
  stroke(hue, 70, 90, 100);
  strokeWeight(weight);
  point(px, py);
}