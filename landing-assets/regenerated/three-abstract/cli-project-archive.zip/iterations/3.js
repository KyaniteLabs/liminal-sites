<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Abstract Geometric Sculpture</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            overflow: hidden;
            background: #0a0a0a;
        }
        canvas {
            display: block;
        }
    </style>
</head>
<body>
    <script type="importmap">{"imports":{"three":"https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.module.js","three/addons/":"https://cdn.jsdelivr.net/npm/three@0.160.0/examples/jsm/"}}</script>
    <script type="module">
        import * as THREE from 'three';
        import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
        import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
        import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
        import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js';

        let scene, camera, renderer, controls, composer;
        let sculpture, particles;
        const clock = new THREE.Clock();

        init();
        animate();

        function init() {
            scene = new THREE.Scene();
            scene.background = new THREE.Color(0x0a0a0a);
            scene.fog = new THREE.FogExp2(0x0a0a0a, 0.02);

            camera = new THREE.PerspectiveCamera(60, window.innerWidth / window.innerHeight, 0.1, 1000);
            camera.position.set(0, 3, 8);

            renderer = new THREE.WebGLRenderer({ antialias: true });
            renderer.setSize(window.innerWidth, window.innerHeight);
            renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
            renderer.toneMapping = THREE.ACESFilmicToneMapping;
            renderer.toneMappingExposure = 1.2;
            document.body.appendChild(renderer.domElement);

            controls = new OrbitControls(camera, renderer.domElement);
            controls.enableDamping = true;
            controls.dampingFactor = 0.05;
            controls.minDistance = 4;
            controls.maxDistance = 20;
            controls.autoRotate = true;
            controls.autoRotateSpeed = 0.5;

            setupLighting();
            createSculpture();
            createParticles();
            setupPostProcessing();

            window.addEventListener('resize', onWindowResize);
        }

        function setupLighting() {
            const ambientLight = new THREE.AmbientLight(0x222233, 0.5);
            scene.add(ambientLight);

            const mainLight = new THREE.DirectionalLight(0xffffff, 1);
            mainLight.position.set(5, 10, 5);
            scene.add(mainLight);

            const pointLight1 = new THREE.PointLight(0xff00ff, 2, 20);
            pointLight1.position.set(-5, 5, 3);
            scene.add(pointLight1);

            const pointLight2 = new THREE.PointLight(0x00ffff, 2, 20);
            pointLight2.position.set(5, 3, -5);
            scene.add(pointLight2);

            const pointLight3 = new THREE.PointLight(0xffff00, 1.5, 15);
            pointLight3.position.set(0, -3, 5);
            scene.add(pointLight3);
        }

        function createIridescentMaterial(color) {
            return new THREE.MeshPhysicalMaterial({
                color: color,
                metalness: 0.9,
                roughness: 0.1,
                clearcoat: 1.0,
                clearcoatRoughness: 0.1,
                iridescence: 1.0,
                iridescenceIOR: 1.5,
                iridescenceThicknessRange: [100, 400],
                reflectivity: 1,
                envMapIntensity: 1.5,
                transparent: true,
                opacity: 0.9
            });
        }

        function createSculpture() {
            sculpture = new THREE.Group();

            const torusKnot = new THREE.TorusKnotGeometry(1.2, 0.3, 128, 32);
            const torusKnotMesh = new THREE.Mesh(torusKnot, createIridescentMaterial(0xff3366));
            sculpture.add(torusKnotMesh);

            const octahedron = new THREE.OctahedronGeometry(0.6, 0);
            const octahedronMesh = new THREE.Mesh(octahedron, createIridescentMaterial(0x33ff99));
            octahedronMesh.position.set(2, 1.5, 0);
            sculpture.add(octahedronMesh);

            const icosahedron = new THREE.IcosahedronGeometry(0.5, 0);
            const icosahedronMesh = new THREE.Mesh(icosahedron, createIridescentMaterial(0x3399ff));
            icosahedronMesh.position.set(-2, 1, 0.5);
            sculpture.add(icosahedronMesh);

            const dodecahedron = new THREE.DodecahedronGeometry(0.4, 0);
            const dodecahedronMesh = new THREE.Mesh(dodecahedron, createIridescentMaterial(0xffff33));
            dodecahedronMesh.position.set(0, 2, 1.5);
            sculpture.add(dodecahedronMesh);

            const torus = new THREE.TorusGeometry(0.8, 0.2, 16, 48);
            const torusMesh = new THREE.Mesh(torus, createIridescentMaterial(0xff9933));
            torusMesh.position.set(-1.5, -0.5, -1);
            torusMesh.rotation.x = Math.PI / 3;
            sculpture.add(torusMesh);

            const cone = new THREE.ConeGeometry(0.4, 1, 6, 1);
            const coneMesh = new THREE.Mesh(cone, createIridescentMaterial(0x9933ff));
            coneMesh.position.set(1.5, -1, 1);
            sculpture.add(coneMesh);

            const sphere = new THREE.SphereGeometry(0.35, 32, 32);
            const sphereMesh = new THREE.Mesh(sphere, createIridescentMaterial(0xff3399));
            sphereMesh.position.set(-1, -1.5, 1);
            sculpture.add(sphereMesh);

            const box = new THREE.BoxGeometry(0.5, 0.5, 0.5);
            const boxMesh = new THREE.Mesh(box, createIridescentMaterial(0x33ffff));
            boxMesh.position.set(1, 0, -1.5);
            boxMesh.rotation.set(Math.PI / 4, Math.PI / 4, 0);
            sculpture.add(boxMesh);

            const ring = new THREE.TorusGeometry(0.6, 0.15, 16, 32);
            const ringMesh = new THREE.Mesh(ring, createIridescentMaterial(0x66ff33));
            ringMesh.position.set(0, -2, 0);
            sculpture.add(ringMesh);

            const tetrahedron = new THREE.TetrahedronGeometry(0.5, 0);
            const tetrahedronMesh = new THREE.Mesh(tetrahedron, createIridescentMaterial(0xff6699));
            tetrahedronMesh.position.set(-1.5, 0.5, -1.5);
            sculpture.add(tetrahedronMesh);

            scene.add(sculpture);
        }

        function createParticles() {
            const particleCount = 500;
            const positions = new Float32Array(particleCount * 3);
            const colors = new Float32Array(particleCount * 3);

            const colorPalette = [
                new THREE.Color(0xff3366),
                new THREE.Color(0x33ff99),
                new THREE.Color(0x3399ff),
                new THREE.Color(0xffff33),
                new THREE.Color(0xff9933),
                new THREE.Color(0x9933ff)
            ];

            for (let i = 0; i < particleCount; i++) {
                positions[i * 3] = (Math.random() - 0.5) * 30;
                positions[i * 3 + 1] = (Math.random() - 0.5) * 30;
                positions[i * 3 + 2] = (Math.random() - 0.5) * 30;

                const color = colorPalette[Math.floor(Math.random() * colorPalette.length)];
                colors[i * 3] = color.r;
                colors[i * 3 + 1] = color.g;
                colors[i * 3 + 2] = color.b;
            }

            const geometry = new THREE.BufferGeometry();
            geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
            geometry.setAttribute('color', new THREE.BufferAttribute(colors, 3));

            const material = new THREE.PointsMaterial({
                size: 0.05,
                vertexColors: true,
                transparent: true,
                opacity: 0.6,
                blending: THREE.AdditiveBlending
            });

            particles = new THREE.Points(geometry, material);
            scene.add(particles);
        }

        function setupPostProcessing() {
            composer = new EffectComposer(renderer);

            const renderPass = new RenderPass(scene, camera);
            composer.addPass(renderPass);

            const bloomPass = new UnrealBloomPass(
                new THREE.Vector2(window.innerWidth, window.innerHeight),
                0.8,
                0.4,
                0.85
            );
            composer.addPass(bloomPass);
        }

        function onWindowResize() {
            camera.aspect = window.innerWidth / window.innerHeight;
            camera.updateProjectionMatrix();
            renderer.setSize(window.innerWidth, window.innerHeight);
            composer.setSize(window.innerWidth, window.innerHeight);
        }

        function animate() {
            requestAnimationFrame(animate);

            const elapsedTime = clock.getElapsedTime();

            if (sculpture) {
                sculpture.rotation.y = elapsedTime * 0.2;
                sculpture.rotation.x = Math.sin(elapsedTime * 0.3) * 0.1;

                sculpture.children.forEach((child, index) => {
                    if (child.geometry.type === 'TorusKnotGeometry') {
                        child.rotation.z = elapsedTime * 0.5;
                    } else {
                        child.position.y += Math.sin(elapsedTime * 2 + index) * 0.001;
                        child.rotation.x += 0.005;
                        child.rotation.y += 0.008;
                    }
                });
            }

            if (particles) {
                particles.rotation.y = elapsedTime * 0.02;
                particles.rotation.x = elapsedTime * 0.01;
            }

            controls.update();
            composer.render();
        }
    </script>
</body>
</html>