precision highp float;

#define MAX_STEPS 80
#define MAX_DIST 100.0
#define SURF_DIST 0.01
#define PI 3.14159265359

uniform vec2 u_resolution;
uniform float u_time;
uniform vec2 u_mouse;

mat2 rot2D(float a) {
    float s = sin(a), c = cos(a);
    return mat2(c, -s, s, c);
}

float hash(vec2 p) {
    return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
}

float noise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    float a = hash(i);
    float b = hash(i + vec2(1.0, 0.0));
    float c = hash(i + vec2(0.0, 1.0));
    float d = hash(i + vec2(1.0, 1.0));
    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}

float fbm(vec2 p) {
    float v = 0.0, a = 0.5;
    for (int i = 0; i < 5; i++) {
        v += a * noise(p);
        p *= 2.0;
        a *= 0.5;
    }
    return v;
}

float terrain(vec2 p) {
    float h = 0.0;
    h += fbm(p * 0.3) * 2.5;
    h += fbm(p * 0.8) * 0.8;
    h += fbm(p * 2.0) * 0.3;
    
    vec2 q = p * 1.5;
    for (int i = 0; i < 3; i++) {
        q = abs(q) / dot(q, q) - vec2(1.2);
        h += sin(q.x * 2.0 + q.y) * 0.15;
    }
    
    return h - 2.5;
}

float map(vec3 p) {
    return p.y - terrain(p.xz);
}

vec3 getNormal(vec3 p) {
    vec2 e = vec2(0.01, 0.0);
    return normalize(vec3(
        map(p + e.xyy) - map(p - e.xyy),
        map(p + e.yxy) - map(p - e.yxy),
        map(p + e.yyx) - map(p - e.yyx)
    ));
}

float raymarch(vec3 ro, vec3 rd) {
    float t = 0.0;
    for (int i = 0; i < MAX_STEPS; i++) {
        vec3 p = ro + rd * t;
        float d = map(p);
        if (d < SURF_DIST) return t;
        if (t > MAX_DIST) break;
        t += d * 0.5;
    }
    return MAX_DIST;
}

float shadow(vec3 ro, vec3 rd, float mint, float maxt) {
    float t = mint;
    float res = 1.0;
    for (int i = 0; i < 32; i++) {
        if (t > maxt) break;
        float h = map(ro + rd * t);
        res = min(res, 8.0 * h / t);
        if (res < 0.001) return 0.0;
        t += h * 0.5;
    }
    return clamp(res, 0.0, 1.0);
}

float fogDensity(vec3 p) {
    float h = max(0.0, p.y + 1.0);
    float base = exp(-h * 0.5) * 0.5;
    
    float time = u_time * 0.2;
    vec3 wp = p;
    wp.xz *= 0.3;
    wp.x += time * 0.5;
    
    float n = fbm(wp.xz * 0.5 + time * 0.1) * 0.5;
    n += fbm(wp.xz * 1.0 - time * 0.15) * 0.3;
    
    float valley = smoothstep(0.0, 2.0, -p.y);
    
    return (base + n * 0.4) * (0.5 + valley * 0.5);
}

vec4 volumetricFog(vec3 ro, vec3 rd, float tMax, vec3 fogColor) {
    vec4 sum = vec4(0.0);
    float t = 0.0;
    float stepSize = tMax / 32.0;
    
    for (int i = 0; i < 32; i++) {
        if (sum.a > 0.95) break;
        
        vec3 p = ro + rd * t;
        float d = fogDensity(p);
        
        float lightAmount = 1.0;
        vec3 lightDir = normalize(vec3(0.5, 0.8, 0.3));
        float lightDist = raymarch(p + lightDir * 0.1, lightDir);
        if (lightDist < MAX_DIST) lightAmount = 0.3;
        
        vec3 fc = fogColor * lightAmount;
        fc += vec3(0.3, 0.15, 0.05) * (1.0 - lightAmount);
        
        float alpha = d * stepSize * 2.0;
        alpha = clamp(alpha, 0.0, 0.5);
        
        sum.rgb += fc * alpha * (1.0 - sum.a);
        sum.a += alpha * (1.0 - sum.a);
        
        t += stepSize;
    }
    
    return sum;
}

vec3 getSky(vec3 rd) {
    vec3 skyBase = vec3(0.3, 0.15, 0.4);
    vec3 skyHorizon = vec3(0.8, 0.4, 0.3);
    
    float sun = pow(max(0.0, dot(rd, normalize(vec3(0.5, 0.4, 0.5)))), 32.0);
    float horizon = pow(1.0 - max(0.0, rd.y), 3.0);
    
    vec3 sky = mix(skyBase, skyHorizon, horizon);
    sky += vec3(1.0, 0.6, 0.2) * sun;
    
    return sky;
}

void main() {
    vec2 uv = (gl_FragCoord.xy - 0.5 * u_resolution.xy) / u_resolution.y;
    
    vec2 mouse = u_mouse / u_resolution;
    float camAngle = (mouse.x - 0.5) * PI * 0.5 + u_time * 0.1;
    float camHeight = 2.0 + sin(u_time * 0.3) * 0.5;
    
    vec3 ro = vec3(0.0, camHeight, -5.0);
    ro.xz *= rot2D(camAngle);
    
    vec3 target = vec3(0.0, 0.0, 0.0);
    vec3 forward = normalize(target - ro);
    vec3 right = normalize(cross(vec3(0.0, 1.0, 0.0), forward));
    vec3 up = cross(forward, right);
    
    vec3 rd = normalize(forward + uv.x * right + uv.y * up);
    
    float t = raymarch(ro, rd);
    vec3 col;
    
    if (t < MAX_DIST) {
        vec3 p = ro + rd * t;
        vec3 n = getNormal(p);
        
        vec3 lightDir = normalize(vec3(0.5, 0.8, 0.3));
        float diff = max(0.0, dot(n, lightDir));
        float amb = 0.3;
        
        float sha = shadow(p + n * 0.02, lightDir, 0.1, 20.0);
        
        vec3 terrainCol;
        float slope = 1.0 - n.y;
        vec3 lowland = vec3(0.15, 0.1, 0.08);
        vec3 highland = vec3(0.6, 0.55, 0.5);
        vec3 snow = vec3(0.9, 0.95, 1.0);
        vec3 rock = vec3(0.3, 0.25, 0.2);
        
        float height = p.y;
        terrainCol = mix(lowland, highland, smoothstep(-1.0, 1.0, height));
        terrainCol = mix(terrainCol, rock, smoothstep(0.3, 0.6, slope));
        terrainCol = mix(terrainCol, snow, smoothstep(1.5, 2.5, height));
        
        float moss = smoothstep(0.0, 0.5, height) * smoothstep(0.7, 0.3, slope);
        terrainCol = mix(terrainCol, vec3(0.1, 0.15, 0.05), moss * 0.5);
        
        col = terrainCol * (diff * sha + amb);
        
        float fogAmount = exp(-t * 0.08);
        vec3 fogColor = vec3(0.5, 0.3, 0.35);
        
        float sunGlow = pow(max(0.0, dot(rd, lightDir)), 8.0);
        fogColor += vec3(1.0, 0.5, 0.2) * sunGlow;
        
        col = mix(fogColor * 0.6, col, fogAmount);
        
        float fogHeight = exp(-max(0.0, p.y + 1.0) * 0.3);
        vec3 volumetricFogColor = volumetricFog(ro, rd, t, fogColor).rgb;
        col = mix(col, volumetricFogColor, 0.3 * fogHeight);
        
    } else {
        col = getSky(rd);
    }
    
    vec4 fog = volumetricFog(ro, rd, 50.0, vec3(0.5, 0.35, 0.4));
    col = mix(col, fog.rgb, fog.a * 0.7);
    
    col = pow(col, vec3(0.85));
    col = col * 1.2 - 0.1;
    col = clamp(col, 0.0, 1.0);
    
    vec2 q = gl_FragCoord.xy / u_resolution.xy;
    col *= 0.5 + 0.5 * pow(16.0 * q.x * q.y * (1.0 - q.x) * (1.0 - q.y), 0.2);
    
    gl_FragColor = vec4(col, 1.0);
}