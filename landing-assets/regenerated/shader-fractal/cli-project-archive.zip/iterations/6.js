precision highp float;

uniform vec2 u_resolution;
uniform float u_time;
uniform vec2 u_mouse;

#define MAX_STEPS 80
#define MAX_DIST 50.0
#define SURF_DIST 0.001
#define PI 3.14159265359

mat2 rot2D(float a) {
    float s = sin(a), c = cos(a);
    return mat2(c, -s, s, c);
}

float hash(float n) {
    return fract(sin(n) * 43758.5453);
}

float hash2(vec2 p) {
    return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
}

float noise(vec3 p) {
    vec3 i = floor(p);
    vec3 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    
    float n = i.x + i.y * 157.0 + 113.0 * i.z;
    return mix(
        mix(mix(hash(n + 0.0), hash(n + 1.0), f.x),
            mix(hash(n + 157.0), hash(n + 158.0), f.x), f.y),
        mix(mix(hash(n + 113.0), hash(n + 114.0), f.x),
            mix(hash(n + 270.0), hash(n + 271.0), f.x), f.y), f.z);
}

float fbm(vec3 p) {
    float f = 0.0;
    float amp = 0.5;
    float freq = 1.0;
    for(int i = 0; i < 5; i++) {
        f += amp * noise(p * freq);
        freq *= 2.0;
        amp *= 0.5;
    }
    return f;
}

float sdBox(vec3 p, vec3 b) {
    vec3 q = abs(p) - b;
    return length(max(q, 0.0)) + min(max(q.x, max(q.y, q.z)), 0.0);
}

float sdSphere(vec3 p, float r) {
    return length(p) - r;
}

float sdTerrain(vec3 p) {
    float terrain = p.y + 2.0;
    terrain += fbm(p * 0.3) * 2.0;
    terrain += fbm(p * 0.8) * 0.5;
    return terrain * 0.7;
}

float mandelbulbDE(vec3 p) {
    vec3 z = p;
    float dr = 1.0;
    float r = 0.0;
    float power = 8.0 + sin(u_time * 0.2) * 2.0;
    
    for(int i = 0; i < 8; i++) {
        r = length(z);
        if(r > 2.0) break;
        
        float theta = acos(z.z / r) + u_time * 0.1;
        float phi = atan(z.y, z.x) + u_time * 0.15;
        dr = pow(r, power - 1.0) * power * dr + 1.0;
        
        float zr = pow(r, power);
        z = zr * vec3(sin(theta * power) * cos(phi * power),
                      sin(theta * power) * sin(phi * power),
                      cos(theta * power));
        z += p;
    }
    return 0.5 * log(r) * r / dr;
}

float sdFractal(vec3 p) {
    vec3 z = p;
    float scale = 2.0;
    float offset = 1.0;
    float iter = 5.0;
    float d = 1e10;
    
    for(int i = 0; i < 6; i++) {
        z = abs(z) - offset;
        z.xy *= rot2D(0.785 + u_time * 0.1);
        z.yz *= rot2D(0.523);
        
        float r = length(z);
        float theta = atan(z.y, z.x);
        float phi = acos(z.z / r);
        
        float newR = pow(r, 1.3);
        z = newR * vec3(sin(theta), cos(theta), sin(phi + u_time * 0.2));
        
        d = min(d, sdSphere(z, 0.3));
    }
    
    return d;
}

float scene(vec3 p) {
    float terrain = sdTerrain(p);
    vec3 fractalPos = p - vec3(0.0, 1.0 + sin(u_time * 0.3) * 0.5, 0.0);
    fractalPos.xz *= rot2D(u_time * 0.2);
    float fractal = sdFractal(fractalPos);
    
    float mountains = p.y + 5.0 + fbm(p * 0.1 + vec3(0.0, 0.0, u_time * 0.1)) * 3.0;
    
    return min(min(terrain, fractal), mountains);
}

float volumetricFog(vec3 ro, vec3 rd, float maxDist) {
    float fogDensity = 0.0;
    float stepSize = maxDist / 32.0;
    float heightFalloff = 0.5;
    
    for(int i = 0; i < 32; i++) {
        float t = float(i) * stepSize;
        if(t > maxDist) break;
        
        vec3 p = ro + rd * t;
        
        float baseDensity = 0.02;
        float heightFactor = exp(-max(p.y + 2.0, 0.0) * heightFalloff);
        float noiseDensity = fbm(p * 0.3 + u_time * 0.1) * 0.02;
        
        float distFactor = exp(-t * 0.08);
        
        fogDensity += (baseDensity + noiseDensity) * heightFactor * distFactor * stepSize;
    }
    
    return 1.0 - exp(-fogDensity);
}

vec3 getNormal(vec3 p) {
    vec2 e = vec2(0.001, 0.0);
    return normalize(vec3(
        scene(p + e.xyy) - scene(p - e.xyy),
        scene(p + e.yxy) - scene(p - e.yxy),
        scene(p + e.yyx) - scene(p - e.yyx)
    ));
}

float softShadow(vec3 ro, vec3 rd, float mint, float maxt, float k) {
    float res = 1.0;
    float t = mint;
    for(int i = 0; i < 32; i++) {
        if(t > maxt) break;
        float h = scene(ro + rd * t);
        res = min(res, k * h / t);
        if(res < 0.001) break;
        t += clamp(h, 0.01, 0.5);
    }
    return clamp(res, 0.0, 1.0);
}

vec3 palette(float t) {
    vec3 a = vec3(0.5, 0.5, 0.5);
    vec3 b = vec3(0.5, 0.5, 0.5);
    vec3 c = vec3(1.0, 1.0, 1.0);
    vec3 d = vec3(0.263, 0.416, 0.557);
    return a + b * cos(6.28318 * (c * t + d));
}

vec3 getMaterial(vec3 p, vec3 n) {
    float terrain = sdTerrain(p);
    float terrainFactor = smoothstep(0.5, 0.0, terrain);
    
    vec3 terrainColor = mix(
        vec3(0.1, 0.3, 0.1),
        vec3(0.3, 0.5, 0.2),
        fbm(p * 2.0)
    );
    
    vec3 mountainColor = mix(
        vec3(0.4, 0.35, 0.3),
        vec3(0.6, 0.55, 0.5),
        noise(p * 0.5)
    );
    
    vec3 fractalColor = palette(length(p) * 0.1 + u_time * 0.05);
    
    float heightBlend = smoothstep(-3.0, 3.0, p.y);
    vec3 baseColor = mix(terrainColor, mountainColor, heightBlend);
    
    float snow = smoothstep(2.0, 4.0, p.y) * smoothstep(0.3, 0.5, noise(p * 3.0));
    baseColor = mix(baseColor, vec3(0.9, 0.95, 1.0), snow);
    
    return mix(baseColor, fractalColor, terrainFactor * 0.7);
}

float ambientOcclusion(vec3 p, vec3 n) {
    float occ = 0.0;
    float weight = 1.0;
    for(int i = 0; i < 5; i++) {
        float dist = 0.05 + 0.1 * float(i);
        float d = scene(p + n * dist);
        occ += (dist - d) * weight;
        weight *= 0.5;
    }
    return clamp(1.0 - 2.0 * occ, 0.0, 1.0);
}

vec3 lighting(vec3 p, vec3 n, vec3 rd, vec3 albedo) {
    vec3 lightDir = normalize(vec3(0.5, 0.8, 0.3));
    vec3 lightColor = vec3(1.0, 0.95, 0.8);
    
    float diff = max(dot(n, lightDir), 0.0);
    float shadow = softShadow(p + n * 0.01, lightDir, 0.1, 10.0, 16.0);
    
    vec3 halfDir = normalize(lightDir - rd);
    float spec = pow(max(dot(n, halfDir), 0.0), 32.0);
    
    float ao = ambientOcclusion(p, n);
    
    vec3 skyColor = vec3(0.3, 0.5, 0.8);
    float skyDiff = max(dot(n, vec3(0.0, 1.0, 0.0)), 0.0);
    
    vec3 rim = pow(1.0 - max(dot(n, -rd), 0.0), 3.0) * vec3(0.2, 0.3, 0.5);
    
    vec3 col = vec3(0.0);
    col += albedo * diff * shadow * lightColor;
    col += albedo * 0.1 * ao;
    col += albedo * skyDiff * 0.2 * skyColor * ao;
    col += spec * shadow * lightColor * 0.5;
    col += rim * 0.3;
    
    return col;
}

vec3 raymarch(vec3 ro, vec3 rd) {
    float t = 0.0;
    vec3 col = vec3(0.0);
    
    for(int i = 0; i < MAX_STEPS; i++) {
        vec3 p = ro + rd * t;
        float d = scene(p);
        
        if(d < SURF_DIST) {
            vec3 n = getNormal(p);
            vec3 albedo = getMaterial(p, n);
            col = lighting(p, n, rd, albedo);
            
            float fog = volumetricFog(ro, rd, t);
            vec3 fogColor = mix(
                vec3(0.5, 0.6, 0.8),
                vec3(0.8, 0.7, 0.5),
                smoothstep(0.0, 20.0, t)
            );
            col = mix(col, fogColor, fog * 0.6);
            break;
        }
        
        if(t > MAX_DIST) {
            vec3 skyColor = mix(
                vec3(0.2, 0.4, 0.8),
                vec3(0.8, 0.6, 0.3),
                pow(1.0 - max(rd.y, 0.0), 4.0)
            );
            
            float sun = pow(max(dot(rd, normalize(vec3(0.5, 0.8, 0.3))), 0.0), 64.0);
            skyColor += vec3(1.0, 0.8, 0.5) * sun;
            
            float stars = smoothstep(0.99, 1.0, noise(rd * 200.0));
            skyColor += vec3(stars) * smoothstep(0.5, 1.0, 1.0 - rd.y);
            
            col = skyColor;
            
            float fog = volumetricFog(ro, rd, MAX_DIST);
            vec3 fogColor = mix(vec3(0.5, 0.6, 0.8), vec3(0.8, 0.7, 0.5), 0.5);
            col = mix(col, fogColor, fog * 0.5);
            break;
        }
        
        t += d * 0.8;
    }
    
    return col;
}

void main() {
    vec2 uv = (gl_FragCoord.xy - 0.5 * u_resolution.xy) / u_resolution.y;
    vec2 mouse = u_mouse / u_resolution;
    
    float time = u_time * 0.3;
    
    vec3 ro = vec3(0.0, 3.0 + sin(time * 0.5) * 1.0, -8.0 + sin(time * 0.3) * 2.0);
    ro.xz *= rot2D(time * 0.2);
    
    if(u_mouse.x > 0.0 || u_mouse.y > 0.0) {
        float rotX = (mouse.y - 0.5) * PI;
        float rotY = (mouse.x - 0.5) * PI * 2.0;
        ro.yz *= rot2D(-rotX);
        ro.xz *= rot2D(-rotY);
    }
    
    vec3 lookAt = vec3(sin(time * 0.5) * 2.0, 0.0, cos(time * 0.3) * 2.0);
    vec3 forward = normalize(lookAt - ro);
    vec3 right = normalize(cross(vec3(0.0, 1.0, 0.0), forward));
    vec3 up = cross(forward, right);
    
    vec3 rd = normalize(forward + uv.x * right + uv.y * up);
    
    vec3 col = raymarch(ro, rd);
    
    col = col / (col + vec3(1.0));
    col = pow(col, vec3(0.8));
    
    col += (hash2(uv + u_time) - 0.5) * 0.02;
    
    gl_FragColor = vec4(col, 1.0);
}