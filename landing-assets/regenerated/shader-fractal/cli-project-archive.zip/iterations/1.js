precision highp float;

#define MAX_STEPS 100
#define MAX_DIST 50.0
#define SURF_DIST 0.001
#define FOG_STEPS 32
#define FOG_DENSITY 0.05

uniform vec2 u_resolution;
uniform float u_time;
uniform vec2 u_mouse;

float hash(float n) { return fract(sin(n) * 43758.5453123); }
float hash2(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }

float noise(vec3 p) {
    vec3 i = floor(p);
    vec3 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    float n = i.x + i.y * 57.0 + i.z * 113.0;
    return mix(
        mix(mix(hash(n), hash(n + 1.0), f.x),
            mix(hash(n + 57.0), hash(n + 58.0), f.x), f.y),
        mix(mix(hash(n + 113.0), hash(n + 114.0), f.x),
            mix(hash(n + 170.0), hash(n + 171.0), f.x), f.y), f.z);
}

float fbm(vec3 p) {
    float f = 0.0;
    float amp = 0.5;
    for(int i = 0; i < 5; i++) {
        f += amp * noise(p);
        p *= 2.01;
        amp *= 0.5;
    }
    return f;
}

float sdSphere(vec3 p, float r) { return length(p) - r; }

float sdBox(vec3 p, vec3 b) {
    vec3 d = abs(p) - b;
    return min(max(d.x, max(d.y, d.z)), 0.0) + length(max(d, 0.0));
}

float sdMenger(vec3 p) {
    float d = sdBox(p, vec3(1.0));
    float s = 1.0;
    for(int i = 0; i < 4; i++) {
        vec3 a = mod(p * s, 2.0) - 1.0;
        s *= 3.0;
        vec3 r = abs(1.0 - 3.0 * abs(a));
        float da = max(r.x, r.y);
        float db = max(r.y, r.z);
        float dc = max(r.z, r.x);
        float c = (min(da, min(db, dc)) - 1.0) / s;
        d = max(d, c);
    }
    return d;
}

float terrain(vec3 p) {
    float h = fbm(p * 0.5) * 2.0;
    h += fbm(p * 1.5) * 0.5;
    return p.y - h + 1.0;
}

float scene(vec3 p) {
    float t = terrain(p);
    float m = sdMenger(p * 0.3) * 3.33;
    vec3 sp = p - vec3(sin(u_time * 0.3) * 2.0, 1.0 + sin(u_time * 0.5) * 0.5, cos(u_time * 0.3) * 2.0);
    float s = sdSphere(sp, 0.8);
    return min(min(t, m * 0.7), s);
}

float rayMarch(vec3 ro, vec3 rd) {
    float d = 0.0;
    for(int i = 0; i < MAX_STEPS; i++) {
        vec3 p = ro + rd * d;
        float ds = scene(p);
        d += ds * 0.7;
        if(ds < SURF_DIST || d > MAX_DIST) break;
    }
    return d;
}

vec3 getNormal(vec3 p) {
    vec2 e = vec2(0.001, 0.0);
    return normalize(vec3(
        scene(p + e.xyy) - scene(p - e.xyy),
        scene(p + e.yxy) - scene(p - e.yxy),
        scene(p + e.yyx) - scene(p - e.yyx)
    ));
}

float softShadow(vec3 ro, vec3 rd, float mint, float maxt, float k) {
    float res = 1.0;
    float t = mint;
    for(int i = 0; i < 32; i++) {
        float h = scene(ro + rd * t);
        res = min(res, k * h / t);
        t += clamp(h, 0.02, 0.1);
        if(h < 0.001 || t > maxt) break;
    }
    return clamp(res, 0.0, 1.0);
}

float volumetricFog(vec3 ro, vec3 rd, float tmax) {
    float fog = 0.0;
    float stepSize = tmax / float(FOG_STEPS);
    float density = FOG_DENSITY;
    
    for(int i = 0; i < FOG_STEPS; i++) {
        float t = stepSize * float(i);
        vec3 p = ro + rd * t;
        
        float h = max(0.0, p.y + 1.0);
        float baseDensity = density * exp(-h * 0.5);
        
        float noiseVal = fbm(p * 0.8 + vec3(u_time * 0.1, 0.0, u_time * 0.05));
        float heightFade = exp(-h * 0.8);
        float localDensity = baseDensity * noiseVal * heightFade;
        
        fog += localDensity * stepSize;
    }
    
    return 1.0 - exp(-fog * 2.0);
}

vec3 getFogColor(vec3 rd, vec3 sunDir) {
    float sunAmount = max(dot(rd, sunDir), 0.0);
    floatv = vec3(0.5, 0.6, 0.7);
    vec3 fogColor = mix(baseFog, vec3(1.0, 0.9, 0.7), pow(sunAmount, 8.0));
    fogColor = mix(fogColor, vec3(1.0, 0.4, 0.2), pow(sunAmount, 32.0));
    return fogColor;
}

void main() {
    vec2 uv = (gl_FragCoord.xy - 0.5 * u_resolution.xy) / u_resolution.y;
    vec2 mouse = u_mouse / u_resolution;
    
    float angle = u_time * 0.2 + mouse.x * 6.28;
    float camHeight = 2.0 + mouse.y * 3.0;
    vec3 ro = vec3(sin(angle) * 5.0, camHeight, cos(angle) * 5.0);
    vec3 lookAt = vec3(0.0, 0.0, 0.0);
    
    vec3 forward = normalize(lookAt - ro);
    vec3 right = normalize(cross(vec3(0.0, 1.0, 0.0), forward));
    vec3 up = cross(forward, right);
    vec3 rd = normalize(forward + right * uv.x + up * uv.y);
    
    vec3 sunDir = normalize(vec3(0.5, 0.8, 0.3));
    vec3 sunColor = vec3(1.0, 0.9, 0.7);
    
    float t = rayMarch(ro, rd);
    
    vec3 col = vec3(0.0);
    vec3 fogCol = getFogColor(rd, sunDir);
    
    float fog = volumetricFog(ro, rd, min(t, MAX_DIST));
    
    if(t < MAX_DIST) {
        vec3 p = ro + rd * t;
        vec3 n = getNormal(p);
        
        float diff = max(dot(n, sunDir), 0.0);
        float sky = max(dot(n, vec3(0.0, 1.0, 0.0)), 0.0);
        float bounce = max(dot(n, vec3(0.0, -1.0, 0.0)), 0.0);
        
        float sha = softShadow(p + n * 0.01, sunDir, 0.1, 10.0, 8.0);
        
        vec3 mat = vec3(0.3);
        if(p.y < -0.5) mat = vec3(0.2, 0.15, 0.1);
        else if(p.y < 0.5) mat = vec3(0.3, 0.25, 0.2);
        else mat = vec3(0.4, 0.5, 0.3);
        
        col = mat * diff * sha * sunColor * 1.5;
        col += mat * sky * vec3(0.3, 0.4, 0.6) * 0.3;
        col += mat * bounce * vec3(0.1, 0.1, 0.15) * 0.2;
        
        float fresnel = pow(1.0 - max(dot(n, -rd), 0.0), 3.0);
        col += fresnel * vec3(0.1, 0.15, 0.2) * 0.5;
        
        col = mix(col, fogCol, t / MAX_DIST * 0.5);
    }
    
    col = mix(col, fogCol, fog * 0.7);
    
    float t2 = rayMarch(ro + rd * fog * 2.0, sunDir);
    if(t2 < MAX_DIST) {
        col *= 0.8;
    }
    
    col += pow(max(dot(rd, sunDir), 0.0), 64.0) * vec3(1.0, 0.8, 0.4) * 0.5;
    
    col = pow(col, vec3(0.4545));
    col = col * 1.1 - 0.1;
    
    float vig = 1.0 - dot(uv * 0.5, uv * 0.5);
    col *= vig;
    
    gl_FragColor = vec4(col, 1.0);
}