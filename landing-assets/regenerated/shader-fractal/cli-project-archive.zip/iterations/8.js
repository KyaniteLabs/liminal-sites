precision highp float;

uniform vec2 u_resolution;
uniform float u_time;
uniform vec2 u_mouse;

#define MAX_STEPS 80
#define MAX_DIST 100.0
#define SURF_DIST 0.001
#define FOG_STEPS 32
#define PI 3.14159265359

float hash(vec2 p) {
    return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
}

float noise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    float a = hash(i);
    float b = hash(i + vec2(1.0, 0.0));
    float c = hash(i + vec2(0.0, 1.0));
    float d = hash(i + vec2(1.0, 1.0));
    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}

float fbm(vec2 p) {
    float value = 0.0;
    float amplitude = 0.5;
    float frequency = 1.0;
    for(int i = 0; i < 5; i++) {
        value += amplitude * noise(p * frequency);
        amplitude *= 0.5;
        frequency *= 2.0;
    }
    return value;
}

float sdTerrain(vec3 p) {
    float height = fbm(p.xz * 0.15) * 4.0;
    height += fbm(p.xz * 0.3) * 1.5;
    height += fbm(p.xz * 0.6) * 0.5;
    return p.y - height;
}

float sdSphere(vec3 p, float r) {
    return length(p) - r;
}

float sdBox(vec3 p, vec3 b) {
    vec3 q = abs(p) - b;
    return length(max(q, 0.0)) + min(max(q.x, max(q.y, q.z)), 0.0);
}

float sceneSDF(vec3 p) {
    float terrain = sdTerrain(p);
    float mountain = p.y - (3.5 + sin(p.x * 0.2) * 1.5 + cos(p.z * 0.15) * 2.0);
    mountain = max(mountain, -sdBox(p - vec3(5.0, 0.0, 3.0), vec3(3.0, 5.0, 3.0)));
    return min(terrain, mountain);
}

vec3 getNormal(vec3 p) {
    vec2 e = vec2(0.01, 0.0);
    return normalize(vec3(
        sceneSDF(p + e.xyy) - sceneSDF(p - e.xyy),
        sceneSDF(p + e.yxy) - sceneSDF(p - e.yxy),
        sceneSDF(p + e.yyx) - sceneSDF(p - e.yyx)
    ));
}

float fogDensity(vec3 p) {
    float baseDensity = 0.02;
    float heightFalloff = exp(-p.y * 0.15);
    float noiseMod = fbm(p.xz * 0.1 + vec2(u_time * 0.05)) * 0.5 + 0.5;
    return baseDensity * heightFalloff * noiseMod;
}

vec4 volumetricFog(vec3 ro, vec3 rd, float tMax) {
    float stepSize = tMax / float(FOG_STEPS);
    vec3 fogColor = vec3(0.4, 0.45, 0.55);
    vec3 sunDir = normalize(vec3(0.5, 0.8, 0.3));
    float fogAccum = 0.0;
    vec3 lightAccum = vec3(0.0);
    
    for(int i = 0; i < FOG_STEPS; i++) {
        float t = stepSize * float(i);
        vec3 p = ro + rd * t;
        float density = fogDensity(p);
        float extinction = density * stepSize;
        fogAccum += extinction;
        
        float sunDensity = fogDensity(p + sunDir * 0.5);
        float sunTransmit = exp(-sunDensity * 3.0);
        vec3 scatteredLight = fogColor + vec3(1.0, 0.9, 0.7) * sunTransmit * 0.5;
        lightAccum += scatteredLight * extinction * (1.0 - fogAccum);
    }
    
    float transmittance = exp(-fogAccum);
    return vec4(lightAccum, transmittance);
}

vec3 raymarch(vec3 ro, vec3 rd, out float dist, out bool hit) {
    dist = 0.0;
    hit = false;
    
    for(int i = 0; i < MAX_STEPS; i++) {
        vec3 p = ro + rd * dist;
        float d = sceneSDF(p);
        
        if(d < SURF_DIST) {
            hit = true;
            return p;
        }
        
        if(dist > MAX_DIST) break;
        
        dist += d * 0.7;
    }
    
    return ro + rd * dist;
}

vec3 lighting(vec3 p, vec3 n, vec3 rd) {
    vec3 lightDir = normalize(vec3(0.5, 0.8, 0.3));
    vec3 lightColor = vec3(1.0, 0.95, 0.85);
    vec3 ambient = vec3(0.15, 0.2, 0.3);
    
    float diff = max(dot(n, lightDir), 0.0);
    float spec = pow(max(dot(reflect(-lightDir, n), -rd), 0.0), 32.0);
    
    vec3 col = ambient;
    col += diff * lightColor * 0.7;
    col += spec * lightColor * 0.3;
    
    float slope = 1.0 - n.y;
    vec3 grassColor = vec3(0.2, 0.35, 0.15);
    vec3 rockColor = vec3(0.3, 0.28, 0.25);
    vec3 snowColor = vec3(0.9, 0.95, 1.0);
    
    vec3 terrainColor = mix(grassColor, rockColor, smoothstep(0.3, 0.6, slope));
    terrainColor = mix(terrainColor, snowColor, smoothstep(3.5, 5.0, p.y));
    terrainColor = mix(terrainColor, rockColor * 1.2, fbm(p.xz * 2.0) * 0.3);
    
    col *= terrainColor;
    
    float height = smoothstep(2.0, 5.0, p.y);
    col = mix(col, vec3(0.6, 0.7, 0.8), height * 0.3);
    
    return col;
}

mat3 setCamera(vec3 ro, vec3 ta) {
    vec3 cw = normalize(ta - ro);
    vec3 up = vec3(0.0, 1.0, 0.0);
    vec3 cu = normalize(cross(cw, up));
    vec3 cv = cross(cu, cw);
    return mat3(cu, cv, cw);
}

void main() {
    vec2 uv = (gl_FragCoord.xy - 0.5 * u_resolution.xy) / u_resolution.y;
    
    float time = u_time * 0.3;
    vec2 mouse = u_mouse * 2.0 - 1.0;
    
    float camAngle = time * 0.5 + mouse.x * 2.0;
    float camHeight = 3.0 + sin(time * 0.3) * 1.5 + mouse.y * 3.0;
    vec3 ro = vec3(sin(camAngle) * 12.0, camHeight, cos(camAngle) * 12.0);
    vec3 ta = vec3(0.0, 2.0, 0.0);
    
    mat3 ca = setCamera(ro, ta);
    vec3 rd = ca * normalize(vec3(uv, 1.5));
    
    float dist;
    bool hit;
    vec3 p = raymarch(ro, rd, dist, hit);
    
    vec3 skyColor = mix(vec3(0.3, 0.4, 0.6), vec3(0.7, 0.8, 0.95), max(rd.y, 0.0));
    skyColor += vec3(1.0, 0.8, 0.6) * pow(max(dot(rd, normalize(vec3(0.5, 0.8, 0.3))), 0.0), 32.0);
    
    vec4 fog = volumetricFog(ro, rd, min(dist, MAX_DIST));
    
    vec3 col;
    if(hit) {
        vec3 n = getNormal(p);
        col = lighting(p, n, rd);
    } else {
        col = skyColor;
    }
    
    col = col * fog.a + fog.rgb;
    
    float sunGlow = smoothstep(0.0, -0.2, rd.y);
    col += vec3(1.0, 0.6, 0.3) * sunGlow * 0.3;
    
    col = 1.0 - exp(-col * 1.2);
    col = pow(col, vec3(0.85));
    
    float vignette = 1.0 - length(uv) * 0.4;
    col *= vignette;
    
    gl_FragColor = vec4(col, 1.0);
}