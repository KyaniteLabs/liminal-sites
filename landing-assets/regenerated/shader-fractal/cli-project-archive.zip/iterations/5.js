precision highp float;

uniform vec2 u_resolution;
uniform float u_time;
uniform vec2 u_mouse;

#define MAX_STEPS 80
#define MAX_DIST 100.0
#define SURF_DIST 0.01
#define FOG_STEPS 32
#define PI 3.14159265359

float hash(float n) {
    return fract(sin(n) * 43758.5453123);
}

float hash2(vec2 p) {
    return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
}

vec3 hash3(vec3 p) {
    p = vec3(dot(p, vec3(127.1, 311.7, 74.7)),
             dot(p, vec3(269.5, 183.3, 246.1)),
             dot(p, vec3(113.5, 271.9, 124.6)));
    return fract(sin(p) * 43758.5453123);
}

float noise(vec3 p) {
    vec3 i = floor(p);
    vec3 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    
    float n = i.x + i.y * 157.0 + 113.0 * i.z;
    return mix(
        mix(mix(hash(n + 0.0), hash(n + 1.0), f.x),
            mix(hash(n + 157.0), hash(n + 158.0), f.x), f.y),
        mix(mix(hash(n + 113.0), hash(n + 114.0), f.x),
            mix(hash(n + 270.0), hash(n + 271.0), f.x), f.y), f.z);
}

float noise2D(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    
    float a = hash2(i);
    float b = hash2(i + vec2(1.0, 0.0));
    float c = hash2(i + vec2(0.0, 1.0));
    float d = hash2(i + vec2(1.0, 1.0));
    
    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}

float fbm(vec3 p) {
    float value = 0.0;
    float amplitude = 0.5;
    float frequency = 1.0;
    
    for(int i = 0; i < 5; i++) {
        value += amplitude * noise(p * frequency);
        amplitude *= 0.5;
        frequency *= 2.0;
    }
    return value;
}

float fbm2D(vec2 p) {
    float value = 0.0;
    float amplitude = 0.5;
    float frequency = 1.0;
    
    for(int i = 0; i < 5; i++) {
        value += amplitude * noise2D(p * frequency);
        amplitude *= 0.5;
        frequency *= 2.0;
    }
    return value;
}

float terrain(vec3 p) {
    float height = fbm2D(p.xz * 0.15) * 4.0;
    height += fbm2D(p.xz * 0.3) * 2.0;
    height += fbm2D(p.xz * 0.6) * 1.0;
    return p.y - height;
}

float fractalTerrain(vec3 p) {
    float d = terrain(p);
    
    vec3 q = p;
    float scale = 1.0;
    for(int i = 0; i < 3; i++) {
        q.xz = abs(q.xz) - 2.0;
        q = q * 1.5 - vec3(2.0, 1.0, 2.0);
        float detail = fbm(q * scale * 0.5) * 0.5;
        d += detail * 0.3 / scale;
        scale *= 2.0;
    }
    
    return d;
}

float map(vec3 p) {
    float ground = fractalTerrain(p);
    
    vec3 fp = fract(p * 0.5) - 0.5;
    float rocks = length(max(abs(fp) - 0.3, 0.0));
    ground -= rocks * 0.2;
    
    return ground;
}

vec3 getNormal(vec3 p) {
    vec2 e = vec2(0.01, 0.0);
    return normalize(vec3(
        map(p + e.xyy) - map(p - e.xyy),
        map(p + e.yxy) - map(p - e.yxy),
        map(p + e.yyx) - map(p - e.yyx)
    ));
}

float raymarch(vec3 ro, vec3 rd) {
    float dO = 0.0;
    
    for(int i = 0; i < MAX_STEPS; i++) {
        vec3 p = ro + rd * dO;
        float dS = map(p);
        dO += dS * 0.7;
        if(dO > MAX_DIST || abs(dS) < SURF_DIST) break;
    }
    
    return dO;
}

float fogDensity(vec3 p) {
    float base = 0.03;
    float h = exp(-p.y * 0.08) * 0.5;
    float n = fbm(p * 0.1 + vec3(u_time * 0.05, 0.0, u_time * 0.03));
    return base * h * (0.5 + n);
}

vec3 volumetricFog(vec3 ro, vec3 rd, float tMax, vec3 fogColor) {
    vec3 fog = vec3(0.0);
    float transmittance = 1.0;
    
    float stepSize = tMax / float(FOG_STEPS);
    
    for(int i = 0; i < FOG_STEPS; i++) {
        float t = stepSize * (float(i) + 0.5);
        vec3 p = ro + rd * t;
        
        float density = fogDensity(p);
        float lightDensity = fogDensity(p + normalize(vec3(1.0, 0.5, 0.3)) * 0.5);
        
        vec3 fogContribution = fogColor * density * stepSize;
        fogContribution *= exp(-lightDensity * 2.0);
        
        fog += fogContribution * transmittance;
        transmittance *= exp(-density * stepSize);
        
        if(transmittance < 0.01) break;
    }
    
    return fog;
}

float softShadow(vec3 ro, vec3 rd, float mint, float maxt, float k) {
    float res = 1.0;
    float t = mint;
    
    for(int i = 0; i < 32; i++) {
        float h = map(ro + rd * t);
        res = min(res, k * h / t);
        t += clamp(h, 0.02, 0.5);
        if(h < 0.001 || t > maxt) break;
    }
    
    return clamp(res, 0.0, 1.0);
}

vec3 lighting(vec3 p, vec3 n, vec3 rd) {
    vec3 lightDir = normalize(vec3(1.0, 0.5, 0.3));
    vec3 lightColor = vec3(1.0, 0.9, 0.8);
    vec3 ambient = vec3(0.2, 0.25, 0.35);
    
    float diff = max(dot(n, lightDir), 0.0);
    float shadow = softShadow(p + n * 0.02, lightDir, 0.1, 20.0, 8.0);
    
    vec3 halfDir = normalize(lightDir - rd);
    float spec = pow(max(dot(n, halfDir), 0.0), 32.0);
    
    float ao = 1.0;
    for(int i = 1; i <= 4; i++) {
        float d = 0.1 * float(i);
        ao -= (d - map(p + n * d)) / pow(2.0, float(i));
    }
    ao = clamp(ao, 0.0, 1.0);
    
    vec3 col = ambient * ao;
    col += lightColor * diff * shadow;
    col += lightColor * spec * shadow * 0.5;
    
    return col;
}

vec3 getTerrainColor(vec3 p, vec3 n) {
    float slope = 1.0 - n.y;
    
    vec3 snowColor = vec3(0.95, 0.97, 1.0);
    vec3 rockColor = vec3(0.4, 0.35, 0.3);
    vec3 grassColor = vec3(0.2, 0.4, 0.15);
    vec3 dirtColor = vec3(0.35, 0.25, 0.15);
    
    float h = p.y;
    float n1 = fbm(p.xz * 2.0);
    float n2 = fbm(p * 5.0);
    
    vec3 col = dirtColor;
    
    col = mix(col, grassColor, smoothstep(0.0, 2.0, h) * (1.0 - slope));
    col = mix(col, rockColor, smoothstep(0.3, 0.7, slope) * (1.0 - smoothstep(4.0, 6.0, h)));
    col = mix(col, snowColor, smoothstep(4.0, 6.0, h + n1 * 1.5));
    col = mix(col, rockColor * 0.8, smoothstep(0.7, 1.0, slope));
    
    col *= 0.8 + 0.4 * n2;
    
    return col;
}

vec3 sky(vec3 rd) {
    vec3 sunDir = normalize(vec3(1.0, 0.5, 0.3));
    float sun = max(dot(rd, sunDir), 0.0);
    
    float horizon = 1.0 - max(rd.y, 0.0);
    vec3 skyCol = mix(vec3(0.6, 0.7, 0.9), vec3(0.95, 0.85, 0.7), pow(sun, 8.0));
    skyCol = mix(skyCol, vec3(0.4, 0.5, 0.7), horizon * horizon);
    
    skyCol += vec3(1.0, 0.8, 0.5) * pow(sun, 64.0) * 0.5;
    
    return skyCol;
}

void main() {
    vec2 uv = (gl_FragCoord.xy - 0.5 * u_resolution.xy) / u_resolution.y;
    
    float camAngle = u_time * 0.1;
    float camHeight = 8.0 + sin(u_time * 0.2) * 2.0;
    float camDist = 15.0;
    
    if(u_mouse.x > 0.01 || u_mouse.y > 0.01) {
        camAngle = u_mouse.x * PI * 2.0;
        camHeight = u_mouse.y * 15.0 + 3.0;
    }
    
    vec3 ro = vec3(sin(camAngle) * camDist, camHeight, cos(camAngle) * camDist);
    vec3 lookAt = vec3(0.0, 3.0, 0.0);
    
    vec3 forward = normalize(lookAt - ro);
    vec3 right = normalize(cross(vec3(0.0, 1.0, 0.0), forward));
    vec3 up = cross(forward, right);
    
    vec3 rd = normalize(forward + uv.x * right + uv.y * up);
    
    float d = raymarch(ro, rd);
    
    vec3 fogColor = vec3(0.6, 0.65, 0.8);
    vec3 col = sky(rd);
    
    if(d < MAX_DIST) {
        vec3 p = ro + rd * d;
        vec3 n = getNormal(p);
        
        vec3 terrainCol = getTerrainColor(p, n);
        vec3 litCol = lighting(p, n, rd);
        
        col = terrainCol * litCol;
        
        float fogAmount = 1.0 - exp(-d * 0.02);
        col = mix(col, fogColor, fogAmount);
    }
    
    vec3 volFog = volumetricFog(ro, rd, min(d, MAX_DIST), fogColor);
    col = col * exp(-volFog * 0.5) + volFog;
    
    float sunDist = length(rd - normalize(vec3(1.0, 0.5, 0.3)));
    col += vec3(1.0, 0.9, 0.7) * smoothstep(0.02, 0.0, sunDist) * 2.0;
    
    col = pow(col, vec3(0.4545));
    col = col * 1.1 - 0.1;
    col = clamp(col, 0.0, 1.0);
    
    vec2 q = gl_FragCoord.xy / u_resolution.xy;
    col *= 0.5 + 0.5 * pow(16.0 * q.x * q.y * (1.0 - q.x) * (1.0 - q.y), 0.2);
    
    gl_FragColor = vec4(col, 1.0);
}