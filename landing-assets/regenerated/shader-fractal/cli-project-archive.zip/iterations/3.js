precision highp float;

#define MAX_STEPS 80
#define MAX_DIST 100.0
#define SURF_DIST 0.01
#define FOG_STEPS 32
#define FOG_DENSITY 0.04

uniform vec2 u_resolution;
uniform float u_time;
uniform vec2 u_mouse;

float hash(vec2 p) {
    return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
}

float noise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    float a = hash(i);
    float b = hash(i + vec2(1.0, 0.0));
    float c = hash(i + vec2(0.0, 1.0));
    float d = hash(i + vec2(1.0, 1.0));
    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}

float fbm(vec2 p) {
    float value = 0.0;
    float amplitude = 0.5;
    float frequency = 1.0;
    for(int i = 0; i < 5; i++) {
        value += amplitude * noise(p * frequency);
        amplitude *= 0.5;
        frequency *= 2.0;
    }
    return value;
}

float terrainSDF(vec3 p) {
    float height = fbm(p.xz * 0.3) * 3.0;
    height += fbm(p.xz * 0.8 + u_time * 0.05) * 1.0;
    return p.y - height;
}

float sceneSDF(vec3 p) {
    return terrainSDF(p);
}

vec3 getNormal(vec3 p) {
    vec2 e = vec2(0.01, 0.0);
    return normalize(vec3(
        sceneSDF(p + e.xyy) - sceneSDF(p - e.xyy),
        sceneSDF(p + e.yxy) - sceneSDF(p - e.yxy),
        sceneSDF(p + e.yyx) - sceneSDF(p - e.yyx)
    ));
}

float fogNoise(vec3 p) {
    return fbm(p.xz * 0.5 + u_time * 0.1) * 0.5 + 0.5;
}

vec3 volumetricFog(vec3 ro, vec3 rd, float maxDist, vec3 lightDir) {
    float fogAmount = 0.0;
    float stepSize = maxDist / float(FOG_STEPS);
    vec3 fogColor = vec3(0.4, 0.45, 0.55);
    vec3 sunColor = vec3(1.0, 0.9, 0.7);
    
    for(int i = 0; i < FOG_STEPS; i++) {
        float t = float(i) * stepSize + stepSize * 0.5;
        vec3 p = ro + rd * t;
        
        float height = fbm(p.xz * 0.3) * 3.0 + fbm(p.xz * 0.8 + u_time * 0.05);
        float distToTerrain = p.y - height;
        
        if(distToTerrain > 0.0) {
            float density = fogNoise(p) * FOG_DENSITY;
            density *= smoothstep(8.0, 2.0, distToTerrain);
            density *= smoothstep(0.0, 3.0, p.y);
            fogAmount += density * stepSize;
        }
        
        fogAmount += FOG_DENSITY * 0.3 * stepSize * fogNoise(p + vec3(u_time * 0.2));
    }
    
    fogAmount = 1.0 - exp(-fogAmount);
    
    float sunVisibility = max(0.0, dot(rd, lightDir));
    vec3 finalFogColor = mix(fogColor, sunColor, pow(sunVisibility, 8.0) * 0.6);
    
    return finalFogColor * fogAmount;
}

float rayMarch(vec3 ro, vec3 rd, out float totalDist) {
    totalDist = 0.0;
    for(int i = 0; i < MAX_STEPS; i++) {
        vec3 p = ro + rd * totalDist;
        float d = sceneSDF(p);
        if(d < SURF_DIST) return 1.0;
        if(totalDist > MAX_DIST) break;
        totalDist += d * 0.7;
    }
    return 0.0;
}

void main() {
    vec2 uv = (gl_FragCoord.xy - 0.5 * u_resolution.xy) / u_resolution.y;
    
    float camAngle = u_mouse.x * 6.28318 + u_time * 0.1;
    float camHeight = 8.0 + u_mouse.y * 4.0;
    vec3 ro = vec3(sin(camAngle) * 12.0, camHeight, cos(camAngle) * 12.0);
    vec3 lookAt = vec3(0.0, 0.0, 0.0);
    
    vec3 forward = normalize(lookAt - ro);
    vec3 right = normalize(cross(vec3(0.0, 1.0, 0.0), forward));
    vec3 up = cross(forward, right);
    
    vec3 rd = normalize(forward + uv.x * right + uv.y * up);
    
    vec3 lightDir = normalize(vec3(0.5, 0.8, 0.3));
    vec3 lightColor = vec3(1.0, 0.95, 0.8);
    
    float totalDist;
    float hit = rayMarch(ro, rd, totalDist);
    
    vec3 col = vec3(0.1, 0.15, 0.2);
    
    if(hit > 0.5) {
        vec3 p = ro + rd * totalDist;
        vec3 n = getNormal(p);
        
        float height = fbm(p.xz * 0.3) * 3.0;
        vec3 terrainColor = mix(
            vec3(0.15, 0.25, 0.15),
            vec3(0.3, 0.35, 0.25),
            smoothstep(0.0, 4.0, p.y - height)
        );
        terrainColor = mix(terrainColor, vec3(0.6, 0.65, 0.6), fbm(p.xz * 2.0) * 0.5);
        
        float diff = max(dot(n, lightDir), 0.0);
        float amb = 0.3;
        float spec = pow(max(dot(reflect(-lightDir, n), -rd), 0.0), 16.0) * 0.3;
        
        col = terrainColor * (diff * lightColor + amb);
        col += spec * lightColor;
        
        float fogFactor = 1.0 - exp(-totalDist * 0.03);
        vec3 fogCol = mix(vec3(0.4, 0.5, 0.6), vec3(0.8, 0.85, 0.9), rd.y * 0.5 + 0.5);
        col = mix(col, fogCol, fogFactor);
    } else {
        float skyGrad = smoothstep(-0.2, 0.5, rd.y);
        col = mix(vec3(0.3, 0.35, 0.4), vec3(0.5, 0.6, 0.8), skyGrad);
        col = mix(col, vec3(1.0, 0.9, 0.7), pow(max(dot(rd, lightDir), 0.0), 32.0) * 0.5);
    }
    
    vec3 volFog = volumetricFog(ro, rd, min(totalDist, MAX_DIST), lightDir);
    col = col + volFog * (1.0 - length(volFog) * 0.3);
    
    col = pow(col, vec3(0.4545));
    
    col *= 1.0 - 0.3 * length(uv);
    
    gl_FragColor = vec4(col, 1.0);
}