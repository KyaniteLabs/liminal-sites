precision highp float;

uniform vec2 u_resolution;
uniform float u_time;
uniform vec2 u_mouse;

#define MAX_STEPS 80
#define MAX_DIST 50.0
#define SURF_DIST 0.001
#define FOG_DENSITY 0.04
#define MAX_FOG_STEPS 32

mat2 rot2D(float a) {
    float s = sin(a), c = cos(a);
    return mat2(c, -s, s, c);
}

float hash(float n) {
    return fract(sin(n) * 43758.5453123);
}

float noise(vec3 p) {
    vec3 i = floor(p);
    vec3 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    
    float n = i.x + i.y * 57.0 + 113.0 * i.z;
    return mix(
        mix(mix(hash(n), hash(n + 1.0), f.x),
            mix(hash(n + 57.0), hash(n + 58.0), f.x), f.y),
        mix(mix(hash(n + 113.0), hash(n + 114.0), f.x),
            mix(hash(n + 170.0), hash(n + 171.0), f.x), f.y), f.z);
}

float fbm(vec3 p) {
    float f = 0.0;
    float amp = 0.5;
    float freq = 1.0;
    for(int i = 0; i < 5; i++) {
        f += amp * noise(p * freq);
        amp *= 0.5;
        freq *= 2.0;
    }
    return f;
}

float sdSphere(vec3 p, float r) {
    return length(p) - r;
}

float sdPlane(vec3 p, vec3 n, float h) {
    return dot(p, n) + h;
}

float sdTerrain(vec3 p) {
    float height = fbm(vec3(p.x * 0.15, 0.0, p.z * 0.15)) * 4.0;
    height += sin(p.x * 0.3) * cos(p.z * 0.3) * 0.5;
    return p.y - height;
}

float sdMandelbulb(vec3 p) {
    vec3 z = p;
    float dr = 1.0;
    float r = 0.0;
    float power = 8.0 + sin(u_time * 0.2) * 2.0;
    
    for(int i = 0; i < 8; i++) {
        r = length(z);
        if(r > 2.0) break;
        
        float theta = acos(z.z / r);
        float phi = atan(z.y, z.x);
        dr = pow(r, power - 1.0) * power * dr + 1.0;
        
        float zr = pow(r, power);
        theta *= power;
        phi *= power;
        
        z = zr * vec3(sin(theta) * cos(phi), sin(theta) * sin(phi), cos(theta));
        z += p;
    }
    return 0.5 * log(r) * r / dr;
}

float map(vec3 p) {
    float terrain = sdTerrain(p);
    vec3 bp = p - vec3(0.0, 1.0, 0.0);
    float bulb = sdMandelbulb(bp * 0.8) / 0.8;
    return min(terrain, bulb * 0.5 + 1.0);
}

vec3 getNormal(vec3 p) {
    vec2 e = vec2(0.001, 0.0);
    return normalize(vec3(
        map(p + e.xyy) - map(p - e.xyy),
        map(p + e.yxy) - map(p - e.yxy),
        map(p + e.yyx) - map(p - e.yyx)
    ));
}

float softShadow(vec3 ro, vec3 rd, float mint, float maxt, float k) {
    float res = 1.0;
    float t = mint;
    for(int i = 0; i < 24; i++) {
        float h = map(ro + rd * t);
        res = min(res, k * h / t);
        t += clamp(h, 0.02, 0.2);
        if(h < 0.001 || t > maxt) break;
    }
    return clamp(res, 0.0, 1.0);
}

float volumetricFog(vec3 ro, vec3 rd, float tMax) {
    float fog = 0.0;
    float stepSize = tMax / float(MAX_FOG_STEPS);
    float t = 0.0;
    
    for(int i = 0; i < MAX_FOG_STEPS; i++) {
        vec3 p = ro + rd * t;
        float density = fbm(p * 0.1 + vec3(u_time * 0.05, 0.0, u_time * 0.03)) * FOG_DENSITY;
        density *= smoothstep(5.0, 0.0, p.y) * 0.5 + 0.5;
        fog += density * stepSize;
        t += stepSize;
    }
    
    return 1.0 - exp(-fog * 2.0);
}

vec3 getSkyColor(vec3 rd) {
    float t = 0.5 * (rd.y + 1.0);
    vec3 skyTop = vec3(0.1, 0.15, 0.4);
    vec3 skyHorizon = vec3(0.6, 0.5, 0.4);
    vec3 sky = mix(skyHorizon, skyTop, t);
    
    float sun = pow(max(dot(rd, normalize(vec3(1.0, 0.4, 0.2))), 0.0), 32.0);
    sky += vec3(1.0, 0.8, 0.4) * sun;
    
    return sky;
}

vec3 getMaterial(vec3 p, vec3 n) {
    float terrain = sdTerrain(p);
    vec3 terrainCol = vec3(0.3, 0.25, 0.2);
    terrainCol = mix(terrainCol, vec3(0.1, 0.3, 0.1), smoothstep(-2.0, 1.0, p.y));
    terrainCol = mix(terrainCol, vec3(0.8, 0.8, 0.9), smoothstep(2.5, 4.0, p.y));
    terrainCol *= 0.8 + 0.2 * fbm(p * 2.0);
    
    return terrainCol;
}

float rayMarch(vec3 ro, vec3 rd) {
    float t = 0.0;
    for(int i = 0; i < MAX_STEPS; i++) {
        vec3 p = ro + rd * t;
        float d = map(p);
        if(d < SURF_DIST) return t;
        if(t > MAX_DIST) break;
        t += d * 0.8;
    }
    return -1.0;
}

void main() {
    vec2 uv = (gl_FragCoord.xy - 0.5 * u_resolution) / u_resolution.y;
    
    vec3 ro = vec3(0.0, 3.0 + sin(u_time * 0.1) * 0.5, -8.0);
    vec3 lookAt = vec3(sin(u_time * 0.15) * 2.0, 1.0, cos(u_time * 0.1) * 2.0);
    
    vec3 forward = normalize(lookAt - ro);
    vec3 right = normalize(cross(vec3(0.0, 1.0, 0.0), forward));
    vec3 up = cross(forward, right);
    
    vec3 rd = normalize(forward + uv.x * right + uv.y * up);
    
    float t = rayMarch(ro, rd);
    
    vec3 col = getSkyColor(rd);
    
    if(t > 0.0) {
        vec3 p = ro + rd * t;
        vec3 n = getNormal(p);
        
        vec3 lightDir = normalize(vec3(1.0, 0.4, 0.2));
        vec3 lightCol = vec3(1.0, 0.9, 0.7);
        
        float diff = max(dot(n, lightDir), 0.0);
        float shadow = softShadow(p + n * 0.01, lightDir, 0.1, 10.0, 8.0);
        
        vec3 viewDir = normalize(ro - p);
        vec3 halfDir = normalize(lightDir + viewDir);
        float spec = pow(max(dot(n, halfDir), 0.0), 32.0);
        
        vec3 mat = getMaterial(p, n);
        vec3 ambient = vec3(0.15, 0.2, 0.3);
        
        col = mat * (ambient + lightCol * diff * shadow);
        col += lightCol * spec * shadow * 0.3;
        
        float fog = volumetricFog(ro, rd, t);
        vec3 fogCol = mix(vec3(0.5, 0.4, 0.3), vec3(0.7, 0.6, 0.5), rd.y * 0.5 + 0.5);
        col = mix(col, fogCol, fog);
    }
    
    float fog = volumetricFog(ro, rd, MAX_DIST);
    col = mix(col, getSkyColor(rd) * 0.7, fog * 0.5);
    
    col = pow(col, vec3(0.4545));
    col = col * 1.2 - 0.1;
    col = clamp(col, 0.0, 1.0);
    
    gl_FragColor = vec4(col, 1.0);
}