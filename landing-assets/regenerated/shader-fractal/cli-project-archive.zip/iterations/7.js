precision highp float;

uniform vec2 u_resolution;
uniform float u_time;
uniform vec2 u_mouse;

#define MAX_STEPS 64
#define MAX_DIST 100.0
#define SURF_DIST 0.001
#define FOG_STEPS 16

mat2 rot2D(float a) {
    float s = sin(a), c = cos(a);
    return mat2(c, -s, s, c);
}

float hash(vec2 p) {
    return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
}

float noise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    
    float a = hash(i);
    float b = hash(i + vec2(1.0, 0.0));
    float c = hash(i + vec2(0.0, 1.0));
    float d = hash(i + vec2(1.0, 1.0));
    
    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}

float fbm(vec2 p) {
    float value = 0.0;
    float amplitude = 0.5;
    for(int i = 0; i < 5; i++) {
        value += amplitude * noise(p);
        p *= 2.0;
        amplitude *= 0.5;
    }
    return value;
}

float sdSphere(vec3 p, float r) {
    return length(p) - r;
}

float sdPlane(vec3 p, vec3 n, float h) {
    return dot(p, n) + h;
}

float terrain(vec2 p) {
    float h = fbm(p * 0.3) * 3.0;
    h += fbm(p * 0.8 + u_time * 0.1) * 0.5;
    return h - 1.5;
}

float fractalTerrain(vec3 p) {
    vec3 q = p;
    float scale = 1.0;
    float amplitude = 1.0;
    float result = p.y + terrain(p.xz);
    
    for(int i = 0; i < 4; i++) {
        q = abs(q) - vec3(0.5, 0.3, 0.5);
        q.xz *= rot2D(0.785 + float(i) * 0.2);
        q.yz *= rot2D(0.3);
        
        float d = sdSphere(q, 0.8) * amplitude;
        result = min(result, d);
        
        amplitude *= 0.5;
        scale *= 2.0;
    }
    
    return result;
}

float map(vec3 p) {
    float terrainDist = fractalTerrain(p);
    float ground = sdPlane(p, vec3(0.0, 1.0, 0.0), 2.0);
    return min(terrainDist, ground);
}

vec3 calcNormal(vec3 p) {
    vec2 e = vec2(0.001, 0.0);
    return normalize(vec3(
        map(p + e.xyy) - map(p - e.xyy),
        map(p + e.yxy) - map(p - e.yxy),
        map(p + e.yyx) - map(p - e.yyx)
    ));
}

float softShadow(vec3 ro, vec3 rd, float mint, float maxt, float k) {
    float res = 1.0;
    float t = mint;
    for(int i = 0; i < 32; i++) {
        float h = map(ro + rd * t);
        res = min(res, k * h / t);
        t += clamp(h, 0.02, 0.2);
        if(h < 0.001 || t > maxt) break;
    }
    return clamp(res, 0.0, 1.0);
}

float volumetricFog(vec3 ro, vec3 rd, float maxDist) {
    float fogDensity = 0.0;
    float stepSize = maxDist / float(FOG_STEPS);
    float t = stepSize * 0.5;
    
    for(int i = 0; i < FOG_STEPS; i++) {
        vec3 p = ro + rd * t;
        
        float height = p.y;
        float baseDensity = exp(-height * 0.5) * 0.15;
        
        float noiseVal = fbm(p.xz * 0.5 + u_time * 0.05);
        float turbulence = sin(p.x * 0.5 + u_time) * sin(p.z * 0.7 + u_time * 0.7) * 0.1;
        
        float density = baseDensity * (0.5 + 0.5 * noiseVal) + turbulence * 0.05;
        
        float distanceFade = exp(-t * 0.03);
        fogDensity += density * stepSize * distanceFade;
        
        t += stepSize;
    }
    
    return 1.0 - exp(-fogDensity);
}

vec3 getSkyColor(vec3 rd) {
    vec3 col = mix(vec3(0.3, 0.2, 0.5), vec3(0.9, 0.4, 0.3), rd.y * 0.5 + 0.5);
    col = mix(col, vec3(0.1, 0.1, 0.2), smoothstep(0.0, -0.2, rd.y));
    return col;
}

float ao(vec3 p, vec3 n) {
    float occ = 0.0;
    float scale = 1.0;
    for(int i = 0; i < 5; i++) {
        float h = 0.01 + 0.12 * float(i);
        float d = map(p + n * h);
        occ += (h - d) * scale;
        scale *= 0.5;
    }
    return clamp(1.0 - 3.0 * occ, 0.0, 1.0);
}

void main() {
    vec2 uv = (gl_FragCoord.xy - 0.5 * u_resolution.xy) / u_resolution.y;
    
    vec2 mouse = u_mouse;
    if(length(mouse) < 0.01) mouse = vec2(0.5, 0.4);
    
    float camDist = 8.0;
    float camAngle = (mouse.x - 0.5) * 6.28;
    float camPitch = (mouse.y - 0.5) * 1.5 + 0.5;
    
    vec3 ro = vec3(camDist * sin(camAngle), 3.0 + camPitch * 3.0, camDist * cos(camAngle));
    vec3 lookAt = vec3(0.0, 0.0, 0.0);
    
    vec3 forward = normalize(lookAt - ro);
    vec3 right = normalize(cross(vec3(0.0, 1.0, 0.0), forward));
    vec3 up = cross(forward, right);
    
    vec3 rd = normalize(forward + uv.x * right + uv.y * up);
    
    float t = 0.0;
    float dist;
    vec3 p;
    bool hit = false;
    
    for(int i = 0; i < MAX_STEPS; i++) {
        p = ro + rd * t;
        dist = map(p);
        if(abs(dist) < SURF_DIST) {
            hit = true;
            break;
        }
        if(t > MAX_DIST) break;
        t += dist * 0.8;
    }
    
    vec3 col;
    
    if(hit) {
        vec3 n = calcNormal(p);
        vec3 lightDir = normalize(vec3(0.5, 0.8, 0.3));
        vec3 lightCol = vec3(1.0, 0.9, 0.8);
        
        float diff = max(dot(n, lightDir), 0.0);
        float spec = pow(max(dot(reflect(-lightDir, n), -rd), 0.0), 32.0);
        float shadow = softShadow(p + n * 0.02, lightDir, 0.02, 10.0, 16.0);
        float occlusion = ao(p, n);
        
        vec3 mate = vec3(0.3, 0.25, 0.2);
        float heightFactor = smoothstep(-2.0, 2.0, p.y);
        mate = mix(vec3(0.15, 0.1, 0.08), vec3(0.4, 0.35, 0.25), heightFactor);
        
        float fractalMask = smoothstep(-1.0, -0.5, p.y);
        mate = mix(mate, vec3(0.2, 0.3, 0.5) * (0.5 + 0.5 * sin(p.y * 10.0)), fractalMask);
        
        col = mate * lightCol * diff * shadow * occlusion;
        col += spec * shadow * vec3(1.0, 0.9, 0.7) * 0.5;
        
        vec3 ambient = vec3(0.1, 0.15, 0.2);
        col += mate * ambient * occlusion;
        
        float fogAmount = 1.0 - exp(-t * 0.04);
        col = mix(col, getSkyColor(rd) * 0.5, fogAmount);
        
    } else {
        col = getSkyColor(rd);
    }
    
    float volFog = volumetricFog(ro, rd, min(t, MAX_DIST));
    vec3 fogColor = mix(vec3(0.3, 0.35, 0.4), vec3(0.6, 0.5, 0.7), smoothstep(0.0, 0.5, rd.y));
    fogColor = mix(fogColor, vec3(0.9, 0.6, 0.4), smoothstep(-0.2, 0.3, rd.y));
    col = mix(col, fogColor, volFog * 0.6);
    
    col = 1.0 - exp(-col * 1.5);
    col = pow(col, vec3(0.85));
    col *= 1.0 - 0.3 * length(uv);
    
    gl_FragColor = vec4(col, 1.0);
}