precision highp float;

#define MAX_STEPS 80
#define MAX_DIST 100.0
#define SURF_DIST 0.001
#define FOG_DENSITY 0.02
#define FOG_STEPS 32

uniform vec2 u_resolution;
uniform float u_time;
uniform vec2 u_mouse;

float hash(float n) { return fract(sin(n) * 43758.5453123); }

float hash2(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }

float noise(vec3 p) {
    vec3 i = floor(p);
    vec3 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    float n = i.x + i.y * 157.0 + 113.0 * i.z;
    return mix(mix(mix(hash(n + 0.0), hash(n + 1.0), f.x),
                   mix(hash(n + 157.0), hash(n + 158.0), f.x), f.y),
               mix(mix(hash(n + 113.0), hash(n + 114.0), f.x),
                   mix(hash(n + 270.0), hash(n + 271.0), f.x), f.y), f.z);
}

float fbm(vec3 p) {
    float value = 0.0;
    float amplitude = 0.5;
    float frequency = 1.0;
    for (int i = 0; i < 4; i++) {
        value += amplitude * noise(p * frequency);
        amplitude *= 0.5;
        frequency *= 2.0;
    }
    return value;
}

mat2 rot2D(float a) {
    float s = sin(a), c = cos(a);
    return mat2(c, -s, s, c);
}

float sdSphere(vec3 p, float r) { return length(p) - r; }

float sdPlane(vec3 p, vec3 n, float h) { return dot(p, n) + h; }

float terrain(vec2 p) {
    float h = 0.0;
    h += sin(p.x * 0.3) * 0.5;
    h += sin(p.y * 0.4) * 0.3;
    h += fbm(vec3(p.x * 0.1, 0.0, p.y * 0.1)) * 2.0;
    h += sin(p.x * 0.8 + u_time * 0.2) * 0.1;
    h += sin(p.y * 0.6 + u_time * 0.15) * 0.08;
    return h;
}

float fractalTerrain(vec3 p) {
    vec3 q = p;
    float scale = 1.0;
    float amplitude = 1.0;
    float d = 1000.0;
    
    for (int i = 0; i < 5; i++) {
        float h = terrain(q.xz * 0.1 * scale) * amplitude;
        float plane = q.y - h;
        d = min(d, plane);
        q.xz = abs(q.xz) - 2.0 * scale;
        q.xz *= rot2D(0.3);
        scale *= 0.5;
        amplitude *= 0.6;
    }
    
    return d;
}

float map(vec3 p) {
    float ground = fractalTerrain(p);
    float sphere = sdSphere(p - vec3(0.0, 3.0 + sin(u_time * 0.5) * 1.5, 0.0), 1.5);
    float d = min(ground, sphere);
    float rocks = fbm(p * 0.5 + u_time * 0.1) * 0.5 - 0.3;
    d += rocks * smoothstep(-2.0, 2.0, p.y);
    return d * 0.8;
}

vec3 getNormal(vec3 p) {
    vec2 e = vec2(0.001, 0.0);
    return normalize(vec3(
        map(p + e.xyy) - map(p - e.xyy),
        map(p + e.yxy) - map(p - e.yxy),
        map(p + e.yyx) - map(p - e.yyx)
    ));
}

float softShadow(vec3 ro, vec3 rd, float mint, float maxt, float k) {
    float res = 1.0;
    float t = mint;
    for (int i = 0; i < 24; i++) {
        if (t > maxt) break;
        float h = map(ro + rd * t);
        if (h < 0.001) return 0.0;
        res = min(res, k * h / t);
        t += h;
    }
    return res;
}

vec3 getSkyColor(vec3 rd) {
    float sun = max(0.0, dot(rd, normalize(vec3(0.5, 0.3, 0.8))));
    vec3 sky = mix(vec3(0.4, 0.6, 0.9), vec3(0.9, 0.7, 0.5), rd.y * 0.5 + 0.5);
    sky += vec3(1.0, 0.8, 0.4) * pow(sun, 32.0) * 0.5;
    sky += vec3(1.0, 0.6, 0.3) * pow(sun, 4.0) * 0.3;
    return sky;
}

vec3 getMaterial(vec3 p, vec3 n) {
    float snow = smoothstep(1.5, 3.0, p.y + fbm(p * 0.3) * 2.0);
    float grass = smoothstep(0.0, 1.0, p.y + fbm(p * 0.2) * 1.5);
    float rock = 1.0 - snow - grass;
    
    vec3 snowCol = vec3(0.95, 0.97, 1.0);
    vec3 grassCol = mix(vec3(0.15, 0.35, 0.1), vec3(0.2, 0.45, 0.15), fbm(p * 2.0));
    vec3 rockCol = mix(vec3(0.3, 0.28, 0.25), vec3(0.4, 0.35, 0.3), fbm(p * 1.5));
    
    vec3 mat = snowCol * snow + grassCol * grass + rockCol * rock;
    mat += vec3(0.1, 0.05, 0.02) * noise(p * 10.0);
    
    return mat;
}

float volumetricFog(vec3 ro, vec3 rd, float t) {
    float fogAccum = 0.0;
    float stepSize = t / float(FOG_STEPS);
    float fogHeight = 5.0;
    
    for (int i = 0; i < FOG_STEPS; i++) {
        vec3 p = ro + rd * stepSize * float(i);
        float heightFog = exp(-max(0.0, p.y + 2.0) / fogHeight);
        float density = FOG_DENSITY * heightFog;
        density *= 0.5 + 0.5 * fbm(p * 0.1 + u_time * 0.05);
        float cloudNoise = fbm(p * 0.05 + vec3(u_time * 0.02, 0.0, u_time * 0.01));
        density *= smoothstep(0.3, 0.7, cloudNoise);
        fogAccum += density * stepSize;
    }
    
    return 1.0 - exp(-fogAccum);
}

vec3 getFogColor(vec3 rd, vec3 p, float sun) {
    float heightGrad = exp(-max(0.0, p.y + 2.0) / 3.0);
    vec3 fogCol = mix(vec3(0.7, 0.75, 0.85), vec3(0.9, 0.85, 0.75), heightGrad);
    fogCol += vec3(1.0, 0.9, 0.7) * sun * 0.3;
    fogCol += vec3(0.3, 0.2, 0.15) * (1.0 - heightGrad) * 0.2;
    return fogCol;
}

vec3 raymarch(vec3 ro, vec3 rd, out float depth) {
    float t = 0.0;
    depth = MAX_DIST;
    
    for (int i = 0; i < MAX_STEPS; i++) {
        vec3 p = ro + rd * t;
        float d = map(p);
        
        if (d < SURF_DIST) {
            depth = t;
            return p;
        }
        if (t > MAX_DIST) break;
        
        float adaptiveStep = d * 0.8;
        adaptiveStep = max(0.01, min(adaptiveStep, 2.0));
        t += adaptiveStep;
    }
    
    depth = MAX_DIST;
    return ro + rd * MAX_DIST;
}

void main() {
    vec2 uv = (gl_FragCoord.xy - 0.5 * u_resolution.xy) / u_resolution.y;
    
    vec2 mouse = u_mouse;
    if (u_mouse.x == 0.0 && u_mouse.y == 0.0) mouse = vec2(0.5, 0.4);
    
    float camRotY = (mouse.x - 0.5) * 6.28 + u_time * 0.1;
    float camRotX = (mouse.y - 0.5) * 1.5;
    
    vec3 ro = vec3(0.0, 6.0 + camRotX * 4.0, -15.0);
    ro.xz *= rot2D(camRotY);
    ro.xz += vec2(sin(u_time * 0.1) * 3.0, cos(u_time * 0.08) * 2.0);
    
    vec3 target = vec3(0.0, 2.0, 0.0);
    vec3 forward = normalize(target - ro);
    vec3 right = normalize(cross(vec3(0.0, 1.0, 0.0), forward));
    vec3 up = cross(forward, right);
    
    vec3 rd = normalize(forward + uv.x * right + uv.y * up);
    
    vec3 lightDir = normalize(vec3(0.5, 0.4, 0.7));
    float sun = max(0.0, dot(rd, lightDir));
    
    float depth;
    vec3 hitPos = raymarch(ro, rd, depth);
    
    vec3 sky = getSkyColor(rd);
    vec3 col = sky;
    
    if (depth < MAX_DIST) {
        vec3 n = getNormal(hitPos);
        vec3 mat = getMaterial(hitPos, n);
        
        float diff = max(0.0, dot(n, lightDir));
        float amb = 0.3 + 0.7 * max(0.0, n.y);
        float spec = pow(max(0.0, dot(reflect(-lightDir, n), -rd)), 32.0);
        float sh = softShadow(hitPos + n * 0.01, lightDir, 0.1, 20.0, 8.0);
        
        vec3 light = vec3(1.0, 0.95, 0.8) * diff * sh;
        light += vec3(0.4, 0.5, 0.7) * amb;
        light += vec3(1.0, 0.9, 0.7) * spec * sh * 0.5;
        
        col = mat * light;
        
        float ao = 1.0;
        for (int i = 0; i < 5; i++) {
            vec3 aoPos = hitPos + n * float(i) * 0.1;
            ao -= (float(i) * 0.1 - map(aoPos)) / pow(2.0, float(i));
        }
        col *= mix(0.5, 1.0, ao);
        
        float distFog = 1.0 - exp(-depth * 0.015);
        col = mix(col, sky, distFog * 0.5);
    }
    
    float fog = volumetricFog(ro, rd, depth);
    vec3 fogColor = getFogColor(rd, hitPos, sun);
    col = mix(col, fogColor, fog);
    
    float sunGlow = pow(sun, 8.0) * 0.3;
    col += vec3(1.0, 0.7, 0.3) * sunGlow;
    
    col = pow(col, vec3(0.4545));
    col = mix(col, col * col * (3.0 - 2.0 * col), 0.3);
    
    float vignette = 1.0 - dot(uv * 0.5, uv * 0.5);
    col *= mix(0.7, 1.0, vignette);
    
    gl_FragColor = vec4(col, 1.0);
}