precision highp float;

uniform vec2 u_resolution;
uniform float u_time;
uniform vec2 u_mouse;

#define PI 3.14159265359
#define TAU 6.28318530718

float hash(vec2 p) {
    p = fract(p * vec2(123.34, 456.21));
    p += dot(p, p + 45.32);
    return fract(p.x * p.y);
}

vec2 hash2(vec2 p) {
    p = vec2(dot(p, vec2(127.1, 311.7)), dot(p, vec2(269.5, 183.3)));
    return fract(sin(p) * 43758.5453);
}

float noise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    
    float a = hash(i);
    float b = hash(i + vec2(1.0, 0.0));
    float c = hash(i + vec2(0.0, 1.0));
    float d = hash(i + vec2(1.0, 1.0));
    
    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}

float fbm(vec2 p, int octaves) {
    float value = 0.0;
    float amplitude = 0.5;
    float frequency = 1.0;
    float lacunarity = 2.0;
    float gain = 0.5;
    
    for(int i = 0; i < 6; i++) {
        if(i >= octaves) break;
        value += amplitude * noise(p * frequency);
        frequency *= lacunarity;
        amplitude *= gain;
    }
    return value;
}

float turbulence(vec2 p, int octaves) {
    float value = 0.0;
    float amplitude = 0.5;
    float frequency = 1.0;
    
    for(int i = 0; i < 6; i++) {
        if(i >= octaves) break;
        value += amplitude * abs(noise(p * frequency) * 2.0 - 1.0);
        frequency *= 2.0;
        amplitude *= 0.5;
    }
    return value;
}

vec2 domainWarp(vec2 p, float strength) {
    float t = u_time * 0.3;
    vec2 q = vec2(
        fbm(p + vec2(0.0, 0.0) + t * 0.5, 4),
        fbm(p + vec2(5.2, 1.3) - t * 0.4, 4)
    );
    
    vec2 r = vec2(
        fbm(p + 4.0 * q + vec2(1.7, 9.2) + t * 0.3, 4),
        fbm(p + 4.0 * q + vec2(8.3, 2.8) - t * 0.2, 4)
    );
    
    return p + strength * r;
}

vec3 palette(float t, vec3 a, vec3 b, vec3 c, vec3 d) {
    return a + b * cos(TAU * (c * t + d));
}

vec3 cosmicGradient(float t) {
    vec3 a = vec3(0.5, 0.5, 0.5);
    vec3 b = vec3(0.5, 0.5, 0.5);
    vec3 c = vec3(1.0, 1.0, 1.0);
    vec3 d = vec3(0.0, 0.33, 0.67);
    return palette(t, a, b, c, d);
}

vec3 plasmaGradient(float t) {
    return palette(t, 
        vec3(0.5, 0.0, 0.5),
        vec3(0.5, 0.5, 0.5),
        vec3(1.0, 0.7, 0.4),
        vec3(0.0, 0.15, 0.20)
    );
}

void main() {
    vec2 uv = (gl_FragCoord.xy - 0.5 * u_resolution.xy) / min(u_resolution.x, u_resolution.y);
    
    float aspect = u_resolution.x / u_resolution.y;
    uv.x *= aspect;
    
    vec2 mouse = u_mouse * 2.0 - 1.0;
    mouse.x *= aspect;
    
    float time = u_time * 0.2;
    
    vec2 warpedUv = domainWarp(uv * 2.0, 1.2 + 0.3 * sin(time * 0.7));
    
    float warpStrength = 1.5 + 0.5 * sin(time * 0.5);
    warpedUv = domainWarp(warpedUv, warpStrength);
    
    float pattern1 = fbm(warpedUv * 3.0 + time * 0.3, 5);
    float pattern2 = turbulence(warpedUv * 2.0 - time * 0.2, 5);
    float pattern3 = fbm(warpedUv * 4.0 + pattern1 * 2.0, 4);
    
    float combined = pattern1 * 0.5 + pattern2 * 0.3 + pattern3 * 0.2;
    
    float radial = length(uv - mouse * 0.5) * 0.5;
    float radialMask = 1.0 - smoothstep(0.0, 1.5, radial);
    combined = mix(combined, combined * (1.0 + radialMask * 0.5), 0.3);
    
    float ripple = sin(length(uv) * 15.0 - time * 3.0) * 0.5 + 0.5;
    combined += ripple * 0.1;
    
    vec3 color1 = cosmicGradient(combined + time * 0.1);
    vec3 color2 = plasmaGradient(combined * 1.5 - time * 0.15);
    
    float colorMix = sin(combined * PI + time) * 0.5 + 0.5;
    vec3 finalColor = mix(color1, color2, colorMix);
    
    float highlight = pow(max(0.0, dot(normalize(vec3(uv, 1.0)), normalize(vec3(mouse, 1.0)))), 3.0);
    finalColor += vec3(1.0, 0.8, 0.6) * highlight * 0.3;
    
    float edgeGlow = pow(1.0 - length(uv) / 1.5, 2.0);
    finalColor += vec3(0.2, 0.4, 0.6) * edgeGlow * 0.2;
    
    float brightness = 1.0 + combined * 0.3;
    finalColor *= brightness;
    
    finalColor = finalColor / (finalColor + 1.0);
    
    finalColor = pow(finalColor, vec3(0.9));
    
    gl_FragColor = vec4(finalColor, 1.0);
}