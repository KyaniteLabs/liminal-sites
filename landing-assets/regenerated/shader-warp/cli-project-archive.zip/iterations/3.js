precision highp float;

#define PI 3.14159265359
#define TAU 6.28318530718

uniform vec2 u_resolution;
uniform float u_time;
uniform vec2 u_mouse;

float hash(vec2 p) {
    return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
}

float noise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    float a = hash(i);
    float b = hash(i + vec2(1.0, 0.0));
    float c = hash(i + vec2(0.0, 1.0));
    float d = hash(i + vec2(1.0, 1.0));
    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}

float fbm(vec2 p, int octaves) {
    float value = 0.0;
    float amplitude = 0.5;
    float frequency = 1.0;
    for(int i = 0; i < 6; i++) {
        if(i >= octaves) break;
        value += amplitude * noise(p * frequency);
        frequency *= 2.0;
        amplitude *= 0.5;
    }
    return value;
}

vec2 warp(vec2 p, float t) {
    float n1 = fbm(p + t * 0.15, 4);
    float n2 = fbm(p + vec2(5.2, 1.3) + t * 0.12, 4);
    return p + vec2(n1, n2) * 2.5;
}

void main() {
    vec2 uv = (gl_FragCoord.xy - 0.5 * u_resolution.xy) / min(u_resolution.x, u_resolution.y);
    
    float t = u_time * 0.3;
    
    uv *= 3.0;
    
    vec2 w1 = warp(uv, t);
    vec2 w2 = warp(uv * 1.5 + vec2(100.0), t * 0.7);
    vec2 w3 = warp(uv * 0.5 - vec2(50.0), t * 1.3);
    
    float n1 = fbm(w1, 5);
    float n2 = fbm(w2, 4);
    float n3 = fbm(w3, 6);
    
    float pattern = n1 * 0.5 + n2 * 0.3 + n3 * 0.2;
    
    pattern = sin(pattern * TAU + t) * 0.5 + 0.5;
    
    vec3 col1 = vec3(0.1, 0.4, 0.8);
    vec3 col2 = vec3(0.8, 0.2, 0.5);
    vec3 col3 = vec3(0.2, 0.8, 0.6);
    vec3 col4 = vec3(0.9, 0.7, 0.3);
    
    float t2 = t * 0.5;
    vec3 color = mix(col1, col2, sin(pattern * PI + t2) * 0.5 + 0.5);
    color = mix(color, col3, sin(pattern * TAU - t2 * 0.7) * 0.5 + 0.5);
    color = mix(color, col4, fbm(uv * 2.0 + t * 0.2, 3) * 0.4);
    
    float brightness = 0.6 + 0.4 * pattern;
    color *= brightness;
    
    float vignette = 1.0 - length(uv) * 0.3;
    color *= vignette;
    
    color = pow(color, vec3(0.9));
    
    gl_FragColor = vec4(color, 1.0);
}