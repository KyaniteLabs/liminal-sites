precision highp float;

uniform vec2 u_resolution;
uniform float u_time;
uniform vec2 u_mouse;

#define PI 3.14159265359
#define TAU 6.28318530718

float hash(vec2 p) {
    p = fract(p * vec2(123.34, 456.21));
    p += dot(p, p + 45.32);
    return fract(p.x * p.y);
}

float hash3(vec3 p) {
    p = fract(p * vec3(123.34, 456.21, 789.63));
    p += dot(p, p.yzx + 19.19);
    return fract(p.x * p.y * p.z);
}

vec2 hash2(vec2 p) {
    p = vec2(dot(p, vec2(127.1, 311.7)), dot(p, vec2(269.5, 183.3)));
    return fract(sin(p) * 43758.5453);
}

float noise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    float a = hash(i);
    float b = hash(i + vec2(1.0, 0.0));
    float c = hash(i + vec2(0.0, 1.0));
    float d = hash(i + vec2(1.0, 1.0));
    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}

float noise3(vec3 p) {
    vec3 i = floor(p);
    vec3 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    float n = mix(mix(mix(hash3(i), hash3(i + vec3(1,0,0)), f.x),
                      mix(hash3(i + vec3(0,1,0)), hash3(i + vec3(1,1,0)), f.x), f.y),
                  mix(mix(hash3(i + vec3(0,0,1)), hash3(i + vec3(1,0,1)), f.x),
                      mix(hash3(i + vec3(0,1,1)), hash3(i + vec3(1,1,1)), f.x), f.y), f.z);
    return n;
}

float fbm(vec2 p, int octaves) {
    float value = 0.0;
    float amplitude = 0.5;
    float frequency = 1.0;
    for(int i = 0; i < 6; i++) {
        if(i >= octaves) break;
        value += amplitude * noise(p * frequency);
        frequency *= 2.0;
        amplitude *= 0.5;
    }
    return value;
}

float fbm3(vec3 p, int octaves) {
    float value = 0.0;
    float amplitude = 0.5;
    float frequency = 1.0;
    for(int i = 0; i < 5; i++) {
        if(i >= octaves) break;
        value += amplitude * noise3(p * frequency);
        frequency *= 2.0;
        amplitude *= 0.5;
    }
    return value;
}

vec2 warp(vec2 p, float t) {
    float n1 = fbm(p + t * 0.1, 4);
    float n2 = fbm(p + vec2(n1) + t * 0.15, 4);
    return vec2(n1, n2);
}

float domainWarp(vec2 p, float t) {
    vec2 q = vec2(
        fbm(p + vec2(0.0, 0.0) + t * 0.2, 5),
        fbm(p + vec2(5.2, 1.3) + t * 0.25, 5)
    );
    
    vec2 r = vec2(
        fbm(p + 4.0 * q + vec2(1.7, 9.2) + t * 0.3, 5),
        fbm(p + 4.0 * q + vec2(8.3, 2.8) + t * 0.35, 5)
    );
    
    return fbm(p + 4.0 * r, 6);
}

float voronoi(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    float minDist = 1.0;
    for(int y = -1; y <= 1; y++) {
        for(int x = -1; x <= 1; x++) {
            vec2 neighbor = vec2(float(x), float(y));
            vec2 point = hash2(i + neighbor);
            point = 0.5 + 0.5 * sin(u_time * 0.5 + TAU * point);
            vec2 diff = neighbor + point - f;
            float dist = length(diff);
            minDist = min(minDist, dist);
        }
    }
    return minDist;
}

vec3 palette(float t, vec3 a, vec3 b, vec3 c, vec3 d) {
    return a + b * cos(TAU * (c * t + d));
}

void main() {
    vec2 uv = gl_FragCoord.xy / u_resolution.xy;
    vec2 aspect = vec2(u_resolution.x / u_resolution.y, 1.0);
    vec2 p = (uv - 0.5) * aspect * 3.0;
    
    float t = u_time * 0.4;
    
    vec2 mouseInfluence = (u_mouse - 0.5) * 0.5;
    p += mouseInfluence * sin(t * 0.3) * 0.5;
    
    float warp1 = domainWarp(p * 1.5, t);
    float warp2 = domainWarp(p * 2.0 + 10.0, t * 0.7);
    
    vec2 warped = p + vec2(warp1, warp2) * 0.8;
    
    float n1 = fbm(warped * 2.0, 6);
    float n2 = fbm(warped * 3.0 + 20.0, 6);
    float n3 = fbm(warped * 1.5 + vec2(n1, n2) * 2.0, 5);
    
    float v1 = voronoi(warped * 2.0 + n1 * 0.5);
    float v2 = voronoi(warped * 3.0 - t * 0.2);
    
    float flow = fbm3(vec3(warped * 4.0, t * 0.5), 4);
    
    vec2 spiral = vec2(
        atan(p.y, p.x) / TAU,
        length(p) * 0.5 + sin(length(p) * 3.0 - t) * 0.2
    );
    float spiralNoise = fbm(spiral * 5.0 + t * 0.3, 4);
    
    float pattern = 0.0;
    pattern += n1 * 0.4;
    pattern += n2 * 0.3;
    pattern += n3 * 0.2;
    pattern += v1 * 0.15;
    pattern += v2 * 0.1;
    pattern += flow * 0.1;
    pattern += spiralNoise * 0.1;
    
    pattern = smoothstep(0.0, 1.0, pattern);
    
    vec3 col1 = palette(pattern + t * 0.1, 
        vec3(0.5, 0.5, 0.5),
        vec3(0.5, 0.5, 0.5),
        vec3(1.0, 1.0, 1.0),
        vec3(0.0, 0.33, 0.67));
    
    vec3 col2 = palette(pattern * 1.5 - t * 0.05,
        vec3(0.5, 0.5, 0.5),
        vec3(0.5, 0.5, 0.5),
        vec3(2.0, 1.0, 0.0),
        vec3(0.5, 0.2, 0.25));
    
    vec3 col3 = palette(flow + warp1,
        vec3(0.3, 0.2, 0.4),
        vec3(0.4, 0.3, 0.2),
        vec3(1.0, 0.7, 0.4),
        vec3(0.0, 0.15, 0.2));
    
    vec3 finalColor = mix(col1, col2, sin(pattern * PI + t) * 0.5 + 0.5);
    finalColor = mix(finalColor, col3, v1 * 0.5 + 0.3);
    
    float edge = fwidth(pattern) * 2.0;
    finalColor += vec3(1.0, 0.8, 0.6) * smoothstep(0.02, 0.0, abs(v1 - 0.3)) * 0.5;
    
    float vignette = 1.0 - length(uv - 0.5) * 0.5;
    finalColor *= vignette;
    
    float brightness = 0.7 + 0.3 * sin(t * 0.2);
    finalColor *= brightness;
    
    finalColor = pow(finalColor, vec3(0.9));
    
    gl_FragColor = vec4(finalColor, 1.0);
}