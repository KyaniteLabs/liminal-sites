precision highp float;

uniform vec2 u_resolution;
uniform float u_time;
uniform vec2 u_mouse;

#define PI 3.14159265359
#define TAU 6.28318530718

vec3 hash3(vec2 p) {
    vec3 q = vec3(dot(p, vec2(127.1, 311.7)), 
                  dot(p, vec2(269.5, 183.3)), 
                  dot(p, vec2(419.2, 371.9)));
    return fract(sin(q) * 43758.5453);
}

float hash(vec2 p) {
    return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
}

float noise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    vec2 u = f * f * (3.0 - 2.0 * f);
    
    float a = hash(i + vec2(0.0, 0.0));
    float b = hash(i + vec2(1.0, 0.0));
    float c = hash(i + vec2(0.0, 1.0));
    float d = hash(i + vec2(1.0, 1.0));
    
    return mix(mix(a, b, u.x), mix(c, d, u.x), u.y);
}

float fbm(vec2 p) {
    float value = 0.0;
    float amplitude = 0.5;
    float frequency = 1.0;
    
    for(int i = 0; i < 5; i++) {
        value += amplitude * noise(p * frequency);
        amplitude *= 0.5;
        frequency *= 2.0;
    }
    return value;
}

vec2 warp(vec2 p, float t) {
    float n1 = fbm(p + vec2(t * 0.1, t * 0.15));
    float n2 = fbm(p + vec2(t * 0.12, -t * 0.08));
    return p + vec2(n1, n2) * 2.0;
}

vec2 curl(vec2 p, float t) {
    float eps = 0.01;
    float n1 = fbm(p + vec2(t * 0.1, t * 0.15));
    float n2 = fbm(p + vec2(t * 0.12 + eps, t * 0.15));
    float n3 = fbm(p + vec2(t * 0.1, t * 0.15 + eps));
    
    float dx = (n2 - n1) / eps;
    float dy = (n3 - n1) / eps;
    
    return vec2(dy, -dx) * 2.0;
}

float pattern(vec2 p, float t, out vec2 q, out vec2 r) {
    q.x = fbm(p + vec2(t * 0.2, 0.0));
    q.y = fbm(p + vec2(0.0, t * 0.25));
    
    r.x = fbm(p + 4.0 * q + vec2(t * 0.3, t * 0.1));
    r.y = fbm(p + 4.0 * q + vec2(-t * 0.15, t * 0.2));
    
    vec2 warped = p + 3.0 * r;
    
    float n = fbm(warped + t * 0.1);
    
    return n;
}

vec3 palette(float t) {
    vec3 a = vec3(0.5, 0.5, 0.5);
    vec3 b = vec3(0.5, 0.5, 0.5);
    vec3 c = vec3(1.0, 1.0, 1.0);
    vec3 d = vec3(0.263, 0.416, 0.557);
    
    return a + b * cos(TAU * (c * t + d));
}

vec3 palette2(float t) {
    vec3 a = vec3(0.6, 0.2, 0.8);
    vec3 b = vec3(0.4, 0.5, 0.3);
    vec3 c = vec3(0.9, 0.8, 0.7);
    vec3 d = vec3(0.1, 0.9, 0.4);
    
    return a + b * cos(TAU * (c * t + d));
}

void main() {
    vec2 uv = (gl_FragCoord.xy - 0.5 * u_resolution.xy) / min(u_resolution.x, u_resolution.y);
    vec2 origUV = uv;
    
    float t = u_time * 0.5;
    
    vec2 warpedUV = warp(uv * 3.0, t);
    vec2 curledUV = uv + curl(uv * 2.0, t);
    
    vec2 q, r;
    float n = pattern(uv * 2.0, t, q, r);
    
    float n1 = fbm(warpedUV);
    float n2 = fbm(curledUV * 2.0 + t * 0.3);
    float n3 = fbm(uv * 5.0 + t * 0.2);
    
    float combined = n * 0.5 + n1 * 0.3 + n2 * 0.2;
    
    float warpStrength = 0.5 + 0.3 * sin(t * 0.5);
    vec2 finalUV = uv + vec2(n) * warpStrength;
    
    float finalNoise = fbm(finalUV * 4.0 + t);
    
    float edge = fwidth(finalNoise) * 2.0;
    float lines = smoothstep(0.3 - edge, 0.3 + edge, finalNoise) - 
                  smoothstep(0.6 - edge, 0.6 + edge, finalNoise);
    
    vec3 col1 = palette(combined + t * 0.1);
    vec3 col2 = palette2(n2 + t * 0.15);
    vec3 col3 = palette(length(origUV) + t * 0.2);
    
    vec3 color = mix(col1, col2, n1);
    color = mix(color, col3, n3 * 0.5);
    
    color += lines * vec3(0.2, 0.3, 0.4);
    
    float glow = exp(-length(origUV) * 2.0) * 0.3;
    color += glow * palette(n + t * 0.2);
    
    float ripple = sin(length(origUV) * 20.0 - t * 3.0) * 0.5 + 0.5;
    ripple *= exp(-length(origUV) * 3.0);
    color += ripple * 0.1 * col1;
    
    float vignette = 1.0 - length(origUV) * 0.5;
    color *= vignette;
    
    color = pow(color, vec3(0.9));
    
    color = mix(color, vec3(dot(color, vec3(0.333))), -0.1);
    
    gl_FragColor = vec4(color, 1.0);
}