precision highp float;

uniform vec2 u_resolution;
uniform float u_time;
uniform vec2 u_mouse;

#define PI 3.14159265359
#define TAU 6.28318530718

float hash(vec2 p) {
    return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453123);
}

float hash3(vec3 p) {
    return fract(sin(dot(p, vec3(127.1, 311.7, 74.7))) * 43758.5453123);
}

float noise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    
    float a = hash(i);
    float b = hash(i + vec2(1.0, 0.0));
    float c = hash(i + vec2(0.0, 1.0));
    float d = hash(i + vec2(1.0, 1.0));
    
    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}

float noise3(vec3 p) {
    vec3 i = floor(p);
    vec3 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    
    float n = mix(
        mix(mix(hash3(i), hash3(i + vec3(1,0,0)), f.x),
            mix(hash3(i + vec3(0,1,0)), hash3(i + vec3(1,1,0)), f.x), f.y),
        mix(mix(hash3(i + vec3(0,0,1)), hash3(i + vec3(1,0,1)), f.x),
            mix(hash3(i + vec3(0,1,1)), hash3(i + vec3(1,1,1)), f.x), f.y),
        f.z);
    return n;
}

float fbm(vec2 p, int octaves) {
    float value = 0.0;
    float amplitude = 0.5;
    float frequency = 1.0;
    
    for(int i = 0; i < 6; i++) {
        if(i >= octaves) break;
        value += amplitude * noise(p * frequency);
        frequency *= 2.0;
        amplitude *= 0.5;
    }
    return value;
}

float fbm3(vec3 p, int octaves) {
    float value = 0.0;
    float amplitude = 0.5;
    float frequency = 1.0;
    
    for(int i = 0; i < 5; i++) {
        if(i >= octaves) break;
        value += amplitude * noise3(p * frequency);
        frequency *= 2.0;
        amplitude *= 0.5;
    }
    return value;
}

vec2 warp(vec2 p, float t) {
    vec2 q = vec2(
        fbm(p + vec2(0.0, 0.0) + 0.1 * t, 4),
        fbm(p + vec2(5.2, 1.3) + 0.12 * t, 4)
    );
    
    vec2 r = vec2(
        fbm(p + 4.0 * q + vec2(1.7, 9.2) + 0.15 * t, 4),
        fbm(p + 4.0 * q + vec2(8.3, 2.8) + 0.13 * t, 4)
    );
    
    return r;
}

vec3 palette(float t) {
    vec3 a = vec3(0.5, 0.5, 0.5);
    vec3 b = vec3(0.5, 0.5, 0.5);
    vec3 c = vec3(1.0, 1.0, 1.0);
    vec3 d = vec3(0.263, 0.416, 0.557);
    
    return a + b * cos(TAU * (c * t + d));
}

vec3 palette2(float t) {
    vec3 a = vec3(0.8, 0.5, 0.4);
    vec3 b = vec3(0.2, 0.4, 0.2);
    vec3 c = vec3(2.0, 1.0, 1.0);
    vec3 d = vec3(0.0, 0.25, 0.25);
    
    return a + b * cos(TAU * (c * t + d));
}

void main() {
    vec2 uv = (gl_FragCoord.xy - 0.5 * u_resolution) / min(u_resolution.x, u_resolution.y);
    
    float t = u_time * 0.3;
    
    vec2 w1 = warp(uv * 2.0, t);
    vec2 w2 = warp(uv * 3.0 + vec2(3.14, 2.71), t * 0.7);
    vec2 w3 = warp(uv * 1.5 - vec2(1.23, 4.56), t * 1.3);
    
    float n1 = fbm(uv * 2.0 + w1 * 3.0, 5);
    float n2 = fbm(uv * 3.0 + w2 * 2.5 + n1, 4);
    float n3 = fbm(uv * 4.0 + w3 * 2.0 + n2 * 0.5, 3);
    
    float warpStrength = fbm(w1 * 2.0 + n2, 3) * 0.5 + 0.5;
    float flowPattern = fbm3(vec3(uv * 8.0, t * 0.5), 4);
    
    vec3 col1 = palette(n1 + t * 0.1);
    vec3 col2 = palette2(n2 - t * 0.08);
    vec3 col3 = palette((n3 + flowPattern) * 0.5 + t * 0.05);
    
    vec3 finalColor = mix(col1, col2, n1 * n2);
    finalColor = mix(finalColor, col3, warpStrength * 0.7);
    
    float edge = fwidth(n3);
    float glow = smoothstep(0.0, 0.3, n3) * 0.5;
    
    finalColor += vec3(glow * 0.3, glow * 0.2, glow * 0.4);
    
    float vignette = 1.0 - length(uv) * 0.4;
    finalColor *= vignette;
    
    finalColor = pow(finalColor, vec3(0.85));
    
    finalColor += (hash(uv + t) - 0.5) * 0.03;
    
    gl_FragColor = vec4(finalColor, 1.0);
}