<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rotating Geometric Shapes</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            overflow: hidden;
            background: #000;
        }
        canvas {
            display: block;
        }
        #info {
            position: absolute;
            bottom: 20px;
            left: 50%;
            transform: translateX(-50%);
            color: rgba(255,255,255,0.6);
            font-family: 'Segoe UI', sans-serif;
            font-size: 14px;
            pointer-events: none;
        }
    </style>
</head>
<body>
    <div id="info">Drag to orbit • Scroll to zoom</div>
    <script type="importmap">{"imports":{"three":"https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.module.js","three/addons/":"https://cdn.jsdelivr.net/npm/three@0.160.0/examples/jsm/"}}</script>
    <script type="module">
        import * as THREE from 'three';
        import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
        import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
        import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
        import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js';

        let scene, camera, renderer, composer, controls;
        let shapes = [];
        let pointLights = [];
        let time = 0;

        function init() {
            scene = new THREE.Scene();
            scene.background = new THREE.Color(0x0a0a15);
            scene.fog = new THREE.FogExp2(0x0a0a15, 0.02);

            camera = new THREE.PerspectiveCamera(60, window.innerWidth / window.innerHeight, 0.1, 1000);
            camera.position.set(0, 5, 15);

            renderer = new THREE.WebGLRenderer({ antialias: true });
            renderer.setSize(window.innerWidth, window.innerHeight);
            renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
            renderer.toneMapping = THREE.ACESFilmicToneMapping;
            renderer.toneMappingExposure = 1.2;
            document.body.appendChild(renderer.domElement);

            controls = new OrbitControls(camera, renderer.domElement);
            controls.enableDamping = true;
            controls.dampingFactor = 0.05;
            controls.minDistance = 5;
            controls.maxDistance = 50;
            controls.autoRotate = true;
            controls.autoRotateSpeed = 0.5;

            setupLighting();
            createShapes();
            setupPostProcessing();

            window.addEventListener('resize', onWindowResize);
            animate();
        }

        function setupLighting() {
            const ambientLight = new THREE.AmbientLight(0x222244, 0.5);
            scene.add(ambientLight);

            const hemisphereLight = new THREE.HemisphereLight(0x4444ff, 0x444444, 0.3);
            scene.add(hemisphereLight);

            const colors = [0xff4444, 0x44ff44, 0x4444ff, 0xffff44, 0xff44ff];
            for (let i = 0; i < 5; i++) {
                const light = new THREE.PointLight(colors[i], 2, 25);
                light.userData = {
                    angle: (i / 5) * Math.PI * 2,
                    radius: 8,
                    speed: 0.3 + Math.random() * 0.2,
                    heightOffset: Math.sin(i * 1.5) * 2
                };
                pointLights.push(light);
                scene.add(light);
            }

            const directionalLight = new THREE.DirectionalLight(0xffffff, 0.5);
            directionalLight.position.set(5, 10, 5);
            scene.add(directionalLight);
        }

        function createShapes() {
            const materials = [
                new THREE.MeshStandardMaterial({ color: 0xff6b6b, metalness: 0.3, roughness: 0.4 }),
                new THREE.MeshStandardMaterial({ color: 0x4ecdc4, metalness: 0.5, roughness: 0.3 }),
                new THREE.MeshStandardMaterial({ color: 0xffe66d, metalness: 0.4, roughness: 0.5 }),
                new THREE.MeshStandardMaterial({ color: 0x95e1d3, metalness: 0.6, roughness: 0.2 }),
                new THREE.MeshStandardMaterial({ color: 0xf38181, metalness: 0.2, roughness: 0.6 }),
                new THREE.MeshStandardMaterial({ color: 0xaa96da, metalness: 0.7, roughness: 0.1 }),
                new THREE.MeshStandardMaterial({ color: 0xfcbad3, metalness: 0.4, roughness: 0.4 }),
                new THREE.MeshStandardMaterial({ color: 0xa8d8ea, metalness: 0.5, roughness: 0.3 })
            ];

            const geometries = [
                new THREE.IcosahedronGeometry(1, 0),
                new THREE.OctahedronGeometry(1, 0),
                new THREE.TetrahedronGeometry(1, 0),
                new THREE.TorusKnotGeometry(0.6, 0.2, 64, 8),
                new THREE.DodecahedronGeometry(1, 0),
                new THREE.TorusGeometry(0.8, 0.3, 16, 32),
                new THREE.ConeGeometry(0.8, 1.5, 6),
                new THREE.BoxGeometry(1.2, 1.2, 1.2)
            ];

            const positions = [
                { x: 0, y: 0, z: 0, scale: 1.5 },
                { x: 5, y: 2, z: -3, scale: 1 },
                { x: -4, y: -1, z: -4, scale: 0.8 },
                { x: 3, y: -2, z: 3, scale: 1.2 },
                { x: -5, y: 1, z: 2, scale: 0.9 },
                { x: -2, y: 3, z: -2, scale: 0.7 },
                { x: 4, y: -1, z: 4, scale: 1.1 },
                { x: -3, y: -3, z: -1, scale: 0.85 }
            ];

            for (let i = 0; i < geometries.length; i++) {
                const material = materials[i].clone();
                material.emissive = material.color.clone();
                material.emissiveIntensity = 0.1;

                const mesh = new THREE.Mesh(geometries[i], material);
                mesh.position.set(positions[i].x, positions[i].y, positions[i].z);
                mesh.scale.setScalar(positions[i].scale);
                mesh.userData = {
                    rotationSpeed: {
                        x: (Math.random() - 0.5) * 0.02,
                        y: (Math.random() - 0.5) * 0.02,
                        z: (Math.random() - 0.5) * 0.02
                    },
                    floatOffset: Math.random() * Math.PI * 2,
                    floatSpeed: 0.5 + Math.random() * 0.5,
                    floatAmplitude: 0.3 + Math.random() * 0.3,
                    baseY: positions[i].y
                };
                shapes.push(mesh);
                scene.add(mesh);
            }

            const particleCount = 200;
            const particleGeometry = new THREE.BufferGeometry();
            const particlePositions = new Float32Array(particleCount * 3);
            const particleColors = new Float32Array(particleCount * 3);

            for (let i = 0; i < particleCount; i++) {
                const i3 = i * 3;
                const radius = 10 + Math.random() * 15;
                const theta = Math.random() * Math.PI * 2;
                const phi = Math.random() * Math.PI;

                particlePositions[i3] = radius * Math.sin(phi) * Math.cos(theta);
                particlePositions[i3 + 1] = radius * Math.sin(phi) * Math.sin(theta);
                particlePositions[i3 + 2] = radius * Math.cos(phi);

                const color = new THREE.Color();
                color.setHSL(Math.random() * 0.2 + 0.5, 0.8, 0.6);
                particleColors[i3] = color.r;
                particleColors[i3 + 1] = color.g;
                particleColors[i3 + 2] = color.b;
            }

            particleGeometry.setAttribute('position', new THREE.BufferAttribute(particlePositions, 3));
            particleGeometry.setAttribute('color', new THREE.BufferAttribute(particleColors, 3));

            const particleMaterial = new THREE.PointsMaterial({
                size: 0.05,
                vertexColors: true,
                transparent: true,
                opacity: 0.8,
                blending: THREE.AdditiveBlending
            });

            const particles = new THREE.Points(particleGeometry, particleMaterial);
            particles.userData.rotationSpeed = 0.0005;
            shapes.push(particles);
            scene.add(particles);
        }

        function setupPostProcessing() {
            composer = new EffectComposer(renderer);
            composer.addPass(new RenderPass(scene, camera));

            const bloomPass = new UnrealBloomPass(
                new THREE.Vector2(window.innerWidth, window.innerHeight),
                0.8,
                0.4,
                0.85
            );
            composer.addPass(bloomPass);
        }

        function onWindowResize() {
            camera.aspect = window.innerWidth / window.innerHeight;
            camera.updateProjectionMatrix();
            renderer.setSize(window.innerWidth, window.innerHeight);
            composer.setSize(window.innerWidth, window.innerHeight);
        }

        function animate() {
            requestAnimationFrame(animate);
            time += 0.016;

            shapes.forEach((shape, index) => {
                shape.rotation.x += shape.userData.rotationSpeed?.x || 0;
                shape.rotation.y += shape.userData.rotationSpeed?.y || 0.01;
                shape.rotation.z += shape.userData.rotationSpeed?.z || 0;

                if (shape.userData.floatOffset !== undefined) {
                    shape.position.y = shape.userData.baseY + 
                        Math.sin(time * shape.userData.floatSpeed + shape.userData.floatOffset) * 
                        shape.userData.floatAmplitude;
                }
            });

            pointLights.forEach((light, i) => {
                const data = light.userData;
                data.angle += data.speed * 0.01;
                light.position.x = Math.cos(data.angle) * data.radius;
                light.position.z = Math.sin(data.angle) * data.radius;
                light.position.y = 2 + Math.sin(time * 2 + i) * 2 + data.heightOffset;
                light.intensity = 1.5 + Math.sin(time * 3 + i * 0.5) * 0.5;
            });

            controls.update();
            composer.render();
        }

        init();
    </script>
</body>
</html>