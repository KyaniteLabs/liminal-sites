<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dynamic Geometric Shapes</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            overflow: hidden;
            background: #000;
        }
        canvas {
            display: block;
        }
        #info {
            position: absolute;
            bottom: 20px;
            left: 50%;
            transform: translateX(-50%);
            color: rgba(255,255,255,0.7);
            font-family: 'Segoe UI', sans-serif;
            font-size: 14px;
            text-align: center;
            pointer-events: none;
        }
    </style>
</head>
<body>
    <div id="info">Drag to orbit • Scroll to zoom</div>
    <script type="importmap">
    {"imports":{"three":"https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.module.js","three/addons/":"https://cdn.jsdelivr.net/npm/three@0.160.0/examples/jsm/"}}
    </script>
    <script type="module">
        import * as THREE from 'three';
        import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
        import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
        import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
        import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js';

        let scene, camera, renderer, composer, controls;
        let shapes = [];
        let lights = [];
        let time = 0;

        function init() {
            scene = new THREE.Scene();
            scene.background = new THREE.Color(0x0a0a0f);
            scene.fog = new THREE.FogExp2(0x0a0a0f, 0.02);

            camera = new THREE.PerspectiveCamera(60, window.innerWidth / window.innerHeight, 0.1, 1000);
            camera.position.set(0, 8, 20);

            renderer = new THREE.WebGLRenderer({ antialias: true });
            renderer.setSize(window.innerWidth, window.innerHeight);
            renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
            renderer.toneMapping = THREE.ACESFilmicToneMapping;
            renderer.toneMappingExposure = 1.2;
            document.body.appendChild(renderer.domElement);

            controls = new OrbitControls(camera, renderer.domElement);
            controls.enableDamping = true;
            controls.dampingFactor = 0.05;
            controls.maxDistance = 50;
            controls.minDistance = 5;

            setupLights();
            createShapes();
            setupPostProcessing();
            addParticles();

            window.addEventListener('resize', onWindowResize);
            animate();
        }

        function setupLights() {
            const ambientLight = new THREE.AmbientLight(0x404060, 0.5);
            scene.add(ambientLight);

            const pointLight1 = new THREE.PointLight(0xff6b9d, 2, 50);
            pointLight1.position.set(10, 10, 10);
            scene.add(pointLight1);
            lights.push({ light: pointLight1, baseX: 10, baseY: 10, baseZ: 10, speed: 0.5 });

            const pointLight2 = new THREE.PointLight(0x4ecdc4, 2, 50);
            pointLight2.position.set(-10, 5, -10);
            scene.add(pointLight2);
            lights.push({ light: pointLight2, baseX: -10, baseY: 5, baseZ: -10, speed: 0.7 });

            const pointLight3 = new THREE.PointLight(0xf39c12, 2, 50);
            pointLight3.position.set(0, 15, 0);
            scene.add(pointLight3);
            lights.push({ light: pointLight3, baseX: 0, baseY: 15, baseZ: 0, speed: 0.3 });

            const directionalLight = new THREE.DirectionalLight(0xffffff, 0.5);
            directionalLight.position.set(5, 10, 5);
            scene.add(directionalLight);
        }

        function createShapes() {
            const materials = [
                new THREE.MeshStandardMaterial({ color: 0xff6b9d, metalness: 0.8, roughness: 0.2, emissive: 0xff6b9d, emissiveIntensity: 0.1 }),
                new THREE.MeshStandardMaterial({ color: 0x4ecdc4, metalness: 0.7, roughness: 0.3, emissive: 0x4ecdc4, emissiveIntensity: 0.1 }),
                new THREE.MeshStandardMaterial({ color: 0xf39c12, metalness: 0.9, roughness: 0.1, emissive: 0xf39c12, emissiveIntensity: 0.1 }),
                new THREE.MeshPhysicalMaterial({ color: 0x9b59b6, metalness: 0.6, roughness: 0.2, clearcoat: 1, emissive: 0x9b59b6, emissiveIntensity: 0.05 }),
                new THREE.MeshStandardMaterial({ color: 0x3498db, metalness: 0.7, roughness: 0.3, emissive: 0x3498db, emissiveIntensity: 0.1 })
            ];

            const geometries = [
                new THREE.IcosahedronGeometry(1.5, 0),
                new THREE.OctahedronGeometry(1.5, 0),
                new THREE.TetrahedronGeometry(1.8, 0),
                new THREE.TorusKnotGeometry(1, 0.4, 100, 16),
                new THREE.DodecahedronGeometry(1.3, 0)
            ];

            const positions = [
                { x: 0, y: 0, z: 0 },
                { x: 8, y: 2, z: 4 },
                { x: -6, y: -1, z: 5 },
                { x: 5, y: -2, z: -6 },
                { x: -8, y: 3, z: -3 }
            ];

            const rotationSpeeds = [
                { x: 0.01, y: 0.015, z: 0.005 },
                { x: -0.008, y: 0.012, z: 0.01 },
                { x: 0.012, y: -0.01, z: 0.008 },
                { x: -0.015, y: 0.008, z: -0.012 },
                { x: 0.01, y: 0.01, z: -0.01 }
            ];

            for (let i = 0; i < 5; i++) {
                const mesh = new THREE.Mesh(geometries[i], materials[i]);
                mesh.position.set(positions[i].x, positions[i].y, positions[i].z);
                mesh.rotation.set(Math.random() * Math.PI, Math.random() * Math.PI, Math.random() * Math.PI);
                mesh.userData = {
                    rotationSpeed: rotationSpeeds[i],
                    floatOffset: Math.random() * Math.PI * 2,
                    floatSpeed: 0.5 + Math.random() * 0.5,
                    floatAmplitude: 0.5 + Math.random() * 0.5,
                    baseY: positions[i].y
                };
                scene.add(mesh);
                shapes.push(mesh);
            }

            const ringGeometry = new THREE.TorusGeometry(12, 0.05, 16, 100);
            const ringMaterial = new THREE.MeshBasicMaterial({ color: 0x4ecdc4, transparent: true, opacity: 0.3 });
            for (let i = 0; i < 3; i++) {
                const ring = new THREE.Mesh(ringGeometry, ringMaterial.clone());
                ring.rotation.x = Math.PI / 2 + (i * 0.3);
                ring.rotation.y = i * 0.5;
                ring.userData = { rotationSpeed: 0.002 * (i + 1) };
                scene.add(ring);
                shapes.push(ring);
            }
        }

        function setupPostProcessing() {
            composer = new EffectComposer(renderer);
            const renderPass = new RenderPass(scene, camera);
            composer.addPass(renderPass);

            const bloomPass = new UnrealBloomPass(
                new THREE.Vector2(window.innerWidth, window.innerHeight),
                0.8,
                0.4,
                0.85
            );
            composer.addPass(bloomPass);
        }

        function addParticles() {
            const particleCount = 500;
            const positions = new Float32Array(particleCount * 3);
            const colors = new Float32Array(particleCount * 3);

            const colorPalette = [
                new THREE.Color(0xff6b9d),
                new THREE.Color(0x4ecdc4),
                new THREE.Color(0xf39c12),
                new THREE.Color(0x9b59b6)
            ];

            for (let i = 0; i < particleCount; i++) {
                positions[i * 3] = (Math.random() - 0.5) * 60;
                positions[i * 3 + 1] = (Math.random() - 0.5) * 60;
                positions[i * 3 + 2] = (Math.random() - 0.5) * 60;

                const color = colorPalette[Math.floor(Math.random() * colorPalette.length)];
                colors[i * 3] = color.r;
                colors[i * 3 + 1] = color.g;
                colors[i * 3 + 2] = color.b;
            }

            const geometry = new THREE.BufferGeometry();
            geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
            geometry.setAttribute('color', new THREE.BufferAttribute(colors, 3));

            const material = new THREE.PointsMaterial({
                size: 0.1,
                vertexColors: true,
                transparent: true,
                opacity: 0.6,
                blending: THREE.AdditiveBlending
            });

            const particles = new THREE.Points(geometry, material);
            particles.userData = { rotationSpeed: 0.0002 };
            scene.add(particles);
        }

        function onWindowResize() {
            camera.aspect = window.innerWidth / window.innerHeight;
            camera.updateProjectionMatrix();
            renderer.setSize(window.innerWidth, window.innerHeight);
            composer.setSize(window.innerWidth, window.innerHeight);
        }

        function animate() {
            requestAnimationFrame(animate);
            time += 0.016;

            shapes.forEach((shape, index) => {
                if (index < 5) {
                    shape.rotation.x += shape.userData.rotationSpeed.x;
                    shape.rotation.y += shape.userData.rotationSpeed.y;
                    shape.rotation.z += shape.userData.rotationSpeed.z;
                    shape.position.y = shape.userData.baseY + Math.sin(time * shape.userData.floatSpeed + shape.userData.floatOffset) * shape.userData.floatAmplitude;
                } else {
                    shape.rotation.z += shape.userData.rotationSpeed;
                }
            });

            lights.forEach((lightData, index) => {
                const angle = time * lightData.speed + index * 2;
                lightData.light.position.x = lightData.baseX * Math.cos(angle);
                lightData.light.position.z = lightData.baseZ * Math.sin(angle);
                lightData.light.position.y = lightData.baseY + Math.sin(time * 0.5 + index) * 3;
            });

            scene.children.forEach(child => {
                if (child instanceof THREE.Points) {
                    child.rotation.y += child.userData.rotationSpeed;
                }
            });

            controls.update();
            composer.render();
        }

        init();
    </script>
</body>
</html>