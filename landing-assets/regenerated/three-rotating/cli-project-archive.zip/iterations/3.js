const vertices = [];
        const indices = [];
        
        // Create hexagon vertices
        for (let i = 0; i < 6; i++) {
            const angle = (i / 6) * Math.PI * 2;
            vertices.push(
                Math.cos(angle) * size,
                0,
                Math.sin(angle) * size
            );
            vertices.push(
                Math.cos(angle) * size * 0.5,
                size * 0.866,
                Math.sin(angle) * size * 0.5
            );
            vertices.push(
                Math.cos(angle) * size * 0.5,
                -size * 0.866,
                Math.sin(angle) * size * 0.5
            );
        }
        
        // Connect vertices to form faces
        for (let i = 0; i < 6; i++) {
            const base = i * 3;
            indices.push(base, base + 1, base + 2);
        }
        
        geo.setIndex(indices);
        geo.setAttribute('position', new THREE.Float32BufferAttribute(vertices, 3));
        geo.computeVertexNormals();
        return geo;
    }

    // Create custom hexagon
    const hexagonGeo = createHexagon(1.2);
    const hexagonMat = new THREE.MeshStandardMaterial({
        color: 0xff6b35,
        metalness: 0.7,
        roughness: 0.3,
        emissive: 0xff6b35,
        emissiveIntensity: 0.1
    });
    const hexagon = new THREE.Mesh(hexagonGeo, hexagonMat);
    hexagon.position.set(3, 0, 2);
    hexagon.castShadow = true;
    scene.add(hexagon);

    // Store all meshes for animation
    const allMeshes = [
        icosahedron, octahedron, torus, dodecahedron, 
        torusKnot, tetrahedron, cone, capsule, box, hexagon
    ];

    // Animation parameters
    const animationParams = allMeshes.map((mesh, i) => ({
        rotationSpeed: {
            x: (Math.random() - 0.5) * 0.02,
            y: (Math.random() - 0.5) * 0.02,
            z: (Math.random() - 0.5) * 0.01
        },
        floatOffset: i * 0.5,
        floatAmplitude: 0.3 + Math.random() * 0.3,
        floatSpeed: 0.5 + Math.random() * 0.5,
        initialY: mesh.position.y
    }));

    // Handle window resize
    window.addEventListener('resize', () => {
        camera.aspect = window.innerWidth / window.innerHeight;
        camera.updateProjectionMatrix();
        renderer.setSize(window.innerWidth, window.innerHeight);
        composer.setSize(window.innerWidth, window.innerHeight);
    });

    // Animation loop
    const clock = new THREE.Clock();

    function animate() {
        requestAnimationFrame(animate);

        const elapsedTime = clock.getElapsedTime();

        // Animate each mesh
        allMeshes.forEach((mesh, index) => {
            const params = animationParams[index];

            // Rotation
            mesh.rotation.x += params.rotationSpeed.x;
            mesh.rotation.y += params.rotationSpeed.y;
            mesh.rotation.z += params.rotationSpeed.z;

            // Floating motion
            const floatY = Math.sin(elapsedTime * params.floatSpeed + params.floatOffset) * params.floatAmplitude;
            mesh.position.y = params.initialY + floatY;
        });

        // Animate point lights - orbit around the scene
        const lightRadius = 12;
        const lightSpeed = 0.3;
        pointLight.position.x = Math.sin(elapsedTime * lightSpeed) * lightRadius;
        pointLight.position.z = Math.cos(elapsedTime * lightSpeed) * lightRadius;
        pointLight.position.y = 3 + Math.sin(elapsedTime * 0.5) * 2;

        pointLight2.position.x = Math.cos(elapsedTime * lightSpeed * 0.7) * lightRadius;
        pointLight2.position.z = Math.sin(elapsedTime * lightSpeed * 0.7) * lightRadius;
        pointLight2.position.y = -2 + Math.cos(elapsedTime * 0.4) * 2;

        // Animate spot light
        spotLight.position.x = Math.sin(elapsedTime * 0.2) * 8;
        spotLight.position.z = Math.cos(elapsedTime * 0.2) * 8;
        spotLight.target.position.x = Math.sin(elapsedTime * 0.2 + Math.PI) * 3;
        spotLight.target.position.z = Math.cos(elapsedTime * 0.2 + Math.PI) * 3;

        // Rotate particles
        particlesMesh.rotation.y += 0.0003;
        particlesMesh.rotation.x += 0.0001;

        // Update controls
        controls.update();

        // Render with post-processing
        composer.render();
    }

    animate();
    </script>
</body>
</html>