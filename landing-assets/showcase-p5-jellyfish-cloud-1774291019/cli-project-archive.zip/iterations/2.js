// Bioluminescent Jellyfish - p5.js Generative Art

let jellyfish = [];
let particles = [];
let numJellyfish = 5;
let numParticles = 100;
let t = 0;

function setup() {
  createCanvas(800, 600);
  pixelDensity(1);
  noiseSeed(random(10000));
  
  // Create jellyfish
  for (let i = 0; i < numJellyfish; i++) {
    jellyfish.push(new Jellyfish(random(width), random(height * 0.3, height * 0.7), random(30, 80)));
  }
  
  // Create ambient particles
  for (let i = 0; i < numParticles; i++) {
    particles.push(new Particle());
  }
}

function draw() {
  // Deep ocean background with gradient
  drawBackground();
  
  // Draw ambient particles
  for (let p of particles) {
    p.update();
    p.display();
  }
  
  // Draw jellyfish
  for (let j of jellyfish) {
    j.update();
    j.display();
  }
  
  t += 0.005;
}

function drawBackground() {
  // Create deep ocean gradient
  for (let y = 0; y < height; y++) {
    let inter = map(y, 0, height, 0, 1);
    let c = lerpColor(color(10, 20, 50), color(0, 10, 30), inter);
    stroke(c);
    line(0, y, width, y);
  }
  
  // Add some subtle variation
  for (let i = 0; i < 50; i++) {
    let x = noise(i * 0.1, t) * width;
    let y = noise(i * 0.1, t + 100) * height;
    let alpha = noise(i * 0.1, t + 200) * 30;
    fill(100, 150, 200, alpha);
    noStroke();
    ellipse(x, y, 2, 2);
  }
}

class Jellyfish {
  constructor(x, y, size) {
    this.x = x;
    this.y = y;
    this.size = size;
    this.numTentacles = 12;
    this.tentacleLength = size * 2;
    this.pulseSpeed = random(0.02, 0.04);
    this.pulseOffset = random(TWO_PI);
    this.hue = random(180, 280); // Cyan to purple range
    this.hueSpeed = random(0.001, 0.003);
  }

  update() {
    // Gentle floating movement
    this.x += noise(t * 0.5, this.y * 0.01) - 0.5;
    this.y += noise(t * 0.3, this.x * 0.01) - 0.5;
    
    // Keep jellyfish on screen with wrapping
    if (this.x < -this.size) this.x = width + this.size;
    if (this.x > width + this.size) this.x = -this.size;
    if (this.y < -this.size) this.y = height + this.size;
    if (this.y > height + this.size) this.y = -this.size;
  }

  display() {
    // Pulsing effect
    let pulse = sin(t * this.pulseSpeed * 100 + this.pulseOffset) * 0.15 + 1;
    let currentHue = (this.hue + t * this.hueSpeed * 100) % 360;
    
    // Draw outer glow
    for (let i = 5; i > 0; i--) {
      let glowSize = this.size * pulse * (1 + i * 0.3);
      let alpha = map(i, 5, 0, 10, 50);
      fill(currentHue, 80, 100, alpha);
      noStroke();
      ellipse(this.x, this.y, glowSize * 2, glowSize * 1.5);
    }
    
    // Draw bell
    fill(currentHue, 70, 90, 200);
    stroke(currentHue, 80, 100);
    strokeWeight(2);
    arc(this.x, this.y, this.size * 2 * pulse, this.size * 1.5 * pulse, PI, TWO_PI);
    
    // Draw inner glow
    fill(currentHue, 60, 100, 150);
    noStroke();
    ellipse(this.x, this.y - this.size * 0.2, this.size * pulse, this.size * 0.6 * pulse);
    
    // Draw tentacles
    for (let i = 0; i < this.numTentacles; i++) {
      let angle = map(i, 0, this.numTentacles, PI, TWO_PI);
      let startX = this.x + cos(angle) * this.size * 0.8;
      let startY = this.y;
      
      noFill();
      stroke(currentHue, 70, 80, 180);
      strokeWeight(1.5);
      
      beginShape();
      for (let j = 0; j < this.tentacleLength; j += 5) {
        let noiseVal = noise(i * 0.5, j * 0.05, t);
        let xOffset = map(noiseVal, 0, 1, -30, 30);
        let yOffset = j * 1.5;
        curveVertex(startX + xOffset, startY + yOffset);
      }
      endShape();
    }
  }
}

class Particle {
  constructor() {
    this.reset();
  }

  reset() {
    this.x = random(width);
    this.y = random(height);
    this.size = random(1, 3);
    this.speed = random(0.2, 0.8);
    this.alpha = random(50, 150);
    this.hue = random(180, 280);
  }

  update() {
    this.y -= this.speed;
    this.x += noise(this.x * 0.01, this.y * 0.01, t) - 0.5;
    
    if (this.y < 0) {
      this.reset();
      this.y = height;
    }
  }

  display() {
    noStroke();
    fill(this.hue, 60, 100, this.alpha);
    ellipse(this.x, this.y, this.size);
  }
}