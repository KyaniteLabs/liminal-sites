<think>
The user wants a p5.js generative art sketch featuring bioluminescent jellyfish with organic flowing tentacles using Perlin noise.

Let me create a complete, self-contained p5.js sketch that:
1. Creates bioluminescent jellyfish with glowing effects
2. Uses noise() for organic tentacle movement
3. Features multiple jellyfish at different depths/sizes
4. Has beautiful bioluminescent color palettes (blues, cyans, purples, magentas)
5. Includes ambient particles and glow effects
6. Is responsive to window resize

I'll create:
- Jellyfish class with body (dome/bell) and tentacles
- Perlin noise-based tentacle movement for organic flow
- Glowing effect using multiple layers with transparency
- Particle system for ambient underwater atmosphere
- Multiple jellyfish at various depths

Let me write the complete code:
</think>

let jellyfish = [];
let particles = [];
let numJellyfish = 6;
let numParticles = 100;

function setup() {
  createCanvas(800, 600);
  pixelDensity(1);
  noiseSeed(random(10000));
  
  for (let i = 0; i < numJellyfish; i++) {
    jellyfish.push(new Jellyfish());
  }
  
  for (let i = 0; i < numParticles; i++) {
    particles.push(new Particle());
  }
}

function draw() {
  // Deep ocean background gradient
  drawOceanBackground();
  
  // Draw ambient particles
  for (let p of particles) {
    p.update();
    p.display();
  }
  
  // Sort jellyfish by depth for proper layering
  jellyfish.sort((a, b) => a.depth - b.depth);
  
  // Draw jellyfish
  for (let j of jellyfish) {
    j.update();
    j.display();
  }
  
  // Add subtle water caustics overlay
  drawCaustics();
}

function drawOceanBackground() {
  // Deep ocean gradient
  for (let y = 0; y < height; y++) {
    let inter = map(y, 0, height, 0, 1);
    let c = lerpColor(
      color(10, 20, 50),
      color(5, 15, 35),
      inter
    );
    stroke(c);
    line(0, y, width, y);
  }
  
  // Add some subtle noise to background
  loadPixels();
  for (let i = 0; i < pixels.length; i += 40) {
    let n = noise(pixels[i % width] * 0.001, pixels[i / 4] * 0.001, frameCount * 0.001);
    if (n > 0.5) {
      let idx = i * 4;
      pixels[idx] = min(255, pixels[idx] + 5);
      pixels[idx + 1] = min(255, pixels[idx + 1] + 8);
      pixels[idx + 2] = min(255, pixels[idx + 2] + 15);
    }
  }
  updatePixels();
}

function drawCaustics() {
  push();
  blendMode(ADD);
  noStroke();
  for (let i = 0; i < 15; i++) {
    let x = noise(frameCount * 0.003 + i * 100) * width;
    let y = noise(frameCount * 0.002 + i * 50) * height * 0.3;
    let size = noise(frameCount * 0.005 + i * 25) * 80 + 20;
    
    fill(20, 60, 100, 15);
    ellipse(x, y, size, size * 0.5);
  }
  pop();
}

class Jellyfish {
  constructor() {
    this.x = random(width);
    this.y = random(height * 0.3, height * 0.8);
    this.baseY = this.y;
    this.depth = random(0.3, 1);
    this.size = map(this.depth, 0.3, 1, 80, 30);
    this.numTentacles = floor(map(this.depth, 0.3, 1, 12, 5));
    this.tentacles = [];
    this.pulsePhase = random(TWO_PI);
    this.pulseSpeed = random(0.02, 0.04);
    this.bellOpacity = map(this.depth, 0.3, 1, 180, 120);
    this.noiseOffset = random(1000);
    
    // Color palette - bioluminescent
    this.hueShift = random(180, 280);
    this.baseColor = color(
      150 + sin(this.hueShift) * 100,
      50 + cos(this.hueShift) * 50,
      200 + sin(this.hueShift * 2) * 55,
      this.bellOpacity
    );
    
    // Initialize tentacles
    for (let i = 0; i < this.numTentacles; i++) {
      this.tentacles.push({
        baseX: map(i, 0, this.numTentacles - 1, -this.size * 0.4, this.size * 0.4),
        length: random(60, 150) * this.depth,
        segments: 20,
        thickness: random(2, 5),
        noiseOffset: random(1000),
        phaseOffset: random(TWO_PI)
      });
    }
  }
  
  update() {
    // Gentle floating movement using noise
    let time = frameCount * 0.01;
    this.x += (noise(time + this.noiseOffset) - 0.5) * 0.5;
    this.y = this.baseY + noise(time * 0.5 + this.noiseOffset) * 20 - 10;
    
    // Keep in bounds
    if (this.x < -50) this.x = width + 50;
    if (this.x > width + 50) this.x = -50;
    
    // Pulsing animation
    this.pulsePhase += this.pulseSpeed;
  }
  
  display() {
    push();
    translate(this.x, this.y);
    
    let pulse = sin(this.pulsePhase) * 0.15 + 1;
    let bellWidth = this.size * pulse;
    let bellHeight = this.size * 0.7 * (2 - pulse);
    
    // Draw glow layers (outer to inner)
    this.drawGlow(bellWidth, bellHeight);
    
    // Draw bell (dome)
    this.drawBell(bellWidth, bellHeight);
    
    // Draw inner details
    this.drawBellDetails(bellWidth, bellHeight);
    
    // Draw tentacles
    for (let t of this.tentacles) {
      this.drawTentacle(t, bellWidth, bellHeight);
    }
    
    pop();
  }
  
  drawGlow(w, h) {
    noStroke();
    for (let i = 4; i > 0; i--) {
      let alpha = map(i, 4, 0, 5, 25);
      let expand = i * 15;
      
      let glowColor = color(
        red(this.baseColor),
        green(this.baseColor),
        blue(this.baseColor),
        alpha
      );
      fill(glowColor);
      ellipse(0, 0, w + expand, h + expand * 0.7);
    }
  }
  
  drawBell(w, h) {
    noStroke();
    
    // Main bell gradient
    let steps = 10;
    for (let i = steps; i > 0; i--) {
      let t = i / steps;
      let c = lerpColor(
        color(red(this.baseColor), green(this.baseColor), blue(this.baseColor), this.bellOpacity * 0.3),
        color(red(this.baseColor), green(this.baseColor), blue(this.baseColor), this.bellOpacity),
        t
      );
      fill(c);
      
      let bellW = w * (0.3 + t * 0.7);
      let bellH = h * (0.2 + t * 0.8);
      
      beginShape();
      // Upper dome
      for (let a = -PI; a < 0; a += 0.1) {
        let x = cos(a) * bellW / 2;
        let y = sin(a) * bellH / 2 - bellH * 0.3;
        vertex(x, y);
      }
      // Lower rim
      for (let a = 0; a < PI; a += 0.1) {
        let flare = 1 + sin(a) * 0.15;
        let x = cos(a) * bellW / 2 * flare;
        let y = bellH * 0.2;
        vertex(x, y);
      }
      endShape(CLOSE);
    }
    
    // Inner bell membrane
    fill(red(this.baseColor), green(this.baseColor), blue(this.baseColor), 40);
    beginShape();
    for (let a = -PI * 0.8; a < PI * 0.8; a += 0.1) {
      let x = cos(a) *