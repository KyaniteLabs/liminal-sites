<think>
The user wants me to create a 3D scene featuring various Three.js geometries. Let me create an impressive, visually appealing scene with multiple geometric shapes, good lighting, post-processing effects, and interactive controls.

I'll create a scene with:
1. Multiple interesting geometries (icosahedron, torus knot, octahedron, dodecahedron, etc.)
2. MeshStandardMaterial with interesting colors and properties
3. Good lighting setup
4. Post-processing with bloom
5. Animation (rotation, floating)
6. OrbitControls for interaction
7. Responsive design

Let me build this out:
</think>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Three.js 3D Geometry Showcase</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            overflow: hidden;
            background: #0a0a0a;
            font-family: 'Segoe UI', sans-serif;
        }
        canvas {
            display: block;
        }
        #info {
            position: absolute;
            top: 20px;
            left: 50%;
            transform: translateX(-50%);
            color: rgba(255,255,255,0.8);
            font-size: 14px;
            text-align: center;
            pointer-events: none;
            text-shadow: 0 0 10px rgba(0,0,0,0.5);
        }
        #info h1 {
            font-size: 24px;
            font-weight: 300;
            margin-bottom: 8px;
            letter-spacing: 4px;
        }
    </style>
</head>
<body>
    <div id="info">
        <h1>GEOMETRY SHOWCASE</h1>
        <span>Drag to rotate • Scroll to zoom</span>
    </div>
    
    <script type="importmap">
    {
        "imports": {
            "three": "https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.module.js",
            "three/addons/": "https://cdn.jsdelivr.net/npm/three@0.160.0/examples/jsm/"
        }
    }
    </script>
    
    <script type="module">
        import * as THREE from 'three';
        import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
        import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
        import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
        import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js';

        // Scene setup
        const scene = new THREE.Scene();
        scene.background = new THREE.Color(0x0a0a0f);
        scene.fog = new THREE.Fog(0x0a0a0f, 8, 25);

        // Camera
        const camera = new THREE.PerspectiveCamera(60, window.innerWidth / window.innerHeight, 0.1, 1000);
        camera.position.set(0, 3, 10);

        // Renderer
        const renderer = new THREE.WebGLRenderer({ antialias: true });
        renderer.setSize(window.innerWidth, window.innerHeight);
        renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
        renderer.toneMapping = THREE.ACESFilmicToneMapping;
        renderer.toneMappingExposure = 1.2;
        document.body.appendChild(renderer.domElement);

        // Post-processing
        const composer = new EffectComposer(renderer);
        const renderPass = new RenderPass(scene, camera);
        composer.addPass(renderPass);

        const bloomPass = new UnrealBloomPass(
            new THREE.Vector2(window.innerWidth, window.innerHeight),
            0.8,
            0.4,
            0.85
        );
        composer.addPass(bloomPass);

        // Controls
        const controls = new OrbitControls(camera, renderer.domElement);
        controls.enableDamping = true;
        controls.dampingFactor = 0.05;
        controls.minDistance = 5;
        controls.maxDistance = 20;

        // Lighting
        const ambientLight = new THREE.AmbientLight(0x404060, 0.5);
        scene.add(ambientLight);

        const pointLight1 = new THREE.PointLight(0xff6b6b, 2, 20);
        pointLight1.position.set(5, 5, 5);
        scene.add(pointLight1);

        const pointLight2 = new THREE.PointLight(0x4ecdc4, 2, 20);
        pointLight2.position.set(-5, 3, -5);
        scene.add(pointLight2);

        const pointLight3 = new THREE.PointLight(0xf7d794, 1.5, 15);
        pointLight3.position.set(0, -3, 0);
        scene.add(pointLight3);

        // Create geometries
        const geometries = [];
        const materials = [];

        // 1. Icosahedron - Center front
        const icoGeo = new THREE.IcosahedronGeometry(1.2, 0);
        const icoMat = new THREE.MeshStandardMaterial({
            color: 0xff6b6b,
            metalness: 0.3,
            roughness: 0.4,
            flatShading: true
        });
        const ico = new THREE.Mesh(icoGeo, icoMat);
        ico.position.set(0, 1.5, 0);
        scene.add(ico);
        geometries.push({ mesh: ico, type: 'icosahedron', speed: 0.01 });

        // 2. Torus Knot - Left
        const torusKnotGeo = new THREE.TorusKnotGeometry(0.8, 0.25, 100, 16);
        const torusKnotMat = new THREE.MeshStandardMaterial({
            color: 0x4ecdc4,
            metalness: 0.7,
            roughness: 0.2
        });
        const torusKnot = new THREE.Mesh(torusKnotGeo, torusKnotMat);
        torusKnot.position.set(-4, 1.5, -2);
        scene.add(torusKnot);
        geometries.push({ mesh: torusKnot, type: 'torusKnot', speed: 0.008 });

        // 3. Octahedron - Right
        const octaGeo = new THREE.OctahedronGeometry(1, 0);
        const octaMat = new THREE.MeshStandardMaterial({
            color: 0x9b59b6,
            metalness: 0.5,
            roughness: 0.3,
            flatShading: true
        });
        const octa = new THREE.Mesh(octaGeo, octaMat);
        octa.position.set(4, 1.5, -2);
        scene.add(octa);
        geometries.push({ mesh: octa, type: 'octahedron', speed: 0.012 });

        // 4. Dodecahedron - Back center
        const dodecaGeo = new THREE.DodecahedronGeometry(0.9, 0);
        const dodecaMat = new THREE.MeshStandardMaterial({
            color: 0xf7d794,
            metalness: 0.4,
            roughness: 0.4,
            flatShading: true
        });
        const dodeca = new THREE.Mesh(dodecaGeo, dodecaMat);
        dodeca.position.set(0, 1.5, -5);
        scene.add(dodeca);
        geometries.push({ mesh: dodeca, type: 'dodecahedron', speed: 0.007 });

        // 5. Tetrahedron - Far left
        const tetraGeo = new THREE.TetrahedronGeometry(1.1, 0);
        const tetraMat = new THREE.MeshStandardMaterial({
            color: 0x1abc9c,
            metalness: 0.3,
            roughness: 0.5,
            flatShading: true
        });
        const tetra = new THREE.Mesh(tetraGeo, tetraMat);
        tetra.position.set(-6, 1.5, 0);
        scene.add(tetra);
        geometries.push({ mesh: tetra, type: 'tetrahedron', speed: 0.015 });

        // 6. Torus - Far right
        const torusGeo = new THREE.TorusGeometry(0.8, 0.3, 16, 50);
        const torusMat = new THREE.MeshStandardMaterial({
            color: 0xe74c3c,
            metalness: 0.6,
            roughness: 0.3
        });
        const torus = new THREE.Mesh(torusGeo, torusMat);
        torus.position.set(6, 1.5, 0);
        scene.add(torus);
        geometries.push({ mesh: torus, type: 'torus', speed: 0.01 });

        // 7. Cone (using CylinderGeometry with 0 top radius) - Lower