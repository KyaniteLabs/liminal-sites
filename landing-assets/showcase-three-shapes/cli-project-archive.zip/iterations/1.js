<think>
The user wants a 3D scene with rotating geometric shapes and dynamic lighting. Let me create a complete, self-contained HTML file with:

1. Three.js setup with proper imports
2. Multiple geometric shapes (different types)
3. Dynamic/animated lighting
4. OrbitControls for interaction
5. Post-processing effects for polish
6. Animation loop with object rotation
7. Window resize handling

Let me create an impressive scene with:
- Multiple geometric primitives (icosahedron, torus knot, octahedron, dodecahedron, etc.)
- Dynamic point lights that move/animate
- Post-processing bloom effect
- MeshStandardMaterial with different colors and properties
- Floating/rotating animations


- Camera controls that orbit around the scene

Building the HTML structure...
</think>

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dynamic Geometric Shapes</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { overflow: hidden; background: #0a0a0f; }
        canvas { display: block; }
        #info {
            position: absolute;
            bottom: 20px;
            left: 50%;
            transform: translateX(-50%);
            color: rgba(255,255,255,0.5);
            font-family: 'Segoe UI', sans-serif;
            font-size: 13px;
            letter-spacing: 1px;
            pointer-events: none;
            user-select: none;
        }
    </style>
    <script type="importmap">{"imports":{"three":"https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.module.js","three/addons/":"https://cdn.jsdelivr.net/npm/three@0.160.0/examples/jsm/"}}</script>
</head>
<body>
    <div id="info">DRAG TO ORBIT • SCROLL TO ZOOM</div>
    <script type="module">
        import * as THREE from 'three';
        import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
        import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
        import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
        import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js';

        // Scene setup
        const scene = new THREE.Scene();
        scene.background = new THREE.Color(0x0a0a0f);
        scene.fog = new THREE.FogExp2(0x0a0a0f, 0.035);

        const camera = new THREE.PerspectiveCamera(60, window.innerWidth / window.innerHeight, 0.1, 1000);
        camera.position.set(0, 2, 14);

        const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
        renderer.setSize(window.innerWidth, window.innerHeight);
        renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
        renderer.toneMapping = THREE.ACESFilmicToneMapping;
        renderer.toneMappingExposure = 1.2;
        renderer.shadowMap.enabled = true;
        renderer.shadowMap.type = THREE.PCFSoftShadowMap;
        document.body.appendChild(renderer.domElement);

        // Controls
        const controls = new OrbitControls(camera, renderer.domElement);
        controls.enableDamping = true;
        controls.dampingFactor = 0.05;
        controls.maxDistance = 35;
        controls.minDistance = 4;
        controls.autoRotate = true;
        controls.autoRotateSpeed = 0.5;

        // Post-processing
        const composer = new EffectComposer(renderer);
        const renderPass = new RenderPass(scene, camera);
        composer.addPass(renderPass);

        const bloomPass = new UnrealBloomPass(
            new THREE.Vector2(window.innerWidth, window.innerHeight),
            0.8, 0.4, 0.85
        );
        composer.addPass(bloomPass);

        // Lighting
        const ambientLight = new THREE.AmbientLight(0x1a1a2e, 0.4);
        scene.add(ambientLight);

        const dirLight = new THREE.DirectionalLight(0xffffff, 0.3);
        dirLight.position.set(5, 10, 5);
        dirLight.castShadow = true;
        dirLight.shadow.mapSize.width = 1024;
        dirLight.shadow.mapSize.height = 1024;
        scene.add(dirLight);

        // Dynamic point lights
        const pointLights = [];
        const lightColors = [0xff6b6b, 0x4ecdc4, 0xffe66d, 0xc44eff, 0x6bcbff];

        lightColors.forEach((color, i) => {
            const light = new THREE.PointLight(color, 2, 20);
            light.castShadow = true;
            light.shadow.mapSize.width = 512;
            light.shadow.mapSize.height = 512;
            scene.add(light);
            pointLights.push({ light, angle: (i / lightColors.length) * Math.PI * 2, radius: 5 + i * 0.5, speed: 0.3 + i * 0.1 });
        });

        // Helper sphere for light visualization
        const lightSphereGeo = new THREE.SphereGeometry(0.12, 16, 16);
        pointLights.forEach(({ light }) => {
            const mat = new THREE.MeshBasicMaterial({ color: light.color });
            const sphere = new THREE.Mesh(lightSphereGeo, mat);
            sphere.position.copy(light.position);
            scene.add(sphere);
            light.userData.sphere = sphere;
        });

        // Shapes data
        const shapes = [];

        function createMaterial(color, emissive = null, metalness = 0.7, roughness = 0.2) {
            return new THREE.MeshStandardMaterial({
                color: color,
                emissive: emissive || color,
                emissiveIntensity: 0.15,
                metalness: metalness,
                roughness: roughness,
            });
        }

        // Central icosahedron
        const icoGeo = new THREE.IcosahedronGeometry(2.2, 1);
        const icoMat = createMaterial(0x4ecdc4, 0x4ecdc4, 0.8, 0.15);
        const icosahedron = new THREE.Mesh(icoGeo, icoMat);
        icosahedron.castShadow = true;
        icosahedron.receiveShadow = true;
        scene.add(icosahedron);
        shapes.push({ mesh: icosahedron, rotSpeed: { x: 0.003, y: 0.005, z: 0.002 }, float: { amp: 0.3, speed: 0.8 }, center: true });

        // Torus knot - outer
        const torusKnotGeo = new THREE.TorusKnotGeometry(1.2, 0.35, 120, 16, 2, 3);
        const torusKnotMat = createMaterial(0xff6b6b, 0xff6b6b, 0.6, 0.25);
        const torusKnot = new THREE.Mesh(torusKnotGeo, torusKnotMat);
        torusKnot.castShadow = true;
        torusKnot.receiveShadow = true;
        scene.add(torusKnot);
        shapes.push({ mesh: torusKnot, rotSpeed: { x: 0.008, y: 0.012, z: 0.004 }, float: { amp: 0.5, speed: 0.5 } });

        // Octahedron
        const octaGeo = new THREE.OctahedronGeometry(1, 0);
        const octaMat = createMaterial(0xc44eff, 0xc44eff, 0.9, 0.1);
        const octahedron = new THREE.Mesh(octaGeo, octaMat);
        octahedron.castShadow = true;
        octahedron.receiveShadow = true;
        scene.add(octahedron);
        shapes.push({ mesh: octahedron, rotSpeed: { x: 0.006, y: 0.008, z: 0.01 }, float: { amp: 0.4, speed: 0.7 } });

        // Dodecahedron
        const dodecaGeo = new THREE.DodecahedronGeometry(0.9, 0);
        const dodecaMat = createMaterial(0xffe66d, 0xffe66d, 0.5, 0.3);
        const dodecahedron = new THREE.Mesh(dodecaGeo, dodecaMat);
        dodecahedron.castShadow = true;
        dodecahedron.receiveShadow = true;
        scene.add(dodecahedron);
        shapes.push({ mesh: dodecahedron, rotSpeed: { x: 0.007, y: 0.004, z: 0.009