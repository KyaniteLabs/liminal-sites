<think>
The user wants a 3D scene with rotating geometric shapes and dynamic lighting. Let me create a complete HTML file with:

1. A variety of geometric shapes (not just cubes)
2. Dynamic/animated lighting
3. Good post-processing effects
4. OrbitControls for camera interaction
5. Proper window resize handling
6. Animation loop
7. MeshStandardMaterial or MeshPhysicalMaterial

Let me create an interesting scene with multiple shapes, dynamic lights, and some visual effects.

I'll include:
- Multiple geometric shapes (icosahedron, torus, octahedron, dodecahedron, etc.)
- Animated rotations
- Dynamic point lights that move
- Bloom post-processing
- Good lighting setup
- OrbitControls
- Window resize handling
</think>

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dynamic Geometric Shapes</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            overflow: hidden;
            background: #000;
        }
        canvas {
            display: block;
        }
        #info {
            position: absolute;
            bottom: 20px;
            left: 50%;
            transform: translateX(-50%);
            color: rgba(255, 255, 255, 0.7);
            font-family: 'Segoe UI', sans-serif;
            font-size: 14px;
            text-align: center;
            pointer-events: none;
            text-shadow: 0 0 10px rgba(0, 0, 0, 0.5);
        }
    </style>
</head>
<body>
    <div id="info">Drag to rotate • Scroll to zoom</div>
    <script type="importmap">
    {
        "imports": {
            "three": "https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.module.js",
            "three/addons/": "https://cdn.jsdelivr.net/npm/three@0.160.0/examples/jsm/"
        }
    }
    </script>
    <script type="module">
        import * as THREE from 'three';
        import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
        import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
        import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
        import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js';

        let scene, camera, renderer, composer, controls;
        let shapes = [];
        let lights = [];
        let time = 0;

        function init() {
            scene = new THREE.Scene();
            scene.fog = new THREE.FogExp2(0x0a0a1a, 0.02);

            camera = new THREE.PerspectiveCamera(60, window.innerWidth / window.innerHeight, 0.1, 1000);
            camera.position.set(0, 5, 20);

            renderer = new THREE.WebGLRenderer({ antialias: true });
            renderer.setSize(window.innerWidth, window.innerHeight);
            renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
            renderer.toneMapping = THREE.ACESFilmicToneMapping;
            renderer.toneMappingExposure = 1.2;
            document.body.appendChild(renderer.domElement);

            controls = new OrbitControls(camera, renderer.domElement);
            controls.enableDamping = true;
            controls.dampingFactor = 0.05;
            controls.maxDistance = 50;
            controls.minDistance = 5;

            setupLights();
            createShapes();
            setupPostProcessing();

            window.addEventListener('resize', onWindowResize);
            animate();
        }

        function setupLights() {
            const ambientLight = new THREE.AmbientLight(0x222244, 0.5);
            scene.add(ambientLight);

            const directionalLight = new THREE.DirectionalLight(0xffffff, 1);
            directionalLight.position.set(10, 20, 10);
            scene.add(directionalLight);

            const colors = [0xff6b6b, 0x4ecdc4, 0xffe66d, 0xc44dff, 0x45b7d1];
            
            colors.forEach((color, i) => {
                const light = new THREE.PointLight(color, 2, 30);
                light.userData = {
                    angle: (i / colors.length) * Math.PI * 2,
                    radius: 12 + Math.random() * 5,
                    speed: 0.3 + Math.random() * 0.3,
                    yOffset: Math.sin(i * 1.5) * 3
                };
                lights.push(light);
                scene.add(light);
            });
        }

        function createShapes() {
            const materials = [
                new THREE.MeshStandardMaterial({ color: 0xff6b6b, metalness: 0.3, roughness: 0.4 }),
                new THREE.MeshStandardMaterial({ color: 0x4ecdc4, metalness: 0.5, roughness: 0.3 }),
                new THREE.MeshStandardMaterial({ color: 0xffe66d, metalness: 0.4, roughness: 0.5 }),
                new THREE.MeshStandardMaterial({ color: 0xc44dff, metalness: 0.6, roughness: 0.2 }),
                new THREE.MeshStandardMaterial({ color: 0x45b7d1, metalness: 0.7, roughness: 0.3 }),
                new THREE.MeshStandardMaterial({ color: 0xff9f43, metalness: 0.3, roughness: 0.4 })
            ];

            const geometries = [
                new THREE.IcosahedronGeometry(1.5, 0),
                new THREE.TorusGeometry(1.2, 0.4, 16, 32),
                new THREE.OctahedronGeometry(1.3, 0),
                new THREE.DodecahedronGeometry(1.2, 0),
                new THREE.TetrahedronGeometry(1.4, 0),
                new THREE.TorusKnotGeometry(0.8, 0.25, 64, 16),
                new THREE.ConeGeometry(1, 2, 6),
                new THREE.CylinderGeometry(0.8, 0.8, 1.5, 6),
                new THREE.RingGeometry(0.5, 1.2, 6),
                new THREE.RoundedBoxGeometry(1.5, 1.5, 1.5, 4, 0.2)
            ];

            for (let i = 0; i < 20; i++) {
                const geometry = geometries[i % geometries.length];
                const material = materials[i % materials.length].clone();
                
                const mesh = new THREE.Mesh(geometry, material);
                
                const radius = 8 + Math.random() * 10;
                const theta = Math.random() * Math.PI * 2;
                const phi = Math.random() * Math.PI;
                
                mesh.position.x = radius * Math.sin(phi) * Math.cos(theta);
                mesh.position.y = radius * Math.cos(phi);
                mesh.position.z = radius * Math.sin(phi) * Math.sin(theta);
                
                mesh.userData = {
                    rotationSpeed: {
                        x: (Math.random() - 0.5) * 0.02,
                        y: (Math.random() - 0.5) * 0.02,
                        z: (Math.random() - 0.5) * 0.02
                    },
                    floatSpeed: Math.random() * 0.5 + 0.5,
                    floatOffset: Math.random() * Math.PI * 2,
                    originalY: mesh.position.y,
                    orbitSpeed: (Math.random() - 0.5) * 0.1,
                    orbitRadius: radius,
                    orbitAngle: theta
                };
                
                shapes.push(mesh);
                scene.add(mesh);
            }

            const starGeometry = new THREE.BufferGeometry();
            const starCount = 2000;
            const starPositions = new Float32Array(starCount * 3);
            
            for (let i = 0; i < starCount * 3; i += 3) {
                const radius = 50 + Math.random() * 150;
                const theta = Math.random() * Math.PI * 2;
                const phi = Math.acos(2 * Math.random() - 1);
                
                starPositions[i] = radius * Math.sin(phi) * Math.cos(theta);
                starPositions[i + 1] = radius * Math.sin(phi) * Math.sin(theta);
                starPositions[i + 2] = radius * Math.cos(phi);
            }
            
            starGeometry.setAttribute('position', new THREE.BufferAttribute(starPositions, 3));
            
            const starMaterial = new THREE.PointsMaterial({
                color: 0xffffff,
                size: 0.5,
                transparent: true,
                opacity: 0