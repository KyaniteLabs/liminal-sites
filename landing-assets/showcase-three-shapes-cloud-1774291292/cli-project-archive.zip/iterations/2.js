<think>
The user wants me to create a Three.js 3D scene with:
1. Rotating geometric shapes
2. Dynamic lighting

Let me create a visually appealing scene with:
- Multiple geometric shapes (cube, sphere, torus, octahedron, etc.)
- Rotating animations
- Dynamic lighting (point lights that move, maybe color changes)
- Post-processing for visual polish (bloom)
- OrbitControls for interaction
- Proper window resize handling
- MeshStandardMaterial or MeshPhysicalMaterial for materials

I'll create a cohesive design with a dark background and colorful glowing shapes.
</think>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rotating Geometric Shapes with Dynamic Lighting</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            overflow: hidden;
            background: #0a0a0f;
        }
        canvas {
            display: block;
        }
        #info {
            position: absolute;
            bottom: 20px;
            left: 50%;
            transform: translateX(-50%);
            color: rgba(255, 255, 255, 0.6);
            font-family: 'Segoe UI', system-ui, sans-serif;
            font-size: 14px;
            text-align: center;
            pointer-events: none;
        }
    </style>
</head>
<body>
    <div id="info">Drag to rotate • Scroll to zoom</div>
    
    <script type="importmap">
    {
        "imports": {
            "three": "https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.module.js",
            "three/addons/": "https://cdn.jsdelivr.net/npm/three@0.160.0/examples/jsm/"
        }
    }
    </script>
    
    <script type="module">
        import * as THREE from 'three';
        import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
        import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
        import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
        import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js';

        // Scene setup
        const scene = new THREE.Scene();
        scene.background = new THREE.Color(0x0a0a0f);
        scene.fog = new THREE.FogExp2(0x0a0a0f, 0.03);

        // Camera
        const camera = new THREE.PerspectiveCamera(60, window.innerWidth / window.innerHeight, 0.1, 1000);
        camera.position.set(0, 3, 12);

        // Renderer
        const renderer = new THREE.WebGLRenderer({ antialias: true });
        renderer.setSize(window.innerWidth, window.innerHeight);
        renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
        renderer.toneMapping = THREE.ACESFilmicToneMapping;
        renderer.toneMappingExposure = 1.2;
        document.body.appendChild(renderer.domElement);

        // Post-processing
        const composer = new EffectComposer(renderer);
        const renderPass = new RenderPass(scene, camera);
        composer.addPass(renderPass);

        const bloomPass = new UnrealBloomPass(
            new THREE.Vector2(window.innerWidth, window.innerHeight),
            1.5,  // strength
            0.4,  // radius
            0.85  // threshold
        );
        composer.addPass(bloomPass);

        // Orbit Controls
        const controls = new OrbitControls(camera, renderer.domElement);
        controls.enableDamping = true;
        controls.dampingFactor = 0.05;
        controls.minDistance = 5;
        controls.maxDistance = 30;

        // Lighting
        const ambientLight = new THREE.AmbientLight(0x222233, 0.5);
        scene.add(ambientLight);

        // Dynamic point lights
        const lights = [];
        const lightColors = [0xff6b6b, 0x4ecdc4, 0xffe66d, 0xc44dff, 0x6bff6b];

        for (let i = 0; i < 5; i++) {
            const light = new THREE.PointLight(lightColors[i], 2, 20);
            light.userData = {
                radius: 8 + Math.random() * 4,
                speed: 0.3 + Math.random() * 0.4,
                offset: (i / 5) * Math.PI * 2,
                baseY: 2 + Math.random() * 3,
                baseIntensity: 1.5 + Math.random()
            };
            lights.push(light);
            scene.add(light);
        }

        // Geometric shapes
        const shapes = [];
        const materials = [
            new THREE.MeshStandardMaterial({ color: 0xff6b6b, metalness: 0.3, roughness: 0.4, emissive: 0xff6b6b, emissiveIntensity: 0.2 }),
            new THREE.MeshStandardMaterial({ color: 0x4ecdc4, metalness: 0.5, roughness: 0.3, emissive: 0x4ecdc4, emissiveIntensity: 0.2 }),
            new THREE.MeshStandardMaterial({ color: 0xffe66d, metalness: 0.2, roughness: 0.5, emissive: 0xffe66d, emissiveIntensity: 0.2 }),
            new THREE.MeshStandardMaterial({ color: 0xc44dff, metalness: 0.4, roughness: 0.3, emissive: 0xc44dff, emissiveIntensity: 0.2 }),
            new THREE.MeshStandardMaterial({ color: 0x6bff6b, metalness: 0.3, roughness: 0.4, emissive: 0x6bff6b, emissiveIntensity: 0.2 }),
            new THREE.MeshPhysicalMaterial({ color: 0xffffff, metalness: 0.9, roughness: 0.1, clearcoat: 1, clearcoatRoughness: 0.1 })
        ];

        // Icosahedron
        const icosaGeometry = new THREE.IcosahedronGeometry(1.5, 0);
        const icosahedron = new THREE.Mesh(icosaGeometry, materials[0]);
        icosahedron.position.set(0, 0, 0);
        icosahedron.userData = { rotSpeed: { x: 0.005, y: 0.008, z: 0.003 }, floatSpeed: 1, floatOffset: 0 };
        shapes.push(icosahedron);
        scene.add(icosahedron);

        // Torus
        const torusGeometry = new THREE.TorusGeometry(1.2, 0.4, 16, 100);
        const torus = new THREE.Mesh(torusGeometry, materials[1]);
        torus.position.set(5, 2, -2);
        torus.userData = { rotSpeed: { x: 0.01, y: 0.015, z: 0.005 }, floatSpeed: 1.3, floatOffset: 1 };
        shapes.push(torus);
        scene.add(torus);

        // Octahedron
        const octaGeometry = new THREE.OctahedronGeometry(1.3, 0);
        const octahedron = new THREE.Mesh(octaGeometry, materials[2]);
        octahedron.position.set(-4.5, 1, 2);
        octahedron.userData = { rotSpeed: { x: 0.008, y: 0.012, z: 0.006 }, floatSpeed: 0.9, floatOffset: 2 };
        shapes.push(octahedron);
        scene.add(octahedron);

        // Dodecahedron
        const dodecaGeometry = new THREE.DodecahedronGeometry(1.1, 0);
        const dodecahedron = new THREE.Mesh(dodecaGeometry, materials[3]);
        dodecahedron.position.set(3, -2, 3);
        dodecahedron.userData = { rotSpeed: { x: 0.006, y: 0.01, z: 0.008 }, floatSpeed: 1.1, floatOffset: 3 };
        shapes.push(dodecahedron);
        scene.add(dodecahedron);

        // Torus Knot
        const torusKnotGeometry = new THREE.TorusKnotGeometry(0.8, 0.25, 100, 16);
        const torusKnot = new THREE.Mesh(torusKnotGeometry, materials[4]);
        torusKnot.position.set(-3, -1, -3);
        torusKnot.userData = { rotSpeed: { x: 0.004, y: 0.007, z: 0.009