<think>
The user wants a 3D scene with rotating geometric shapes and dynamic lighting. Let me create a complete, self-contained HTML file with:

1. A variety of geometric shapes (different primitives)
2. Rotating animations
3. Dynamic lighting (point lights, directional lights)
4. Post-processing effects (bloom for the lights)
5. OrbitControls for interaction
6. Proper window resize handling
7. MeshStandardMaterial or MeshPhysicalMaterial for materials

Let me design something visually impressive with:
- Multiple geometric shapes scattered in the scene
- Different materials (metallic, rough, colored)
- Multiple point lights with different colors
- A main directional light
- Ambient light
- Bloom post-processing for glow effects
- Floating/rotating animations for the shapes
- A nice background color or gradient effect

I'll use the importmap approach with Three.js 0.160.0.
</think>

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dynamic 3D Geometric Scene</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            overflow: hidden;
            background: #000;
        }
        canvas {
            display: block;
        }
        #info {
            position: absolute;
            bottom: 20px;
            left: 50%;
            transform: translateX(-50%);
            color: rgba(255, 255, 255, 0.7);
            font-family: 'Segoe UI', sans-serif;
            font-size: 14px;
            text-align: center;
            pointer-events: none;
        }
    </style>
</head>
<body>
    <div id="info">Drag to orbit • Scroll to zoom</div>
    <script type="importmap">
    {
        "imports": {
            "three": "https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.module.js",
            "three/addons/": "https://cdn.jsdelivr.net/npm/three@0.160.0/examples/jsm/"
        }
    }
    </script>
    <script type="module">
        import * as THREE from 'three';
        import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
        import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
        import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
        import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js';

        // Scene setup
        const scene = new THREE.Scene();
        scene.background = new THREE.Color(0x0a0a1a);
        scene.fog = new THREE.FogExp2(0x0a0a1a, 0.02);

        // Camera
        const camera = new THREE.PerspectiveCamera(60, window.innerWidth / window.innerHeight, 0.1, 1000);
        camera.position.set(0, 5, 15);

        // Renderer
        const renderer = new THREE.WebGLRenderer({ antialias: true });
        renderer.setSize(window.innerWidth, window.innerHeight);
        renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
        renderer.shadowMap.enabled = true;
        renderer.shadowMap.type = THREE.PCFSoftShadowMap;
        renderer.toneMapping = THREE.ACESFilmicToneMapping;
        renderer.toneMappingExposure = 1.2;
        document.body.appendChild(renderer.domElement);

        // Post-processing
        const composer = new EffectComposer(renderer);
        const renderPass = new RenderPass(scene, camera);
        composer.addPass(renderPass);

        const bloomPass = new UnrealBloomPass(
            new THREE.Vector2(window.innerWidth, window.innerHeight),
            1.5, 0.4, 0.85
        );
        bloomPass.threshold = 0.2;
        bloomPass.strength = 1.2;
        bloomPass.radius = 0.5;
        composer.addPass(bloomPass);

        // Controls
        const controls = new OrbitControls(camera, renderer.domElement);
        controls.enableDamping = true;
        controls.dampingFactor = 0.05;
        controls.maxDistance = 50;
        controls.minDistance = 5;

        // Lighting
        const ambientLight = new THREE.AmbientLight(0x222244, 0.5);
        scene.add(ambientLight);

        const directionalLight = new THREE.DirectionalLight(0xffffff, 1);
        directionalLight.position.set(10, 20, 10);
        directionalLight.castShadow = true;
        directionalLight.shadow.mapSize.width = 2048;
        directionalLight.shadow.mapSize.height = 2048;
        directionalLight.shadow.camera.near = 0.5;
        directionalLight.shadow.camera.far = 50;
        directionalLight.shadow.camera.left = -20;
        directionalLight.shadow.camera.right = 20;
        directionalLight.shadow.camera.top = 20;
        directionalLight.shadow.camera.bottom = -20;
        scene.add(directionalLight);

        // Dynamic colored point lights
        const pointLights = [];
        const lightColors = [0xff6b6b, 0x4ecdc4, 0xffe66d, 0x95e1d3, 0xf38181];
        
        lightColors.forEach((color, i) => {
            const light = new THREE.PointLight(color, 2, 20);
            const angle = (i / lightColors.length) * Math.PI * 2;
            light.position.set(
                Math.cos(angle) * 8,
                3 + Math.random() * 4,
                Math.sin(angle) * 8
            );
            light.castShadow = true;
            scene.add(light);
            pointLights.push({ light, angle, radius: 8, speed: 0.3 + Math.random() * 0.2 });
        });

        // Geometric shapes
        const shapes = [];

        // Create materials
        const materials = [
            new THREE.MeshStandardMaterial({ color: 0xff6b6b, metalness: 0.8, roughness: 0.2 }),
            new THREE.MeshStandardMaterial({ color: 0x4ecdc4, metalness: 0.9, roughness: 0.1 }),
            new THREE.MeshStandardMaterial({ color: 0xffe66d, metalness: 0.7, roughness: 0.3 }),
            new THREE.MeshStandardMaterial({ color: 0x95e1d3, metalness: 0.6, roughness: 0.4 }),
            new THREE.MeshStandardMaterial({ color: 0xf38181, metalness: 0.85, roughness: 0.15 }),
            new THREE.MeshPhysicalMaterial({ color: 0xaa96da, metalness: 0.9, roughness: 0.1, clearcoat: 1 }),
            new THREE.MeshPhysicalMaterial({ color: 0xfcbad3, metalness: 0.7, roughness: 0.2, clearcoat: 0.8 }),
        ];

        // Icosahedron
        const icoGeo = new THREE.IcosahedronGeometry(1.5, 0);
        const ico = new THREE.Mesh(icoGeo, materials[0]);
        ico.position.set(0, 3, 0);
        ico.castShadow = true;
        scene.add(ico);
        shapes.push({ mesh: ico, rotationSpeed: { x: 0.01, y: 0.015, z: 0.005 }, floatSpeed: 0.8, floatHeight: 1 });

        // Torus knot
        const torusKnotGeo = new THREE.TorusKnotGeometry(0.8, 0.3, 100, 16);
        const torusKnot = new THREE.Mesh(torusKnotGeo, materials[1]);
        torusKnot.position.set(-4, 4, -3);
        torusKnot.castShadow = true;
        scene.add(torusKnot);
        shapes.push({ mesh: torusKnot, rotationSpeed: { x: 0.008, y: 0.012, z: 0.01 }, floatSpeed: 1.2, floatHeight: 0.8 });

        // Octahedron
        const octaGeo = new THREE.OctahedronGeometry(1.2, 0);
        const octa = new THREE.Mesh(octaGeo, materials[2]);
        octa.position.set(4, 5, 2);
        octa.castShadow = true;
        scene.add(octa);
        shapes.push({ mesh: octa, rotationSpeed: { x: 0.015, y: 0.008, z: 0.012 }, floatSpeed: 0.6, floatHeight: 1.2 });

        // Dodecahedron
        const dodecaGeo = new THREE.DodecahedronGeometry(1, 0);
        const dodeca = new THREE.Mesh(dodecaGeo, materials[3]);
        dodeca.position.set(-3