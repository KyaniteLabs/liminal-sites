<think>
The user wants a Three.js 3D scene with rotating geometric shapes and lighting. Let me create a complete HTML file with:

1. Three.js via CDN importmap
2. Various geometric shapes (using BufferGeometry)
3. MeshStandardMaterial or MeshPhysicalMaterial
4. OrbitControls for camera interaction
5. Proper lighting (ambient + directional/point lights)
6. Animation loop
7. Window resize handling
8. Post-processing effects for polish
9. Subtle animations (rotation, floating)

I'll create an interesting scene with multiple shapes, good lighting setup, and visual effects.
</think>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rotating Geometric Shapes</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            overflow: hidden;
            background: #000;
        }
        canvas {
            display: block;
        }
        #info {
            position: absolute;
            bottom: 20px;
            left: 50%;
            transform: translateX(-50%);
            color: rgba(255,255,255,0.7);
            font-family: 'Segoe UI', sans-serif;
            font-size: 14px;
            pointer-events: none;
        }
    </style>
</head>
<body>
    <div id="info">Drag to rotate • Scroll to zoom</div>
    <script type="importmap">
    {"imports":{"three":"https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.module.js","three/addons/":"https://cdn.jsdelivr.net/npm/three@0.160.0/examples/jsm/"}}
    </script>
    <script type="module">
        import * as THREE from 'three';
        import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
        import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
        import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
        import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js';

        let scene, camera, renderer, composer, controls;
        let shapes = [];
        let clock = new THREE.Clock();

        init();
        animate();

        function init() {
            scene = new THREE.Scene();
            scene.background = new THREE.Color(0x0a0a0f);
            scene.fog = new THREE.Fog(0x0a0a0f, 10, 50);

            camera = new THREE.PerspectiveCamera(60, window.innerWidth / window.innerHeight, 0.1, 1000);
            camera.position.set(0, 3, 12);

            renderer = new THREE.WebGLRenderer({ antialias: true });
            renderer.setSize(window.innerWidth, window.innerHeight);
            renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
            renderer.toneMapping = THREE.ACESFilmicToneMapping;
            renderer.toneMappingExposure = 1.2;
            document.body.appendChild(renderer.domElement);

            controls = new OrbitControls(camera, renderer.domElement);
            controls.enableDamping = true;
            controls.dampingFactor = 0.05;
            controls.minDistance = 5;
            controls.maxDistance = 30;

            const ambientLight = new THREE.AmbientLight(0x404060, 0.5);
            scene.add(ambientLight);

            const pointLight1 = new THREE.PointLight(0xff6b6b, 2, 30);
            pointLight1.position.set(5, 5, 5);
            scene.add(pointLight1);

            const pointLight2 = new THREE.PointLight(0x4ecdc4, 2, 30);
            pointLight2.position.set(-5, 3, -5);
            scene.add(pointLight2);

            const pointLight3 = new THREE.PointLight(0xf7d794, 1.5, 25);
            pointLight3.position.set(0, -5, 0);
            scene.add(pointLight3);

            const directionalLight = new THREE.DirectionalLight(0xffffff, 0.8);
            directionalLight.position.set(10, 10, 5);
            scene.add(directionalLight);

            createShapes();

            const gridHelper = new THREE.GridHelper(20, 20, 0x222233, 0x111122);
            gridHelper.position.y = -4;
            scene.add(gridHelper);

            const renderPass = new RenderPass(scene, camera);
            const bloomPass = new UnrealBloomPass(
                new THREE.Vector2(window.innerWidth, window.innerHeight),
                0.8, 0.4, 0.85
            );

            composer = new EffectComposer(renderer);
            composer.addPass(renderPass);
            composer.addPass(bloomPass);

            window.addEventListener('resize', onWindowResize);
        }

        function createShapes() {
            const materials = [
                new THREE.MeshStandardMaterial({ color: 0xff6b6b, metalness: 0.3, roughness: 0.4 }),
                new THREE.MeshStandardMaterial({ color: 0x4ecdc4, metalness: 0.5, roughness: 0.3 }),
                new THREE.MeshStandardMaterial({ color: 0xf7d794, metalness: 0.2, roughness: 0.5 }),
                new THREE.MeshPhysicalMaterial({ color: 0x845ec2, metalness: 0.1, roughness: 0.2, clearcoat: 1 }),
                new THREE.MeshStandardMaterial({ color: 0x00c9a7, metalness: 0.6, roughness: 0.3 }),
                new THREE.MeshStandardMaterial({ color: 0xff9671, metalness: 0.4, roughness: 0.4 })
            ];

            const geometries = [
                new THREE.IcosahedronGeometry(1, 0),
                new THREE.OctahedronGeometry(1, 0),
                new THREE.TetrahedronGeometry(1, 0),
                new THREE.DodecahedronGeometry(0.8, 0),
                new THREE.TorusKnotGeometry(0.6, 0.2, 100, 16),
                new THREE.TorusGeometry(0.7, 0.3, 16, 100)
            ];

            const positions = [
                { x: 0, y: 0, z: 0 },
                { x: 4, y: 1, z: 2 },
                { x: -4, y: -1, z: 2 },
                { x: 2, y: 2, z: -3 },
                { x: -2, y: -2, z: -3 },
                { x: 0, y: 3, z: -2 }
            ];

            const rotationSpeeds = [
                { x: 0.01, y: 0.015, z: 0.005 },
                { x: -0.008, y: 0.012, z: 0.01 },
                { x: 0.012, y: -0.01, z: 0.008 },
                { x: -0.015, y: 0.008, z: -0.012 },
                { x: 0.006, y: -0.012, z: 0.015 },
                { x: -0.01, y: -0.006, z: 0.012 }
            ];

            const floatOffsets = [
                Math.random() * Math.PI * 2,
                Math.random() * Math.PI * 2,
                Math.random() * Math.PI * 2,
                Math.random() * Math.PI * 2,
                Math.random() * Math.PI * 2,
                Math.random() * Math.PI * 2
            ];

            for (let i = 0; i < 6; i++) {
                const mesh = new THREE.Mesh(geometries[i], materials[i]);
                mesh.position.set(positions[i].x, positions[i].y, positions[i].z);
                mesh.userData = {
                    rotationSpeed: rotationSpeeds[i],
                    floatOffset: floatOffsets[i],
                    floatSpeed: 0.5 + Math.random() * 0.5,
                    baseY: positions[i].y,
                    floatAmplitude: 0.3 + Math.random() * 0.3
                };
                scene.add(mesh);
                shapes.push(mesh);
            }

            const starGeometry = new THREE.BufferGeometry();
            const starCount = 1000;
            const starPositions = new Float32Array(starCount * 3);

            for (let i = 0; i < starCount * 3; i += 3) {
                starPositions[i] = (Math.random() - 0.5) * 100;
                starPositions[i + 1] = (Math.random() - 0.5) * 100;
                starPositions[i + 2] = (Math.random() - 0.5) * 100;
            }

            starGeometry.setAttribute('position', new THREE.BufferAttribute(starPositions, 3));

            const starMaterial = new THREE.PointsMaterial({
                color: 0xffffff,
                size: 0.1,
                transparent: true,
                opacity: 0.8
            });

            const stars = new THREE.Points(starGeometry, starMaterial);
            scene.add(stars);
        }

        function onWindowResize() {
            camera.aspect = window.innerWidth / window.innerHeight;
            camera.updateProjectionMatrix();
            renderer.setSize(window.innerWidth, window.innerHeight);
            composer.setSize(window.innerWidth, window.innerHeight);
        }

        function animate() {
            requestAnimationFrame(animate);

            const elapsed = clock.getElapsedTime();

            shapes.forEach((shape) => {
                shape.rotation.x += shape.userData.rotationSpeed.x;
                shape.rotation.y += shape.userData.rotationSpeed.y;
                shape.rotation.z += shape.userData.rotationSpeed.z;

                shape.position.y = shape.userData.baseY +
                    Math.sin(elapsed * shape.userData.floatSpeed + shape.userData.floatOffset) *
                    shape.userData.floatAmplitude;
            });

            controls.update();
            composer.render();
        }
    </script>
</body>
</html>