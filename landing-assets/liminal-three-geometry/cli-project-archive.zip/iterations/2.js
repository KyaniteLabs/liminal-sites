<think>
The user wants a 3D scene with rotating geometric shapes and lighting. Let me create a visually appealing scene with:

1. Multiple geometric shapes (cubes, spheres, torus, etc.)
2. Nice lighting setup (ambient + point/directional lights)
3. Rotation animations
4. OrbitControls for interaction
5. Post-processing effects like bloom for polish
6. Responsive handling

Let me create a complete HTML file with Three.js using ES modules.
</think>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Three.js Rotating Geometric Shapes</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            overflow: hidden;
            background: #0a0a0f;
        }
        canvas {
            display: block;
        }
        #info {
            position: absolute;
            bottom: 20px;
            left: 50%;
            transform: translateX(-50%);
            color: rgba(255, 255, 255, 0.7);
            font-family: 'Segoe UI', system-ui, sans-serif;
            font-size: 14px;
            text-align: center;
            pointer-events: none;
            text-shadow: 0 2px 10px rgba(0, 0, 0, 0.5);
        }
    </style>
</head>
<body>
    <div id="info">Drag to rotate • Scroll to zoom</div>
    <script type="importmap">{"imports":{"three":"https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.module.js","three/addons/":"https://cdn.jsdelivr.net/npm/three@0.160.0/examples/jsm/"}}</script>
    <script type="module">
        import * as THREE from 'three';
        import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
        import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
        import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
        import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js';

        // Scene setup
        const scene = new THREE.Scene();
        scene.background = new THREE.Color(0x0a0a0f);
        scene.fog = new THREE.Fog(0x0a0a0f, 10, 50);

        // Camera
        const camera = new THREE.PerspectiveCamera(60, window.innerWidth / window.innerHeight, 0.1, 1000);
        camera.position.set(0, 5, 15);

        // Renderer
        const renderer = new THREE.WebGLRenderer({ antialias: true });
        renderer.setSize(window.innerWidth, window.innerHeight);
        renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
        renderer.toneMapping = THREE.ACESFilmicToneMapping;
        renderer.toneMappingExposure = 1.2;
        document.body.appendChild(renderer.domElement);

        // Post-processing
        const composer = new EffectComposer(renderer);
        const renderPass = new RenderPass(scene, camera);
        composer.addPass(renderPass);

        const bloomPass = new UnrealBloomPass(
            new THREE.Vector2(window.innerWidth, window.innerHeight),
            0.8,
            0.4,
            0.85
        );
        composer.addPass(bloomPass);

        // Controls
        const controls = new OrbitControls(camera, renderer.domElement);
        controls.enableDamping = true;
        controls.dampingFactor = 0.05;
        controls.maxDistance = 40;
        controls.minDistance = 5;

        // Lighting
        const ambientLight = new THREE.AmbientLight(0x222233, 0.5);
        scene.add(ambientLight);

        const pointLight1 = new THREE.PointLight(0xff6b6b, 2, 30);
        pointLight1.position.set(10, 8, 5);
        scene.add(pointLight1);

        const pointLight2 = new THREE.PointLight(0x4ecdc4, 2, 30);
        pointLight2.position.set(-10, 5, -5);
        scene.add(pointLight2);

        const pointLight3 = new THREE.PointLight(0xf7d794, 1.5, 25);
        pointLight3.position.set(0, -5, 10);
        scene.add(pointLight3);

        const directionalLight = new THREE.DirectionalLight(0xffffff, 0.5);
        directionalLight.position.set(5, 10, 7);
        scene.add(directionalLight);

        // Materials
        const materials = {
            cube: new THREE.MeshStandardMaterial({
                color: 0xff6b6b,
                metalness: 0.3,
                roughness: 0.4,
                emissive: 0xff6b6b,
                emissiveIntensity: 0.1
            }),
            sphere: new THREE.MeshStandardMaterial({
                color: 0x4ecdc4,
                metalness: 0.5,
                roughness: 0.2,
                emissive: 0x4ecdc4,
                emissiveIntensity: 0.1
            }),
            torus: new THREE.MeshStandardMaterial({
                color: 0xf7d794,
                metalness: 0.4,
                roughness: 0.3,
                emissive: 0xf7d794,
                emissiveIntensity: 0.15
            }),
            octahedron: new THREE.MeshStandardMaterial({
                color: 0xa29bfe,
                metalness: 0.6,
                roughness: 0.2,
                emissive: 0xa29bfe,
                emissiveIntensity: 0.2
            }),
            dodecahedron: new THREE.MeshStandardMaterial({
                color: 0xfd79a8,
                metalness: 0.4,
                roughness: 0.3,
                emissive: 0xfd79a8,
                emissiveIntensity: 0.15
            }),
            icosahedron: new THREE.MeshStandardMaterial({
                color: 0x00b894,
                metalness: 0.5,
                roughness: 0.25,
                emissive: 0x00b894,
                emissiveIntensity: 0.15
            })
        };

        // Geometric shapes array
        const shapes = [];

        // Cube
        const cubeGeometry = new THREE.BoxGeometry(2, 2, 2);
        const cube = new THREE.Mesh(cubeGeometry, materials.cube);
        cube.position.set(0, 0, 0);
        scene.add(cube);
        shapes.push({ mesh: cube, rotationSpeed: { x: 0.01, y: 0.015, z: 0 } });

        // Sphere
        const sphereGeometry = new THREE.SphereGeometry(1.2, 32, 32);
        const sphere = new THREE.Mesh(sphereGeometry, materials.sphere);
        sphere.position.set(5, 2, -3);
        scene.add(sphere);
        shapes.push({ mesh: sphere, rotationSpeed: { x: 0.008, y: 0.012, z: 0.005 } });

        // Torus
        const torusGeometry = new THREE.TorusGeometry(1.5, 0.5, 16, 100);
        const torus = new THREE.Mesh(torusGeometry, materials.torus);
        torus.position.set(-5, 1, 2);
        scene.add(torus);
        shapes.push({ mesh: torus, rotationSpeed: { x: 0.02, y: 0.01, z: 0.015 } });

        // Octahedron
        const octahedronGeometry = new THREE.OctahedronGeometry(1.5);
        const octahedron = new THREE.Mesh(octahedronGeometry, materials.octahedron);
        octahedron.position.set(-3, -2, -4);
        scene.add(octahedron);
        shapes.push({ mesh: octahedron, rotationSpeed: { x: 0.012, y: 0.018, z: 0.008 } });

        // Dodecahedron
        const dodecahedronGeometry = new THREE.DodecahedronGeometry(1.3);
        const dodecahedron = new THREE.Mesh(dodecahedronGeometry, materials.dodecahedron);
        dodecahedron.position.set(4, -1, 4);
        scene.add(dodecahedron);
        shapes.push({ mesh: dodecahedron, rotationSpeed: { x: 0.015, y: 0.01, z: 0.02 } });

        // Icosahedron
        const icosahedronGeometry = new THREE.IcosahedronGeometry(1.4);
        const icosahedron = new THREE.Mesh(icosahedronGeometry, materials.icosahedron);
        icosahedron.position.set(-6, 3, -1);
        scene.add(icosahedron);
        shapes.push({ mesh: icosahedron, rotationSpeed: { x: 0.018, y: 0.008, z: 0.012 } });

        // Torus Knot
        const torusKnotGeometry = new THREE.TorusKnotGeometry(1, 0.3, 100, 16);
        const torusKnotMaterial = new THREE.MeshStandardMaterial({
            color: 0x74b9ff,
            metalness: 0.7,
            roughness: 0.2,
            emissive: 0x74b9ff,
            emissiveIntensity: 0.2
        });
        const torusKnot = new THREE.Mesh(torusKnotGeometry, torusKnotMaterial);
        torusKnot.position.set(2, -3, -2);
        scene.add(torusKnot);
        shapes.push({ mesh: torusKnot, rotationSpeed: { x: 0.01, y: 0.02, z: 0.01 } });

        // Cone
        const coneGeometry = new THREE.ConeGeometry(1, 2, 32);
        const coneMaterial = new THREE.MeshStandardMaterial({
            color: 0xe17055,
            metalness: 0.4,
            roughness: 0.3,
            emissive: 0xe17055,
            emissiveIntensity: 0.15
        });
        const cone = new THREE.Mesh(coneGeometry, coneMaterial);
        cone.position.set(-2, 4, 3);
        scene.add(cone);
        shapes.push({ mesh: cone, rotationSpeed: { x: 0.015, y: 0.01, z: 0.02 } });

        // Floating particles
        const particlesGeometry = new THREE.BufferGeometry();
        const particlesCount = 500;
        const positions = new Float32Array(particlesCount * 3);

        for (let i = 0; i < particlesCount * 3; i += 3) {
            positions[i] = (Math.random() - 0.5) * 40;
            positions[i + 1] = (Math.random() - 0.5) * 40;
            positions[i + 2] = (Math.random() - 0.5) * 40;
        }

        particlesGeometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));

        const particlesMaterial = new THREE.PointsMaterial({
            size: 0.05,
            color: 0xffffff,
            transparent: true,
            opacity: 0.6,
            blending: THREE.AdditiveBlending
        });

        const particles = new THREE.Points(particlesGeometry, particlesMaterial);
        scene.add(particles);

        // Ground plane with grid
        const gridHelper = new THREE.GridHelper(30, 30, 0x444466, 0x222244);
        gridHelper.position.y = -5;
        scene.add(gridHelper);

        // Animation
        const clock = new THREE.Clock();

        function animate() {
            requestAnimationFrame(animate);

            const elapsedTime = clock.getElapsedTime();

            // Rotate shapes
            shapes.forEach((shape, index) => {
                shape.mesh.rotation.x += shape.rotationSpeed.x;
                shape.mesh.rotation.y += shape.rotationSpeed.y;
                shape.mesh.rotation.z += shape.rotationSpeed.z;

                // Subtle floating motion
                shape.mesh.position.y += Math.sin(elapsedTime + index * 0.5) * 0.002;
            });

            // Rotate particles slowly
            particles.rotation.y += 0.0002;
            particles.rotation.x += 0.0001;

            // Animate lights
            pointLight1.position.x = Math.sin(elapsedTime * 0.5) * 10;
            pointLight1.position.z = Math.cos(elapsedTime * 0.5) * 10;

            pointLight2.position.x = Math.cos(elapsedTime * 0.3) * 10;
            pointLight2.position.z = Math.sin(elapsedTime * 0.3) * 10;

            // Torus knot specific animation
            torusKnot.position.y = -3 + Math.sin(elapsedTime) * 0.5;

            controls.update();
            composer.render();
        }

        // Handle resize
        window.addEventListener('resize', () => {
            camera.aspect = window.innerWidth / window.innerHeight;
            camera.updateProjectionMatrix();
            renderer.setSize(window.innerWidth, window.innerHeight);
            composer.setSize(window.innerWidth, window.innerHeight);
        });

        animate();
    </script>
</body>
</html>