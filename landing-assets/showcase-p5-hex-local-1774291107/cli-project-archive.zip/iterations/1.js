// Rotating hexagons with color gradients in HSB mode
let hexagons = [];
let noiseOffset = 0;

function setup() {
  createCanvas(800, 600);
  colorMode(HSB, 360, 100, 100, 100);
  pixelDensity(1);
  noStroke();
  
  // Create multiple hexagon layers
  for (let i = 0; i < 6; i++) {
    hexagons.push({
      size: 300 - i * 40,
      rotation: i * PI / 6,
      rotationSpeed: 0.005 + i * 0.002,
      hueOffset: i * 60
    });
  }
}

function draw() {
  background(0, 0, 10);
  noiseOffset += 0.01;
  
  translate(width / 2, height / 2);
  
  // Draw hexagons from largest to smallest
  for (let i = 0; i < hexagons.length; i++) {
    let h = hexagons[i];
    h.rotation += h.rotationSpeed;
    
    // Use noise for color variation
    let hue = (h.hueOffset + noise(noiseOffset + i * 0.3) * 120 + frameCount * 0.2) % 360;
    let saturation = 70 + noise(noiseOffset + 100 + i * 0.5) * 30;
    let brightness = 80 + noise(noiseOffset + 200 + i * 0.4) * 20;
    let alpha = 40;
    
    drawHexagon(h.size, h.rotation, hue, saturation, brightness, alpha);
  }
  
  // Add central glow
  let centerHue = (noise(noiseOffset + 300) * 360 + frameCount * 0.3) % 360;
  fill(centerHue, 50, 100, 60);
  ellipse(0, 0, 50, 50);
}

function drawHexagon(size, rotation, hue, saturation, brightness, alpha) {
  fill(hue, saturation, brightness, alpha);
  beginShape();
  for (let i = 0; i < 6; i++) {
    let angle = TWO_PI / 6 * i + rotation;
    let x = cos(angle) * size;
    let y = sin(angle) * size;
    vertex(x, y);
  }
  endShape(CLOSE);
}

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
}