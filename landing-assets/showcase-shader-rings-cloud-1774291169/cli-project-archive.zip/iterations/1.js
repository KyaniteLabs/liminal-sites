glsl
precision highp float;

uniform vec2 u_resolution;
uniform float u_time;
uniform vec2 u_mouse;

#define PI 3.14159265359

void main() {
    vec2 uv = (gl_FragCoord.xy - 0.5 * u_resolution.xy) / min(u_resolution.x, u_resolution.y);
    
    float dist = length(uv);
    float angle = atan(uv.y, uv.x);
    
    // Pulsing rings
    float pulse = sin(u_time * 2.0) * 0.5 + 0.5;
    float rings = sin(dist * 20.0 - u_time * 3.0) * 0.5 + 0.5;
    rings *= smoothstep(0.5, 0.0, dist);
    
    // Chromatic aberration offsets
    float aberration = 0.01 + pulse * 0.02;
    
    vec2 uvR = uv + aberration * normalize(uv);
    vec2 uvG = uv;
    vec2 uvB = uv - aberration * normalize(uv);
    
    float distR = length(uvR);
    float distG = length(uvG);
    float distB = length(uvB);
    
    float ringsR = sin(distR * 20.0 - u_time * 3.0) * 0.5 + 0.5;
    float ringsG = sin(distG * 20.0 - u_time * 3.0) * 0.5 + 0.5;
    float ringsB = sin(distB * 20.0 - u_time * 3.0) * 0.5 + 0.5;
    
    ringsR *= smoothstep(0.5, 0.0, distR);
    ringsG *= smoothstep(0.5, 0.0, distG);
    ringsB *= smoothstep(0.5, 0.0, distB);
    
    vec3 color = vec3(ringsR, ringsG, ringsB);
    
    gl_FragColor = vec4(color, 1.0);
}