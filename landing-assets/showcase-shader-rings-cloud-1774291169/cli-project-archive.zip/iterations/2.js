glsl
precision highp float;

uniform vec2 u_resolution;
uniform float u_time;
uniform vec2 u_mouse;

#define PI 3.14159265359

void main() {
    vec2 uv = (gl_FragCoord.xy - 0.5 * u_resolution) / min(u_resolution.x, u_resolution.y);
    
    float dist = length(uv);
    float angle = atan(uv.y, uv.x);
    
    // Pulsing rings
    float rings = sin(dist * 20.0 - u_time * 2.0) * 0.5 + 0.5;
    rings = pow(rings, 2.0);
    
    // Chromatic aberration - offset the distance for each channel
    float distR = length(uv * vec2(1.02, 0.98));
    float distG = dist;
    float distB = length(uv * vec2(0.98, 1.02));
    
    float ringsR = sin(distR * 20.0 - u_time * 2.0) * 0.5 + 0.5;
    float ringsG = sin(distG * 20.0 - u_time * 2.0) * 0.5 + 0.5;
    float ringsB = sin(distB * 20.0 - u_time * 2.0) * 0.5 + 0.5;
    
    // Apply different intensity to each channel
    ringsR = pow(ringsR, 2.0);
    ringsG = pow(ringsG, 2.0);
    ringsB = pow(ringsB, 2.0);
    
    // Combine with wave interference pattern for added depth
    float wave = sin(angle * 3.0 + u_time) * 0.5 + 0.5;
    
    vec3 color = vec3(ringsR * (0.7 + wave * 0.3), 
                      ringsG * 0.8, 
                      ringsB * (0.7 + (1.0 - wave) * 0.3));
    
    // Add radial vignette
    color *= 1.0 - dist * 0.5;
    
    gl_FragColor = vec4(color, 1.0);
}