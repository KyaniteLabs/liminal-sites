<think>
The user wants a fractal tree with:
1. Recursive branches
2. Leaves that change color based on depth
3. Should use p5.js with noise() for organic variation
4. Self-contained, immediately runnable

Let me create a beautiful fractal tree with:
- Recursive branching structure
- Noise-based variation for organic feel
- Color gradient based on depth (leaves are typically at max depth)
- Smooth animations or static but organic appearance
- Responsive canvas

I'll create a classic fractal tree using recursion, with each branch getting smaller and turning slightly. The color will change from trunk brown at the base to green leaves at the tips.
</think>

let angle = 0;
let depth = 0;
let maxDepth = 10;
let seed;

function setup() {
  createCanvas(800, 600);
  pixelDensity(1);
  seed = random(10000);
  angleMode(RADIANS);
}

function draw() {
  background(20, 25, 35);
  noiseSeed(seed);
  
  let startY = height - 50;
  let startX = width / 2;
  
  push();
  translate(startX, startY);
  
  let trunkLength = map(noise(frameCount * 0.005), 0, 1, 120, 180);
  
  drawBranch(trunkLength, 0);
  
  pop();
  
  noLoop();
}

function drawBranch(len, d) {
  let noiseFactor = noise(d * 0.1, frameCount * 0.01) * 0.3 + 0.7;
  len *= noiseFactor;
  
  let col = getColorForDepth(d);
  stroke(col.r, col.g, col.b, 255);
  strokeWeight(map(d, 0, maxDepth, 8, 1));
  
  line(0, 0, 0, -len);
  
  translate(0, -len);
  
  if (d < maxDepth && len > 4) {
    let angleVariation = noise(d * 0.5, 100) * 0.4;
    let branchAngle = map(noise(d * 0.3), 0, 1, 0.3, 0.7);
    
    let lengthFactor = map(d, 0, maxDepth, 0.7, 0.65);
    
    push();
    rotate(-branchAngle - angleVariation);
    drawBranch(len * lengthFactor, d + 1);
    pop();
    
    push();
    rotate(branchAngle + angleVariation);
    drawBranch(len * lengthFactor, d + 1);
    pop();
    
    if (d > maxDepth - 3 && len > 3) {
      drawLeaf(d);
    }
  }
}

function drawLeaf(d) {
  let leafCol = getLeafColor(d);
  fill(leafCol.r, leafCol.g, leafCol.b, 200);
  noStroke();
  
  let size = random(3, 8);
  let wobbleX = noise(d * 0.2, 50) * 4 - 2;
  let wobbleY = noise(d * 0.2, 100) * 4 - 2;
  
  push();
  translate(wobbleX, wobbleY);
  rotate(random(TWO_PI));
  ellipse(0, 0, size, size * 0.5);
  pop();
}

function getColorForDepth(d) {
  let trunkR = 80, trunkG = 60, trunkB = 40;
  let leafR = 60, leafG = 140, leafB = 80;
  
  let t = d / maxDepth;
  
  return {
    r: lerp(trunkR, leafR, t),
    g: lerp(trunkG, leafG, t),
    b: lerp(trunkB, leafB, t)
  };
}

function getLeafColor(d) {
  let t = (d - (maxDepth - 3)) / 3;
  
  let green = color(50, 180, 60);
  let yellow = color(200, 200, 80);
  let orange = color(220, 120, 50);
  
  if (t < 0.5) {
    return lerpColor(green, yellow, t * 2);
  } else {
    return lerpColor(yellow, orange, (t - 0.5) * 2);
  }
}

function lerpColor(c1, c2, amt) {
  return {
    r: lerp(red(c1), red(c2), amt),
    g: lerp(green(c1), green(c2), amt),
    b: lerp(blue(c1), blue(c2), amt)
  };
}

function mousePressed() {
  seed = random(10000);
  noiseSeed(seed);
  loop();
}

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
  loop();
}