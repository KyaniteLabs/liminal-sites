<think>
The user wants a GLSL fragment shader that creates concentric circles. I need to make this visually interesting and creative while following all the constraints.

Let me create a shader with:
1. Concentric circles pattern
2. Some animation using u_time
3. Nice color scheme
4. Possibly some noise or variation for visual interest
5. Proper uniforms and precision declaration

I'll make the concentric circles animated, with:
- Smooth gradients between circles
- Color variation across the circles
- Maybe some wobble or pulsing effect
- Mouse interaction could influence the pattern

Let me write this shader:
</think>

precision highp float;

#define PI 3.14159265359
#define TWO_PI 6.28318530718

uniform vec2 u_resolution;
uniform float u_time;
uniform vec2 u_mouse;

float circle(in vec2 st, in float radius) {
    vec2 dist = st - vec2(0.5);
    return 1.0 - smoothstep(radius - 0.01, radius + 0.01, dot(dist, dist) * 4.0);
}

void main() {
    vec2 uv = gl_FragCoord.xy / u_resolution.xy;
    vec2 st = uv;
    st.x *= u_resolution.x / u_resolution.y;
    
    vec3 color = vec3(0.0);
    vec3 colorA = vec3(0.5 + 0.5 * sin(u_time * 0.3), 0.3, 0.6 + 0.3 * sin(u_time * 0.5));
    vec3 colorB = vec3(0.2, 0.6 + 0.4 * cos(u_time * 0.4), 0.8 + 0.2 * sin(u_time));
    
    float centerDist = length(st - vec2(0.5 * u_resolution.x / u_resolution.y, 0.5));
    
    float numCircles = 12.0;
    float animOffset = u_time * 0.5;
    
    for (float i = 0.0; i < numCircles; i++) {
        float radius = (i + 0.5 + 0.3 * sin(u_time + i * 0.5)) / numCircles;
        float circleMask = circle(st, radius);
        
        float wavePattern = sin(centerDist * 30.0 - u_time * 2.0 + i * 0.5) * 0.5 + 0.5;
        
        vec3 circleColor = mix(colorA, colorB, (i / numCircles) + wavePattern * 0.3);
        
        float thickness = 0.015 + 0.01 * sin(u_time * 2.0 + i * 1.2);
        float innerRadius = radius - thickness * 0.5;
        float outerRadius = radius + thickness * 0.5;
        
        float ringMask = smoothstep(innerRadius - 0.01, innerRadius, centerDist) 
                        * smoothstep(outerRadius + 0.01, outerRadius, centerDist);
        
        color += circleColor * ringMask;
    }
    
    float mouseInfluence = smoothstep(0.0, 0.3, length(uv - u_mouse));
    color += vec3(0.1, 0.05, 0.15) * mouseInfluence * sin(u_time * 3.0);
    
    float glow = 0.02 / (centerDist + 0.05);
    color += mix(colorA, colorB, 0.5) * glow * (0.5 + 0.5 * sin(u_time));
    
    float cornerFade = smoothstep(0.0, 0.15, min(min(uv.x, 1.0 - uv.x), min(uv.y, 1.0 - uv.y)) * 2.0);
    color *= cornerFade;
    
    gl_FragColor = vec4(color, 1.0);
}