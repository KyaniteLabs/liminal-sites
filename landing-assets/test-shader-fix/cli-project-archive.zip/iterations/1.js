glsl
precision highp float;

uniform vec2 u_resolution;
uniform float u_time;

#define PI 3.14159265359
#define TWO_PI 6.28318530718

// Simple hash for noise
float hash(float n) {
    return fract(sin(n) * 43758.5453123);
}

// 2D noise
float noise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    
    float a = hash(i.x + i.y * 57.0);
    float b = hash(i.x + 1.0 + i.y * 57.0);
    float c = hash(i.x + (i.y + 1.0) * 57.0);
    float d = hash(i.x + 1.0 + (i.y + 1.0) * 57.0);
    
    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}

void main() {
    vec2 uv = (gl_FragCoord.xy - 0.5 * u_resolution.xy) / min(u_resolution.x, u_resolution.y);
    
    float dist = length(uv);
    float angle = atan(uv.y, uv.x);
    
    // Create concentric rings
    float ringCount = 12.0;
    float ringIndex = floor(dist * ringCount * 2.0);
    float ringFraction = fract(dist * ringCount * 2.0);
    
    // Animate ring thickness and brightness
    float pulse = sin(u_time * 2.0 + ringIndex * 0.5) * 0.5 + 0.5;
    float ringWidth = 0.15 + 0.1 * pulse;
    
    // Create ring pattern
    float ring = smoothstep(0.0, ringWidth, ringFraction) * smoothstep(ringWidth * 2.0, ringWidth, ringFraction);
    
    // Add color variation based on ring index
    vec3 color = vec3(
        0.5 + 0.5 * sin(ringIndex * 0.3 + u_time),
        0.5 + 0.5 * sin(ringIndex * 0.3 + u_time + 2.0),
        0.5 + 0.5 * sin(ringIndex * 0.3 + u_time + 4.0)
    );
    
    // Add noise to break up the pattern
    float noiseValue = noise(uv * 10.0 + u_time) * 0.1;
    
    // Final color with rings and noise
    color *= ring + noiseValue;
    
    gl_FragColor = vec4(color, 1.0);
}