<think>
The user wants me to create a Three.js 3D scene featuring various 3D geometries. Let me create an impressive, well-designed scene with multiple geometric shapes, good lighting, post-processing effects, and smooth animations.

I'll create:
1. Multiple 3D geometries (spheres, boxes, torus, etc.)
2. Good lighting setup
3. Post-processing (bloom)
4. OrbitControls for interaction
5. Subtle animations
6. Nice colors and materials

Let me write this as a single HTML file with ES modules.
</think>

```html
<script type="importmap">{"imports":{"three":"https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.module.js","three/addons/":"https://cdn.jsdelivr.net/npm/three@0.160.0/examples/jsm/"}}</script>
<script type="module">
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js';

let scene, camera, renderer, composer, controls;
let geometries = [];
let time = 0;

function init() {
    // Scene
    scene = new THREE.Scene();
    scene.background = new THREE.Color(0x0a0a0f);
    scene.fog = new THREE.FogExp2(0x0a0a0f, 0.05);

    // Camera
    camera = new THREE.PerspectiveCamera(60, window.innerWidth / window.innerHeight, 0.1, 1000);
    camera.position.set(0, 5, 15);

    // Renderer
    renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.2;
    document.body.appendChild(renderer.domElement);

    // Controls
    controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.05;
    controls.maxDistance = 50;
    controls.minDistance = 5;

    // Lighting
    const ambientLight = new THREE.AmbientLight(0x404060, 0.5);
    scene.add(ambientLight);

    const pointLight1 = new THREE.PointLight(0xff6b6b, 2, 50);
    pointLight1.position.set(10, 10, 10);
    scene.add(pointLight1);

    const pointLight2 = new THREE.PointLight(0x4ecdc4, 2, 50);
    pointLight2.position.set(-10, -10, -10);
    scene.add(pointLight2);

    const pointLight3 = new THREE.PointLight(0xf7d794, 1.5, 50);
    pointLight3.position.set(0, 15, 0);
    scene.add(pointLight3);

    // Create geometries
    createGeometries();

    // Post-processing
    composer = new EffectComposer(renderer);
    composer.addPass(new RenderPass(scene, camera));
    
    const bloomPass = new UnrealBloomPass(
        new THREE.Vector2(window.innerWidth, window.innerHeight),
        0.8, 0.4, 0.85
    );
    composer.addPass(bloomPass);

    // Window resize
    window.addEventListener('resize', onWindowResize);

    animate();
}

function createGeometries() {
    const materials = [
        new THREE.MeshStandardMaterial({ 
            color: 0xff6b6b, 
            metalness: 0.3, 
            roughness: 0.4,
            emissive: 0xff6b6b,
            emissiveIntensity: 0.2
        }),
        new THREE.MeshStandardMaterial({ 
            color: 0x4ecdc4, 
            metalness: 0.5, 
            roughness: 0.3,
            emissive: 0x4ecdc4,
            emissiveIntensity: 0.2
        }),
        new THREE.MeshStandardMaterial({ 
            color: 0xf7d794, 
            metalness: 0.4, 
            roughness: 0.5,
            emissive: 0xf7d794,
            emissiveIntensity: 0.2
        }),
        new THREE.MeshStandardMaterial({ 
            color: 0xa55eea, 
            metalness: 0.6, 
            roughness: 0.2,
            emissive: 0xa55eea,
            emissiveIntensity: 0.2
        }),
        new THREE.MeshStandardMaterial({ 
            color: 0x26de81, 
            metalness: 0.3, 
            roughness: 0.4,
            emissive: 0x26de81,
            emissiveIntensity: 0.2
        })
    ];

    // Sphere
    const sphereGeo = new THREE.SphereGeometry(1.5, 32, 32);
    const sphere = new THREE.Mesh(sphereGeo, materials[0]);
    sphere.position.set(0, 2, 0);
    sphere.userData = { type: 'rotate', speed: 0.01, axis: 'y' };
    scene.add(sphere);
    geometries.push(sphere);

    // Box
    const boxGeo = new THREE.BoxGeometry(2, 2, 2);
    const box = new THREE.Mesh(boxGeo, materials[1]);
    box.position.set(-5, 0, 3);
    box.userData = { type: 'rotate', speed: 0.015, axis: 'xyz' };
    scene.add(box);
    geometries.push(box);

    // Torus
    const torusGeo = new THREE.TorusGeometry(1.2, 0.4, 16, 100);
    const torus = new THREE.Mesh(torusGeo, materials[2]);
    torus.position.set(5, 0, 3);
    torus.userData = { type: 'rotate', speed: 0.02, axis: 'x' };
    scene.add(torus);
    geometries.push(torus);

    // Icosahedron
    const icoGeo = new THREE.IcosahedronGeometry(1.3, 0);
    const ico = new THREE.Mesh(icoGeo, materials[3]);
    ico.position.set(-3, 4, -3);
    ico.userData = { type: 'float', speed: 0.02, amplitude: 0.5 };
    scene.add(ico);
    geometries.push(ico);

    // Octahedron
    const octaGeo = new THREE.OctahedronGeometry(1.2, 0);
    const octa = new THREE.Mesh(octaGeo, materials[4]);
    octa.position.set(3, 4, -3);
    octa.userData = { type: 'float', speed: 0.025, amplitude: 0.4 };
    scene.add(octa);
    geometries.push(octa);

    // Torus Knot
    const knotGeo = new THREE.TorusKnotGeometry(0.8, 0.25, 100, 16);
    const knot = new THREE.Mesh(knotGeo, materials[0]);
    knot.position.set(8, 2, -2);
    knot.userData = { type: 'rotate', speed: 0.012, axis: 'z' };
    scene.add(knot);
    geometries.push(knot);

    // Dodecahedron
    const dodecGeo = new THREE.DodecahedronGeometry(1, 0);
    const dodec = new THREE.Mesh(dodecGeo, materials[1]);
    dodec.position.set(-8, 2, -2);
    dodec.userData = { type: 'rotate', speed: 0.018, axis: 'y' };
    scene.add(dodec);
    geometries.push(dodec);

    // Cone
    const coneGeo = new THREE.ConeGeometry(1, 2.5, 32);
    const cone = new THREE.Mesh(coneGeo, materials[2]);
    cone.position.set(0, -2, -5);
    cone.userData = { type: 'rotate', speed: 0.01, axis: 'y' };
    scene.add(cone);
    geometries.push(cone);

    // Cylinder
    const cylGeo = new THREE.CylinderGeometry(0.8, 0.8, 2.5, 32);
    const cyl = new THREE.Mesh(cylGeo, materials[3]);
    cyl.position.set(-6, -2, -5);
    cyl.userData = { type: 'rotate', speed: 0.015, axis: 'x' };
    scene.add(cyl);
    geometries.push(cyl);

    // Tetrahedron
    const tetraGeo = new THREE.TetrahedronGeometry(1.4, 0);
    const tetra =