<think>
The user wants a GLSL fragment shader that creates animated concentric circles. Let me create a visually interesting shader with:

1. Concentric circles that animate over time
2. Smooth transitions and motion
3. Creative use of colors
4. Proper uniforms (u_resolution, u_time, u_mouse)

I'll make it visually appealing with:
- Pulsating/breathing circles
- Color variation based on distance and time
- Some subtle noise for organic feel
- Smooth animation

Let me write the shader code:
</think>

precision highp float;

#define PI 3.14159265359
#define TWO_PI 6.28318530718

uniform vec2 u_resolution;
uniform vec2 u_mouse;
uniform float u_time;

float random(vec2 st) {
    return fract(sin(dot(st.xy, vec2(12.9898, 78.233))) * 43758.5453123);
}

float noise(vec2 st) {
    vec2 i = floor(st);
    vec2 f = fract(st);
    float a = random(i);
    float b = random(i + vec2(1.0, 0.0));
    float c = random(i + vec2(0.0, 1.0));
    float d = random(i + vec2(1.0, 1.0));
    vec2 u = f * f * (3.0 - 2.0 * f);
    return mix(a, b, u.x) + (c - a) * u.y * (1.0 - u.x) + (d - b) * u.x * u.y;
}

void mainImage(out vec4 fragColor, in vec2 fragCoord) {
    vec2 uv = fragCoord / u_resolution;
    vec2 center = vec2(0.5);
    float aspect = u_resolution.x / u_resolution.y;
    
    vec2 pos = uv - center;
    pos.x *= aspect;
    
    float dist = length(pos);
    float angle = atan(pos.y, pos.x);
    
    float numCircles = 12.0;
    float speed = 0.8;
    float pulseSpeed = 1.5;
    
    float timeOffset = u_time * speed;
    float pulse = sin(u_time * pulseSpeed) * 0.1;
    
    float ringWidth = 0.02 + 0.01 * sin(u_time * 2.0 + dist * 10.0);
    
    float pattern = sin(dist * numCircles * TWO_PI - timeOffset + sin(angle * 3.0) * 2.0);
    pattern = smoothstep(-0.3, 0.3, pattern);
    
    float innerRing = smoothstep(0.05, 0.08 + pulse, dist);
    float outerRing = 1.0 - smoothstep(0.45, 0.5, dist);
    
    float circle = pattern * innerRing * outerRing;
    
    float waveNoise = noise(vec2(angle * 5.0, dist * 20.0 - u_time));
    circle += waveNoise * 0.2 * innerRing * outerRing;
    
    vec3 color1 = vec3(0.2 + 0.3 * sin(u_time * 0.5), 0.4, 0.8);
    vec3 color2 = vec3(0.8, 0.3 + 0.2 * cos(u_time * 0.7), 0.2);
    vec3 color3 = vec3(0.1, 0.7, 0.5 + 0.3 * sin(u_time * 0.3));
    
    float colorMix = sin(dist * 8.0 + angle * 2.0 + u_time) * 0.5 + 0.5;
    float colorMix2 = cos(dist * 6.0 - angle * 3.0 + u_time * 1.3) * 0.5 + 0.5;
    
    vec3 baseColor = mix(color1, color2, colorMix);
    baseColor = mix(baseColor, color3, colorMix2);
    
    float glow = exp(-dist * 4.0) * 0.3;
    vec3 glowColor = vec3(0.5, 0.8, 1.0) * glow;
    
    vec3 finalColor = baseColor * circle + glowColor;
    
    float alpha = smoothstep(0.0, 0.1, circle + glow * 0.5);
    
    finalColor += vec3(0.05, 0.02, 0.08) * (1.0 - dist * 2.0);
    
    fragColor = vec4(finalColor, alpha);
}