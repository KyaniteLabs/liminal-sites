<think>
The user wants me to create a Three.js 3D scene featuring 3D geometry. Let me create an impressive, interactive 3D scene with multiple geometric shapes, good lighting, post-processing effects, and animations.

I'll create:
1. Multiple 3D geometries (torus, icosahedron, octahedron, torus knot, dodecahedron, etc.)
2. Good lighting setup
3. Post-processing with bloom
4. OrbitControls for interaction
5. Animations (rotation, floating)
6. A nice color scheme

Let me write the complete HTML file:
</think>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Three.js 3D Geometry</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            overflow: hidden;
            background: #0a0a0f;
            font-family: 'Segoe UI', sans-serif;
        }
        canvas {
            display: block;
        }
        #info {
            position: absolute;
            top: 20px;
            left: 20px;
            color: #fff;
            z-index: 100;
            pointer-events: none;
        }
        #info h1 {
            font-size: 28px;
            font-weight: 300;
            margin-bottom: 8px;
            background: linear-gradient(135deg, #667eea, #764ba2);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        #info p {
            font-size: 13px;
            color: rgba(255,255,255,0.5);
        }
    </style>
</head>
<body>
    <div id="info">
        <h1>3D Geometry Explorer</h1>
        <p>Drag to rotate • Scroll to zoom</p>
    </div>

    <script type="importmap">
    {
        "imports": {
            "three": "https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.module.js",
            "three/addons/": "https://cdn.jsdelivr.net/npm/three@0.160.0/examples/jsm/"
        }
    }
    </script>

    <script type="module">
        import * as THREE from 'three';
        import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
        import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
        import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
        import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js';

        // Scene setup
        const scene = new THREE.Scene();
        scene.background = new THREE.Color(0x0a0a0f);
        scene.fog = new THREE.FogExp2(0x0a0a0f, 0.03);

        // Camera
        const camera = new THREE.PerspectiveCamera(60, window.innerWidth / window.innerHeight, 0.1, 1000);
        camera.position.set(0, 5, 20);

        // Renderer
        const renderer = new THREE.WebGLRenderer({ antialias: true });
        renderer.setSize(window.innerWidth, window.innerHeight);
        renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
        renderer.toneMapping = THREE.ACESFilmicToneMapping;
        renderer.toneMappingExposure = 1.2;
        document.body.appendChild(renderer.domElement);

        // Controls
        const controls = new OrbitControls(camera, renderer.domElement);
        controls.enableDamping = true;
        controls.dampingFactor = 0.05;
        controls.maxDistance = 50;
        controls.minDistance = 5;

        // Post-processing
        const composer = new EffectComposer(renderer);
        const renderPass = new RenderPass(scene, camera);
        composer.addPass(renderPass);

        const bloomPass = new UnrealBloomPass(
            new THREE.Vector2(window.innerWidth, window.innerHeight),
            0.8, 0.4, 0.85
        );
        composer.addPass(bloomPass);

        // Lighting
        const ambientLight = new THREE.AmbientLight(0x404040, 0.5);
        scene.add(ambientLight);

        const pointLight1 = new THREE.PointLight(0x667eea, 2, 50);
        pointLight1.position.set(10, 10, 10);
        scene.add(pointLight1);

        const pointLight2 = new THREE.PointLight(0x764ba2, 2, 50);
        pointLight2.position.set(-10, 10, -10);
        scene.add(pointLight2);

        const pointLight3 = new THREE.PointLight(0xf093fb, 1.5, 40);
        pointLight3.position.set(0, -5, 15);
        scene.add(pointLight3);

        // Geometry data
        const geometries = [
            { geo: new THREE.TorusGeometry(1.5, 0.5, 32, 64), color: 0x667eea, pos: [-8, 2, 0], name: 'Torus' },
            { geo: new THREE.IcosahedronGeometry(1.5, 0), color: 0x764ba2, pos: [-4, 2, 4], name: 'Icosahedron' },
            { geo: new THREE.OctahedronGeometry(1.5, 0), color: 0xf093fb, pos: [0, 2, 0], name: 'Octahedron' },
            { geo: new THREE.TorusKnotGeometry(1, 0.35, 100, 16), color: 0x4facfe, pos: [4, 2, 4], name: 'Torus Knot' },
            { geo: new THREE.DodecahedronGeometry(1.5, 0), color: 0x00f2fe, pos: [8, 2, 0], name: 'Dodecahedron' },
            { geo: new THREE.TetrahedronGeometry(1.5, 0), color: 0xff6b6b, pos: [-6, 2, -4], name: 'Tetrahedron' },
            { geo: new THREE.BoxGeometry(2, 2, 2), color: 0x51cf66, pos: [0, 2, -5], name: 'Cube' },
            { geo: new THREE.ConeGeometry(1.2, 2.5, 32), color: 0xffd93d, pos: [6, 2, -4], name: 'Cone' },
            { geo: new THREE.CylinderGeometry(1, 1, 2.5, 32), color: 0x74b9ff, pos: [-4, 2, -4], name: 'Cylinder' },
            { geo: new THREE.SphereGeometry(1.3, 32, 32), color: 0xa29bfe, pos: [4, 2, -4], name: 'Sphere' }
        ];

        // Create meshes
        const meshes = [];
        geometries.forEach((item, index) => {
            const material = new THREE.MeshStandardMaterial({
                color: item.color,
                metalness: 0.3,
                roughness: 0.4,
                emissive: item.color,
                emissiveIntensity: 0.15
            });

            const mesh = new THREE.Mesh(item.geo, material);
            mesh.position.set(...item.pos);
            mesh.userData = {
                originalY: item.pos[1],
                rotationSpeed: {
                    x: (Math.random() - 0.5) * 0.01,
                    y: (Math.random() - 0.5) * 0.02 + 0.01,
                    z: (Math.random() - 0.5) * 0.01
                },
                floatOffset: Math.random() * Math.PI * 2,
                name: item.name
            };

            scene.add(mesh);
            meshes.push(mesh);
        });

        // Wireframe versions
        meshes.forEach((mesh, index) => {
            const wireframeGeo = mesh.geometry.clone();
            const wireframeMat = new THREE.MeshBasicMaterial({
                color: mesh.material.color,
                wireframe: true,
                transparent: true,
                opacity: 0.1
            });
            const wireframe = new THREE.Mesh(wireframeGeo, wireframeMat);
            wireframe.position.copy(mesh.position);
            wireframe.scale.setScalar(1.01);
            mesh.userData.wireframe = wireframe;
            scene.add(wireframe);
        });

        // Grid helper
        const gridHelper = new THREE.GridHelper(30, 30, 0x333355, 0x222244);
        gridHelper.position.y = -1;
        scene.add(gridHelper);

        // Floating particles
        const particleCount