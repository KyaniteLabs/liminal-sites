<think>
The user wants a Three.js 3D scene with rotating geometric shapes and lighting. Let me create a comprehensive, visually appealing scene that follows all the constraints and best practices.

I'll create:
1. Multiple geometric shapes (cube, sphere, cone, cylinder, torus, etc.)
2. Proper lighting setup (ambient + directional + point lights)
3. Post-processing effects for polish
4. Subtle animations (rotation, floating)
5. OrbitControls for interaction
6. Window resize handling
7. MeshStandardMaterial or MeshPhysicalMaterial

Let me design a nice scene with various shapes arranged artistically with good lighting and materials.
</think>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rotating 3D Geometric Shapes</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            overflow: hidden;
            background: #000;
        }
        canvas {
            display: block;
        }
        #info {
            position: absolute;
            bottom: 20px;
            left: 50%;
            transform: translateX(-50%);
            color: rgba(255, 255, 255, 0.7);
            font-family: 'Segoe UI', sans-serif;
            font-size: 14px;
            pointer-events: none;
            text-align: center;
        }
    </style>
</head>
<body>
    <div id="info">Drag to rotate • Scroll to zoom • Right-click to pan</div>
    <script type="importmap">
    {
        "imports": {
            "three": "https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.module.js",
            "three/addons/": "https://cdn.jsdelivr.net/npm/three@0.160.0/examples/jsm/"
        }
    }
    </script>
    <script type="module">
        import * as THREE from 'three';
        import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
        import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
        import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
        import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js';

        let scene, camera, renderer, composer, controls;
        let shapes = [];
        let clock = new THREE.Clock();

        init();
        animate();

        function init() {
            scene = new THREE.Scene();
            scene.background = new THREE.Color(0x0a0a0f);
            scene.fog = new THREE.Fog(0x0a0a0f, 15, 35);

            camera = new THREE.PerspectiveCamera(60, window.innerWidth / window.innerHeight, 0.1, 100);
            camera.position.set(0, 5, 12);

            renderer = new THREE.WebGLRenderer({ antialias: true });
            renderer.setSize(window.innerWidth, window.innerHeight);
            renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
            renderer.toneMapping = THREE.ACESFilmicToneMapping;
            renderer.toneMappingExposure = 1.2;
            document.body.appendChild(renderer.domElement);

            controls = new OrbitControls(camera, renderer.domElement);
            controls.enableDamping = true;
            controls.dampingFactor = 0.05;
            controls.minDistance = 5;
            controls.maxDistance = 30;

            const ambientLight = new THREE.AmbientLight(0x404040, 0.5);
            scene.add(ambientLight);

            const directionalLight = new THREE.DirectionalLight(0xffffff, 1);
            directionalLight.position.set(5, 10, 7);
            scene.add(directionalLight);

            const pointLight1 = new THREE.PointLight(0xff6b6b, 2, 20);
            pointLight1.position.set(-5, 3, -5);
            scene.add(pointLight1);

            const pointLight2 = new THREE.PointLight(0x4ecdc4, 2, 20);
            pointLight2.position.set(5, 3, -5);
            scene.add(pointLight2);

            const pointLight3 = new THREE.PointLight(0xf7d794, 2, 20);
            pointLight3.position.set(0, 5, 5);
            scene.add(pointLight3);

            createShapes();

            const gridHelper = new THREE.GridHelper(20, 20, 0x222233, 0x111122);
            gridHelper.position.y = -3;
            scene.add(gridHelper);

            composer = new EffectComposer(renderer);
            const renderPass = new RenderPass(scene, camera);
            composer.addPass(renderPass);

            const bloomPass = new UnrealBloomPass(
                new THREE.Vector2(window.innerWidth, window.innerHeight),
                0.8,
                0.4,
                0.85
            );
            composer.addPass(bloomPass);

            window.addEventListener('resize', onWindowResize);
        }

        function createShapes() {
            const materials = [
                new THREE.MeshStandardMaterial({ color: 0xff6b6b, metalness: 0.3, roughness: 0.4 }),
                new THREE.MeshStandardMaterial({ color: 0x4ecdc4, metalness: 0.3, roughness: 0.4 }),
                new THREE.MeshStandardMaterial({ color: 0xf7d794, metalness: 0.3, roughness: 0.4 }),
                new THREE.MeshStandardMaterial({ color: 0xa29bfe, metalness: 0.3, roughness: 0.4 }),
                new THREE.MeshStandardMaterial({ color: 0xfd79a8, metalness: 0.3, roughness: 0.4 }),
                new THREE.MeshStandardMaterial({ color: 0x00b894, metalness: 0.3, roughness: 0.4 })
            ];

            const geometries = [
                new THREE.BoxGeometry(1.5, 1.5, 1.5),
                new THREE.SphereGeometry(0.9, 32, 32),
                new THREE.ConeGeometry(0.8, 1.6, 32),
                new THREE.CylinderGeometry(0.5, 0.5, 1.5, 32),
                new THREE.TorusGeometry(0.7, 0.3, 16, 100),
                new THREE.OctahedronGeometry(0.9),
                new THREE.TetrahedronGeometry(0.9),
                new THREE.DodecahedronGeometry(0.8),
                new THREE.IcosahedronGeometry(0.8),
                new THREE.TorusKnotGeometry(0.5, 0.2, 64, 8)
            ];

            const positions = [
                { x: 0, y: 0, z: 0 },
                { x: 4, y: 1, z: 0 },
                { x: -4, y: -0.5, z: 0 },
                { x: 0, y: 2.5, z: -3 },
                { x: 3, y: -1, z: -2 },
                { x: -3, y: 1.5, z: -2 },
                { x: 2, y: -2, z: -4 },
                { x: -2, y: -1.5, z: -3 },
                { x: 5, y: 2, z: -5 },
                { x: -5, y: 0, z: -4 }
            ];

            const rotationSpeeds = [
                { x: 0.01, y: 0.015, z: 0 },
                { x: 0.008, y: 0.01, z: 0.005 },
                { x: 0.012, y: 0.008, z: 0.003 },
                { x: 0.006, y: 0.012, z: 0.008 },
                { x: 0.015, y: 0.005, z: 0.01 }
            ];

            const floatOffsets = [];
            const floatSpeeds = [];

            for (let i = 0; i < geometries.length; i++) {
                const material = materials[i % materials.length];
                const mesh = new THREE.Mesh(geometries[i], material);
                
                const pos = positions[i];
                mesh.position.set(pos.x, pos.y, pos.z);
                
                mesh.rotation.x = Math.random() * Math.PI;
                mesh.rotation.y = Math.random() * Math.PI;

                const speed = rotationSpeeds[i % rotationSpeeds.length];
                mesh.userData.rotationSpeed = { ...speed };
                mesh.userData.originalY = pos.y;
                mesh.userData.index = i;

                floatOffsets.push(Math.random() * Math.PI * 2);
                floatSpeeds.push(0.5 + Math.random() * 0.5