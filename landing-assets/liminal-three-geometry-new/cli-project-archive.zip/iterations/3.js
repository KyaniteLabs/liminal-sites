<think>
The user wants a creative 3D scene with rotating geometric shapes and lighting. Let me create an engaging scene with:

1. Multiple geometric shapes (icosahedron, torus knot, octahedron, dodecahedron, etc.)
2. MeshStandardMaterial with interesting colors and properties
3. Multiple lights (ambient + point/directional)
4. Post-processing bloom effect
5. Animation loop with rotating/floating shapes
6. OrbitControls for interaction
7. Window resize handling

Let me make this visually impressive with:
- A variety of geometric shapes arranged in an interesting composition
- Different materials with metallic/roughness properties
- Bloom post-processing for a glowing effect
- Subtle floating/rotating animations
- A nice background
</think>

```html
<script type="importmap">{"imports":{"three":"https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.module.js","three/addons/":"https://cdn.jsdelivr.net/npm/three@0.160.0/examples/jsm/"}}</script>
<script type="module">
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js';

// Scene setup
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x0a0a1a);
scene.fog = new THREE.FogExp2(0x0a0a1a, 0.03);

// Camera
const camera = new THREE.PerspectiveCamera(60, window.innerWidth / window.innerHeight, 0.1, 1000);
camera.position.set(0, 5, 15);

// Renderer
const renderer = new THREE.WebGLRenderer({ antialias: true });
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.2;
document.body.appendChild(renderer.domElement);

// Orbit Controls
const controls = new OrbitControls(camera, renderer.domElement);
controls.enableDamping = true;
controls.dampingFactor = 0.05;
controls.maxDistance = 50;
controls.minDistance = 5;

// Lighting
const ambientLight = new THREE.AmbientLight(0x222233, 0.5);
scene.add(ambientLight);

const pointLight1 = new THREE.PointLight(0xff6b6b, 2, 50);
pointLight1.position.set(10, 10, 10);
scene.add(pointLight1);

const pointLight2 = new THREE.PointLight(0x4ecdc4, 2, 50);
pointLight2.position.set(-10, 5, -10);
scene.add(pointLight2);

const pointLight3 = new THREE.PointLight(0xf7d794, 1.5, 40);
pointLight3.position.set(0, 15, 0);
scene.add(pointLight3);

// Create geometric shapes
const shapes = [];
const shapeConfigs = [
    { geometry: new THREE.IcosahedronGeometry(1.5, 0), color: 0xff6b6b, metalness: 0.8, roughness: 0.2, position: [0, 3, 0], speed: 0.5 },
    { geometry: new THREE.TorusKnotGeometry(1, 0.3, 100, 16), color: 0x4ecdc4, metalness: 0.9, roughness: 0.1, position: [-4, 2, 2], speed: 0.3 },
    { geometry: new THREE.OctahedronGeometry(1.2, 0), color: 0xf7d794, metalness: 0.7, roughness: 0.3, position: [4, 1, -2], speed: 0.7 },
    { geometry: new THREE.DodecahedronGeometry(1, 0), color: 0xa29bfe, metalness: 0.85, roughness: 0.15, position: [-2, 0, -3], speed: 0.4 },
    { geometry: new THREE.TetrahedronGeometry(1.3, 0), color: 0xfd79a8, metalness: 0.75, roughness: 0.25, position: [3, -1, 3], speed: 0.6 },
    { geometry: new THREE.TorusGeometry(1, 0.4, 20, 40), color: 0x00cec9, metalness: 0.6, roughness: 0.4, position: [-3, -2, 1], speed: 0.8 },
    { geometry: new THREE.ConeGeometry(1, 2, 6, 1), color: 0xfdcb6e, metalness: 0.9, roughness: 0.1, position: [1, -1, -4], speed: 0.45 },
    { geometry: new THREE.BoxGeometry(1.5, 1.5, 1.5, 2, 2, 2), color: 0xe17055, metalness: 0.7, roughness: 0.3, position: [0, -3, 0], speed: 0.35 }
];

shapeConfigs.forEach(config => {
    const material = new THREE.MeshStandardMaterial({
        color: config.color,
        metalness: config.metalness,
        roughness: config.roughness,
        flatShading: true
    });
    
    const mesh = new THREE.Mesh(config.geometry, material);
    mesh.position.set(...config.position);
    mesh.userData = {
        initialY: config.position[1],
        speed: config.speed,
        rotationSpeed: Math.random() * 0.02 + 0.01,
        floatOffset: Math.random() * Math.PI * 2
    };
    
    shapes.push(mesh);
    scene.add(mesh);
});

// Add wireframe versions for visual interest
const wireframeMaterial = new THREE.MeshBasicMaterial({
    color: 0xffffff,
    wireframe: true,
    transparent: true,
    opacity: 0.1
});

shapes.forEach(shape => {
    const wireframe = new THREE.Mesh(shape.geometry, wireframeMaterial);
    wireframe.scale.setScalar(1.01);
    shape.add(wireframe);
});

// Particle system
const particleCount = 500;
const particleGeometry = new THREE.BufferGeometry();
const particlePositions = new Float32Array(particleCount * 3);
const particleSizes = new Float32Array(particleCount);

for (let i = 0; i < particleCount; i++) {
    particlePositions[i * 3] = (Math.random() - 0.5) * 50;
    particlePositions[i * 3 + 1] = (Math.random() - 0.5) * 50;
    particlePositions[i * 3 + 2] = (Math.random() - 0.5) * 50;
    particleSizes[i] = Math.random() * 2;
}

particleGeometry.setAttribute('position', new THREE.BufferAttribute(particlePositions, 3));
particleGeometry.setAttribute('size', new THREE.BufferAttribute(particleSizes, 1));

const particleMaterial = new THREE.PointsMaterial({
    color: 0xffffff,
    size: 0.05,
    transparent: true,
    opacity: 0.6,
    sizeAttenuation: true
});

const particles = new THREE.Points(particleGeometry, particleMaterial);
scene.add(particles);

// Post-processing
const composer = new EffectComposer(renderer);
const renderPass = new RenderPass(scene, camera);
composer.addPass(renderPass);

const bloomPass = new UnrealBloomPass(
    new THREE.Vector2(window.innerWidth, window.innerHeight),
    0.8,
    0.4,
    0.85
);
composer.addPass(bloomPass);

// Animation
let time = 0;

function animate() {
    requestAnimationFrame(animate);
    
    time += 0.016;
    
    // Animate shapes
    shapes.forEach((shape, index) => {
        shape.rotation.x += shape.userData.rotationSpeed;
        shape.rotation.y += shape.userData.rotationSpeed * 0.7;
        
        // Floating animation
        const floatY = Math.sin(time * shape.userData.speed + shape.userData.floatOffset) * 0.5;
        shape.position.y = shape.userData.initialY + floatY;
    });
    
    // Animate particles
    particles.rotation.y += 0.0005;
    particles.rotation.x += 0.0002;
    
    // Animate lights
    pointLight1.position.x = Math.sin(time * 0.5) * 12;
    pointLight1.position.z = Math.cos(time * 0.5) * 12;
    
    pointLight2.position.x = Math.cos(time * 0.3) * 10;
    pointLight2.position.z = Math.sin