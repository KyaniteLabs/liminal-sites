<think>
The user wants a Three.js 3D scene with rotating geometric shapes and lighting. Let me create a comprehensive, visually impressive scene with:

1. Multiple 3D geometric shapes (icosahedron, torus, octahedron, dodecahedron, etc.)
2. Different materials (MeshStandardMaterial/MeshPhysicalMaterial)
3. Proper lighting (ambient + point lights + directional light)
4. Post-processing (bloom effect for glow)
5. OrbitControls for camera interaction
6. Animation loop with rotating shapes
7. Window resize handling
8. Nice colors and visual effects

Let me create this:
</think>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rotating Geometric Shapes</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            overflow: hidden;
            background: #000;
        }
        canvas {
            display: block;
        }
        #info {
            position: absolute;
            bottom: 20px;
            left: 50%;
            transform: translateX(-50%);
            color: rgba(255, 255, 255, 0.7);
            font-family: 'Segoe UI', sans-serif;
            font-size: 14px;
            text-align: center;
            pointer-events: none;
        }
    </style>
</head>
<body>
    <div id="info">Drag to rotate • Scroll to zoom</div>
    <script type="importmap">{"imports":{"three":"https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.module.js","three/addons/":"https://cdn.jsdelivr.net/npm/three@0.160.0/examples/jsm/"}}</script>
    <script type="module">
        import * as THREE from 'three';
        import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
        import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
        import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
        import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js';

        let scene, camera, renderer, composer, controls;
        const shapes = [];
        const clock = new THREE.Clock();

        function init() {
            scene = new THREE.Scene();
            scene.background = new THREE.Color(0x0a0a15);
            scene.fog = new THREE.FogExp2(0x0a0a15, 0.05);

            camera = new THREE.PerspectiveCamera(60, window.innerWidth / window.innerHeight, 0.1, 1000);
            camera.position.set(0, 0, 25);

            renderer = new THREE.WebGLRenderer({ antialias: true });
            renderer.setSize(window.innerWidth, window.innerHeight);
            renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
            renderer.toneMapping = THREE.ACESFilmicToneMapping;
            renderer.toneMappingExposure = 1.2;
            document.body.appendChild(renderer.domElement);

            controls = new OrbitControls(camera, renderer.domElement);
            controls.enableDamping = true;
            controls.dampingFactor = 0.05;
            controls.maxDistance = 50;
            controls.minDistance = 10;

            setupLights();
            createShapes();
            setupPostProcessing();
            addParticles();

            window.addEventListener('resize', onWindowResize);
            animate();
        }

        function setupLights() {
            const ambientLight = new THREE.AmbientLight(0x404060, 0.5);
            scene.add(ambientLight);

            const pointLight1 = new THREE.PointLight(0xff6b9d, 2, 50);
            pointLight1.position.set(10, 10, 10);
            scene.add(pointLight1);

            const pointLight2 = new THREE.PointLight(0x4ecdc4, 2, 50);
            pointLight2.position.set(-10, -10, 10);
            scene.add(pointLight2);

            const pointLight3 = new THREE.PointLight(0xf7dc6f, 1.5, 50);
            pointLight3.position.set(0, 10, -10);
            scene.add(pointLight3);

            const directionalLight = new THREE.DirectionalLight(0xffffff, 0.8);
            directionalLight.position.set(5, 5, 5);
            scene.add(directionalLight);
        }

        function createShapes() {
            const materials = [
                new THREE.MeshStandardMaterial({ color: 0xff6b9d, metalness: 0.3, roughness: 0.4, emissive: 0xff6b9d, emissiveIntensity: 0.2 }),
                new THREE.MeshStandardMaterial({ color: 0x4ecdc4, metalness: 0.5, roughness: 0.3, emissive: 0x4ecdc4, emissiveIntensity: 0.2 }),
                new THREE.MeshStandardMaterial({ color: 0xf7dc6f, metalness: 0.4, roughness: 0.5, emissive: 0xf7dc6f, emissiveIntensity: 0.2 }),
                new THREE.MeshPhysicalMaterial({ color: 0x9b59b6, metalness: 0.6, roughness: 0.2, clearcoat: 1.0, emissive: 0x9b59b6, emissiveIntensity: 0.15 }),
                new THREE.MeshStandardMaterial({ color: 0x3498db, metalness: 0.7, roughness: 0.3, emissive: 0x3498db, emissiveIntensity: 0.2 }),
                new THREE.MeshPhysicalMaterial({ color: 0xe74c3c, metalness: 0.5, roughness: 0.4, clearcoat: 0.5, emissive: 0xe74c3c, emissiveIntensity: 0.15 }),
            ];

            const geometries = [
                new THREE.IcosahedronGeometry(2, 0),
                new THREE.TorusGeometry(1.5, 0.5, 16, 32),
                new THREE.OctahedronGeometry(1.8, 0),
                new THREE.DodecahedronGeometry(1.5, 0),
                new THREE.TetrahedronGeometry(2, 0),
                new THREE.TorusKnotGeometry(1, 0.4, 64, 16),
            ];

            const positions = [
                { x: -8, y: 3, z: 0 },
                { x: 8, y: -2, z: 2 },
                { x: 0, y: -5, z: -3 },
                { x: -5, y: -3, z: 4 },
                { x: 6, y: 4, z: -2 },
                { x: 0, y: 0, z: 0 },
            ];

            const rotationSpeeds = [
                { x: 0.005, y: 0.008, z: 0.003 },
                { x: 0.007, y: 0.004, z: 0.006 },
                { x: 0.003, y: 0.007, z: 0.005 },
                { x: 0.006, y: 0.003, z: 0.007 },
                { x: 0.004, y: 0.006, z: 0.004 },
                { x: 0.008, y: 0.005, z: 0.002 },
            ];

            const floatOffsets = [
                Math.random() * Math.PI * 2,
                Math.random() * Math.PI * 2,
                Math.random() * Math.PI * 2,
                Math.random() * Math.PI * 2,
                Math.random() * Math.PI * 2,
                Math.random() * Math.PI * 2,
            ];

            for (let i = 0; i < geometries.length; i++) {
                const mesh = new THREE.Mesh(geometries[i], materials[i]);
                mesh.position.set(positions[i].x, positions[i].y, positions[i].z);
                mesh.userData = {
                    rotationSpeed: rotationSpeeds[i],
                    floatOffset: floatOffsets[i],
                    baseY: positions[i].y,
                    floatSpeed: 0.5 + Math.random() * 0.5,
                    floatAmplitude: 0.5 + Math.random() * 0.5,
                };
                shapes.push(mesh);
                scene.add(mesh);
            }
        }

        function setupPostProcessing() {
            composer = new EffectComposer(renderer);

            const renderPass = new RenderPass(scene, camera);
            composer.addPass(renderPass);

            const bloomPass = new UnrealBloomPass(
                new THREE.Vector2(window.innerWidth, window.innerHeight),
                0.8,
                0.4,
                0.85