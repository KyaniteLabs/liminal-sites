<think>
The user wants a simple p5.js sketch with colorful circles. The conversation shows "Compiling..." and some partial code, but I should create a fresh, complete p5.js sketch based on the original request.

Let me create an engaging sketch with:
- Colorful circles with varying sizes
- Perlin noise for organic movement
- Smooth color gradients
- Animation for visual interest

I'll make it self-contained and immediately runnable.
</think>

let circles = [];
let numCircles = 80;
let noiseScale = 0.004;
let time = 0;

function setup() {
  createCanvas(800, 600);
  pixelDensity(1);
  
  for (let i = 0; i < numCircles; i++) {
    circles.push({
      x: random(width),
      y: random(height),
      baseX: random(width),
      baseY: random(height),
      size: random(20, 80),
      noiseOffsetX: random(1000),
      noiseOffsetY: random(2000),
      hue: random(360),
      saturation: random(60, 100),
      brightness: random(70, 100),
      alpha: random(100, 200)
    });
  }
  colorMode(HSB, 360, 100, 100, 255);
  noStroke();
}

function draw() {
  background(0, 0, 10, 40);
  time += 0.008;
  
  for (let c of circles) {
    let nx = noise(c.noiseOffsetX + time * 0.5);
    let ny = noise(c.noiseOffsetY + time * 0.5);
    
    let targetX = c.baseX + map(nx, 0, 1, -100, 100);
    let targetY = c.baseY + map(ny, 0, 1, -100, 100);
    
    c.x = lerp(c.x, targetX, 0.02);
    c.y = lerp(c.y, targetY, 0.02);
    
    c.hue = (c.hue + 0.2) % 360;
    
    let pulse = sin(time * 2 + c.noiseOffsetX * 0.01) * 0.2 + 0.8;
    let finalSize = c.size * pulse;
    
    for (let i = 3; i > 0; i--) {
      let layerSize = finalSize * (1 + i * 0.3);
      let layerAlpha = c.alpha * (1 / (i + 1));
      fill(c.hue, c.saturation * 0.5, c.brightness * 0.7, layerAlpha);
      ellipse(c.x, c.y, layerSize, layerSize);
    }
    
    fill(c.hue, c.saturation * 0.3, 100, c.alpha);
    ellipse(c.x, c.y, finalSize, finalSize);
    
    fill(c.hue, c.saturation, c.brightness, c.alpha * 0.8);
    ellipse(c.x, c.y, finalSize * 0.6, finalSize * 0.6);
    
    fill(0, 0, 100, c.alpha);
    ellipse(c.x - finalSize * 0.1, c.y - finalSize * 0.15, finalSize * 0.15, finalSize * 0.15);
  }
}

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
  
  for (let c of circles) {
    c.baseX = random(width);
    c.baseY = random(height);
  }
}