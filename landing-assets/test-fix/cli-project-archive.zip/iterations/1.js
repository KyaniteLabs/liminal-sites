<think>
The user wants a simple p5.js sketch with colorful circles. Let me create an engaging, creative sketch that uses Perlin noise for organic variation in the circles' positions, colors, or sizes.

I'll create:
- Circles with varying positions based on noise
- Colorful gradients or palettes
- Some animation for visual interest
- Perhaps a flow field or wave-like motion

Let me write a complete p5.js sketch.
</think>

let circles = [];
let numCircles = 60;
let noiseScale = 0.005;
let timeOffset = 0;

function setup() {
  createCanvas(800, 600);
  pixelDensity(1);
  colorMode(HSB, 360, 100, 100, 100);
  noiseSeed(random(10000));
  
  for (let i = 0; i < numCircles; i++) {
    circles.push({
      x: random(width),
      y: random(height),
      baseX: random(width),
      baseY: random(height),
      size: random(20, 80),
      noiseOffsetX: random(1000),
      noiseOffsetY: random(2000),
      hue: random(360),
      speed: random(0.5, 2)
    });
  }
}

function draw() {
  background(0, 0, 10, 30);
  
  timeOffset += 0.01;
  
  for (let c of circles) {
    let nx = noise(c.baseX * noiseScale + c.noiseOffsetX, timeOffset * c.speed);
    let ny = noise(c.baseY * noiseScale + c.noiseOffsetY, timeOffset * c.speed);
    
    c.x = lerp(c.x, map(nx, 0, 1, 0, width), 0.02);
    c.y = lerp(c.y, map(ny, 0, 1, 0, height), 0.02);
    
    let pulseSize = c.size + sin(frameCount * 0.05 + c.noiseOffsetX) * 10;
    
    let hueShift = (noise(c.baseX * 0.01, timeOffset) * 60);
    let currentHue = (c.hue + hueShift) % 360;
    
    noStroke();
    fill(currentHue, 70, 90, 60);
    ellipse(c.x, c.y, pulseSize);
    
    fill(currentHue, 50, 100, 30);
    ellipse(c.x, c.y, pulseSize * 0.5);
  }
}

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
  for (let c of circles) {
    c.baseX = random(width);
    c.baseY = random(height);
  }
}

function mousePressed() {
  noiseSeed(random(10000));
  for (let c of circles) {
    c.noiseOffsetX = random(1000);
    c.noiseOffsetY = random(2000);
    c.baseX = random(width);
    c.baseY = random(height);
  }
}