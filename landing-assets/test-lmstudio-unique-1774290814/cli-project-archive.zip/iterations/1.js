<think>
The user wants a p5.js sketch featuring:
1. Flowing bezier curves
2. Mouse position responsiveness
3. Hue that changes over time

Let me create a generative art piece with these elements. I'll use:
- Perlin noise for organic curve variation
- HSB color mode for smooth hue cycling
- Mouse position to influence the curve control points
- Multiple layered bezier curves for depth

I need to output just the raw code, no markdown fences or explanations.
</think>

let curves = [];
let numCurves = 12;
let time = 0;

function setup() {
  createCanvas(800, 600);
  colorMode(HSB, 360, 100, 100, 100);
  pixelDensity(1);
  
  for (let i = 0; i < numCurves; i++) {
    curves.push({
      offset: i * 0.3,
      thickness: map(i, 0, numCurves, 3, 1),
      speed: random(0.3, 0.7)
    });
  }
}

function draw() {
  background(0, 0, 10, 30);
  
  let baseHue = (frameCount * 0.5) % 360;
  
  for (let i = 0; i < numCurves; i++) {
    let c = curves[i];
    let hueOffset = (i * 25) % 360;
    let hue = (baseHue + hueOffset) % 360;
    
    stroke(hue, 70, 90, 80);
    noFill();
    strokeWeight(c.thickness);
    
    drawFlowingCurve(c, hue);
  }
  
  time += 0.008;
}

function drawFlowingCurve(c, hue) {
  beginShape();
  
  let segments = 8;
  for (let s = 0; s <= segments; s++) {
    let t = s / segments;
    let x = t * width;
    let y = getNoiseY(t, c.offset);
    
    curveVertex(x, y);
  }
  
  endShape();
  
  beginShape();
  
  for (let s = 0; s <= segments; s++) {
    let t = s / segments;
    let x = t * width;
    let y = getNoiseY2(t, c.offset);
    
    curveVertex(x, y);
  }
  
  endShape();
  
  drawBezierOverlay(c, hue);
}

function getNoiseY(t, offset) {
  let scale1 = 150;
  let scale2 = 0.8;
  
  let n1 = noise(t * scale2 + offset, time * 2 + offset);
  let n2 = noise(t * scale2 * 1.5 + 100, time * 1.5 + offset + 50);
  
  let mouseInfluence = map(mouseX, 0, width, 0.3, 1.2);
  let yOffset = map(mouseY, 0, height, -100, 100);
  
  let y = height * 0.5 + (n1 - 0.5) * scale1 * mouseInfluence;
  y += (n2 - 0.5) * 80;
  y += yOffset * (n1 * 0.5 + 0.5);
  
  return y;
}

function getNoiseY2(t, offset) {
  let scale = 200;
  let n = noise(t * 0.5 + offset + 200, time * 1.2 + offset);
  
  let mouseInfluence = map(mouseY, 0, height, 0.5, 1.5);
  
  let y = height * 0.5 + (n - 0.5) * scale * mouseInfluence;
  y += map(mouseX, 0, width, -50, 50) * n;
  
  return y;
}

function drawBezierOverlay(c, hue) {
  let x1 = width * 0.1;
  let x2 = width * 0.9;
  
  let noiseOffset = time * 2 + c.offset * 10;
  
  let y1 = height * 0.3 + noise(noiseOffset) * 200;
  let y2 = height * 0.7 + noise(noiseOffset + 50) * 200;
  
  let cx1 = width * 0.3 + noise(noiseOffset + 100) * 150 + map(mouseX, 0, width, -50, 50);
  let cy1 = height * 0.5 + noise(noiseOffset + 150) * 100 + map(mouseY, 0, height, -80, 80);
  
  let cx2 = width * 0.7 + noise(noiseOffset + 200) * 150 + map(mouseX, 0, width, -30, 30);
  let cy2 = height * 0.5 + noise(noiseOffset + 250) * 100 + map(mouseY, 0, height, -60, 60);
  
  stroke(hue, 50, 95, 50);
  strokeWeight(c.thickness * 0.7);
  noFill();
  
  beginShape();
  for (let t = 0; t <= 1; t += 0.05) {
    let x = bezierPoint(x1, cx1, cx2, x2, t);
    let y = bezierPoint(y1, cy1, cy2, y2, t);
    
    let n = noise(t * 3 + noiseOffset, time * 3);
    y += (n - 0.5) * 40;
    
    curveVertex(x, y);
  }
  endShape();
  
  stroke(hue, 80, 100, 30);
  strokeWeight(0.5);
  
  let steps = 60;
  for (let i = 0; i < steps; i++) {
    let t1 = i / steps;
    let t2 = (i + 1) / steps;
    
    let x1 = bezierPoint(x1, cx1, cx2, x2, t1);
    let y1 = bezierPoint(y1, cy1, cy2, y2, t1);
    let x2 = bezierPoint(x1, cx1, cx2, x2, t2);
    let y2 = bezierPoint(y1, cy1, cy2, y2, t2);
    
    let n1 = noise(t1 * 4 + noiseOffset + 300);
    let n2 = noise(t2 * 4 + noiseOffset + 300);
    
    y1 += (n1 - 0.5) * 30;
    y2 += (n2 - 0.5) * 30;
    
    line(x1, y1, x2, y2);
  }
}

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
}

function mousePressed() {
  noiseSeed(random(10000));
  time = 0;
  
  for (let i = 0; i < numCurves; i++) {
    curves[i].offset = random(1000);
    curves[i].speed = random(0.3, 0.7);
  }
}