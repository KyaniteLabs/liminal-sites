<think>
The user wants a p5.js sketch with:
1. Flowing bezier curves
2. Mouse position responsiveness
3. Hue that changes over time

Let me create a beautiful generative art piece with these elements. I'll use Perlin noise for organic curve movement, HSB color mode for smooth hue cycling, and mouse position to influence the curves.

I need to output only the JavaScript code, no markdown fences or explanatory text.

Let me design this:
- Multiple bezier curves that flow and undulate
- Perlin noise controlling the control points for organic movement
- Hue shifts over time
- Mouse position influences the curve behavior
- Layered curves for depth and visual interest
</think>

let noiseSeeds = [];
let timeOffset = 0;
let numCurves = 8;

function setup() {
  createCanvas(800, 600);
  colorMode(HSB, 360, 100, 100, 100);
  pixelDensity(1);
  
  for (let i = 0; i < numCurves; i++) {
    noiseSeeds.push(random(1000));
  }
}

function draw() {
  background(0, 0, 10, 30);
  
  let baseHue = (frameCount * 0.5) % 360;
  
  for (let c = 0; c < numCurves; c++) {
    let noiseVal = noiseSeeds[c];
    let hue = (baseHue + c * 40) % 360;
    let saturation = 70 + sin(frameCount * 0.02 + c) * 20;
    let brightness = 80 + sin(frameCount * 0.03 + c * 0.5) * 15;
    let alpha = 40 + c * 5;
    
    stroke(hue, saturation, brightness, alpha);
    noFill();
    strokeWeight(map(c, 0, numCurves - 1, 1, 4));
    
    beginShape();
    
    let segments = 20;
    for (let i = 0; i <= segments; i++) {
      let t = i / segments;
      
      let x = t * width;
      let y = height * 0.5;
      
      let noiseX = map(noise(noiseVal + t * 2 + timeOffset), 0, 1, -200, 200);
      let noiseY = map(noise(noiseVal + t * 3 + 100 + timeOffset), 0, 1, -150, 150);
      
      let mouseInfluenceX = map(mouseX, 0, width, -100, 100);
      let mouseInfluenceY = map(mouseY, 0, height, -80, 80);
      
      let mouseNoiseX = map(noise(mouseX * 0.01, mouseY * 0.01 + timeOffset), 0, 1, -50, 50);
      let mouseNoiseY = map(noise(mouseX * 0.01 + 50, mouseY * 0.01 + timeOffset), 0, 1, -50, 50);
      
      x += noiseX + mouseInfluenceX * 0.3 + mouseNoiseX * 0.5;
      y += noiseY + mouseInfluenceY * 0.3 + mouseNoiseY * 0.5;
      
      let curveOffset = sin(t * PI * 2 + frameCount * 0.02 + c) * 30;
      y += curveOffset;
      
      curveVertex(x, y);
    }
    
    endShape();
    
    // Secondary flowing curve offset
    stroke(hue, saturation * 0.8, brightness * 0.9, alpha * 0.5);
    strokeWeight(map(c, 0, numCurves - 1, 0.5, 2));
    
    beginShape();
    
    for (let i = 0; i <= segments; i++) {
      let t = i / segments;
      
      let x = t * width;
      let y = height * 0.5;
      
      let noiseX = map(noise(noiseVal + t * 2.5 + timeOffset + 500), 0, 1, -250, 250);
      let noiseY = map(noise(noiseVal + t * 3.5 + 600 + timeOffset), 0, 1, -180, 180);
      
      let mouseInfluenceX = map(mouseX, 0, width, -150, 150);
      let mouseInfluenceY = map(mouseY, 0, height, -100, 100);
      
      x += noiseX + mouseInfluenceX * 0.4;
      y += noiseY + mouseInfluenceY * 0.4;
      
      let curveOffset = cos(t * PI * 3 + frameCount * 0.025 + c * 0.3) * 40;
      y += curveOffset;
      
      curveVertex(x, y);
    }
    
    endShape();
  }
  
  // Connecting threads
  for (let i = 0; i < 5; i++) {
    let threadHue = (baseHue + i * 72 + 180) % 360;
    stroke(threadHue, 50, 70, 20);
    strokeWeight(0.5);
    
    let yStart = map(noise(i * 100 + timeOffset), 0, 1, height * 0.2, height * 0.8);
    let yEnd = map(noise(i * 100 + 50 + timeOffset), 0, 1, height * 0.2, height * 0.8);
    
    let cp1x = map(noise(i * 50 + timeOffset, 10), 0, 1, width * 0.2, width * 0.4);
    let cp1y = map(noise(i * 50 + 20 + timeOffset, mouseY * 0.01), 0, 1, height * 0.1, height * 0.9);
    let cp2x = map(noise(i * 50 + 30 + timeOffset, 20), 0, 1, width * 0.6, width * 0.8);
    let cp2y = map(noise(i * 50 + 40 + timeOffset, mouseX * 0.01), 0, 1, height * 0.1, height * 0.9);
    
    let endX = map(noise(i * 100 + 100 + timeOffset), 0, 1, width * 0.8, width);
    let endY = map(noise(i * 100 + 150 + timeOffset), 0, 1, height * 0.2, height * 0.8);
    
    bezier(0, yStart, cp1x, cp1y, cp2x, cp2y, endX, endY);
  }
  
  timeOffset += 0.003;
}

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
}