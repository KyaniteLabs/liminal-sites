<think>
The user wants an underwater scene with light rays, caustics, and bubbles using p5.js. Let me create a complete sketch with:

1. Light rays coming from above (God rays effect)
2. Caustic patterns on the floor
3. Bubbles rising up
4. Organic movement using noise()
5. A deep blue/green color palette

I'll create:
- A gradient background from deep blue to lighter blue
- Multiple light rays using noise for variation
- Caustic patterns on the "seafloor"
- Particle-based bubbles with varying sizes and speeds
- Smooth, natural movements

Let me write this without any markdown or code blocks, just raw JavaScript.
</think>

let bubbles = [];
let numBubbles = 60;
let numRays = 12;
let rayNoiseSeeds = [];
let causticPoints = [];

function setup() {
  createCanvas(800, 600);
  pixelDensity(1);
  
  for (let i = 0; i < numBubbles; i++) {
    bubbles.push({
      x: random(width),
      y: random(height),
      size: random(3, 12),
      speed: random(0.5, 2),
      wobbleOffset: random(1000),
      wobbleSpeed: random(0.02, 0.05),
      opacity: random(100, 200)
    });
  }
  
  for (let i = 0; i < numRays; i++) {
    rayNoiseSeeds.push(random(1000));
  }
  
  for (let i = 0; i < 40; i++) {
    causticPoints.push({
      x: random(width),
      y: random(height * 0.6, height),
      baseX: random(width),
      baseY: random(height * 0.6, height),
      size: random(30, 80),
      noiseOffset: random(1000),
      speed: random(0.005, 0.015)
    });
  }
}

function draw() {
  drawBackground();
  drawLightRays();
  drawCaustics();
  drawSeabed();
  updateAndDrawBubbles();
  drawWaterSurface();
}

function drawBackground() {
  for (let y = 0; y < height; y++) {
    let inter = map(y, 0, height, 0, 1);
    let c = lerpColor(color(20, 60, 100), color(10, 30, 60), inter);
    stroke(c);
    line(0, y, width, y);
  }
}

function drawLightRays() {
  noStroke();
  for (let i = 0; i < numRays; i++) {
    let rayX = map(i, 0, numRays, 0, width);
    let time = frameCount * 0.01;
    
    rayX += noise(rayNoiseSeeds[i], time) * 100 - 50;
    
    let rayWidth = noise(rayNoiseSeeds[i] + 100, time) * 80 + 40;
    let rayOpacity = noise(rayNoiseSeeds[i] + 200, time) * 40 + 20;
    
    for (let w = rayWidth; w > 0; w -= 2) {
      let alpha = map(w, 0, rayWidth, rayOpacity * 0.3, rayOpacity);
      fill(150, 220, 255, alpha);
      
      beginShape();
      let topWidth = w * 0.1;
      vertex(rayX - topWidth, 0);
      vertex(rayX + topWidth, 0);
      vertex(rayX + w, height);
      vertex(rayX - w, height);
      endShape(CLOSE);
    }
  }
}

function drawCaustics() {
  noStroke();
  let time = frameCount * 0.02;
  
  for (let c of causticPoints) {
    let nx = noise(c.noiseOffset, time);
    let ny = noise(c.noiseOffset + 500, time);
    
    let cx = c.baseX + (nx - 0.5) * 150;
    let cy = c.baseY + (ny - 0.5) * 80;
    let size = c.size + noise(c.noiseOffset + 300, time) * 30;
    
    for (let i = 5; i > 0; i--) {
      let alpha = map(i, 5, 0, 5, 30);
      let sh = map(i, 5, 0, size * 0.3, size);
      fill(100, 200, 255, alpha);
      
      beginShape();
      for (let a = 0; a < TWO_PI; a += PI / 3) {
        let r = sh * (0.8 + noise(c.noiseOffset + a * 100, time * 2) * 0.4);
        let px = cx + cos(a) * r;
        let py = cy + sin(a) * r;
        vertex(px, py);
      }
      endShape(CLOSE);
    }
  }
}

function drawSeabed() {
  noStroke();
  for (let y = height * 0.75; y < height; y++) {
    let inter = map(y, height * 0.75, height, 0, 1);
    let sandNoise = noise(y * 0.02, frameCount * 0.01) * 20;
    let c = lerpColor(color(40, 60, 80), color(20, 35, 50), inter + sandNoise * 0.01);
    fill(c);
    rect(0, y, width, 1);
  }
  
  for (let i = 0; i < 50; i++) {
    let px = noise(i * 0.1, frameCount * 0.005) * width;
    let py = height - 20 + noise(i * 0.1 + 500, frameCount * 0.005) * 40;
    let ps = noise(i * 0.1 + 200) * 8 + 2;
    fill(60, 90, 110, 100);
    ellipse(px, py, ps, ps * 0.5);
  }
}

function updateAndDrawBubbles() {
  noStroke();
  for (let b of bubbles) {
    b.y -= b.speed;
    b.x += sin(frameCount * b.wobbleSpeed + b.wobbleOffset) * 0.8;
    
    if (b.y < -b.size) {
      b.y = height + b.size;
      b.x = random(width);
    }
    
    let highlightSize = b.size * 0.3;
    fill(200, 230, 255, b.opacity * 0.8);
    ellipse(b.x, b.y, b.size, b.size);
    
    fill(255, 255, 255, b.opacity);
    ellipse(b.x - b.size * 0.25, b.y - b.size * 0.25, highlightSize, highlightSize);
    
    stroke(180, 220, 255, b.opacity * 0.3);
    strokeWeight(1);
    noFill();
    ellipse(b.x, b.y, b.size * 1.1, b.size * 1.1);
    noStroke();
  }
}

function drawWaterSurface() {
  noStroke();
  fill(30, 80, 120, 100);
  beginShape();
  vertex(0, 0);
  
  for (let x = 0; x <= width; x += 20) {
    let y = noise(x * 0.01, frameCount * 0.03) * 15 + 5;
    vertex(x, y);
  }
  
  vertex(width, 0);
  endShape(CLOSE);
  
  fill(80, 160, 200, 50);
  beginShape();
  vertex(0, 0);
  
  for (let x = 0; x <= width; x += 20) {
    let y = noise(x * 0.02 + 100, frameCount * 0.04) * 10 + 3;
    vertex(x, y);
  }
  
  vertex(width, 0);
  endShape(CLOSE);
}

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
  causticPoints = [];
  for (let i = 0; i < 40; i++) {
    causticPoints.push({
      x: random(width),
      y: random(height * 0.6, height),
      baseX: random(width),
      baseY: random(height * 0.6, height),
      size: random(30, 80),
      noiseOffset: random(1000),
      speed: random(0.005, 0.015)
    });
  }
}