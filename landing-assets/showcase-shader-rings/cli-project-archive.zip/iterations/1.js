This creates animated concentric rings with the RGB channels offset radially to produce chromatic aberration. The rings pulse and shift over time with smooth color transitions. , aberrationB);
    
    gl_FragColor = vec4(color, 1.0);
}