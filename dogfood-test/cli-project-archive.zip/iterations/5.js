<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Interactive Canvas Visualization</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            display: flex;
            flex-direction: column;
            align-items: center;
            margin: 20px;
            background-color: #f4f4f9;
        }
        h1 {
            color: #333;
        }
        #visualizationCanvas {
            border: 2px solid #ccc;
            background-color: #fff;
            cursor: crosshair;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .controls {
            margin-top: 20px;
            padding: 15px;
            background-color: #e9e9ff;
            border-radius: 8px;
            display: flex;
            gap: 20px;
            align-items: center;
        }
        button {
            padding: 10px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            background-color: #007bff;
            color: white;
            transition: background-color 0.3s;
        }
        button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>

    <h1>Interactive Canvas Visualization (Sine Wave Example)</h1>

    <canvas id="visualizationCanvas" width="800" height="400"></canvas>

    <div class="controls">
        <button id="resetButton">Reset View</button>
        <label for="amplitudeSlider">Amplitude:</label>
        <input type="range" id="amplitudeSlider" min="10" max="100" value="70">
        <span id="amplitudeValue">70</span>
    </div>

    <script>
        const canvas = document.getElementById('visualizationCanvas');
        const ctx = canvas.getContext('2d');
        const resetButton = document.getElementById('resetButton');
        const amplitudeSlider = document.getElementById('amplitudeSlider');
        const amplitudeValueSpan = document.getElementById('amplitudeValue');

        const CANVAS_WIDTH = canvas.width;
        const CANVAS_HEIGHT = canvas.height;

        let amplitude = parseFloat(amplitudeSlider.value);
        let waveFrequency = 0.01; // Controls how many cycles fit on screen

        // --- Drawing Function ---
        function drawVisualization() {
            // 1. Clear the canvas
            ctx.clearRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);

            // 2. Draw the central axis (x-axis baseline)
            ctx.strokeStyle = '#aaa';
            ctx.lineWidth = 1;
            ctx.beginPath();
            ctx.moveTo(0, CANVAS_HEIGHT / 2);
            ctx.lineTo(CANVAS_WIDTH, CANVAS_HEIGHT / 2);
            ctx.stroke();

            // 3. Draw the Sine Wave
            ctx.beginPath();
            ctx.strokeStyle = '#ff6b6b'; // Coral color for the wave
            ctx.lineWidth = 3;

            const centerY = CANVAS_HEIGHT / 2;
            const amplitudeY = amplitude; // Use the dynamic amplitude

            // Start at the left edge
            ctx.moveTo(0, centerY + amplitudeY * Math.sin(waveFrequency * 0));

            // Draw the curve using a loop (approximating a continuous wave)
            for (let x = 0; x <= CANVAS_WIDTH; x += 10) {
                // Calculate the y-coordinate based on a sine function: y = A * sin(k*x) + C
                // A = amplitude, k = waveFrequency, C = centerY
                const y = centerY + (amplitudeY * Math.sin(waveFrequency * x * 0.02));
                ctx.lineTo(x, y);
            }

            ctx.stroke();
        }

        // --- Event Handlers ---

        // 1. Slider Interaction
        amplitudeSlider.addEventListener('input', (e) => {
            amplitude = parseFloat(e.target.value);
            amplitudeValueSpan.textContent = amplitude;
            drawVisualization();
        });

        // 2. Reset Button
        resetButton.addEventListener('click', () => {
            // Reset slider and amplitude value
            amplitudeSlider.value = 70;
            amplitude = 70;
            amplitudeValueSpan.textContent = 70;
            drawVisualization();
        });

        // 3. Mouse Interaction (Example: Click to mark a point)
        let isDrawing = false;
        canvas.addEventListener('mousedown', (e) => {
            isDrawing = true;
            // Draw a temporary marker when clicking
            drawMarker(e);
        });

        canvas.addEventListener('mouseup', () => {
            isDrawing = false;
        });

        canvas.addEventListener('mousemove', (e) => {
            if (isDrawing) {
                drawMarker(e);
            }
        });

        function drawMarker(e) {
            // Get the coordinates relative to the canvas
            const rect = canvas.getBoundingClientRect();
            const mouseX = e.clientX - rect.left;
            const mouseY = e.clientY - rect.top;

            // Redraw the wave first
            drawVisualization();

            // Draw a circle marker at the mouse position
            ctx.fillStyle = 'rgba(255, 99, 71, 0.8)'; // Reddish color
            ctx.beginPath();
            ctx.arc(mouseX, mouseY, 5, 0, Math.PI * 2);
            ctx.fill();
        }


        // --- Initialization ---
        window.onload = () => {
            drawVisualization();
        };

    </script>

</body>
</html>