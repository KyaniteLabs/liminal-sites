<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Interactive Canvas Visualization</title>
    <style>
        body {
            font-family: sans-serif;
            display: flex;
            flex-direction: column;
            align-items: center;
            background-color: #f4f4f9;
            padding: 20px;
        }
        h1 {
            color: #333;
        }
        canvas {
            border: 2px solid #333;
            background-color: #ffffff;
            cursor: crosshair;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .controls {
            margin-top: 20px;
            padding: 15px;
            background: #eef;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
        }
        button {
            padding: 10px 15px;
            margin-right: 10px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            background-color: #007bff;
            color: white;
            transition: background-color 0.3s;
        }
        button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>

    <h1>Interactive Data Visualization (Canvas Drawing/Simulation)</h1>

    <canvas id="visualizationCanvas" width="800" height="500"></canvas>

    <div class="controls">
        <button id="resetButton">Reset Simulation</button>
        <label for="particleCount">Particles:</label>
        <input type="range" id="particleCount" min="10" max="100" value="50">
    </div>

    <script>
        const canvas = document.getElementById('visualizationCanvas');
        const ctx = canvas.getContext('2d');
        const resetButton = document.getElementById('resetButton');
        const particleCountSlider = document.getElementById('particleCount');

        // --- Particle System Setup ---
        class Particle {
            constructor(x, y) {
                this.x = x;
                this.y = y;
                this.radius = Math.random() * 3 + 1;
                this.color = `hsl(${Math.random() * 360}, 70%, 50%)`;
                this.vx = (Math.random() - 0.5) * 1.5;
                this.vy = (Math.random() - 0.5) * 1.5;
                this.life = 1; // For potential fading effects
            }

            update() {
                // Apply physics (damping and movement)
                this.vx *= 0.98;
                this.vy *= 0.98;
                this.x += this.vx;
                this.y += this.vy;

                // Boundary collision detection (bouncing off walls)
                if (this.x + this.radius > canvas.width || this.x - this.radius < 0) {
                    this.vx *= -1;
                }
                if (this.y + this.radius > canvas.height || this.y - this.radius < 0) {
                    this.vy *= -1;
                }

                // Simple life decay
                this.life -= 0.005;
            }

            draw() {
                ctx.beginPath();
                ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2);
                
                // Fade color based on life
                const alpha = Math.min(1, this.life * 2);
                ctx.fillStyle = this.color.replace(')', `, ${alpha})`); // Simple attempt to adjust alpha
                ctx.globalAlpha = alpha;
                ctx.fill();
                ctx.globalAlpha = 1.0; // Reset global alpha
            }
        }

        let particles = [];

        // --- Initialization & Reset ---
        function initializeParticles(count) {
            particles = [];
            for (let i = 0; i < count; i++) {
                const x = Math.random() * (canvas.width - 20) + 10;
                const y = Math.random() * (canvas.height - 20) + 10;
                particles.push(new Particle(x, y));
            }
        }

        function draw() {
            // Clear the canvas for the next frame
            ctx.clearRect(0, 0, canvas.width, canvas.height);

            // Draw a faint background effect to simulate trails
            ctx.fillStyle = 'rgba(255, 255, 255, 0.05)'; 
            ctx.fillRect(0, 0, canvas.width, canvas.height);

            // Update and Draw Particles
            particles.forEach(p => {
                p.update();
                p.draw();
            });

            // Request next animation frame
            requestAnimationFrame(draw);
        }

        // --- Event Handlers ---

        // 1. Interaction: Mouse Click (Spawn temporary effect)
        canvas.addEventListener('click', (event) => {
            const rect = canvas.getBoundingClientRect();
            const clickX = event.clientX - rect.left;
            const clickY = event.clientY - rect.top;

            // Spawn a burst of particles at the click location
            for (let i = 0; i < 10; i++) {
                const burstParticle = new Particle(clickX, clickY);
                // Give it an initial outward velocity
                burstParticle.vx = (Math.random() - 0.5) * 5;
                burstParticle.vy = (Math.random() - 0.5) * 5;
                particles.push(burstParticle);
            }
        });

        // 2. Controls: Reset Button
        resetButton.addEventListener('click', () => {
            const count = parseInt(particleCountSlider.value);
            initializeParticles(count);
        });

        // 3. Controls: Particle Count Slider
        particleCountSlider.addEventListener('input', () => {
            const count = parseInt(particleCountSlider.value);
            // Re-initialize particles when the slider changes
            initializeParticles(count);
        });


        // --- Initial Setup ---
        let animationFrameId;

        function startSimulation() {
            // Initialize with default particle count
            const initialCount = parseInt(particleCountSlider.value);
            initializeParticles(initialCount);

            // Start the drawing loop if it hasn't started
            if (!animationFrameId) {
                draw();
            }
        }
        
        // Start the visualization when the script loads
        startSimulation();

    </script>

</body>
</html>