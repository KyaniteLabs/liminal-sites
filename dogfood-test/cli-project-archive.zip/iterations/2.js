let particles = [];
const NUM_PARTICLES = 150;
const BLUE_HUE = 200; // A calming blue hue value (in HSB context, often around 200)

class Particle {
  constructor(x, y) {
    this.pos = createVector(x, y);
    // Initial velocity is small and somewhat random
    this.vel = p5.Vector.random2D().mult(0.5);
    this.acc = createVector(0, 0);
    this.lifespan = 255;
    this.radius = random(2, 5);
  }

  applyForce(force) {
    this.acc.add(force);
  }

  update() {
    this.vel.add(this.acc);
    this.vel.limit(2); // Limit speed to keep movement gentle
    this.pos.add(this.vel);
    this.acc.mult(0); // Reset acceleration for the next frame

    // Gradually reduce lifespan and fade
    this.lifespan -= 1.5;
  }

  display() {
    let alpha = this.lifespan;
    let color = color(BLUE_HUE, 80, 90, alpha); // HSB color: Hue, Saturation, Brightness, Alpha
    stroke(color);
    strokeWeight(this.radius);
    fill(color);
    ellipse(this.pos.x, this.pos.y, this.radius * 2);
  }

  isDead() {
    return this.lifespan < 0;
  }
}

function setup() {
  createCanvas(windowWidth, windowHeight);
  
  // Initialize particles spread across the canvas
  for (let i = 0; i < NUM_PARTICLES; i++) {
    let x = random(width);
    let y = random(height);
    particles.push(new Particle(x, y));
  }
}

function draw() {
  // Create a faint, semi-transparent background to generate trails (the "flow")
  background(0, 0, 0, 15); 

  // Loop through particles and update/display them
  for (let i = particles.length - 1; i >= 0; i--) {
    let p = particles[i];

    if (p.isDead()) {
      // If dead, respawn it near the center or edge to keep the system alive
      p = new Particle(random(width), random(height));
      particles[i] = p;
    } else {
      // --- Flow Field Simulation using Perlin Noise ---
      // Calculate a slight directional influence based on position and time
      let noiseValX = noise(p.pos.x * 0.005, p.pos.y * 0.005, frameCount * 0.003);
      let noiseValY = noise(p.pos.x * 0.005, p.pos.y * 0.005, frameCount * 0.003 + 100);
      
      // Convert noise values (0 to 1) to directional forces
      let angle = map(noiseValX, 0, 1, 0, TWO_PI);
      let flowForce = p5.Vector.fromAngle(angle).mult(0.5);

      // Apply the calculated force to the particle's acceleration
      p.applyForce(flowForce);

      p.update();
      p.display();
    }
  }
}

// Handle window resizing
function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
}