function setup() {
  createCanvas(400, 400);
}

let x;
let y;
let r = 20;
let speedX = 5;
let speedY = 5;

function setup() {
  createCanvas(400, 400);
  x = width / 2;
  y = height / 2;
}

function draw() {
  background(220);

  // Update position
  x += speedX;
  y += speedY;

  // Bounce off left/right walls
  if (x + r > width || x - r < 0) {
    speedX *= -1;
  }

  // Bounce off top/bottom walls
  if (y + r > height || y - r < 0) {
    speedY *= -1;
  }

  // Draw the red ball
  fill(255, 0, 0); // Red color
  ellipse(x, y, r * 2, r * 2);
}