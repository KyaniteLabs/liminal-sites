<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Interactive Data Visualization on Canvas</title>
    <style>
        body {
            font-family: sans-serif;
            display: flex;
            flex-direction: column;
            align-items: center;
            background-color: #f4f4f9;
            margin: 0;
            padding: 20px;
        }
        h1 {
            color: #333;
        }
        #visualizationCanvas {
            border: 2px solid #ccc;
            background-color: #fff;
            cursor: pointer;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }
        .controls {
            margin-top: 20px;
            padding: 15px;
            background: #e9e9ff;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.05);
        }
        .controls label {
            margin-right: 10px;
            font-weight: bold;
        }
        .controls input[type="range"] {
            width: 200px;
        }
        #tooltip {
            position: absolute;
            background: rgba(0, 0, 0, 0.8);
            color: white;
            padding: 8px 12px;
            border-radius: 4px;
            pointer-events: none; /* Important to not block mouse events on canvas */
            opacity: 0;
            transition: opacity 0.2s;
            z-index: 10;
        }
    </style>
</head>
<body>

    <h1>Interactive Bar Chart Visualization</h1>
    <canvas id="visualizationCanvas" width="800" height="400"></canvas>
    <div id="tooltip"></div>

    <div class="controls">
        <label for="dataRange">Data Scale:</label>
        <input type="range" id="dataRange" min="0.1" max="1.0" value="0.5" step="0.1">
        <span id="rangeValue">0.5</span>
    </div>

    <script>
        const canvas = document.getElementById('visualizationCanvas');
        const ctx = canvas.getContext('2d');
        const tooltip = document.getElementById('tooltip');
        const dataRangeSlider = document.getElementById('dataRange');
        const rangeValueDisplay = document.getElementById('rangeValue');

        // Sample Data: Representing different categories/time points
        const dataPoints = [
            { label: 'A', value: 40 },
            { label: 'B', value: 75 },
            { label: 'C', value: 20 },
            { label: 'D', value: 90 },
            { label: 'E', value: 55 }
        ];

        // --- Visualization Logic ---

        function drawChart(data, containerWidth, containerHeight) {
            // Clear canvas
            ctx.clearRect(0, 0, containerWidth, containerHeight);

            const padding = 40;
            const chartWidth = containerWidth - 2 * padding;
            const chartHeight = containerHeight - 2 * padding;
            const numPoints = data.length;

            if (numPoints === 0) return;

            // 1. Determine Max Value (for scaling)
            const maxValue = Math.max(...data.map(d => d.value));
            
            // 2. Determine the scaling factor based on the slider input
            const scaleFactor = parseFloat(dataRangeSlider.value);
            const effectiveMax = Math.max(maxValue, scaleFactor * 100); // Ensure minimum visualization size
            
            // Calculate the height scale: 1 unit of data value maps to this many pixels
            const yScale = chartHeight / effectiveMax;
            
            // Calculate the width scale: Distribute space evenly among bars
            const barWidth = chartWidth / (numPoints * 1.5);
            const gap = chartWidth / (numPoints + 1);

            // --- Drawing Axes ---
            ctx.strokeStyle = '#aaa';
            ctx.lineWidth = 1;
            
            // X-Axis (Bottom)
            ctx.beginPath();
            ctx.moveTo(padding, containerHeight - padding);
            ctx.lineTo(containerWidth - padding, containerHeight - padding);
            ctx.stroke();

            // Y-Axis (Left)
            ctx.beginPath();
            ctx.moveTo(padding, padding);
            ctx.lineTo(padding, containerHeight - padding);
            ctx.stroke();

            // --- Drawing Labels and Ticks (Simplified) ---
            ctx.fillStyle = '#555';
            ctx.font = '14px Arial';
            ctx.textAlign = 'center';
            
            // Y-Axis Ticks (Top and Bottom)
            ctx.fillText(effectiveMax.toFixed(0), padding - 10, padding); // Max value label
            ctx.fillText('0', padding - 10, containerHeight - padding + 15); // Zero label

            // X-Axis Labels
            for (let i = 0; i < numPoints; i++) {
                const xPos = padding + (i * (barWidth + gap)) + (barWidth / 2);
                ctx.fillText(data[i].label, xPos, containerHeight - padding + 20);
            }


            // --- Drawing Bars ---
            for (let i = 0; i < numPoints; i++) {
                const dataPoint = data[i];
                
                // Calculate bar height based on data value and scale factor
                // We normalize the value relative to the effective max for better visualization scaling
                const normalizedValue = dataPoint.value / 100; // Assume max data value is capped around 100 for visual consistency
                const barHeight = (dataPoint.value / effectiveMax) * chartHeight * 0.9; // Scale factor applied here
                
                const x = padding + (i * (barWidth + gap)) + (barWidth / 2);
                const y = containerHeight - padding - barHeight;
                
                // Draw the bar
                ctx.fillStyle = `hsl(${(i * 360 / numPoints)}, 70%, 50%)`;
                ctx.fillRect(x - barWidth / 2, y, barWidth, barHeight);

                // Optional: Add value text on top of the bar
                ctx.fillStyle = '#333';
                ctx.fillText(dataPoint.value, x, y - 5);
            }
        }

        // --- Interactivity Handlers ---

        function handleMouseMove(event) {
            const rect = canvas.getBoundingClientRect();
            const mouseX = event.clientX - rect.left;
            const mouseY = event.clientY - rect.top;

            // Simple detection: If mouse is over the canvas, show tooltip
            const isOverCanvas = mouseX >= 0 && mouseX <= canvas.width && mouseY >= 0 && mouseY <= canvas.height;

            if (isOverCanvas) {
                // For simplicity, we just show the coordinates on hover
                tooltip.style.opacity = 1;
                tooltip.style.left = `${event.pageX + 10}px`;
                tooltip.style.top = `${event.pageY - 20}px`;
                tooltip.textContent = `X: ${mouseX.toFixed(0)}, Y: ${mouseY.toFixed(0)}`;
            } else {
                tooltip.style.opacity = 0;
            }
        }

        function handleMouseLeave() {
            tooltip.style.opacity = 0;
        }

        function handleSliderChange() {
            const value = parseFloat(dataRangeSlider.value);
            rangeValueDisplay.textContent = value.toFixed(1);
            drawChart(dataPoints, canvas.width, canvas.height);
        }

        // --- Initialization ---
        
        window.onload = () => {
            // Initial Draw
            drawChart(dataPoints, canvas.width, canvas.height);

            // Event Listeners
            canvas.addEventListener('mousemove', handleMouseMove);
            canvas.addEventListener('mouseleave', handleMouseLeave);
            dataRangeSlider.addEventListener('input', handleSliderChange);
        };
    </script>
</body>
</html>