let particles = [];
const numParticles = 150;
const blueHue = 200; // Calming blue hue

class Particle {
  constructor() {
    this.position = createVector(random(width), random(height));
    this.velocity = p5.Vector.random2D().mult(random(0.1, 1));
    this.acceleration = createVector(0, 0);
    this.lifespan = 255;
    this.radius = random(1, 3);
  }

  applyForce(force) {
    this.acceleration.add(force);
  }

  update() {
    this.velocity.add(this.acceleration);
    this.position.add(this.velocity);
    this.acceleration.add(createVector(0, 0)); // Reset acceleration
    this.lifespan -= 1.5; // Fade over time
  }

  show() {
    stroke(blueHue, 80, 100, this.lifespan); // HSB for better color control
    strokeWeight(this.radius);
    point(this.position.x, this.position.y);
  }

  isDead() {
    return this.lifespan < 0;
  }
}

function setup() {
  createCanvas(windowWidth, windowHeight);
  background(0, 0, 0, 50); // Slight initial background fade effect
  
  for (let i = 0; i < numParticles; i++) {
    particles.push(new Particle());
  }
}

function draw() {
  // Create a transparent background to create a trailing/flowing effect
  background(0, 0, 0, 10); 

  // Simulate a gentle, constant force (like wind or gravity pulling slightly down)
  let flowForce = createVector(0, 0.05);

  for (let i = particles.length - 1; i >= 0; i--) {
    let p = particles[i];
    
    // Apply the gentle flow force
    p.applyForce(flowForce);
    
    p.update();
    p.show();

    // If the particle fades out or moves off screen, respawn it
    if (p.isDead() || p.position.x < 0 || p.position.x > width || p.position.y > height) {
      particles.splice(i, 1);
      particles.push(new Particle());
    }
  }
}

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
  // Re-initialize particles slightly on resize for better effect
  particles = [];
  for (let i = 0; i < numParticles; i++) {
    particles.push(new Particle());
  }
}