import {useCurrentFrame, spring} from 'remotion';
import {TypedTextLayerProps} from '@react-spring/typed-text-layer';

export const TypingAnimationVideo = ({fps}) => {
  // Animation for the typed text
  return (
    <div style={{display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100%'}}>
      {Array(10)
        .fill(null, { length: 200 })
        .map((_, index) => spring({
          frame,
          startFrame: Math.floor(frame / fps * 2),
          endFrame: (Math.floor(frame / fps + 1)),
          config: {
            tension: 1700,
            friction: 120
          }
        }))
        .reduceRight(
          <TypedTextLayer key={`typed-${index}`} text="Typing Animation with React and Remotion" />,
          ({children}) => children
        )}
    </div>
  );
};

export default {fps};