precision highp float;

uniform vec2 u_resolution;
uniform float u_time;
uniform vec2 u_mouse;
uniform vec2 u_center;

#define MAX_ITERATIONS 256
#define MAX_DEPTH 8

// Noise parameters
#define SCALE 20.0
#define OFFSET 0.0
#define AMPLITUDE 0.5

// Color parameters
#define COLOR_START 0.0
#define COLOR_END 1.0

// Distortion parameters
#define DISTORTION_AMOUNT 0.01
#define DISTORTION_SCALE 2.0

// Function to calculate hash
float hash(vec2 p) { return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453); }

// Function to calculate noise
float noise(vec2 p) { vec2 i = floor(p); vec2 f = fract(p); float a = hash(i); float b = hash(i + vec2(1.0, 0.0)); float c = hash(i + vec2(0.0, 1.0)); float d = hash(i + vec2(1.0, 1.0)); vec2 u = f * f * (3.0 - 2.0 * f); return mix(mix(a, b, u.x), mix(c, d, u.x), u.y); }

// Function to calculate fractal brownian motion
float fbm(vec2 p) { float v = 0.0; float a = 0.5; for (int i = 0; i < 5; i++) { v += a * noise(p); p *= 2.0; a *= 0.5; } return v; }

// Function to calculate color based on noise
vec3 getColor(vec2 p) {
    float n = noise(p * SCALE + OFFSET);
    return vec3(n, n * 0.5, n * 0.75);
}

// Function to warp the coordinates
vec2 warp(vec2 p) {
    float dist = dot(p, p);
    float factor = 1.0 + DISTORTION_AMOUNT * dist * DISTORTION_SCALE;
    return p * factor;
}


void main() {
    vec2 uv = gl_FragCoord.xy / u_resolution.xy;
    vec2 zoomedUV = uv * 0.01;
    vec2 finalUV = warp(zoomedUV) + u_center;

    float timeFactor = u_time * 0.1;
    float noiseFactor = fbm(finalUV) * 20.0;
    float colorFactor = noiseFactor * timeFactor;

    vec3 color = vec3(colorFactor);
    color = mix(color, vec3(1.0, 0.0, 0.0), colorFactor);
    color = mix(color, vec3(0.0, 0.0, 1.0), colorFactor * 0.5);


    // Apply more noise to create a more chaotic look
    vec2 noiseUV = finalUV + vec2(u_time * 0.01, u_time * 0.02);
    float noiseVal = noise(noiseUV * SCALE);
    color += vec3(noiseVal) * 0.1;

    //Radial distortion
    float dist = length(finalUV - u_center);
    float radialFactor = 1.0 - smoothstep(0.0, 1.0, dist);
    color = mix(color, vec3(radialFactor), radialFactor * 0.5);


    gl_FragColor.rgb = color;
}