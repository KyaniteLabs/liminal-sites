precision highp float;

uniform vec2 u_resolution;
uniform float u_time;
uniform vec2 u_mouse;
uniform vec2 u_center;

#define MAX_ITERATIONS 100
#define MAX_DEPTH 6
#define SCALE 0.5
#define COLOR_SCALE 3.0
#define NOISE_SCALE 2.0
#define PALETTE_SIZE 16

#define PI 3.14159265358979323846

float hash(vec2 p) { return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453); }

float noise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    float a = hash(i);
    float b = hash(i + vec2(1.0, 0.0));
    float c = hash(i + vec2(0.0, 1.0));
    float d = hash(i + vec2(1.0, 1.0));
    vec2 u = f * f * (3.0 - 2.0 * f);
    return mix(mix(a, b, u.x), mix(c, d, u.x), u.y);
}

vec3 colorTransform(vec3 c, float t) {
    float r = c.r * (1.0 + sin(t * 3.0));
    float g = c.g * (1.0 + cos(t * 2.0));
    float b = c.b * (1.0 + sin(t * 4.0));
    return vec3(r, g, b);
}

float fbm(vec2 p) {
    float v = 0.0;
    float a = 0.5;
    for (int i = 0; i < 5; i++) {
        v += a * noise(p);
        p *= 2.0;
        a *= 0.5;
    }
    return v;
}

// Color Palette
vec3 palette[PALETTE_SIZE];

void main() {
    vec2 uv = gl_FragCoord.xy / u_resolution;
    float time = u_time;
    vec2 offset = vec2(u_mouse.x * 0.01, u_mouse.y * 0.01);

    vec3 color = vec3(0.0);

    for (int i = 0; i < MAX_ITERATIONS; i++) {
        vec2 currentUV = uv + offset * i;
        float depth = fbm(currentUV * NOISE_SCALE);
        float distortion = depth * SCALE;

        vec3 baseColor = vec3(0.5, 0.7, 0.9);

        // Apply color transformation and noise
        vec3 finalColor = colorTransform(baseColor, time + i * 0.1);
        color += finalColor * distortion;

        // Limit iterations
        if (depth < 0.01) break;
    }

    // Color Palette Animation
    float paletteIndex = fract(time * COLOR_SCALE) * PALETTE_SIZE;
    vec3 currentPaletteColor = palette[(int)paletteIndex];

    // Add some more variation
    color += currentPaletteColor * (0.1 + sin(time * 2.0) * 0.05);

    // Output color
    gl_FragColor.rgb = mix(vec3(0.0), color, 0.5);
}