precision highp float;

uniform vec2 u_resolution;
uniform float u_time;
uniform vec2 u_mouse;
#define PI 3.14159265358979323846

uniform vec3 color1 = vec3(0.9, 0.2, 0.4);
uniform vec3 color2 = vec3(0.3, 0.5, 0.8);
uniform float scale = 5.0;
uniform float distortionStrength = 0.02;
uniform float noiseScale = 10.0;
uniform float frequency = 2.0;
uniform float amplitude = 0.5;

float hash(vec2 p) { return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453); }

float noise(vec2 p) { vec2 i = floor(p); vec2 f = fract(p); float a = hash(i); float b = hash(i + vec2(1.0, 0.0)); float c = hash(i + vec2(0.0, 1.0)); float d = hash(i + vec2(1.0, 1.0)); vec2 u = f * f * (3.0 - 2.0 * f); return mix(mix(a, b, u.x), mix(c, d, u.x), u.y); }

float fbm(vec2 p) { float v = 0.0; float a = 0.5; for (int i = 0; i < 5; i++) { v += a * noise(p); p *= 2.0; a *= 0.5; } return v; }

void main() {
    vec2 uv = vec2(u_time * 0.01, u_time * 0.02);
    vec2 offset = vec2(noise(uv * noiseScale), noise(uv * noiseScale + vec2(0.1)));
    vec2 pos = uv + offset;

    float dist = length(pos * scale - u_mouse);
    float distortion = distortionStrength * dist * frequency;
    float timeFactor = u_time;

    vec3 color = mix(color1, color2, timeFactor);

    float wave = amplitude * fbm(pos);
    color += wave * 0.1;

    vec3 finalColor = color;

    // Domain Warping
    vec2 warpedUV = pos * scale + distortion;
    float warpedNoise = noise(warpedUV);
    finalColor = vec3(warpedNoise, warpedNoise, warpedNoise);

    gl_FragColor.rgb = vec3(finalColor);
}