precision highp float;

uniform vec2 u_resolution;
uniform float u_time;
uniform vec2 u_mouse;
uniform vec2 u_center;

#define MAX_ITERATIONS 256
#define SCALE 100.0
#define AMPLITUDE 0.7
#define FREQUENCY 1.0
#define COLOR_SHIFT 0.01

float hash(vec2 p) { return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453); }

float noise(vec2 p) { vec2 i = floor(p); vec2 f = fract(p); float a = hash(i); float b = hash(i + vec2(1.0, 0.0)); float c = hash(i + vec2(0.0, 1.0)); float d = hash(i + vec2(1.0, 1.0)); vec2 u = f * f * (3.0 - 2.0 * f); return mix(mix(a, b, u.x), mix(c, d, u.x), u.y); }

float fbm(vec2 p) { float v = 0.0; float a = 0.5; for (int i = 0; i < 5; i++) { v += a * noise(p); p *= 2.0; a *= 0.5; } return v; }

vec3 generate_plasma_color(float time) {
    float t = time * FREQUENCY;
    float x = u_mouse.x;
    float y = u_mouse.y;
    vec2 pos = vec2(x, y);

    float noise_val = noise(pos * SCALE);
    float fbm_val = fbm(pos * SCALE) * AMPLITUDE;

    float color_offset = sin(t + pos.x * 100.0) * COLOR_SHIFT;
    float color_variation = noise_val * 0.5 + fbm_val * 0.3;


    vec3 color = vec3(
        (color_variation + 0.5) * 0.8,
        (color_variation + 0.2) * 0.7,
        (color_variation + 0.3) * 0.9
    );

    return color;
}

void main() {
    vec2 uv = gl_FragCoord.xy / u_resolution;
    vec3 color = generate_plasma_color(u_time);

    // Distortion effect using fbm
    float distortion = fbm(vec2(uv.x * 20.0, uv.y * 20.0)) * 0.2;
    vec3 final_color = color * (1.0 + distortion);

    gl_FragColor = vec4(final_color, 1.0);
}