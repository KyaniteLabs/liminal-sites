precision highp float;

uniform vec2 u_resolution;
uniform float u_time;
uniform vec2 u_mouse;
uniform vec2 u_center;

#define MAX_ITERATIONS 128
#define MAX_DEPTH 6
#define SCALE 0.5

float hash(vec2 p) { return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453); }

float noise(vec2 p) { vec2 i = floor(p); vec2 f = fract(p); float a = hash(i); float b = hash(i + vec2(1.0, 0.0)); float c = hash(i + vec2(0.0, 1.0)); float d = hash(i + vec2(1.0, 1.0)); vec2 u = f * f * (3.0 - 2.0 * f); return mix(mix(a, b, u.x), mix(c, d, u.x), u.y); }

float fbm(vec2 p) { float v = 0.0; float a = 0.5; for (int i = 0; i < 5; i++) { v += a * noise(p); p *= 2.0; a *= 0.5; } return v; }

vec3 colorTransform(vec3 c, float t) {
    float dist = length(vec2(u_time, u_mouse.x)) * SCALE;
    vec3 offset = vec3(noise(vec2(dist, t)), noise(vec2(dist * 2, t)), noise(vec2(dist * 3, t)));
    return c + offset;
}

void main() {
    vec2 uv = gl_FragCoord.xy / u_resolution.xy;
    vec2 center = uv - u_center;

    float depth = fbm(center * 5.0);

    vec3 color = vec3(0.0);
    int iterations = 0;

    while (iterations < MAX_ITERATIONS) {
        vec3 newColor = colorTransform(color, float(iterations));
        color = newColor;
        color *= 0.9; // Fade out
        depth *= 0.93; // Reduce depth over iterations
        
        if (depth < 0.001) break;
        iterations++;
    }

    // Color Palette
    vec3 finalColor = mix(vec3(1.0, 0.0, 0.0), vec3(0.0, 1.0, 1.0), color.r);
    finalColor += color.g * 0.1;
    finalColor += color.b * 0.05;

    gl_FragColor.rgb = finalColor;
}