let bubbles = [];
let rayCount = 7;
let rays = [];
let time = 0;

function setup() {
  createCanvas(800, 600);
  pixelDensity(1);
  
  // Create bubbles
  for (let i = 0; i < 50; i++) {
    bubbles.push(new Bubble());
  }
  
  // Create light rays
  for (let i = 0; i < rayCount; i++) {
    rays.push({
      x: map(i, 0, rayCount, 50, width - 50),
      width: random(30, 80),
      noiseOffset: random(1000)
    });
  }
}

function draw() {
  time += 0.005;
  
  // Draw gradient background
  drawBackground();
  
  // Draw light rays
  drawLightRays();
  
  // Draw caustics on seabed
  drawCaustics();
  
  // Draw bubbles
  for (let bubble of bubbles) {
    bubble.update();
    bubble.display();
  }
  
  // Draw seabed
  drawSeabed();
}

function drawBackground() {
  for (let y = 0; y < height; y++) {
    let inter = map(y, 0, height, 0, 1);
    let c = lerpColor(color(20, 60, 100), color(5, 20, 40), inter);
    stroke(c);
    line(0, y, width, y);
  }
}

function drawLightRays() {
  noStroke();
  for (let ray of rays) {
    for (let i = 0; i < 10; i++) {
      let rayNoise = noise(ray.noiseOffset + time * 0.5 + i * 0.1);
      let rayWidth = ray.width * (0.8 + rayNoise * 0.4);
      let alpha = map(i, 0, 10, 40, 10);
      fill(200, 240, 255, alpha);
      
      beginShape();
      vertex(ray.x - rayWidth / 2 + rayNoise * 20, i * (height / 10));
      vertex(ray.x + rayWidth / 2 + rayNoise * 20, i * (height / 10));
      vertex(ray.x + rayWidth / 2 + rayNoise * 20 + 10, (i + 1) * (height / 10));
      vertex(ray.x - rayWidth / 2 + rayNoise * 20 - 10, (i + 1) * (height / 10));
      endShape(CLOSE);
    }
  }
}

function drawCaustics() {
  loadPixels();
  for (let x = 0; x < width; x += 4) {
    for (let y = height * 0.6; y < height; y += 4) {
      let n = noise(x * 0.01 + time, y * 0.01 + time);
      let brightness = map(n, 0.3, 0.7, 0, 100);
      let c = color(100, 200, 255, brightness);
      fill(c);
      noStroke();
      rect(x, y, 4, 4);
    }
  }
  updatePixels();
}

function drawSeabed() {
  noStroke();
  fill(30, 60, 80);
  beginShape();
  vertex(0, height);
  for (let x = 0; x <= width; x += 20) {
    let y = height - 50 + noise(x * 0.02 + time) * 30;
    vertex(x, y);
  }
  vertex(width, height);
  endShape(CLOSE);
}

class Bubble {
  constructor() {
    this.x = random(width);
    this.y = random(height);
    this.size = random(5, 15);
    this.speed = random(0.5, 1.5);
    this.noiseOffset = random(1000);
  }
  
  update() {
    this.y -= this.speed;
    this.x += noise(this.noiseOffset + frameCount * 0.01) * 2 - 1;
    
    if (this.y < 0) {
      this.y = height;
      this.x = random(width);
    }
  }
  
  display() {
    noFill();
    stroke(255, 255, 255, 150);
    strokeWeight(1);
    ellipse(this.x, this.y, this.size, this.size);
  }
}