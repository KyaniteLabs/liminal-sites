let history = [];
const colors = [color(255), color(100, 200, 255), color(255, 100, 100), color(100, 255, 100)];

function setup() {
  createCanvas(windowWidth, windowHeight);
  noStroke();
}

function draw() {
  background(20);
  
  // Add new point to history with random shape and color
  let type = floor(random(4));
  let x = width * (random()) + random(-100, 100);
  let y = height * (random()) + random(-100, 100);
  
  // Wrap around screen edges for infinite motion feel
  if (x < -50) x += width;
  else if (x > width + 50) x -= width;
  if (y < -50) y += height;
  else if (y > height + 50) y -= height;

  let c = colors[floor(random(colors.length))];
  
  // Draw shape based on type
  push();
  translate(x, y);
  rotate(frameCount * 0.05);
  scale(10);
  fill(c);
  if (type === 0) rectMode(CENTER); rect(0, 0, 40, 30);
  else if (type === 1) {
    strokeWeight(2);
    noFill();
    beginShape();
    vertex(0, -25);
    vertex(-25, 0);
    vertex(0, 25);
    vertex(25, 0);
    endShape(CLOSE);
  } else if (type === 2) {
    circle(0, 0, 40);
  } else {
    triangle(-30, -15, 30, -15, 0, 20);
  }
  pop();

  // Store point
  history.unshift({x: x + random(-20, 20), y: y + random(-20, 20), age: frameCount});

  // Draw feedback trails (exponential decay)
  noStroke();
  for (let i = 0; i < history.length; i++) {
    let p = history[i];
    let alpha = map(p.age, 0, 300, 1, 0); // Fade out over time
    if (alpha <= 0) continue;

    push();
    translate(p.x, p.y);
    
    // Size shrinks with age
    let s = map(p.age, 0, 200, 50, 2); 
    scale(s / 50);
    
    stroke(255, alpha * 0.8);
    strokeWeight(alpha);
    line(-s/4, -s/6, s/4, s/6); // Draw a trail segment towards the new point
    
    pop();
  }

  if (frameCount % 10 === 0) history = []; // Keep memory usage low
}

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
}