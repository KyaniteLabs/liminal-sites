function setup() {
  createCanvas(windowWidth, windowHeight);
  colorMode(HSB, 360, 100, 100, 255);
  frameRate(30);
}

function draw() {
  background(240);
  
  let x = width / 2;
  let y = height / 2;
  
  for (let i = 0; i < 10; i++) {
    noStroke();
    
    // Random geometric shape based on iteration count
    let type = floor(random(3));
    let size = random(5, 40);
    let hue = map(i * 10, 0, 360, 0, 240);
    fill(hue, 80, 100);
    
    if (type === 0) {
      circle(x + size/2, y + size/2, size);
    } else if (type === 1) {
      rectMode(CENTER);
      rect(x - size, y - size, size * 3, size * 3);
    } else {
      beginShape();
      for (let j = 0; j < 6; j++) {
        let angle = map(j, 0, 5, 0, TWO_PI);
        vertex(x + cos(angle) * size/2, y + sin(angle) * size/2);
      }
      endShape(CLOSE);
    }
    
    // Trail effect: draw from previous position to current
    stroke(240, 80, 100, 50);
    strokeWeight(size / 3);
    line(x - size/2, y - size/2, x + size/2, y + size/2);
    
    // Move origin
    let vx = random(-5, 5);
    let vy = random(-5, 5);
    x += vx;
    y += vy;
    constrain(x, 0, width);
    constrain(y, 0, height);
  }
}

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
}