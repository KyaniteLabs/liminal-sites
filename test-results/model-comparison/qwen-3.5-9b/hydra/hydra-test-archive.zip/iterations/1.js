const particleSize = 4;
let particles = [];
let hueOffset = 0;

function setup() {
  createCanvas(800, 600);
  pixelDensity(1);
  
  noiseSeed(12345);
  
  for (let i = 0; i < 300; i++) {
    particles.push(new Particle());
  }
}

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
  background(0);
}

function draw() {
  hueOffset += 2;
  
  // Draw semi-transparent background for trails
  blendMode(BLEND);
  noStroke();
  fill(0, 15);
  rect(0, 0, width, height);
  
  // Switch to additive blending for glowing effect
  blendMode(BLEND_ADD);
  
  for (let p of particles) {
    if (!p.update()) continue;
    
    let s = map(p.life, 0, 100, particleSize * 2, particleSize);
    stroke(s > 0 ? 255 : 0);
    strokeWeight(s / 4);
    
    // Draw geometric shape based on sine wave of life
    let angle = p.angle;
    let points = [];
    let numPoints = floor(p.life * 1.5);
    
    if (numPoints > 2) {
      for (let i = 0; i < numPoints; i++) {
        let a = map(i, 0, numPoints - 1, angle, angle + TWO_PI);
        let r = map(p.life, 0, 100, 5, 20);
        // Add noise variation to radius for organic feel
        r += sin(frameCount * 0.1 + i) * noise(p.life * 0.05);
        
        points.push(createVector(cos(a) * r, sin(a) * r));
      }
      
      beginShape();
      noFill();
      strokeWeight(s / 3);
      for (let pt of points) {
        vertex(pt.x + p.pos.x, pt.y + p.pos.y);
      }
      endShape(CLOSE);
    } else {
      // Simple circle if life is very low
      let r = map(p.life, 0, 100, 2, 8);
      point(p.pos.x, p.pos.y);
    }
    
    // Draw connecting lines between points for extra geometric feel
    noFill();
    strokeWeight(s / 15);
    beginShape();
    for (let i = 0; i < points.length - 1; i++) {
      let pt1 = points[i];
      let pt2 = points[i + 1];
      vertex(pt1.x + p.pos.x, pt1.y + p.pos.y);
      vertex(pt2.x + p.pos.x, pt2.y + p.pos.y);
    }
    endShape();
  }
  
  // Reset blending for next frame background
  blendMode(BLEND);
}

class Particle {
  constructor() {
    this.pos = createVector(width / 2, height / 2);
    this.vel = p5.Vector.random2D();
    this.acc = createVector(0, 0);
    this.life = random(50, 100);
    this.maxLife = this.life;
    this.angle = random(TWO_PI);
    this.speed = map(this.pos.x, 0, width, 2, 8);
    this.hueVal = noise(particles.indexOf(this) * 0.1) * 360;
  }
  
  update() {
    // Perlin noise based flow field for organic movement
    let nX = noise(frameCount * 0.02 + this.pos.x * 0.01, frameCount * 0.02 + this.pos.y * 0.01);
    let nY = noise(frameCount * 0.03 + this.pos.x * 0.015, frameCount * 0.025 + this.pos.y * 0.012);
    
    // Combine with existing velocity
    this.vel.add(createVector(nX - 0.5, nY - 0.5).mult(0.1));
    
    // Limit speed
    let v = p5.Vector.limit(this.vel, this.speed * 2);
    this.vel = v;
    
    this.pos.add(this.vel);
    
    // Wrap around edges
    if (this.pos.x < -50) this.pos.x += width + 100;
    if (this.pos.x > width + 50) this.pos.x -= width + 100;
    if (this.pos.y < -50) this.pos.y += height + 100;
    if (this.pos.y > height + 50) this.pos.y -= height + 100;
    
    // Rotate based on movement
    let speed = this.vel.mag();
    this.angle += speed * 0.05;
    
    this.life--;
    return this.life >= 0;
  }
}