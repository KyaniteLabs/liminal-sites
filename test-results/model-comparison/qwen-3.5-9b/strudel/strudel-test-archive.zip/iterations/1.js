$: s("bd*4, sd~").gain(0.9).room(0.4),
  $: s("hh*8").pan(0.5).delay(0.2, 0.6)
).speed(130/120).every(4, chop(0.3))