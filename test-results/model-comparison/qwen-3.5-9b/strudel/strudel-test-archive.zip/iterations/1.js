const BPM = 130;
let particles = [];
let frameCount = 0;
let beatFrame = 0;

function setup() {
  createCanvas(800, 600);
  pixelDensity(1);
  noStroke();
  
  noiseSeed(4297153);
  
  for (let i = 0; i < 600; i++) {
    particles.push(new Particle());
  }
}

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
  background(0);
}

function draw() {
  frameCount++;
  
  // Calculate beat timing
  const msPerBeat = (60.0 / BPM) * 1000;
  const framesPerBeat = floor(msPerBeat / FPS);
  
  let isBeating = false;
  
  if (beatFrame === 0) {
    isBeating = true; // On the beat
  } else if (frameCount % framesPerBeat < 2) {
    // Sustain phase right after beat
    isBeating = true;
  }
  
  beatFrame++;
  if (beatFrame > framesPerBeat) beatFrame = 0;
  
  let bgAlpha = 15;
  if (isBeating) bgAlpha = 60;
  background(255 * bgAlpha, 30, 80); // Dark purple base
  
  fill(255);
  for (let p of particles) {
    let speedMod = isBeating ? 1.5 : 1.0;
    
    if (isBeating && frameCount % framesPerBeat === 0) {
      // Pulse effect on beat
      p.pos.x += random(-4, 4);
      p.pos.y += random(-4, 4);
    }
    
    p.update(speedMod);
    p.show();
  }
}

class Particle {
  constructor() {
    this.pos = createVector(random(width), random(height));
    this.vel = p5.Vector.random2D().mult(random(0.5, 1.5));
    this.acc = createVector(0, 0);
    
    // Perlin noise influence
    this.noiseX = noise(this.pos.x * 0.003) * 0.5 + 0.5;
    this.noiseY = noise(this.pos.y * 0.003) * 0.5 + 0.5;
    
    // Color based on position and noise
    let hueVal = map(noiseX, 0, 1, 200, 360);
    this.color = color(0, hueVal, 255);
    
    this.size = random(1, 2.5);
  }
  
  update(speedMod) {
    let flowX = noise(frameCount * 0.002 + this.pos.x * 0.01) * 0.3;
    let flowY = sin(frameCount * 0.002 + this.pos.y * 0.01) * 0.3;
    
    // Techno wobble effect
    if (frameCount % 5 === 0) {
      noiseX += random(-0.01, 0.01);
    }
    
    this.vel.x = lerp(this.vel.x, flowX * speedMod, 0.02);
    this.vel.y = lerp(this.vel.y, flowY * speedMod, 0.02);
    
    // Add some acceleration based on noise
    if (isBeating && frameCount % framesPerBeat === 0) {
      this.vel.add(createVector(random(-2, 2), random(-2, 2)));
    }
    
    this.pos.add(this.vel.mult(speedMod));
    
    // Wrap around screen
    if (this.pos.x > width + 50) this.pos.x = -50;
    if (this.pos.x < -50) this.pos.x = width + 50;
    if (this.pos.y > height + 50) this.pos.y = -50;
    if (this.pos.y < -50) this.pos.y = height + 50;
    
    // Update noise value for color variation over time
    this.noiseX += 0.001 * speedMod;
    
    // Color modulation on beat
    let beatColorShift = isBeating ? map(frameCount % framesPerBeat, 0, framesPerBeat + 5, -20, 20) : 0;
    this.color.hue = (this.noiseX * 360) + beatColorShift;
  }
  
  show() {
    let sizeMod = isBeating ? map(frameCount % framesPerBeat, 0, framesPerBeat/2, 1.5, 4) : this.size;
    
    // Glow effect using additive blending
    noStroke();
    fill(this.color);
    circle(this.pos.x, this.pos.y, sizeMod);
  }
}