let particles = [];
const NUM_PARTICLES = 400;
const MAX_SPEED = 3.5;
const FRICTION = 0.96;

function setup() {
  createCanvas(800, 600);
  pixelDensity(1);
  noStroke();
  
  noiseSeed(12345);
  
  for (let i = 0; i < NUM_PARTICLES; i++) {
    particles.push(new Particle());
  }
}

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
  background(0);
}

function draw() {
  // Slight fade for trails instead of hard clear
  noFill();
  background(255 * 0.1, 0, 0, 50); 
  fill(255);

  for (let p of particles) {
    p.update();
    p.show();
  }
}

class Particle {
  constructor() {
    this.pos = createVector(random(width), random(height));
    this.vel = p5.Vector.random2D().mult(random(0.5, MAX_SPEED));
    this.acc = createVector(0, 0);
    
    // Color properties with cycling
    this.baseHue = random(180); 
    this.size = random(4, 10);
    
    // Noise offsets for organic movement
    this.noiseOffsetX = random(TWO_PI * 20);
    this.noiseOffsetY = random(TWO_PI * 20);
  }

  update() {
    // Flow field influence based on Perlin noise
    let angle = map(noise(this.pos.x * 0.01 + frameCount * 0.02, 
                         this.pos.y * 0.01 + this.noiseOffsetX), 
                    0, 1, 0, TWO_PI);
    
    // Add slight spiral effect
    angle += sin(frameCount * 0.05 + this.noiseOffsetY) * 0.2;
    
    let force = p5.Vector.fromAngle(angle).mult(0.3);
    this.acc.add(force);
    
    this.vel.add(this.acc);
    this.vel.mult(FRICTION);
    this.pos.add(this.vel);
    
    // Wrap around screen edges
    if (this.pos.x > width) { this.pos.x = 0; }
    else if (this.pos.x < 0) { this.pos.x = width; }
    
    if (this.pos.y > height) { this.pos.y = 0; }
    else if (this.pos.y < 0) { this.pos.y = height; }

    // Cycle color over time
    this.baseHue += frameCount * 0.5;
  }

  show() {
    let x = this.pos.x;
    let y = this.pos.y;
    
    // Color cycling using HSB
    let hue = map(this.baseHue, 0, 360, 180, 330); // Cyan to Magenta range
    let sat = 100;
    let light = map(noise(x * 0.02 + frameCount * 0.05), 0, 1, 40, 90);
    
    stroke(hue, sat, light);
    strokeWeight(this.size);
    
    // Glow effect using multiple circles
    for (let i = this.size; i > 0; i -= 2) {
      ellipse(x, y, i * 1.5, i * 1.5);
    }
  }
}