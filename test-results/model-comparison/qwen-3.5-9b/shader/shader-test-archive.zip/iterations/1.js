let width, height;
let plasmaImg;
let time = 0;
const cols = 16;
const rows = 9;

function setup() {
  createCanvas(800, 450);
  colorMode(HSB, 360, 100, 100);
  plasmaImg = get();
}

function draw() {
  background(20);
  
  time += 0.05;
  
  for (let i = 0; i < cols; i++) {
    for (let j = 0; j < rows; j++) {
      let x = map(i, 0, cols - 1, 0, width);
      let y = map(j, 0, rows - 1, 0, height);
      
      let hue = (i * 25 + j * 36 + time * 50) % 360;
      let sat = random(80, 100);
      let light = map(sin(time + i), -1, 1, 40, 90);
      
      noStroke();
      fill(hue, sat, light);
      circle(x, y, 60);
    }
  }
  
  // Create a secondary overlay layer for depth
  stroke(255, 80);
  strokeWeight(1);
  for (let i = 0; i < cols; i++) {
    for (let j = 0; j < rows; j++) {
      let x = map(i, 0, cols - 1, 0, width) + 20;
      let y = map(j, 0, rows - 1, 0, height) + 20;
      
      if (random(1) > 0.95) {
        line(x, y, x + random(-30, 30), y + random(-30, 30));
      }
    }
  }
}