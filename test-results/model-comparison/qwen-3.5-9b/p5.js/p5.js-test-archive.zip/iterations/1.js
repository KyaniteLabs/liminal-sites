import React from 'react';
import { useCurrentFrame, interpolate } from 'remotion';
import { AbsoluteFill } from '@remotion/player';

export const BlueCircleAnimation: React.FC = () => {
  const frame = useCurrentFrame();
  
  // Animation parameters for a 150-frame sequence at 30fps (5 seconds)
  const totalFrames = 150;
  
  return (
    <AbsoluteFill style={{ backgroundColor: '#0d1b2a' }}>
      {/* Background decorative elements */}
      <div 
        style={{
          position: 'absolute',
          top: '20%',
          left: '20%',
          width: '300px',
          height: '300px',
          borderRadius: '50%',
          background: 'radial-gradient(circle, rgba(64, 198, 252, 0.2) 0%, rgba(0, 0, 0, 0) 70%)',
        }}
      />
      
      <div 
        style={{
          position: 'absolute',
          bottom: '30%',
          right: '15%',
          width: '200px',
          height: '200px',
          borderRadius: '50%',
          background: 'radial-gradient(circle, rgba(64, 198, 252, 0.1) 0%, rgba(0, 0, 0, 0) 70%)',
        }}
      />

      {/* Main Blue Circle */}
      <div 
        style={{
          position: 'absolute',
          top: '50%',
          left: '50%',
          transform: `translate(-50%, -50%) scale(${interpolate(frame, [0, 75, totalFrames], [1, 2.5, 1])})`,
          width: '400px',
          height: '400px',
          borderRadius: '50%',
          background: interpolate(frame, [0, 30, 60, totalFrames - 30, totalFrames], ['rgba(26, 188, 156, 0.9)', '#00d4ff', '#7f00ff', '#ff00aa', '#ffffff']),
          boxShadow: '0 0 60px rgba(0, 212, 255, 0.3), inset 0 0 30px rgba(255, 255, 255, 0.2)',
        }}
      />

      {/* Inner rotating ring */}
      <div 
        style={{
          position: 'absolute',
          top: '50%',
          left: '50%',
          transform: `translate(-50%, -50%) rotate(${interpolate(frame, [0, totalFrames], [0, 1080])}deg)`,
          width: '320px',
          height: '320px',
          borderRadius: '50%',
          border: '2px solid rgba(26, 188, 156, 0.6)',
          boxShadow: '0 0 20px rgba(40, 167, 255, 0.3)',
        }}
      />

      {/* Pulsing effect */}
      <div 
        style={{
          position: 'absolute',
          top: '50%',
          left: '50%',
          transform: `translate(-50%, -50%) scale(${interpolate(frame, [0, totalFrames], [1, 1.2])})`,
          width: '380px',
          height: '380px',
          borderRadius: '50%',
          border: '4px solid rgba(64, 198, 252, 0.4)',
          opacity: interpolate(frame, [0, totalFrames], [0.7, 0]),
        }}
      />
    </AbsoluteFill>
  );
};