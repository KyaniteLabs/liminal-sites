import React from 'react';
import {useCurrentFrame, interpolate, spring, AbsoluteFill} from 'remotion';

export const BlueCircleAnimation: React.FC = () => {
  const frame = useCurrentFrame();

  const scale = spring({frame, fps: 30, from: 0, to: 1, config: {damping: 12}});
  
  const opacity = interpolate(frame, [0, 30, 120, 150], [0, 1, 1, 0]);
  
  const rotate = interpolate(frame, [0, 150], [0, 360]);

  return (
    <AbsoluteFill style={{backgroundColor: '#1a1a2e', justifyContent: 'center', alignItems: 'center'}}>
      <div
        style={{
          width: 200,
          height: 200,
          borderRadius: 100,
          backgroundColor: '#4a90d9',
          transform: `scale(${scale}) rotate(${rotate}deg)`,
          opacity,
          boxShadow: `0 0 ${interpolate(scale, [0, 1], [0, 60])}px rgba(74, 144, 217, 0.6)`,
        }}
      />
    </AbsoluteFill>
  );
};