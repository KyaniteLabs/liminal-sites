import React from 'react';
import { useCurrentFrame, interpolate } from 'remotion';
import { AbsoluteFill, Img } from 'remotion';

export const BlueCircleAnimation: React.FC = () => {
  const frame = useCurrentFrame();

  // Animation logic
  const radius = interpolate(frame, [0, 60], [100, 250]); // Grow 0-60 frames
  const opacity = interpolate(frame, [0, 60], [0, 1]);   // Fade in 0-60 frames
  
  const positionY = interpolate(frame, [0, 120], [-100, -500]); // Float down 60-120 frames
  const rotation = (frame / 30) % 360; // Continuous spin

  return (
    <AbsoluteFill style={{ backgroundColor: '#1a1a2e' }}>
      <Img
        src="https://placehold.co/400x400/2563eb/ffffff?text=Circle"
        alt="Blue Circle"
        width={radius * 2}
        height={radius * 2}
        style={{
          left: '50%',
          top: `calc(50% + ${positionY}px)`,
          transform: `translate(-50%, -50%) rotate(${rotation}deg)`,
          opacity,
          borderRadius: '50%',
        }}
      />
    </AbsoluteFill>
  );
};