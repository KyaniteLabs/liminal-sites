import React from 'react';
import {useCurrentFrame, interpolate, AbsoluteFill} from 'remotion';

export const BlueCircleAnimation: React.FC = () => {
  const frame = useCurrentFrame();
  
  const x = interpolate(frame, [0, 75, 150], [200, 860, 200], {
    extrapolateRight: 'clamp',
  });
  
  const scale = interpolate(frame, [0, 75, 150], [0.5, 1.2, 0.5], {
    extrapolateRight: 'clamp',
  });
  
  const opacity = interpolate(frame, [0, 30, 120, 150], [0, 1, 1, 0], {
    extrapolateRight: 'clamp',
  });

  return (
    <AbsoluteFill style={{backgroundColor: '#1a1a2e'}}>
      <div
        style={{
          position: 'absolute',
          left: x - 75,
          top: 440,
          width: 150,
          height: 150,
          borderRadius: '50%',
          backgroundColor: '#4da6ff',
          boxShadow: `0 0 ${30 + frame * 0.5}px rgba(77, 166, 255, 0.8)`,
          transform: `scale(${scale})`,
          opacity: opacity,
        }}
      />
    </AbsoluteFill>
  );
};