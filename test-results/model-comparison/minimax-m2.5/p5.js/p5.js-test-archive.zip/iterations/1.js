import React from 'react';
import {useCurrentFrame, interpolate, AbsoluteFill, spring} from 'remotion';

export const BlueCircle: React.FC = () => {
  const frame = useCurrentFrame();
  
  const scale = spring({frame, fps: 30, from: 0, to: 1, config: {damping: 10}});
  
  const yPos = interpolate(frame, [0, 150], [200, 600]);
  
  const circleSize = interpolate(
    Math.sin(frame * 0.05),
    [-1, 1],
    [150, 250]
  );
  
  return (
    <AbsoluteFill style={{backgroundColor: '#0a0a0a', justifyContent: 'center', alignItems: 'center'}}>
      <div
        style={{
          width: circleSize,
          height: circleSize,
          borderRadius: circleSize / 2,
          backgroundColor: '#3b82f6',
          transform: `scale(${scale})`,
          boxShadow: '0 0 60px rgba(59, 130, 246, 0.6)',
          position: 'absolute',
          top: yPos,
        }}
      />
    </AbsoluteFill>
  );
};