import React from 'react';
import {useCurrentFrame, interpolate, AbsoluteFill, spring} from 'remotion';

export const BlueCircle: React.FC = () => {
  const frame = useCurrentFrame();
  
  const scale = spring({
    frame,
    fps: 30,
    config: {
      damping: 10,
      stiffness: 100,
    },
  });
  
  const opacity = interpolate(
    frame,
    [0, 30, 120, 150],
    [0, 1, 1, 0]
  );
  
  const translateY = spring({
    frame,
    fps: 30,
    config: {
      damping: 12,
      stiffness: 80,
    },
  });
  
  return (
    <AbsoluteFill style={{backgroundColor: '#0a0a1a', justifyContent: 'center', alignItems: 'center'}}>
      <div
        style={{
          width: 200,
          height: 200,
          borderRadius: 100,
          backgroundColor: '#3b82f6',
          boxShadow: `0 0 ${40 + scale * 20}px rgba(59, 130, 246, 0.6)`,
          transform: `translateY(${-50 + translateY * 50}px) scale(${0.8 + scale * 0.2})`,
          opacity,
        }}
      />
    </AbsoluteFill>
  );
};