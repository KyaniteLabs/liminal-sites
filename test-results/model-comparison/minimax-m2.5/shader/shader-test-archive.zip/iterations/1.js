let t = 0;

function setup() {
  createCanvas(800, 600);
  pixelDensity(1);
  noStroke();
}

function draw() {
  background(0);
  
  loadPixels();
  
  for (let x = 0; x < width; x++) {
    for (let y = 0; y < height; y++) {
      let nx = x * 0.005;
      let ny = y * 0.005;
      
      let v1 = noise(nx + t * 0.5, ny, t * 0.3);
      let v2 = noise(nx - t * 0.4, ny + t * 0.6, t * 0.2 + 10);
      let v3 = noise(nx * 1.5 + t * 0.3, ny * 1.5 - t * 0.2, t * 0.4 + 20);
      
      let plasma = (v1 + v2 + v3) / 3;
      plasma = sin(plasma * PI * 4 + t);
      
      let r = sin(plasma * PI + 0) * 127 + 128;
      let g = sin(plasma * PI + TWO_PI / 3) * 127 + 128;
      let b = sin(plasma * PI + TWO_PI * 2 / 3) * 127 + 128;
      
      let colorShift = t * 0.5;
      r = (r + colorShift) % 255;
      g = (g + colorShift * 1.2) % 255;
      b = (b + colorShift * 0.8) % 255;
      
      let idx = (x + y * width) * 4;
      pixels[idx] = r;
      pixels[idx + 1] = g;
      pixels[idx + 2] = b;
      pixels[idx + 3] = 255;
    }
  }
  
  updatePixels();
  
  for (let i = 0; i < 50; i++) {
    let angle = noise(i * 0.1, t) * TWO_PI;
    let dist = noise(i * 0.1 + 100, t * 0.5) * 300;
    let x = width / 2 + cos(angle) * dist;
    let y = height / 2 + sin(angle) * dist;
    let size = noise(i * 0.2 + 200, t * 0.3) * 40 + 10;
    
    let c = noise(i * 0.05, t * 0.2);
    fill(c * 100 + 155, c * 80 + 100, c * 150 + 105, 200);
    ellipse(x, y, size);
  }
  
  t += 0.015;
}

function windowResized() {
  resizeCanvas(800, 600);
}