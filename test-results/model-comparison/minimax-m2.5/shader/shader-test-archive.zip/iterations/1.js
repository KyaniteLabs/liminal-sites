let t = 0;
let cols, rows;
let scale = 20;
let particles = [];
let flowField;
let resolution = 20;

function setup() {
  createCanvas(800, 600);
  pixelDensity(1);
  cols = floor(width / resolution);
  rows = floor(height / resolution);
  flowField = new Array(cols * rows);
  
  for (let i = 0; i < 800; i++) {
    particles.push(new Particle());
  }
  
  colorMode(HSB, 360, 100, 100);
  background(0);
}

function draw() {
  background(0, 0, 0, 25);
  
  let noiseScale = 0.1;
  let timeOffset = t * 0.005;
  
  for (let y = 0; y < rows; y++) {
    for (let x = 0; x < cols; x++) {
      let index = x + y * cols;
      let noiseVal = noise(x * noiseScale + timeOffset, y * noiseScale + timeOffset);
      let angle = noiseVal * TWO_PI * 2;
      let v = p5.Vector.fromAngle(angle);
      v.setMag(0.5);
      flowField[index] = v;
    }
  }
  
  let hueCycle = (sin(t * 0.01) * 0.5 + 0.5) * 360;
  
  for (let p of particles) {
    let x = floor(p.pos.x / resolution);
    let y = floor(p.pos.y / resolution);
    let index = x + y * cols;
    
    if (index >= 0 && index < flowField.length) {
      let force = flowField[index];
      p.applyForce(force);
    }
    
    p.update();
    p.edges();
    
    let particleHue = (hueCycle + p.pos.x * 0.5 + p.pos.y * 0.3) % 360;
    let brightness = map(noise(p.pos.x * 0.01, p.pos.y * 0.01, t * 0.02), 0, 1, 70, 100);
    let saturation = 100;
    
    p.show(particleHue, saturation, brightness);
  }
  
  drawPlasmaOverlay(hueCycle);
  
  t += 1;
}

function drawPlasmaOverlay(baseHue) {
  loadPixels();
  
  let time = t * 0.03;
  
  for (let x = 0; x < width; x += 4) {
    for (let y = 0; y < height; y += 4) {
      let noiseVal = noise(
        x * 0.008 + time,
        y * 0.008 + time,
        time * 0.5
      );
      
      let r = sin(x * 0.01 + time) * 127 + 128;
      let g = sin(y * 0.01 + time) * 127 + 128;
      let b = sin((x + y) * 0.01 + time) * 127 + 128;
      
      let alpha = noiseVal * 15;
      
      let idx = (x + y * width) * 4;
      if (idx >= 0 && idx < pixels.length - 4) {
        pixels[idx] = r * (alpha / 255);
        pixels[idx + 1] = g * (alpha / 255);
        pixels[idx + 2] = b * (alpha / 255);
      }
    }
  }
  
  updatePixels();
  
  for (let i = 0; i < 5; i++) {
    let x = noise(time + i * 100) * width;
    let y = noise(time + i * 200 + 50) * height;
    let size = noise(time + i * 300) * 100 + 20;
    
    noStroke();
    let orbHue = (baseHue + i * 60) % 360;
    fill(orbHue, 80, 100, 30);
    ellipse(x, y, size * 2);
    fill(orbHue, 60, 100, 50);
    ellipse(x, y, size);
    fill(orbHue, 40, 100, 80);
    ellipse(x, y, size * 0.5);
  }
}

class Particle {
  constructor() {
    this.pos = createVector(random(width), random(height));
    this.vel = createVector(0, 0);
    this.acc = createVector(0, 0);
    this.maxSpeed = 2;
    this.prevPos = this.pos.copy();
  }
  
  applyForce(force) {
    this.acc.add(force);
  }
  
  update() {
    this.vel.add(this.acc);
    this.vel.limit(this.maxSpeed);
    this.pos.add(this.vel);
    this.acc.mult(0);
  }
  
  edges() {
    if (this.pos.x > width) {
      this.pos.x = 0;
      this.updatePrev();
    }
    if (this.pos.x < 0) {
      this.pos.x = width;
      this.updatePrev();
    }
    if (this.pos.y > height) {
      this.pos.y = 0;
      this.updatePrev();
    }
    if (this.pos.y < 0) {
      this.pos.y = height;
      this.updatePrev();
    }
  }
  
  updatePrev() {
    this.prevPos.x = this.pos.x;
    this.prevPos.y = this.pos.y;
  }
  
  show(h, s, b) {
    stroke(h, s, b);
    strokeWeight(2);
    line(this.prevPos.x, this.prevPos.y, this.pos.x, this.pos.y);
    this.updatePrev();
  }
}

function windowResized() {
  resizeCanvas(800, 600);
  cols = floor(width / resolution);
  rows = floor(height / resolution);
  flowField = new Array(cols * rows);
}