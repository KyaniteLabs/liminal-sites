$: s("bd*4").gain(1),
  $: s("~ cp ~ cp").gain(0.7),
  $: s("hh*8").gain(0.4),
  $: s("mt*4").speed("1.5!2 1").gain(0.3),
  $: note("c2 c2 ~ c2 c2/2").s("sawtooth").shape(0.8).gain(0.5)
)

let shapes = [];
let numShapes = 12;
let t = 0;

function setup() {
  createCanvas(800, 600);
  pixelDensity(1);
  noStroke();
  for (let i = 0; i < numShapes; i++) {
    shapes.push({
      x: noise(i * 0.5) * width,
      y: noise(i * 0.5 + 100) * height,
      size: 20 + noise(i * 0.3) * 60,
      type: floor(random(3)),
      hue: random(360),
      vx: (noise(i * 0.7) - 0.5) * 2,
      vy: (noise(i * 0.7 + 50) - 0.5) * 2,
      trail: []
    });
  }
  colorMode(HSB, 360, 100, 100, 100);
}

function draw() {
  fill(0, 0, 0, 8);
  rect(0, 0, width, height);
  
  for (let s of shapes) {
    s.x += s.vx + noise(t * 0.5 + s.hue) - 0.5;
    s.y += s.vy + noise(t * 0.5 + s.hue + 200) - 0.5;
    
    if (s.x < 0 || s.x > width) s.vx *= -1;
    if (s.y < 0 || s.y > height) s.vy *= -1;
    
    s.trail.push({x: s.x, y: s.y, h: s.hue});
    if (s.trail.length > 30) s.trail.shift();
    
    for (let i = 0; i < s.trail.length; i++) {
      let t = s.trail[i];
      let alpha = map(i, 0, s.trail.length, 0, 60);
      let size = map(i, 0, s.trail.length, s.size * 0.3, s.size);
      
      fill(t.h, 80, 90, alpha);
      
      if (s.type === 0) {
        ellipse(t.x, t.y, size);
      } else if (s.type === 1) {
        rect(t.x - size/2, t.y - size/2, size, size);
      } else {
        triangle(t.x, t.y - size/2, t.x - size/2, t.y + size/2, t.x + size/2, t.y + size/2);
      }
    }
    
    s.hue += 0.3;
    if (s.hue > 360) s.hue -= 360;
  }
  t += 0.02;
}

function windowResized() {
  resizeCanvas(800, 600);
}