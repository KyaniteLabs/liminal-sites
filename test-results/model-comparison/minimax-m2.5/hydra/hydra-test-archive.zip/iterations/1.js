let t = 0;
let shapes = [];
let numShapes = 12;

function setup() {
  createCanvas(800, 600);
  pixelDensity(1);
  noStroke();
  
  for (let i = 0; i < numShapes; i++) {
    shapes.push({
      x: 0,
      y: 0,
      size: 0,
      hue: 0,
      rot: 0,
      baseX: 0,
      baseY: 0
    });
  }
}

function draw() {
  fill(0, 0, 0, 25);
  rect(0, 0, width, height);
  
  t += 0.008;
  
  for (let i = 0; i < numShapes; i++) {
    let s = shapes[i];
    
    let noiseScale = 0.003;
    let timeOffset = i * 0.5;
    
    let noiseX = noise(t + timeOffset, i * 0.1);
    let noiseY = noise(t + timeOffset + 100, i * 0.1 + 50);
    
    let angle = noiseX * TWO_PI * 2;
    let radius = 150 + noiseY * 200;
    
    let centerX = width / 2;
    let centerY = height / 2;
    
    s.x = centerX + cos(angle + t * 0.5) * radius;
    s.y = centerY + sin(angle + t * 0.3) * radius * 0.7;
    
    s.size = 30 + noise(t * 2 + i) * 50;
    
    s.hue = (noise(t * 0.5 + i * 0.2) * 180 + 200) % 360;
    
    s.rot = t * 2 + i * 0.3;
    
    let shapeType = i % 3;
    
    push();
    translate(s.x, s.y);
    rotate(s.rot);
    
    colorMode(HSB, 360, 100, 100, 100);
    let alpha = 70 + noise(t + i) * 30;
    fill(s.hue, 80, 90, alpha);
    
    if (shapeType === 0) {
      rectMode(CENTER);
      rect(0, 0, s.size, s.size * 0.6);
    } else if (shapeType === 1) {
      ellipse(0, 0, s.size, s.size);
    } else {
      let r = s.size * 0.5;
      triangle(0, -r, -r * 0.866, r * 0.5, r * 0.866, r * 0.5);
    }
    
    stroke(s.hue, 90, 100, 40);
    strokeWeight(2);
    noFill();
    
    if (shapeType === 0) {
      rect(0, 0, s.size * 1.2, s.size * 0.8);
    } else if (shapeType === 1) {
      ellipse(0, 0, s.size * 1.3, s.size * 1.3);
    } else {
      let r = s.size * 0.7;
      triangle(0, -r, -r * 0.866, r * 0.5, r * 0.866, r * 0.5);
    }
    
    pop();
  }
  
  colorMode(RGB, 255);
  
  noFill();
  stroke(255, 30);
  strokeWeight(1);
  
  beginShape();
  for (let i = 0; i < numShapes; i++) {
    let s = shapes[i];
    if (i === 0) {
      vertex(s.x, s.y);
    }
  }
  endShape();
  
  drawConnectionLines();
}

function drawConnectionLines() {
  for (let i = 0; i < numShapes; i++) {
    for (let j = i + 1; j < numShapes; j++) {
      let d = dist(shapes[i].x, shapes[i].y, shapes[j].x, shapes[j].y);
      
      if (d < 150) {
        let alpha = map(d, 0, 150, 60, 0);
        
        stroke(255, alpha);
        strokeWeight(map(d, 0, 150, 2, 0.5));
        line(shapes[i].x, shapes[i].y, shapes[j].x, shapes[j].y);
      }
    }
  }
}

function windowResized() {
  resizeCanvas(800, 600);
}