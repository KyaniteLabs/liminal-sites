$: s("bd:0*4 ~ bd:0 ~ ~").pan(sine)
$: s("~ sd ~ sd").gain(0.8)
$: s("hh*16").gain(0.5).room(0.2)
$: s("~ ~ ~ ~ cp ~ ~ ~").gain(0.3).delay(0.25)
stack(
  $: n("0 ~ 0 ~ 0 ~ 0 5").s("sawtooth").gain(0.4)
$.every(2, fast(2))