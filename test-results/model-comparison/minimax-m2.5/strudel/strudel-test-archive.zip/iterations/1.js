stack(
  $: s("bd*4").gain(1),
  $: s("~ cp ~ cp").gain(0.7),
  $: s("hh*8").gain(0.4),
  $: s("mt*4").speed("1.5!2 1").gain(0.3),
  $: note("c2 c2 ~ c2 c2/2").s("sawtooth").shape(0.8).gain(0.5)