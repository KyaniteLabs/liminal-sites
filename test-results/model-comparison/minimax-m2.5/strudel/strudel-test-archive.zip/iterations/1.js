let beatInterval;
let lastBeatTime;
let beatCount = 0;
let t = 0;

function setup() {
  createCanvas(800, 600);
  pixelDensity(1);
  noStroke();
  beatInterval = 60000 / 130;
  lastBeatTime = millis();
}

function draw() {
  background(0);
  
  let currentTime = millis();
  let timeSinceBeat = currentTime - lastBeatTime;
  
  if (timeSinceBeat >= beatInterval) {
    beatCount++;
    lastBeatTime = currentTime;
    timeSinceBeat = 0;
  }
  
  let beatPulse = map(timeSinceBeat, 0, beatInterval, 1, 0);
  beatPulse = pow(beatPulse, 0.3);
  
  let mx = mouseX / width;
  let my = mouseY / height;
  
  t += 0.02;
  
  push();
  translate(width/2, height/2);
  
  let numRings = 12;
  for (let i = 0; i < numRings; i++) {
    let angle = TWO_PI / numRings * i + t * (0.5 + i * 0.1);
    let baseRadius = 50 + i * 25;
    
    let beatOffset = beatPulse * 30 * (1 + i * 0.1);
    let noiseRadius = noise(i * 0.5, t) * 40;
    let mouseRadius = dist(mouseX, mouseY, width/2, height/2) * 0.3 * (i / numRings);
    
    let radius = baseRadius + beatOffset + noiseRadius + mouseRadius;
    
    let hue = (i * 30 + beatCount * 2 + t * 20) % 360;
    colorMode(HSB, 360, 100, 100);
    
    let alpha = 80 - i * 5 + beatPulse * 20;
    fill(hue, 80, 100, alpha);
    
    for (let j = 0; j < 8; j++) {
      let a = angle + j * TWO_PI / 8;
      let px = cos(a) * radius;
      let py = sin(a) * radius;
      let size = 20 + beatPulse * 15 + noise(i + j, t) * 10;
      ellipse(px, py, size, size);
    }
  }
  pop();
  
  colorMode(RGB);
  let barWidth = width / 32;
  for (let i = 0; i < 32; i++) {
    let barHeight;
    let beatPhase = (beatCount + i / 32) % 1;
    
    if (i % 4 === 0) {
      barHeight = 150 * beatPulse + 50;
    } else if (i % 2 === 0) {
      barHeight = 80 * beatPulse + 30;
    } else {
      barHeight = 40 * beatPulse + 20;
    }
    
    barHeight += noise(i, t * 2) * 30;
    barHeight += abs(mouseX - i * barWidth) < barWidth ? 50 : 0;
    
    let hue = map(i, 0, 32, 180, 300);
    colorMode(HSB, 360, 100, 100);
    fill(hue, 70, 90);
    rect(i * barWidth, height - barHeight, barWidth - 2, barHeight);
  }
  
  colorMode(RGB);
  let waveY = height / 2;
  noFill();
  stroke(255, 100);
  strokeWeight(2);
  beginShape();
  for (let x = 0; x < width; x += 5) {
    let y = waveY + sin(x * 0.02 + t * 3) * 50 * beatPulse;
    y += noise(x * 0.01, t) * 30;
    y += (mouseY - waveY) * 0.3;
    vertex(x, y);
  }
  endShape();
  
  noStroke();
  fill(255, 200);
  textSize(14);
  text("130 BPM", 20, 30);
  text("BEAT: " + beatCount, 20, 50);
  
  let flash = beatPulse > 0.9;
  if (flash) {
    fill(255, random(5, 15));
    rect(0, 0, width, height);
  }
}

function mousePressed() {
  beatCount++;
  lastBeatTime = millis() - beatInterval;
}

function windowResized() {
  resizeCanvas(800, 600);
}