stack(
  $: s("bd*4").gain(0.9).distort(0.3),
  $: s("hh*8").gain(0.4).speed(1),
  $: s("~ sd ~ sd").gain(0.6),
  $: s("cp*4").gain(0.3).room(0.5),
  $: note("c2 c2 f2 f2 c2 c2 g2 g2").s("sawtooth").gain(0.5).shape(0.8).cut(0.5)