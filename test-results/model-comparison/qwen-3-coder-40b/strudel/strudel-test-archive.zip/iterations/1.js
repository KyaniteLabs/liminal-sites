$: s("bd*4").speed(1.08)
$: s("sd*4, sd~ sd~").every(4, rev).gain(0.6)
$: s("hh*8, hh~ hh~").gain(0.5).delay(0.1)
$: note("c2 e2 g2 c3").s("sawtooth").gain(0.2).fast(2)