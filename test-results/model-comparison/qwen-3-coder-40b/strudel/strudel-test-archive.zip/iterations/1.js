$: s("bd*4").speed(1.083)
$: s("~ sd ~ sd").every(4, rev).gain(0.6)
$: s("hh*8").gain(0.5).delay(0.05)
$: note("c2 e2 g2 b2").s("sawtooth").gain(0.25).room(0.4)