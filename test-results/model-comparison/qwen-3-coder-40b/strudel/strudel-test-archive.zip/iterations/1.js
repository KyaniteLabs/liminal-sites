let particles = [];
let beatTime = 0;
let bpm = 130;
let beatInterval = (60 / bpm) * 1000;
let lastBeatTime = 0;
let beatStrength = 0;

function setup() {
  createCanvas(windowWidth, windowHeight);
  pixelDensity(1);
  noiseSeed(Math.floor(random(10000)));
  
  for (let i = 0; i < 250; i++) {
    particles.push(new Particle());
  }
}

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
}

function draw() {
  // Beat detection
  let now = millis();
  if (now - lastBeatTime > beatInterval) {
    beatStrength = 1.2;
    lastBeatTime = now;
  } else {
    beatStrength = lerp(beatStrength, 0, 0.1);
  }
  
  // Background with trail effect
  fill(5, 30);
  noStroke();
  rect(0, 0, width, height);
  
  // Update and draw particles
  let centerX = width / 2;
  let centerY = height / 2;
  
  for (let p of particles) {
    p.update(centerX, centerY, beatStrength);
    p.draw();
  }
}

class Particle {
  constructor() {
    this.reset();
    // Random initial position within a circle
    let angle = random(TWO_PI);
    let radius = random(100, min(width, height) * 0.4);
    this.x = width/2 + cos(angle) * radius;
    this.y = height/2 + sin(angle) * radius;
  }
  
  reset() {
    this.angle = random(TWO_PI);
    this.radius = random(100, min(width, height) * 0.45);
    this.speed = random(0.02, 0.08);
    this.baseSpeed = this.speed;
    this.size = random(2, 6);
    this.hue = random(0, 360);
    this.life = random(100, 300);
    this.opacity = 255;
  }
  
  update(centerX, centerY, beatMult) {
    // Beat amplification
    let currentSpeed = this.baseSpeed * (1 + beatStrength * 0.8);
    
    // Spiral motion using noise for smoothness
    this.angle += currentSpeed;
    let noiseVal = noise(millis() * 0.002, this.hue * 0.01);
    
    // Dynamic radius with beat influence
    let targetRadius = min(width, height) * (0.3 + noiseVal * 0.4);
    this.radius = lerp(this.radius, targetRadius, 0.05);
    
    // Calculate position
    this.x = centerX + cos(this.angle) * this.radius;
    this.y = centerY + sin(this.angle) * this.radius;
    
    // Color cycling
    this.hue = (this.hue + beatStrength * 10 + 0.5) % 360;
    this.life -= 1;
    
    if (this.life <= 0) {
      this.reset();
    }
  }
  
  draw() {
    let alpha = map(sin(millis() * 0.005), -1, 1, 100, 255);
    let beatAlpha = map(beatStrength, 0, 1, 100, 255);
    
    let r = red(this.hue, 100, 100);
    let g = green(this.hue, 100, 100);
    let b = blue(this.hue, 100, 100);
    
    // Beat-enhanced brightness
    colorMode(HSB);
    fill(this.hue, 80, 100 + beatStrength * 50, alpha);
    
    noStroke();
    circle(this.x, this.y, this.size + beatStrength * 4);
    
    // Draw trails with fading circles
    for (let i = 1; i <= 3; i++) {
      let trailAlpha = map(i, 1, 3, alpha * 0.5, 20);
      circle(this.x - cos(this.angle) * this.radius * 0.1 * i,
             this.y - sin(this.angle) * this.radius * 0.1 * i,
             this.size * (1 - i/4), trailAlpha);
    }
  }
}