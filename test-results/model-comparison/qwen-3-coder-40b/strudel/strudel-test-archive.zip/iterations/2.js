const BPM = 130;
let particles = [];
let frameCount = 0;
let beatFrame = 0;
let flowField = [];
let particleIndex = 0;

function setup() {
  createCanvas(800, 600);
  pixelDensity(1);
  noStroke();
  
  noiseSeed(4297153);
  
  // Initialize particles with random positions and velocities
  for (let i = 0; i < 400; i++) {
    particles.push(new Particle());
  }
}

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
  background(0);
  noiseSeed(frameCount * 12345); // Change seed on resize for variety
}

function draw() {
  frameCount++;
  
  // Clear with slight transparency for trail effect
  background(0, 100);
  
  const msPerBeat = (60.0 / BPM) * 1000;
  const framesPerBeat = floor(msPerBeat / fps());
  
  beatFrame++;
  
  // Beat timing logic
  if (beatFrame >= framesPerBeat) {
    beatFrame = 0;
    
    // Create visual burst on beat using noise for organic spread
    let x = width/2 + sin(frameCount * 0.1) * 50;
    let y = height/2 + cos(frameCount * 0.13) * 50;
    
    noFill();
    stroke(255, 100);
    strokeWeight(2);
    
    for (let i = 0; i < 10; i++) {
      let angle = map(i, 0, 10, 0, TWO_PI * 2);
      let r = random(50, 300);
      
      // Use noise to vary the radius slightly for organic feel
      r += sin(noise(frameCount * 0.002 + i) * 1000) * 20;
      
      line(x, y, x + cos(angle) * r, y + sin(angle) * r);
    }
    
    // Flash effect using noise gradient
    let flash = map(noise(frameCount * 0.05), 0, 1, 0, 255);
    fill(255, flash);
    rectMode(CENTER);
    rect(width/2 + random(-100, 100), height/2 + random(-100, 100), random(100, 300), random(100, 300));
    
    // Reset particle flow field based on beat
    if (frameCount % framesPerBeat === 0) {
      updateFlowField();
    }
  }
  
  // Update and draw particles using noise for organic movement
  let t = frameCount * 0.01;
  let yoff = 0;
  
  for (let i = 0; i < particles.length; i++) {
    let p = particles[i];
    
    // Smooth velocity changes based on Perlin noise
    p.vel.x += sin(t + p.pos.y * 0.1) * 0.5;
    p.vel.y += cos(t + p.pos.x * 0.1) * 0.5;
    
    // Limit speed slightly but allow flow
    if (p.vel.mag() > 4) {
      p.vel.setMag(4);
    }
    
    p.update();
    p.edges();
    p.show();
  }
  
  // Draw grid lines that pulse with the beat using noise
  let gridSize = 20;
  for (let x = 0; x < width; x += gridSize) {
    noFill();
    stroke(50, 10);
    line(x, 0, x, height);
    
    // Pulse opacity based on beat and noise
    let pulse = map(noise(frameCount * 0.02 + x * 0.01), 0, 1, 0, 50);
    stroke(255, pulse);
    line(x, 0, x, height);
  }
  
  for (let y = 0; y < height; y += gridSize) {
    noFill();
    stroke(50, 10);
    line(0, y, width, y);
    
    // Pulse opacity based on beat and noise
    let pulse = map(noise(frameCount * 0.02 + y * 0.01), 0, 1, 0, 50);
    stroke(255, pulse);
    line(0, y, width, y);
  }
}

function updateFlowField() {
  // Create a new flow field based on current time and noise seed
  let angleOffset = frameCount * 0.1;
  
  for (let x = 0; x < width; x += 2) {
    for (let y = 0; y < height; y += 2) {
      // Use noise to determine flow direction at each point
      let n = noise(x * 0.01, y * 0.01, frameCount * 0.005);
      let angle = map(n, 0, 1, 0, TWO_PI * 2) + angleOffset;
      
      // Store in a way particles can access (using index mapping)
      let idx = int(x / 2 + y * width / 2);
      if (idx < particles.length && !particles[idx].setAngle(angle)) {
         // Fallback for particles that don't have angle set
      }
    }
  }
}

class Particle {
  constructor() {
    this.pos = createVector(random(width), random(height));
    this.vel = p5.Vector.random2D();
    this.vel.setMag(random(1, 3));
    
    // Each particle has its own noise offset for smoother individual paths
    this.noiseOffsetX = random(100);
    this.noiseOffsetY = random(100);
    
    this.angle = random(TWO_PI * 2);
    this.size = random(2, 5);
    
    // Color variation based on position and time using noise
    let hueVal = map(this.pos.y, 0, height, 0, 360);
    this.hue = lerpColor(color(hueVal), color(180), noise(this.noiseOffsetX));
  }
  
  update() {
    // Apply Perlin noise to velocity for organic flow
    let n = noise(frameCount * 0.01 + this.pos.x * 0.01, frameCount * 0.01 + this.pos.y * 0.01);
    
    // Modulate velocity based on noise
    let speedMod = map(n, 0, 1, 0.5, 2.0);
    this.vel.setMag(this.vel.mag() * speedMod);
    
    this.pos.add(this.vel);
    
    // Update angle for color variation
    this.angle += 0.05;
  }
  
  edges() {
    if (this.pos.x > width) { this.pos.x = 0; }
    else if (this.pos.x < 0) { this.pos.x = width; }
    
    if (this.pos.y > height) { this.pos.y = 0; }
    else if (this.pos.y < 0) { this.pos.y = height; }
  }
  
  show() {
    // Color based on angle and noise for techno aesthetic
    let cHue = map(this.angle, 0, TWO_PI * 2, 180, 360);
    
    // Pulsate brightness with noise
    let alpha = map(noise(frameCount * 0.05 + this.pos.x * 0.01), 0, 1, 100, 255);
    
    fill(cHue, 80, 100, alpha/2);
    noStroke();
    circle(this.pos.x, this.pos.y, this.size);
  }
}