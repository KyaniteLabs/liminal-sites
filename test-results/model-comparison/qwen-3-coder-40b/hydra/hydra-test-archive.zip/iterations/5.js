let t = 0;
let shapes = [];
let hueOffset = 0;

function setup() {
  createCanvas(windowWidth, windowHeight);
  background(10);
}

function draw() {
  // Dynamic fade for trails
  let fadeAlpha = map(sin(t * 0.5), -1, 1, 30, 80);
  fill(10, fadeAlpha);
  rect(0, 0, width, height);

  t += 0.02;
  hueOffset = (hueOffset + 0.5) % 360;

  // Add new shapes
  if (frameCount % 4 === 0) {
    let x = random(width * 0.1, width * 0.9);
    let y = random(height * 0.1, height * 0.9);
    let size = random(20, 80);
    shapes.push({
      x: x,
      y: y,
      size: size,
      angle: random(TWO_PI),
      type: floor(random(3)), // 0: circle, 1: square, 2: triangle
      hue: (hueOffset + random(-20, 20)) % 360,
      speedX: random(-2, 2),
      speedY: random(-2, 2)
    });
  }

  // Draw and update shapes
  for (let i = 0; i < shapes.length; i++) {
    let s = shapes[i];
    
    // Update position with bounce
    s.x += s.speedX;
    s.y += s.speedY;
    s.angle += 0.05;
    
    if (s.x < 0 || s.x > width) s.speedX *= -1;
    if (s.y < 0 || s.y > height) s.speedY *= -1;

    // Draw shape with color
    push();
    translate(s.x, s.y);
    rotate(s.angle);
    
    let col = color(s.hue, 80, 90);
    fill(col);
    stroke(col);
    strokeWeight(2);
    
    if (s.type === 0) {
      circle(0, 0, s.size);
    } else if (s.type === 1) {
      rect(-s.size/2, -s.size/2, s.size, s.size);
    } else {
      triangle(-s.size/2, s.size/2, 0, -s.size/2, s.size/2, s.size/2);
    }
    
    pop();
  }

  // Add interactive effect on mouse movement
  if (mouseX > 0 && mouseX < width && mouseY > 0 && mouseY < height) {
    let distToMouse = dist(mouseX, mouseY, width/2, height/2);
    let intensity = map(distToMouse, 0, min(width,height), 5, 1);
    
    if (frameCount % floor(intensity) === 0) {
      shapes.push({
        x: mouseX,
        y: mouseY,
        size: random(10, 30),
        angle: 0,
        type: 0,
        hue: (hueOffset + 180) % 360,
        speedX: random(-5, 5),
        speedY: random(-5, 5)
      });
    }
  }

  // Limit number of shapes for performance
  if (shapes.length > 150) {
    shapes.splice(0, shapes.length - 150);
  }
}