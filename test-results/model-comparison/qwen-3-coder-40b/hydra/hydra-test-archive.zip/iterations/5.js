let particles = [];
let hueOffset = 0;
let trailFade = 30;

function setup() {
  createCanvas(windowWidth, windowHeight);
  pixelDensity(1);
  noiseSeed(24681);
  
  for (let i = 0; i < 400; i++) {
    particles.push(new Particle());
  }
}

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
  background(5);
}

function draw() {
  background(10, trailFade);
  
  hueOffset += 0.5;
  
  for (let p of particles) {
    p.update();
    p.draw();
  }
}

class Particle {
  constructor() {
    this.init();
  }

  init() {
    this.x = random(width);
    this.y = random(height);
    this.size = random(3, 12);
    this.angle = random(TWO_PI);
    this.speed = random(1, 4);
    this.hueBase = random(0, 360);
    this.turnSpeed = random(-0.05, 0.05);
    
    let n = noise(this.x * 0.01, this.y * 0.01) * TWO_PI;
    this.vx = cos(n) * this.speed;
    this.vy = sin(n) * this.speed;
    
    this.shapeType = random() > 0.5 ? 'circle' : (random() > 0.5 ? 'rect' : 'triangle');
  }

  update() {
    let n = noise(this.x * 0.01, this.y * 0.01, frameCount * 0.01) * TWO_PI;
    this.angle = lerpAngle(this.angle, n, 0.1);
    
    this.vx += cos(n) * 0.2 - this.vx * 0.1;
    this.vy += sin(n) * 0.2 - this.vy * 0.1;
    
    // Normalize speed
    let speed = sqrt(this.vx * this.vx + this.vy * this.vy);
    if (speed > 5) {
      this.vx *= 0.95;
      this.vy *= 0.95;
    }
    
    this.x += this.vx;
    this.y += this.vy;

    // Wrap around
    if (this.x < -20) this.x = width + 20;
    if (this.x > width + 20) this.x = -20;
    if (this.y < -20) this.y = height + 20;
    if (this.y > height + 20) this.y = -20;

    // Change shape occasionally
    if (random() < 0.005) {
      this.shapeType = random() > 0.5 ? 'circle' : (random() > 0.5 ? 'rect' : 'triangle');
    }
  }

  draw() {
    let hue = (this.hueBase + hueOffset + noise(frameCount * 0.1) * 60) % 360;
    colorMode(HSB);
    
    stroke(hue, 80, 255);
    noFill();
    strokeWeight(2);
    
    push();
    translate(this.x, this.y);
    rotate(this.angle + frameCount * 0.02);
    
    if (this.shapeType === 'circle') {
      ellipse(0, 0, this.size);
    } else if (this.shapeType === 'rect') {
      rect(-this.size/2, -this.size/2, this.size, this.size);
    } else {
      triangle(-this.size/2, -this.size/3, 
               this.size/2, -this.size/3, 
               0, this.size/2);
    }
    
    pop();
  }
}

function lerpAngle(a, b, amount) {
  let diff = b - a;
  while (diff < -PI) diff += TWO_PI;
  while (diff > PI) diff -= TWO_PI;
  return a + diff * amount;
}