let t = 0;
let particles = [];

function setup() {
  createCanvas(windowWidth, windowHeight);
  background(10);
}

function draw() {
  // Fade effect for trails
  fill(0, 5);
  rect(0, 0, width, height);

  t += 0.02;

  // Create new particles periodically
  if (frameCount % 3 === 0) {
    let hue = (t * 10 + frameCount * 2) % 360;
    particles.push(new Particle(hue));
  }

  // Update and draw particles
  for (let i = particles.length - 1; i >= 0; i--) {
    particles[i].update();
    particles[i].draw();
    if (particles[i].isDead()) {
      particles.splice(i, 1);
    }
  }
}

class Particle {
  constructor(hue) {
    this.x = width / 2 + random(-50, 50);
    this.y = height / 2 + random(-50, 50);
    this.size = random(10, 60);
    this.hue = hue;
    this.life = 1.0;
    this.speed = random(1, 4);
    this.angle = random(TWO_PI);
    this.vx = cos(this.angle) * this.speed;
    this.vy = sin(this.angle) * this.speed;
    this.rotation = random(0, TWO_PI);
    this.rotSpeed = random(-0.1, 0.1);
    this.shapeType = random() < 0.33 ? 'circle' : (random() < 0.5 ? 'rect' : 'triangle');
  }

  update() {
    this.x += this.vx;
    this.y += this.vy;
    this.rotation += this.rotSpeed;
    this.life -= 0.015;
    this.size *= 0.97;

    // Bounce off edges
    if (this.x < 0 || this.x > width) this.vx *= -1;
    if (this.y < 0 || this.y > height) this.vy *= -1;
  }

  draw() {
    push();
    translate(this.x, this.y);
    rotate(this.rotation);
    
    // Color with fade
    fill(this.hue, 80, 90, this.life);
    noStroke();

    if (this.shapeType === 'circle') {
      ellipse(0, 0, this.size);
    } else if (this.shapeType === 'rect') {
      rect(-this.size/2, -this.size/2, this.size, this.size);
    } else {
      polygon(0, 0, this.size/2, 3);
    }
    
    pop();
  }

  isDead() {
    return this.life <= 0;
  }
}

// Helper function for drawing polygons
function polygon(x, y, radius, sides) {
  let angle = TWO_PI / sides;
  beginShape();
  for (let i = 0; i < sides; i++) {
    vertex(
      x + radius * cos(i * angle),
      y + radius * sin(i * angle)
    );
  }
  endShape(CLOSE);
}