let t = 0;
let hueVal;

function setup() {
  createCanvas(windowWidth, windowHeight);
  background(10);
}

function draw() {
  // Create trails by drawing semi-transparent black rectangle over canvas
  fill(0, 30); 
  rect(0, 0, width, height);
  
  // Update time variable
  t += 0.02;
  
  // Set up color and stroke style
  hueVal = (t * 50) % 360;
  stroke(hueVal, 80, 100);
  noFill();
  strokeWeight(2);
  
  // Calculate dynamic values based on time
  const centerX = width / 2 + cos(t * 0.8) * (width / 4);
  const centerY = height / 2 + sin(t * 0.6) * (height / 4);
  
  const rotation = t;
  const size = 100 + 50 * sin(t * 1.3);
  const shapeCount = 8;
  
  // Draw rotating geometric shapes with feedback trails
  for (let i = 0; i < shapeCount; i++) {
    push();
    
    // Rotate around center with offset
    translate(centerX, centerY);
    rotate(rotation + (i * TWO_PI / shapeCount));
    
    // Dynamic sizing based on time and index
    const currentSize = size * (1 + 0.3 * sin(t + i * 0.5));
    
    // Draw different shapes for variety
    if (i % 2 === 0) {
      // Triangle
      polygon(0, 0, currentSize / 2, 3);
    } else {
      // Square
      rect(-currentSize/2, -currentSize/2, currentSize, currentSize);
    }
    
    pop();
  }
  
  // Add a central rotating star for visual complexity
  push();
  translate(centerX, centerY);
  rotate(rotation * 1.7);
  stroke(hueVal + 180, 90, 100); // Complementary color for contrast
  const starSize = size * 0.6;
  polygon(0, 0, starSize / 2, 5);
  pop();
}

// Helper function to draw regular polygons
function polygon(x, y, radius, sides) {
  beginShape();
  for (let i = 0; i < sides; i++) {
    const angle = map(i, 0, sides, 0, TWO_PI);
    vertex(
      x + radius * cos(angle),
      y + radius * sin(angle)
    );
  }
  endShape(CLOSE);
}

// Handle window resizing
function resizeCanvas() {
  resizeCanvas(windowWidth, windowHeight);
}