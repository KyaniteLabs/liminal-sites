let particles = [];
let trailStrength = 25;
let shapeSize = 10;
let timeScale = 0.01;

function setup() {
  createCanvas(windowWidth, windowHeight);
  pixelDensity(1);
  background(10);
  
  for (let i = 0; i < 150; i++) {
    particles.push(new Particle());
  }
}

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
}

function draw() {
  fill(0, trailStrength);
  rect(0, 0, width, height);
  
  let time = millis() * timeScale;
  
  for (let i = 0; i < particles.length; i++) {
    particles[i].update(time);
    particles[i].show();
  }
}

class Particle {
  constructor() {
    this.reset();
  }
  
  reset() {
    this.x = random(width);
    this.y = random(height);
    this.size = random(5, 20);
    this.speed = random(1, 4);
    this.angle = random(TWO_PI);
    this.turnSpeed = random(-0.1, 0.1);
    this.hue = random(360);
    this.hueChange = random(-1, 1);
    this.type = floor(random(3)); // 0: circle, 1: square, 2: triangle
  }
  
  update(time) {
    // Use noise for organic movement
    let noiseX = noise(this.x * 0.01, time) - 0.5;
    let noiseY = noise(this.y * 0.01, time) - 0.5;
    
    this.angle += this.turnSpeed + noiseX * 0.2;
    this.x += cos(this.angle) * this.speed + noiseX * 3;
    this.y += sin(this.angle) * this.speed + noiseY * 3;
    
    // Wrap around screen
    if (this.x < -50) this.x = width + 50;
    if (this.x > width + 50) this.x = -50;
    if (this.y < -50) this.y = height + 50;
    if (this.y > height + 50) this.y = -50;
    
    // Cycle colors
    this.hue += this.hueChange;
    if (this.hue < 0) this.hue += 360;
    if (this.hue > 360) this.hue -= 360;
    
    // Occasionally reset some particles for variety
    if (random(1) < 0.01) {
      this.reset();
    }
  }
  
  show() {
    push();
    translate(this.x, this.y);
    rotate(this.angle);
    colorMode(HSB);
    stroke(this.hue, 80, 255);
    noFill();
    
    let size = this.size + sin(millis() * 0.01) * 5;
    
    if (this.type === 0) {
      circle(0, 0, size);
    } else if (this.type === 1) {
      rect(-size/2, -size/2, size, size);
    } else {
      let r = size / 1.8;
      beginShape();
      for (let i = 0; i < 3; i++) {
        let angle = map(i, 0, 3, 0, TWO_PI);
        vertex(r * cos(angle), r * sin(angle));
      }
      endShape(CLOSE);
    }
    
    // Draw secondary geometric elements
    stroke(this.hue + 180, 80, 255, 100);
    noFill();
    circle(0, 0, size * 1.7);
    rect(-size/1.5, -size/1.5, size*1.3, size*1.3);
    
    pop();
  }
}