let t = 0;
let shapes = [];
let hueOffset = 0;

function setup() {
  createCanvas(windowWidth, windowHeight);
  background(10);
}

function draw() {
  // Dynamic fade for trails
  let fadeAlpha = map(sin(t * 0.5), -1, 1, 30, 80);
  fill(10, fadeAlpha);
  rect(0, 0, width, height);

  t += 0.02;
  hueOffset = (hueOffset + 0.5) % 360;

  // Add new shapes
  if (frameCount % 4 === 0) {
    let x = random(width * 0.1, width * 0.9);
    let y = random(height * 0.1, height * 0.9);
    let size = random(20, 80);
    let type = floor(random(3));
    shapes.push({
      x: x,
      y: y,
      vx: random(-2, 2),
      vy: random(-2, 2),
      size: size,
      type: type,
      hue: (hueOffset + frameCount * 2) % 360,
      rotation: random(TWO_PI),
      rotSpeed: random(-0.1, 0.1)
    });
  }

  // Draw and update shapes
  for (let i = 0; i < shapes.length; i++) {
    let s = shapes[i];
    
    // Update position
    s.x += s.vx;
    s.y += s.vy;
    s.rotation += s.rotSpeed;
    
    // Bounce from edges
    if (s.x < -50 || s.x > width + 50) s.vx *= -1;
    if (s.y < -50 || s.y > height + 50) s.vy *= -1;
    
    // Keep shapes within reasonable bounds with gentle bouncing
    if (s.x < 0) { s.x = 0; s.vx *= -1.02; }
    if (s.x > width) { s.x = width; s.vx *= -1.02; }
    if (s.y < 0) { s.y = 0; s.vy *= -1.02; }
    if (s.y > height) { s.y = height; s.vy *= -1.02; }

    // Draw shape with glowing effect
    colorMode(HSB);
    stroke(s.hue, 80, 100, 150);
    fill(s.hue, 70, 80, 60);
    
    translate(s.x, s.y);
    rotate(s.rotation);
    
    if (s.type === 0) {
      rect(0, 0, s.size, s.size);
    } else if (s.type === 1) {
      triangle(
        -s.size/2, -s.size/2,
        s.size/2, -s.size/2,
        0, s.size/2
      );
    } else {
      let sides = floor(map(s.hue, 0, 360, 3, 8));
      polygon(0, 0, s.size/2, sides);
    }
    
    rotate(-s.rotation);
    translate(-s.x, -y);

    // Remove very large shapes to keep performance
    if (s.size > 150) {
      shapes.splice(i, 1);
      i--;
    }
  }

  // Add mouse interaction trail
  if (mouseX > 0 && mouseX < width && mouseY > 0 && mouseY < height) {
    colorMode(HSB);
    stroke((hueOffset + frameCount * 3) % 360, 90, 100, 200);
    fill((hueOffset + frameCount * 3) % 360, 80, 90, 150);
    
    let size = map(mouseX, 0, width, 30, 100);
    ellipse(mouseX, mouseY, size, size);
  }
}

function polygon(x, y, radius, sides) {
  beginShape();
  for (let i = 0; i < sides; i++) {
    let angle = map(i, 0, sides, 0, TWO_PI);
    let sx = x + cos(angle) * radius;
    let sy = y + sin(angle) * radius;
    vertex(sx, sy);
  }
  endShape(CLOSE);
}