const particleSize = 12;
let particles = [];
let hueOffset = 0;
let angleOffset = 0;
let speedMultiplier = 3.5;
let trailFade = 28; // Lower = longer trails

function setup() {
  createCanvas(800, 600);
  pixelDensity(1);
  
  noiseSeed(42976);
  
  for (let i = 0; i < 500; i++) {
    particles.push(new Particle());
  }
}

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
  background(10);
}

class Particle {
  constructor() {
    this.init();
  }

  init() {
    let x = random(width);
    let y = random(height);
    
    // Use noise for initial velocity variation to ensure organic distribution
    let vNoise = noise(x * 0.01, y * 0.01) * 2.5;
    let angle = map(vNoise, -2.5, 2.5, 0, PI * 2);
    
    this.x = x;
    this.y = y;
    this.vx = cos(angle) * vNoise * speedMultiplier;
    this.vy = sin(angle) * vNoise * speedMultiplier;
    
    // Noise-based initial color variation
    let h = map(noise(x, y), 0, 1, 0, 240);
    this.hue = h + noiseOffset;
    this.size = map(noise(x/50, y/50), 0, 1, 2, particleSize);
    this.life = random(100);
  }

  update() {
    // Update position with velocity
    this.x += this.vx;
    this.y += this.vy;
    
    // Add noise to movement for organic wandering
    let wanderX = (noise(this.x * 0.02, this.y * 0.02) - 0.5) * 0.5;
    let wanderY = (noise(this.x * 0.03, this.y * 0.02 + 1) - 0.5) * 0.5;
    
    this.vx += wanderX * 0.05;
    this.vy += wanderY * 0.05;
    
    // Keep velocity somewhat bounded but allow flow
    let currentSpeed = sqrt(sq(this.vx) + sq(this.vy));
    if (currentSpeed > 12) {
      this.vx *= 0.98;
      this.vy *= 0.98;
    } else if (currentSpeed < 4) {
      this.vx *= 1.02;
      this.vy *= 1.02;
    }
    
    // Wrap around screen edges
    if (this.x > width + particleSize * 2) this.x = -particleSize * 2;
    if (this.x < -particleSize * 2) this.x = width + particleSize * 2;
    if (this.y > height + particleSize * 2) this.y = -particleSize * 2;
    if (this.y < -particleSize * 2) this.y = height + particleSize * 2;
    
    // Update color based on position noise for smooth gradients
    let baseHue = map(noise(this.x * 0.01, this.y * 0.01), 0, 1, 0, 360);
    this.hue = lerp(this.hue, baseHue + hueOffset, 0.02);
    
    // Slowly pulse size
    let targetSize = map(noise(this.x * 0.005, frameCount * 0.1), 0, 1, particleSize * 0.3, particleSize * 1.8);
    this.size += (targetSize - this.size) * 0.05;
    
    // Decay life for trail effect
    this.life -= 2;
    if (this.life <= 0) {
      this.init();
    }
  }

  draw() {
    noStroke();
    
    // Draw a small circle at the current position
    fill(this.hue, 60, 100);
    circle(this.x, this.y, this.size);
    
    // Draw a trail behind the particle based on previous positions
    if (this.life > 5) {
      let prevX = this.x - this.vx * 3;
      let prevY = this.y - this.vy * 3;
      
      fill(this.hue, 60, 100);
      noStroke();
      
      // Draw a line segment for the trail
      triangle(this.x, this.y, prevX + (this.vx/2), prevY + (this.vy/2), 
               prevX + (this.vx/4), prevY + (this.vy/4));
    }
  }
}

function draw() {
  // Create fade effect for trails
  background(10, trailFade);
  
  hueOffset = lerp(hueOffset, noise(frameCount * 0.05) * 60 - 30, 0.02);
  
  // Draw particles with feedback loop
  for (let p of particles) {
    p.update();
    p.draw();
    
    // Occasional geometric burst based on position noise
    if (noise(p.x * 0.01, p.y * 0.01, frameCount * 0.02) > 0.95 && random() < 0.3) {
      drawGeometryBurst(p.x + noise(0), p.y + noise(0));
    }
  }
}

function drawGeometryBurst(cx, cy) {
  push();
  translate(cx, cy);
  
  let numShapes = floor(random(4, 8));
  for (let i = 0; i < numShapes; i++) {
    let angle = map(i, 0, numShapes, 0, TWO_PI * 1.5) + noise(i * 3);
    let dist = random(20, 60);
    
    rotate(angle);
    
    // Draw geometric shapes radiating from center
    fill(255, 80, 120);
    noStroke();
    beginShape();
    for (let j = 0; j <= 4; j++) {
      let r = dist * map(j, 0, 4, 0.2, 1) + noise(frameCount * 0.5 + i);
      vertex(r * cos(j * PI / 2), r * sin(j * PI / 2));
    }
    endShape(CLOSE);
    
    // Draw connecting lines for geometric feel
    stroke(255, 100, 60);
    strokeWeight(1);
    line(-dist/2, -dist/4, dist/2, dist/4);
    line(dist/2, -dist/4, -dist/2, dist/4);
  }
  
  pop();
}

// Initial random offset for color variation
let noiseOffset = map(noise(0), 0, 1, -50, 50);