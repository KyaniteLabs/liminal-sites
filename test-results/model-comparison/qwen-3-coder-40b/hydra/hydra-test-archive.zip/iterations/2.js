let t = 0;
let shapes = [];

function setup() {
  createCanvas(windowWidth, windowHeight);
  background(10);
}

function draw() {
  // Fade effect for trails
  fill(0, 30);
  rect(0, 0, width, height);

  t += 0.02;

  // Create new shapes periodically
  if (frameCount % 5 === 0) {
    let hue = (t * 20 + frameCount * 10) % 360;
    shapes.push(new Shape(hue));
  }

  // Update and draw shapes
  for (let i = shapes.length - 1; i >= 0; i--) {
    shapes[i].update();
    shapes[i].draw();
    
    if (shapes[i].isDead()) {
      shapes.splice(i, 1);
    }
  }
}

class Shape {
  constructor(hue) {
    this.x = random(width * 0.2, width * 0.8);
    this.y = random(height * 0.2, height * 0.8);
    this.size = random(20, 60);
    this.hue = hue;
    this.life = 1.0;
    this.rotation = random(0, TWO_PI);
    this.rotSpeed = random(-0.05, 0.05);
    this.shapeType = random() > 0.5 ? 'circle' : 'square';
    
    // Random velocity
    this.vx = random(-3, 3);
    this.vy = random(-3, 3);
  }
  
  update() {
    this.x += this.vx;
    this.y += this.vy;
    this.rotation += this.rotSpeed;
    this.life -= 0.015;
    
    // Bounce from edges
    if (this.x < 0 || this.x > width) this.vx *= -1;
    if (this.y < 0 || this.y > height) this.vy *= -1;
    
    // Clamp position to keep within canvas
    this.x = constrain(this.x, 0, width);
    this.y = constrain(this.y, 0, height);
  }
  
  draw() {
    push();
    translate(this.x, this.y);
    rotate(this.rotation);
    
    colorMode(HSB);
    let alpha = map(this.life, 0, 1, 0, 255);
    fill(this.hue, 200, 200, alpha);
    noStroke();
    
    if (this.shapeType === 'circle') {
      ellipse(0, 0, this.size * this.life);
    } else {
      rectMode(CENTER);
      rect(0, 0, this.size * this.life, this.size * this.life);
    }
    
    // Draw secondary geometric elements
    if (this.shapeType === 'circle') {
      stroke(this.hue + 180, 200, 200, alpha * 0.7);
      noFill();
      strokeWeight(2);
      ellipse(0, 0, this.size * 0.6 * this.life);
    } else {
      stroke(this.hue + 180, 200, 200, alpha * 0.7);
      noFill();
      strokeWeight(2);
      rectMode(CENTER);
      rect(0, 0, this.size * 0.6 * this.life, this.size * 0.6 * this.life);
    }
    
    pop();
  }
  
  isDead() {
    return this.life <= 0;
  }
}