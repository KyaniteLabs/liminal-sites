const particleSize = 5;
let particles = [];
let hueOffset = 0;
let angleOffset = 0;
let speedMultiplier = 2.5;

function setup() {
  createCanvas(800, 600);
  pixelDensity(1);
  
  noiseSeed(42976);
  
  for (let i = 0; i < 450; i++) {
    particles.push(new Particle());
  }
}

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
  background(0);
}

function draw() {
  hueOffset += 1.2;
  angleOffset += speedMultiplier * 0.05;
  
  // Draw semi-transparent background for trails
  blendMode(BLEND);
  noStroke();
  fill(0, 18);
  rect(0, 0, width, height);
  
  // Update and draw particles
  for (let p of particles) {
    p.update(angleOffset);
    p.draw(hueOffset);
    
    if (p.age > 30) {
      p.reset();
    }
  }
}

class Particle {
  constructor() {
    this.init();
  }
  
  init() {
    // Random position across canvas
    this.x = random(width);
    this.y = random(height);
    
    // Calculate angle from center for radial flow
    let cx = width / 2;
    let cy = height / 2;
    let dx = this.x - cx;
    let dy = this.y - cy;
    this.angle = atan2(dy, dx) + random(-0.5, 0.5);
    
    // Speed varies by distance from center using noise for smoothness
    let dist = sqrt(dx * dx + dy * dy);
    let normalizedDist = map(dist, 0, max(width, height), 0.1, 2.0);
    this.speed = lerp(0.5, 3.5, normalizedDist) + noise(this.x * 0.01, this.y * 0.01, frameCount * 0.1) * 0.8;
    
    // Shape type: 0=circle, 1=square, 2=triangle, 3=diamond
    let shapeType = int(noise(this.x * 0.02, this.y * 0.02) * 4);
    this.shapeType = shapeType;
    
    // Size variation based on position noise
    this.size = map(noise(this.x * 0.015, frameCount * 0.03), 0, 1, particleSize * 0.3, particleSize * 2);
    this.age = random(10, 40);
    
    // Color variation - some particles are brighter than others
    let brightnessFactor = noise(this.x * 0.05, this.y * 0.05) * 0.8 + 0.6;
    this.brightness = map(brightnessFactor, 0, 1, 50, 255);
  }
  
  update(angleOffset) {
    // Move particle in radial direction with added noise perturbation
    let flowNoise = noise(this.x * 0.01 + frameCount * 0.05, this.y * 0.01 - angleOffset * 0.02);
    
    this.x += cos(angleOffset + this.angle) * this.speed * (1 + flowNoise * 0.3);
    this.y += sin(angleOffset + this.angle) * this.speed * (1 + flowNoise * 0.3);
    
    // Add some spiral effect based on angle offset
    let spiralStrength = 0.1;
    this.x += -sin(angleOffset * spiralStrength) * this.speed * 0.2;
    this.y += cos(angleOffset * spiralStrength) * this.speed * 0.2;
    
    // Keep particles within bounds with wraparound or bounce (using noise for soft edges)
    let edgeNoise = noise(this.x / width, this.y / height);
    
    if (this.x < -50 || this.x > width + 50) {
      this.x = random(width * 0.2, width * 0.8);
      this.angle += random(-PI, PI);
    }
    if (this.y < -50 || this.y > height + 50) {
      this.y = random(height * 0.2, height * 0.8);
      this.angle += random(-PI, PI);
    }
    
    // Slowly increase age as particle moves
    if (this.age < 35) {
      this.age++;
    } else if (this.age >= 40 && random() > 0.95) {
      // Random chance to reset early for variety
      return;
    }
  }
  
  draw(hue) {
    let h = hue + sin(this.x * 0.01 + this.y * 0.01) * 30 - 180;
    let s = map(noise(this.age, frameCount), 0, 1, 70, 95);
    
    push();
    translate(this.x, this.y);
    
    if (this.shapeType === 0) {
      // Circle
      noStroke();
      fill(h, s, this.brightness);
      ellipse(0, 0, this.size);
    } else if (this.shapeType === 1) {
      // Square
      noStroke();
      fill(h, s, this.brightness, 200);
      rectMode(CENTER);
      square(0, 0, this.size * 1.5);
    } else if (this.shapeType === 2) {
      // Triangle
      push();
      rotate(frameCount * 0.05);
      noStroke();
      fill(h, s, this.brightness, 220);
      beginShape(TRIANGLE_FAN);
      vertex(0, -this.size / 1.8);
      vertex(this.size / 3, this.size / 2);
      vertex(-this.size / 3, this.size / 2);
      endShape(CLOSE);
      pop();
    } else {
      // Diamond/Rhombus
      noStroke();
      fill(h, s, this.brightness, 180);
      beginShape();
      vertex(0, -this.size / 1.4);
      vertex(this.size / 2, 0);
      vertex(0, this.size / 1.4);
      vertex(-this.size / 2, 0);
      endShape(CLOSE);
    }
    
    pop();
  }
}