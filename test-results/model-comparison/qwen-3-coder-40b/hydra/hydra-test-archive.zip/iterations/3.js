const particleSize = 8;
let particles = [];
let hueOffset = 0;
let angleOffset = 0;
let speedMultiplier = 2.5;

function setup() {
  createCanvas(800, 600);
  pixelDensity(1);
  
  noiseSeed(42976);
  
  for (let i = 0; i < 300; i++) {
    particles.push(new Particle());
  }
}

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
  background(10);
}

class Particle {
  constructor() {
    this.init();
  }

  init() {
    let x = random(width);
    let y = random(height);
    
    // Use noise for smooth initial velocity distribution
    let angle = map(noise(x * 0.01, y * 0.01), 0, 1, -PI, PI);
    let speed = map(noise(x * 0.02 + frameCount * 0.05), 0, 1, 1, 4) * speedMultiplier;
    
    this.x = x;
    this.y = y;
    this.vx = cos(angle) * speed;
    this.vy = sin(angle) * speed;
    this.size = random(particleSize / 2, particleSize + 2);
    this.history = [];
    this.maxHistory = floor(random(15, 40));
    
    // Color variation based on noise position
    let baseHue = map(noise(x * 0.01), 0, 1, 0, 360);
    this.hueOffset = baseHue;
  }

  update() {
    // Apply subtle friction using smoothed noise value
    let friction = 1 - (noise(angleOffset + this.y * 0.02) * 0.05);
    
    this.vx *= friction;
    this.vy *= friction;
    
    // Add constant push from noise flow field
    let flowX = noise(this.x * 0.01, this.y * 0.01 + frameCount * 0.02) * 0.5;
    let flowY = noise(this.x * 0.01 + frameCount * 0.03, this.y * 0.01) * 0.5;
    
    this.vx += flowX;
    this.vy += flowY;
    
    // Increase speed slightly over time
    if (frameCount % 60 === 0 && frameCount > 100) {
      speedMultiplier *= 1.02;
    }

    this.x += this.vx;
    this.y += this.vy;
    
    // Wrap around screen edges
    if (this.x < -50) this.x = width + 50;
    else if (this.x > width + 50) this.x = -50;
    if (this.y < -50) this.y = height + 50;
    else if (this.y > height + 50) this.y = -50;

    // Update history for trails
    this.history.push({ x: this.x, y: this.y });
    if (this.history.length > this.maxHistory) {
      this.history.shift();
    }
    
    // Color shifts with time and position noise
    let currentHue = map(noise(this.x * 0.01 + frameCount * 0.05), 0, 1, 0, 360);
    return color(currentHue + this.hueOffset, 200, 60);
  }

  draw() {
    let c = this.update();
    
    // Draw trail
    for (let i = 0; i < this.history.length - 1; i++) {
      let point = this.history[i];
      let nextPoint = this.history[i + 1];
      
      let dist = dist(point.x, point.y, nextPoint.x, nextPoint.y);
      let opacity = map(i / this.maxHistory, 0, 1, 0.2, 0.8);
      
      noStroke();
      fill(c);
      alpha(opacity * 255);
      
      // Draw geometric shape instead of circle - use triangle or rect based on index
      if (i % 3 === 0) {
        push();
        translate(point.x, point.y);
        rotate(frameCount * 0.1 + i);
        fill(c);
        noStroke();
        beginShape(TRIANGLE);
        vertex(0, -this.size / 2);
        vertex(-this.size / 3, this.size / 4);
        vertex(this.size / 3, this.size / 4);
        endShape(CLOSE);
        pop();
      } else if (i % 3 === 1) {
        push();
        translate(point.x, point.y);
        rotate(frameCount * 0.2 + i * 2);
        fill(c);
        noStroke();
        rectMode(CENTER);
        beginShape();
        vertex(this.size/4, this.size/4);
        vertex(-this.size/3, -this.size/3);
        endShape(CLOSE);
        pop();
      } else {
        push();
        translate(point.x, point.y);
        rotate(frameCount * 0.15 + i * 1.5);
        fill(c);
        noStroke();
        rectMode(CENTER);
        beginShape();
        vertex(-this.size/2, -this.size/4);
        vertex(this.size/4, this.size/2);
        endShape(CLOSE);
        pop();
      }
    }
  }
}

function draw() {
  hueOffset += 1.5;
  angleOffset += speedMultiplier * 0.08;
  
  // Draw semi-transparent background for trails effect
  blendMode(ADD);
  noStroke();
  fill(20, 30);
  rect(0, 0, width, height);
  blendMode(BLEND);
  
  for (let p of particles) {
    p.draw();
  }
}