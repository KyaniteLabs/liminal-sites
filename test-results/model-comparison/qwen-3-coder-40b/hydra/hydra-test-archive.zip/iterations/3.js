let t = 0;
let shapes = [];
let hueOffset = 0;

function setup() {
  createCanvas(windowWidth, windowHeight);
  background(10);
}

function draw() {
  // Fade effect for trails with dynamic opacity
  let fadeAlpha = map(sin(t * 0.5), -1, 1, 30, 70);
  fill(0, fadeAlpha);
  rect(0, 0, width, height);

  t += 0.02;
  hueOffset = (hueOffset + 0.5) % 360;

  // Create new shapes with varied geometric types
  if (frameCount % 3 === 0) {
    let x = random(width * 0.2, width * 0.8);
    let y = random(height * 0.2, height * 0.8);
    let size = random(10, 40);
    let type = floor(random(3)); // 0: circle, 1: square, 2: triangle
    shapes.push(new Shape(x, y, size, type));
  }

  // Update and draw shapes
  for (let i = shapes.length - 1; i >= 0; i--) {
    let shape = shapes[i];
    shape.update();
    shape.draw();

    if (shape.life <= 0) {
      shapes.splice(i, 1);
    }
  }

  // Add rotating geometric guide lines
  stroke(255, 30);
  strokeWeight(1);
  push();
  translate(width / 2, height / 2);
  rotate(t);
  for (let i = 0; i < 6; i++) {
    let angle = map(i, 0, 5, 0, TWO_PI);
    let x = cos(angle + t * 0.3) * min(width, height) * 0.3;
    let y = sin(angle + t * 0.3) * min(width, height) * 0.3;
    point(x, y);
    line(0, 0, x, y);
  }
  pop();
}

class Shape {
  constructor(x, y, size, type) {
    this.x = x;
    this.y = y;
    this.size = size;
    this.type = type; // 0: circle, 1: square, 2: triangle
    this.vx = random(-3, 3);
    this.vy = random(-3, 3);
    this.life = 255;
    this.hue = (hueOffset + random(0, 60)) % 360;
    this.rotation = 0;
    this.rotSpeed = random(-0.1, 0.1);
  }

  update() {
    this.x += this.vx;
    this.y += this.vy;
    this.life -= 4;
    this.rotation += this.rotSpeed;

    // Bounce from edges
    if (this.x < 0 || this.x > width) this.vx *= -1;
    if (this.y < 0 || this.y > height) this.vy *= -1;

    // Keep within bounds
    this.x = constrain(this.x, 0, width);
    this.y = constrain(this.y, 0, height);
  }

  draw() {
    push();
    translate(this.x, this.y);
    rotate(this.rotation);

    let alpha = map(this.life, 0, 255, 0, 1);
    colorMode(HSB);
    fill(this.hue, 80, 80, alpha);
    stroke(255, alpha * 0.5);
    strokeWeight(2);

    if (this.type === 0) {
      // Circle
      circle(0, 0, this.size);
    } else if (this.type === 1) {
      // Square
      rect(-this.size/2, -this.size/2, this.size, this.size);
    } else {
      // Triangle
      triangle(
        0, -this.size/2,
        -this.size/2, this.size/2,
        this.size/2, this.size/2
      );
    }

    pop();
  }
}