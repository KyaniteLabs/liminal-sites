let t = 0;

function setup() {
  createCanvas(windowWidth, windowHeight);
  pixelDensity(1);
}

function draw() {
  background(0);
  loadPixels();
  
  const w = width;
  const h = height;
  const d = pixelDensity();
  const w_d = w * d;
  const h_d = h * d;
  
  t += 0.02;
  
  for (let y = 0; y < h_d; y++) {
    for (let x = 0; x < w_d; x++) {
      const i = (x + y * w_d) * 4;
      
      // Create swirling motion
      const dx = x - w_d / 2;
      const dy = y - h_d / 2;
      const dist = Math.sqrt(dx * dx + dy * dy);
      const angle = Math.atan2(dy, dx) + t * 0.5;
      
      // Create interference patterns with multiple sine waves
      const val1 = sin(dist * 0.03 - t * 2);
      const val2 = cos(angle * 3 + dist * 0.02 + t);
      const val3 = sin(x * 0.01 + y * 0.01 + t);
      
      // Combine patterns for complex plasma effect
      let colorVal = (val1 + val2 + val3) / 3;
      
      // Create smooth color cycling using HSB-like approach
      const r = int(128 + 127 * sin(colorVal + t));
      const g = int(128 + 127 * sin(colorVal + t + TWO_PI / 3));
      const b = int(128 + 127 * sin(colorVal + t + TWO_PI * 2/3));
      
      pixels[i] = r;
      pixels[i + 1] = g;
      pixels[i + 2] = b;
      pixels[i + 3] = 255;
    }
  }
  
  updatePixels();
}