let particles = [];
const particleCount = 400;
let timeOffset = 0;

function setup() {
  createCanvas(windowWidth, windowHeight);
  pixelDensity(1);
  colorMode(HSB, 360, 100, 100, 1);
  
  for (let i = 0; i < particleCount; i++) {
    particles.push({
      x: random(width),
      y: random(height),
      vx: random(-2, 2),
      vy: random(-2, 2),
      size: random(3, 8),
      hueOffset: random(360)
    });
  }
}

function draw() {
  background(15, 15, 20);
  
  // Create plasma effect using noise field
  let time = frameCount * 0.02;
  
  for (let i = 0; i < particles.length; i++) {
    let p = particles[i];
    
    // Calculate noise-based flow field
    let angle = noise(p.x * 0.01, p.y * 0.01, time) * PI * 4;
    let speed = map(noise(p.x * 0.01, p.y * 0.01, time + 100), 0, 1, 2, 6);
    
    // Update particle position
    p.vx += cos(angle) * 0.2;
    p.vy += sin(angle) * 0.2;
    p.x += p.vx * speed * 0.5 + random(-1, 1);
    p.y += p.vy * speed * 0.5 + random(-1, 1);
    
    // Apply damping
    p.vx *= 0.95;
    p.vy *= 0.95;
    
    // Wrap around screen
    if (p.x < 0) p.x = width;
    if (p.x > width) p.x = 0;
    if (p.y < 0) p.y = height;
    if (p.y > height) p.y = 0;
    
    // Calculate dynamic color based on position and time
    let baseHue = (frameCount * 2 + noise(p.x * 0.01, p.y * 0.01, time) * 360 + p.hueOffset) % 360;
    let saturation = map(noise(p.x * 0.01, p.y * 0.01, time + 50), 0, 1, 80, 100);
    let brightness = map(noise(p.x * 0.01, p.y * 0.01, time + 200), 0, 1, 70, 100);
    
    // Add glow effect
    blendMode(ADD);
    fill(baseHue, saturation, brightness, 0.3);
    noStroke();
    
    // Draw particle with varying size based on noise
    let drawSize = p.size * (1 + noise(p.x * 0.02, p.y * 0.02, time) * 2);
    circle(p.x, p.y, drawSize);
    
    blendMode(BLEND);
  }
  
  // Add subtle gradient overlay
  let gradientAlpha = map(sin(frameCount * 0.01), -1, 1, 0.1, 0.3);
  fill(255, 0, 0, gradientAlpha * 10); // Red tint
  rect(0, 0, width, height);
  
  fill(0, 255, 0, gradientAlpha * 10); // Green tint
  rect(width/4, height/4, width/2, height/2);
  
  fill(0, 0, 255, gradientAlpha * 10); // Blue tint
  blendMode(ADD);
  rect(0, 0, width/3, height/3);
  blendMode(BLEND);
}

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
}