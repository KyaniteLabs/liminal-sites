let t = 0;

function setup() {
  createCanvas(windowWidth, windowHeight);
  noStroke();
}

function draw() {
  background(0);
  
  // Create plasma effect with noise and color cycling
  for (let y = 0; y < height; y += 4) {
    for (let x = 0; x < width; x += 4) {
      // Calculate noise values for plasma effect
      let noiseX = noise(x * 0.01 + t, y * 0.01);
      let noiseY = noise(x * 0.01, y * 0.01 + t);
      let combinedNoise = (noiseX + noiseY) / 2;
      
      // Create complex interference pattern
      let plasma = sin(x * 0.02 + t) + 
                   cos(y * 0.02 + t) + 
                   sin((x + y) * 0.015 + t * 0.8) + 
                   noiseX;
      
      // Map to hue for color cycling
      let hue = (plasma * 30 + t * 50) % 360;
      fill(hue, 90, 90);
      
      rect(x, y, 4, 4);
    }
  }
  
  t += 0.02;
}