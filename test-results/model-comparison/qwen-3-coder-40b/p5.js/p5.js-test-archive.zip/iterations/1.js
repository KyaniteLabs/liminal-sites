import React from 'react';
import {useCurrentFrame, interpolate, spring, AbsoluteFill} from 'remotion';

export const BlueCircleAnimation: React.FC = () => {
  const frame = useCurrentFrame();
  
  // Spring animation for scale (0 to 1.5, then back to 1)
  const scale = spring({
    frame,
    fps: 30,
    config: {damping: 20, stiffness: 400}
  });
  
  // Linear movement from left to right
  const xPosition = interpolate(frame, [0, 150], [-400, 400]);
  
  // Opacity fade in/out at start and end
  const opacity = interpolate(frame, [0, 20, 130, 150], [0, 1, 1, 0]);

  return (
    <AbsoluteFill style={{backgroundColor: '#1a1a1a'}}>
      <div
        style={{
          position: 'absolute',
          top: '50%',
          left: '50%',
          transform: `translate(${xPosition}px, -50%) scale(${scale})`,
          width: 200,
          height: 200,
          borderRadius: '50%',
          backgroundColor: '#3b82e6',
          opacity,
          boxShadow: '0 10px 30px rgba(59, 130, 230, 0.4)'
        }}
      />
    </AbsoluteFill>
  );
};