import React from 'react';
import {useCurrentFrame, interpolate, AbsoluteFill, spring} from 'remotion';

export const BlueCircleAnimation: React.FC = () => {
  const frame = useCurrentFrame();
  
  // Animation parameters
  const fps = 30;
  const durationInFrames = 150;
  
  // Scale animation using spring physics
  const scale = spring({
    frame,
    fps,
    config: {m: 1, b: 10, k: 100, damping: 0.8},
    stiffness: 20,
    damping: 15,
    restDelta: 0.001
  });
  
  // Opacity fade in/out
  const opacity = interpolate(frame, [0, 30, 120, 150], [0, 1, 1, 0]);
  
  // Position animation (move from left to center)
  const translateX = interpolate(frame, [0, 60], [-800, 0]);
  const translateY = interpolate(frame, [0, 45, 105, 150], [300, 0, 0, -300]);
  
  // Rotation animation
  const rotation = interpolate(frame, [0, 90], [0, 720]);

  return (
    <AbsoluteFill style={{backgroundColor: '#1a1a2e'}}>
      <div
        style={{
          width: 300,
          height: 300,
          borderRadius: '50%',
          backgroundColor: '#4da8b6',
          position: 'absolute',
          top: '50%',
          left: '50%',
          transform: `translate(-50%, -50%) translate(${translateX}px, ${translateY}px) scale(${scale}) rotate(${rotation}deg)`,
          opacity,
          boxShadow: '0 20px 60px rgba(77, 168, 182, 0.4)'
        }}
      />
    </AbsoluteFill>
  );
};