import React from 'react';
import {useCurrentFrame, interpolate, AbsoluteFill, spring} from 'remotion';

export const SimpleBlueCircle: React.FC = () => {
  const frame = useCurrentFrame();
  
  // Define the center of the screen
  const centerX = 960;
  const centerY = 540;
  const baseRadius = 100;
  
  // Create a scaling animation using spring for smooth oscillation
  const scale = spring({
    frame,
    fps: 30,
    config: {damping: 20, stiffness: 300}
  });
  
  // Calculate the radius with animation
  const animatedRadius = baseRadius * (1 + 0.5 * scale);
  
  // Create a color interpolation that fades between blue shades
  const opacity = interpolate(frame % 60, [0, 30], [0.8, 1]);
  
  return (
    <AbsoluteFill style={{backgroundColor: '#1a2a40'}}>
      <div 
        style={{
          position: 'absolute',
          left: centerX - animatedRadius,
          top: centerY - animatedRadius,
          width: animatedRadius * 2,
          height: animatedRadius * 2,
          backgroundColor: `rgba(65, 130, 255, ${opacity})`,
          borderRadius: '50%',
        }}
      />
    </AbsoluteFill>
  );
};