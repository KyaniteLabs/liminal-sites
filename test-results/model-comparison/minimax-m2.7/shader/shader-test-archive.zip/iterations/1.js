let time = 0;

function setup() {
  createCanvas(800, 600);
  pixelDensity(1);
  colorMode(HSB, 360, 100, 100);
}

function draw() {
  loadPixels();
  
  for (let x = 0; x < width; x++) {
    for (let y = 0; y < height; y++) {
      let nx = x / width;
      let ny = y / height;
      
      let n1 = noise(nx * 4 + time * 0.6, ny * 4, time * 0.4);
      let n2 = noise(nx * 6 - time * 0.5, ny * 6 + time * 0.3, time * 0.5);
      let n3 = noise(nx * 2 + time * 0.2, ny * 2 - time * 0.2, time * 0.6);
      let n4 = noise(nx * 8, ny * 8, time * 0.3);
      
      let plasma = (n1 * 0.4 + n2 * 0.3 + n3 * 0.2 + n4 * 0.1);
      
      let hue = (plasma * 360 + time * 30) % 360;
      let saturation = 85 + n2 * 15;
      let brightness = 55 + n1 * 45;
      
      let c = hsbToRgb(hue, saturation, brightness);
      
      let idx = (x + y * width) * 4;
      pixels[idx] = c.r;
      pixels[idx + 1] = c.g;
      pixels[idx + 2] = c.b;
      pixels[idx + 3] = 255;
    }
  }
  
  updatePixels();
  time += 0.015;
}

function hsbToRgb(h, s, b) {
  h = h % 360;
  s = s / 100;
  b = b / 100;
  
  let c = b * s;
  let x = c * (1 - Math.abs((h / 60) % 2 - 1));
  let m = b - c;
  
  let r, g, bl;
  
  if (h < 60) { r = c; g = x; bl = 0; }
  else if (h < 120) { r = x; g = c; bl = 0; }
  else if (h < 180) { r = 0; g = c; bl = x; }
  else if (h < 240) { r = 0; g = x; bl = c; }
  else if (h < 300) { r = x; g = 0; bl = c; }
  else { r = c; g = 0; bl = x; }
  
  return {
    r: Math.round((r + m) * 255),
    g: Math.round((g + m) * 255),
    b: Math.round((bl + m) * 255)
  };
}

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
}