let t = 0;

function setup() {
  createCanvas(800, 600);
  pixelDensity(1);
  colorMode(HSB, 360, 100, 100, 100);
  noStroke();
}

function draw() {
  background(0, 0, 0, 30);
  
  loadPixels();
  for (let x = 0; x < width; x += 4) {
    for (let y = 0; y < height; y += 4) {
      let size = 4;
      
      let n1 = noise(x * 0.005, y * 0.005, t * 0.5);
      let n2 = noise(x * 0.01 + 100, y * 0.01 + 100, t * 0.3);
      let n3 = noise(x * 0.003 - 200, y * 0.003 - 200, t * 0.7);
      
      let plasma = sin(x * 0.02 + t * 2) + sin(y * 0.02 + t * 1.5) + sin((x + y) * 0.01 + t);
      plasma = (plasma + 3) / 6;
      
      let combined = (n1 * 0.3 + n2 * 0.2 + n3 * 0.2 + plasma * 0.3);
      
      let hue = (combined * 360 + t * 50) % 360;
      let brightness = map(combined, 0, 1, 40, 100);
      let saturation = map(combined, 0, 1, 80, 100);
      
      fill(hue, saturation, brightness);
      rect(x, y, size, size);
    }
  }
  
  t += 0.02;
}

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
}