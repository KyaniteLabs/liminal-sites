let time = 0;
let cols, rows;
let resolution = 20;
let particles = [];

function setup() {
  createCanvas(windowWidth, windowHeight);
  pixelDensity(1);
  colorMode(HSB, 360, 100, 100, 100);
  cols = floor(width / resolution);
  rows = floor(height / resolution);
  noiseSeed(random(10000));
  
  for (let i = 0; i < 150; i++) {
    particles.push({
      x: random(width),
      y: random(height),
      vx: 0,
      vy: 0,
      hue: random(360)
    });
  }
}

function draw() {
  background(0, 0, 0, 30);
  
  time += 0.008;
  
  for (let p of particles) {
    let angle = noise(p.x * 0.003, p.y * 0.003, time) * TWO_PI * 2;
    let speed = noise(p.x * 0.005 + 100, p.y * 0.005 + 100, time + 50) * 2;
    
    p.vx = cos(angle) * speed;
    p.vy = sin(angle) * speed;
    
    p.x += p.vx;
    p.y += p.vy;
    
    p.hue = (p.hue + 0.3) % 360;
    
    if (p.x < 0) p.x = width;
    if (p.x > width) p.x = 0;
    if (p.y < 0) p.y = height;
    if (p.y > height) p.y = 0;
    
    for (let i = 0; i < 3; i++) {
      let glowSize = 30 + i * 15;
      let alpha = map(i, 0, 3, 80, 10);
      fill(p.hue, 100, 100, alpha);
      noStroke();
      ellipse(p.x, p.y, glowSize, glowSize);
    }
  }
  
  for (let i = 0; i < particles.length; i++) {
    for (let j = i + 1; j < particles.length; j++) {
      let d = dist(particles[i].x, particles[i].y, particles[j].x, particles[j].y);
      if (d < 80) {
        let alpha = map(d, 0, 80, 60, 0);
        stroke((particles[i].hue + particles[j].hue) / 2, 90, 100, alpha);
        strokeWeight(map(d, 0, 80, 2, 0.5));
        line(particles[i].x, particles[i].y, particles[j].x, particles[j].y);
      }
    }
  }
  
  for (let x = 0; x < cols; x++) {
    for (let y = 0; y < rows; y++) {
      let px = x * resolution;
      let py = y * resolution;
      
      let n = noise(x * 0.04 + time, y * 0.04 + time * 0.5);
      let n2 = noise(x * 0.06 + time * 1.5, y * 0.06 - time);
      
      let plasmaHue = (n * 180 + n2 * 180 + time * 50) % 360;
      
      noStroke();
      fill(plasmaHue, 80, 60, 15);
      rect(px, py, resolution, resolution);
    }
  }
}

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
  cols = floor(width / resolution);
  rows = floor(height / resolution);
}