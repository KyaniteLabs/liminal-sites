let beatTime = 0;
let lastBeatTime = 0;
let beatInterval = 60 / 130;
let isKick = true;
let mousePressed = false;

function setup() {
  createCanvas(800, 600);
  pixelDensity(1);
  colorMode(HSB, 360, 100, 100);
  noiseSeed(millis());
}

function draw() {
  background(0, 0, 5);
  
  let currentTime = millis() / 1000;
  beatTime += deltaTime / 1000;
  
  if (beatTime >= beatInterval) {
    beatTime -= beatInterval;
    isKick = !isKick;
  }
  
  let beatPhase = beatTime / beatInterval;
  let kickIntensity = pow(1 - beatPhase, 3);
  let hihatIntensity = sin(beatPhase * PI) * 0.5;
  
  translate(width / 2, height / 2);
  
  for (let i = 0; i < 8; i++) {
    let angle = TWO_PI / 8 * i + currentTime * 0.3;
    let baseRadius = 100 + noise(i * 0.5, currentTime * 0.2) * 100;
    
    if (isKick) {
      baseRadius += kickIntensity * 150;
    }
    
    let x = cos(angle) * baseRadius;
    let y = sin(angle) * baseRadius;
    
    let hue = (i * 45 + currentTime * 50) % 360;
    let sat = 70 + kickIntensity * 30;
    let bri = 60 + kickIntensity * 40;
    
    fill(hue, sat, bri);
    noStroke();
    
    let size = 30 + kickIntensity * 50 + noise(i, currentTime) * 20;
    ellipse(x, y, size, size);
    
    stroke(hue, 100, 80);
    strokeWeight(2);
    let lineLen = 50 + kickIntensity * 100 + hihatIntensity * 50;
    line(x, y, x + cos(angle) * lineLen, y + sin(angle) * lineLen);
  }
  
  let waveAmp = 50 + kickIntensity * 100;
  stroke(0, 0, 100, 0.5);
  strokeWeight(2);
  noFill();
  beginShape();
  for (let x = -width / 2; x < width / 2; x += 5) {
    let y = sin(x * 0.02 + currentTime * 3) * waveAmp * 0.5;
    y += noise(x * 0.01, currentTime) * waveAmp;
    vertex(x, y);
  }
  endShape();
  
  if (mouseIsPressed || mousePressed) {
    let mx = mouseX - width / 2;
    let my = mouseY - height / 2;
    let d = dist(mx, my, 0, 0);
    
    for (let i = 0; i < 20; i++) {
      let angle = noise(i, currentTime * 2) * TWO_PI;
      let r = noise(i * 0.1, currentTime * 0.5) * d * 0.5;
      let px = cos(angle) * r + mx * 0.3;
      let py = sin(angle) * r + my * 0.3;
      
      fill(200 + sin(currentTime + i) * 30, 80, 100, 0.7);
      noStroke();
      ellipse(px, py, 10 + kickIntensity * 20, 10 + kickIntensity * 20);
    }
  }
  
  let centerPulse = 20 + kickIntensity * 80;
  fill(0, 0, 100, 0.3);
  noStroke();
  ellipse(0, 0, centerPulse, centerPulse);
  
  let rectSize = 600 + kickIntensity * 100;
  stroke(0, 0, 50, 0.2);
  strokeWeight(1);
  noFill();
  rectMode(CENTER);
  rect(0, 0, rectSize, rectSize);
}

function mousePressed() {
  mousePressed = true;
}

function mouseReleased() {
  mousePressed = false;
}

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
}