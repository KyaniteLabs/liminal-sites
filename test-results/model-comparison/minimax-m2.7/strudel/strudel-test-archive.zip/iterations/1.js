$: s("bd:0*4 [bd:0 bd:0 bd:0] bd:0*2").bpm(130)
$: s("~ ~ ~ ~, ~ ~ cl:0 ~").gain(0.75)
$: s("hh:0*8 hh:1*4").gain(0.45)
stack(
  $: s("bd:0*4 [bd:0 bd:0 bd:0] bd:0*2").bpm(130).gain(0.9),
  $: s("~ ~ ~ ~, ~ ~ cl:0 ~").gain(0.75),
  $: s("hh:0*8 hh:1*4").gain(0.4),
  $: note("[c2 c2] [c2 c2] [c2 c2] c2").s("sawtooth").gain(0.35).delay(0.25)