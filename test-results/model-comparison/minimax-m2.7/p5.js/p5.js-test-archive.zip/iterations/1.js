import React from 'react';
import {useCurrentFrame, interpolate, AbsoluteFill, spring} from 'remotion';

export const BlueCircleAnimation: React.FC = () => {
  const frame = useCurrentFrame();

  const scale = interpolate(frame, [0, 30], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });

  const pulse = 1 + Math.sin(frame * 0.1) * 0.1;

  const yOffset = interpolate(frame, [0, 60], [100, 0], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });

  const opacity = interpolate(frame, [0, 20, 130, 150], [0, 1, 1, 0], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });

  return (
    <AbsoluteFill style={{backgroundColor: '#1a1a2e', justifyContent: 'center', alignItems: 'center'}}>
      <div
        style={{
          width: 300 * scale * pulse,
          height: 300 * scale * pulse,
          borderRadius: '50%',
          backgroundColor: '#4a90d9',
          boxShadow: '0 0 60px rgba(74, 144, 217, 0.5)',
          transform: `translateY(${yOffset}px)`,
          opacity: opacity,
        }}
      />
    </AbsoluteFill>
  );
};