import React from 'react';
import {useCurrentFrame, interpolate, AbsoluteFill, spring} from 'remotion';

export const BlueCircleAnimation: React.FC = () => {
  const frame = useCurrentFrame();

  const scale = interpolate(frame, [0, 60, 120, 150], [0, 1.2, 0.8, 0], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });

  const opacity = interpolate(frame, [0, 30, 120, 150], [0, 1, 1, 0], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });

  const yOffset = Math.sin(frame * 0.1) * 30;

  const shadowSpread = interpolate(frame, [0, 75, 150], [5, 20, 5], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });

  return (
    <AbsoluteFill style={{backgroundColor: '#0a0a1a', justifyContent: 'center', alignItems: 'center'}}>
      <div
        style={{
          width: 300,
          height: 300,
          borderRadius: '50%',
          backgroundColor: '#3b82f6',
          transform: `scale(${scale}) translateY(${yOffset}px)`,
          opacity: opacity,
          boxShadow: `0 0 ${shadowSpread * 3}px #60a5fa, 0 0 ${shadowSpread * 6}px #3b82f6`,
        }}
      />
    </AbsoluteFill>
  );
};