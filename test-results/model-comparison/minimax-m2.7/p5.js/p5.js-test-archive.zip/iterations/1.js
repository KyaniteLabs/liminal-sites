import React from 'react';
import {useCurrentFrame, interpolate, AbsoluteFill, spring} from 'remotion';

export const BlueCircleAnimation: React.FC = () => {
  const frame = useCurrentFrame();

  const scale = interpolate(frame, [0, 30, 60, 90, 120, 150], [0, 1.2, 0.8, 1.1, 0.9, 1]);

  const yOffset = interpolate(frame, [0, 75, 150], [-100, 100, -100]);

  const opacity = interpolate(frame, [0, 15, 135, 150], [0, 1, 1, 0]);

  const shadowOpacity = interpolate(frame, [0, 75, 150], [0.2, 0.5, 0.2]);

  return (
    <AbsoluteFill style={{backgroundColor: '#0a0a1a', justifyContent: 'center', alignItems: 'center'}}>
      <div
        style={{
          position: 'absolute',
          top: '50%',
          left: '50%',
          transform: `translate(-50%, calc(-50% + ${yOffset}px)) scale(${scale})`,
          opacity: opacity,
          width: 300,
          height: 300,
          borderRadius: '50%',
          backgroundColor: '#3b82f6',
          boxShadow: `0 0 60px 20px rgba(59, 130, 246, ${shadowOpacity}), 0 0 120px 40px rgba(59, 130, 246, ${shadowOpacity * 0.5})`,
        }}
      />
      <div
        style={{
          position: 'absolute',
          top: '50%',
          left: '50%',
          transform: `translate(-50%, calc(-50% + ${yOffset}px)) scale(${scale * 0.95})`,
          opacity: opacity * 0.3,
          width: 300,
          height: 300,
          borderRadius: '50%',
          backgroundColor: '#60a5fa',
        }}
      />
    </AbsoluteFill>
  );
};