let shapes = [];
let trailCanvas;

function setup() {
  createCanvas(800, 600);
  pixelDensity(1);
  colorMode(HSB, 360, 100, 100, 100);
  
  trailCanvas = createGraphics(800, 600);
  trailCanvas.pixelDensity(1);
  trailCanvas.colorMode(HSB, 360, 100, 100, 100);
  trailCanvas.background(0, 0, 5);
  
  for (let i = 0; i < 12; i++) {
    shapes.push({
      x: random(width),
      y: random(height),
      baseX: random(width),
      baseY: random(height),
      size: random(20, 60),
      noiseOffsetX: random(1000),
      noiseOffsetY: random(1000),
      noiseOffsetAngle: random(1000),
      hue: random(360),
      hueSpeed: random(0.2, 0.5),
      sides: floor(random(3, 8)),
      rotation: 0,
      rotSpeed: random(-0.03, 0.03),
      type: floor(random(4))
    });
  }
}

function draw() {
  trailCanvas.background(0, 0, 5, 15);
  
  for (let i = 0; i < shapes.length; i++) {
    let s = shapes[i];
    
    let noiseX = noise(s.noiseOffsetX + frameCount * 0.005) * 200 - 100;
    let noiseY = noise(s.noiseOffsetY + frameCount * 0.005) * 200 - 100;
    
    s.x = s.baseX + noiseX;
    s.y = s.baseY + noiseY;
    
    s.x = constrain(s.x, s.size, width - s.size);
    s.y = constrain(s.y, s.size, height - s.size);
    
    s.rotation += s.rotSpeed;
    s.hue = (s.hue + s.hueSpeed) % 360;
    
    let alpha = map(noise(s.noiseOffsetAngle + frameCount * 0.01), 0, 1, 40, 80);
    
    trailCanvas.push();
    trailCanvas.translate(s.x, s.y);
    trailCanvas.rotate(s.rotation);
    
    trailCanvas.fill(s.hue, 70, 90, alpha);
    trailCanvas.noStroke();
    
    if (s.type === 0) {
      ellipse(0, 0, s.size * 2);
    } else if (s.type === 1) {
      rectMode(CENTER);
      rect(0, 0, s.size * 1.5, s.size * 1.5);
    } else if (s.type === 2) {
      drawPolygon(0, 0, s.size, s.sides);
    } else {
      drawStar(0, 0, s.size * 0.4, s.size, 5);
    }
    
    trailCanvas.pop();
    
    s.noiseOffsetAngle += 0.002;
  }
  
  image(trailCanvas, 0, 0);
  
  stroke(0, 0, 100, 50);
  strokeWeight(1);
  noFill();
  for (let i = 0; i < shapes.length; i++) {
    let s = shapes[i];
    let nextS = shapes[(i + 1) % shapes.length];
    let connectionAlpha = map(dist(s.x, s.y, nextS.x, nextS.y), 0, 300, 30, 0);
    stroke(0, 0, 100, connectionAlpha);
    line(s.x, s.y, nextS.x, nextS.y);
  }
}

function drawPolygon(x, y, radius, npoints) {
  let angle = TWO_PI / npoints;
  beginShape();
  for (let a = -HALF_PI; a < TWO_PI - HALF_PI; a += angle) {
    let sx = x + cos(a) * radius;
    let sy = y + sin(a) * radius;
    vertex(sx, sy);
  }
  endShape(CLOSE);
}

function drawStar(x, y, radius1, radius2, npoints) {
  let angle = TWO_PI / npoints;
  let halfAngle = angle / 2.0;
  beginShape();
  for (let a = 0; a < TWO_PI; a += angle) {
    let sx = x + cos(a) * radius2;
    let sy = y + sin(a) * radius2;
    vertex(sx, sy);
    sx = x + cos(a + halfAngle) * radius1;
    sy = y + sin(a + halfAngle) * radius1;
    vertex(sx, sy);
  }
  endShape(CLOSE);
}

function windowResized() {
  resizeCanvas(800, 600);
  trailCanvas.resizeCanvas(800, 600);
  trailCanvas.background(0, 0, 5);
}