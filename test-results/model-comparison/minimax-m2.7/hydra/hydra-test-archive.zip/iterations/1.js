let shapes = [];
const numShapes = 40;

function setup() {
  createCanvas(windowWidth, windowHeight);
  pixelDensity(1);
  colorMode(HSB, 360, 100, 100, 1);
  for (let i = 0; i < numShapes; i++) {
    shapes.push({
      x: random(width),
      y: random(height),
      nx: random(1000),
      ny: random(1000),
      size: random(20, 80),
      rot: random(TWO_PI),
      rotSpeed: random(-0.03, 0.03),
      hue: random(360),
      type: floor(random(4)),
      speed: random(0.003, 0.01)
    });
  }
}

function draw() {
  background(0, 0, 15, 0.08);
  for (let s of shapes) {
    s.x += (noise(s.nx) - 0.5) * 4;
    s.y += (noise(s.ny) - 0.5) * 4;
    s.nx += s.speed;
    s.ny += s.speed;
    s.rot += s.rotSpeed;
    s.x = (s.x + width) % width;
    s.y = (s.y + height) % height;
    push();
    translate(s.x, s.y);
    rotate(s.rot);
    fill(s.hue, 70, 90, 0.6);
    noStroke();
    if (s.type === 0) {
      rect(0, 0, s.size, s.size);
    } else if (s.type === 1) {
      triangle(0, -s.size/2, -s.size/2, s.size/2, s.size/2, s.size/2);
    } else if (s.type === 2) {
      ellipse(0, 0, s.size, s.size * 0.6);
    } else {
      beginShape();
      for (let i = 0; i < 6; i++) {
        let angle = TWO_PI / 6 * i;
        vertex(cos(angle) * s.size/2, sin(angle) * s.size/2);
      }
      endShape(CLOSE);
    }
    pop();
  }
}

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
}