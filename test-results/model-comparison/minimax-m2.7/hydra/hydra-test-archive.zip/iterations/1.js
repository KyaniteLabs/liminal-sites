let shapes = [];
let t = 0;

function setup() {
  createCanvas(windowWidth, windowHeight);
  colorMode(HSB, 360, 100, 100, 100);
  for (let i = 0; i < 12; i++) {
    shapes.push({
      x: noise(i * 0.4) * width,
      y: noise(i * 0.4 + 50) * height,
      size: noise(i * 0.3) * 80 + 40,
      sides: floor(noise(i * 0.6) * 5) + 3,
      hue: noise(i * 0.5) * 360,
      phase: noise(i * 2) * 1000
    });
  }
}

function draw() {
  background(0, 0, 8, 18);
  t += 0.008;
  
  for (let s of shapes) {
    let nx = (noise(t + s.phase) - 0.5) * 4;
    let ny = (noise(t + s.phase + 800) - 0.5) * 4;
    s.x = (s.x + nx + width) % width;
    s.y = (s.y + ny + height) % height;
    
    let rot = t * 2 + s.phase;
    let pulse = sin(t * 3 + s.phase) * 0.2 + 1;
    
    push();
    translate(s.x, s.y);
    rotate(rot);
    
    noStroke();
    fill(s.hue, 70, 90, 60);
    
    beginShape();
    for (let i = 0; i < s.sides; i++) {
      let a = TWO_PI / s.sides * i - HALF_PI;
      let r = s.size * pulse * (1 + noise(i * 0.5 + t, s.phase) * 0.3);
      vertex(cos(a) * r, sin(a) * r);
    }
    endShape(CLOSE);
    
    stroke(s.hue, 90, 100, 80);
    strokeWeight(2);
    noFill();
    
    beginShape();
    for (let i = 0; i < s.sides; i++) {
      let a = TWO_PI / s.sides * i - HALF_PI;
      let r = s.size * pulse * 1.1;
      vertex(cos(a) * r, sin(a) * r);
    }
    endShape(CLOSE);
    pop();
    
    s.hue = (s.hue + 0.3) % 360;
  }
}

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
}