let shapes = [];
let trailCanvas;
let trailAlpha = 8;

function setup() {
  createCanvas(800, 600);
  pixelDensity(1);
  colorMode(HSB, 360, 100, 100, 100);
  
  trailCanvas = createGraphics(800, 600);
  trailCanvas.pixelDensity(1);
  trailCanvas.colorMode(HSB, 360, 100, 100, 100);
  trailCanvas.background(0, 0, 3);
  
  for (let i = 0; i < 15; i++) {
    shapes.push({
      x: random(width),
      y: random(height),
      baseX: random(width),
      baseY: random(height),
      size: random(25, 70),
      noiseOffsetX: random(1000),
      noiseOffsetY: random(1000),
      speed: random(0.003, 0.008),
      rotation: random(TWO_PI),
      rotationSpeed: random(-0.03, 0.03),
      hue: random(360),
      hueSpeed: random(0.5, 1.5),
      shapeType: floor(random(5)),
      strokeWeight: random(1.5, 3.5),
      noiseScale: random(0.003, 0.007)
    });
  }
  
  windowResized();
}

function draw() {
  trailCanvas.noStroke();
  trailCanvas.fill(0, 0, 3, trailAlpha);
  trailCanvas.rect(0, 0, width, height);
  
  for (let shape of shapes) {
    let noiseX = noise(shape.noiseOffsetX) * 400 - 200;
    let noiseY = noise(shape.noiseOffsetY) * 400 - 200;
    
    shape.x = shape.baseX + noiseX;
    shape.y = shape.baseY + noiseY;
    
    shape.noiseOffsetX += shape.speed;
    shape.noiseOffsetY += shape.speed;
    
    shape.rotation += shape.rotationSpeed;
    shape.hue = (shape.hue + shape.hueSpeed) % 360;
    
    trailCanvas.push();
    trailCanvas.translate(shape.x, shape.y);
    trailCanvas.rotate(shape.rotation);
    
    let displayHue = (shape.hue + frameCount * 0.3) % 360;
    trailCanvas.stroke(displayHue, 70, 95, 85);
    trailCanvas.strokeWeight(shape.strokeWeight);
    trailCanvas.noFill();
    
    drawShape(shape.shapeType, shape.size);
    
    trailCanvas.pop();
  }
  
  image(trailCanvas, 0, 0);
  
  let currentHue = (frameCount * 2) % 360;
  fill(currentHue, 30, 100, 15);
  noStroke();
  rect(0, 0, width, height);
}

function drawShape(type, size) {
  switch(type) {
    case 0:
      trailCanvas.triangle(0, -size/2, -size/2, size/2, size/2, size/2);
      break;
    case 1:
      trailCanvas.rectMode(CENTER);
      trailCanvas.rect(0, 0, size, size);
      break;
    case 2:
      trailCanvas.ellipse(0, 0, size, size * 0.7);
      break;
    case 3:
      drawHexagon(0, 0, size/2);
      break;
    case 4:
      drawDiamond(0, 0, size);
      break;
  }
}

function drawHexagon(x, y, radius) {
  trailCanvas.beginShape();
  for (let i = 0; i < 6; i++) {
    let angle = TWO_PI / 6 * i - PI / 6;
    trailCanvas.vertex(x + cos(angle) * radius, y + sin(angle) * radius);
  }
  trailCanvas.endShape(CLOSE);
}

function drawDiamond(x, y, size) {
  trailCanvas.beginShape();
  trailCanvas.vertex(x, y - size/2);
  trailCanvas.vertex(x + size/3, y);
  trailCanvas.vertex(x, y + size/2);
  trailCanvas.vertex(x - size/3, y);
  trailCanvas.endShape(CLOSE);
}

function mousePressed() {
  for (let shape of shapes) {
    shape.baseX = mouseX;
    shape.baseY = mouseY;
    shape.noiseOffsetX = random(1000);
    shape.noiseOffsetY = random(1000);
  }
}

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
  trailCanvas.resizeCanvas(windowWidth, windowHeight);
}