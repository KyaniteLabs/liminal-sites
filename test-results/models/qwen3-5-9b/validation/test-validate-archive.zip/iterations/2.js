function setup() {
  createCanvas(windowWidth, windowHeight);
}

function draw() {
  background(10, 20, 40, 50);
  
  let particleCount = 300;
  let particles = [];
  
  for (let i = 0; i < particleCount; i++) {
    particles.push(new Particle());
  }
  
  for (let p of particles) {
    p.update();
    p.show();
    
    // Additive blending for glowing effect
    blendMode(BLEND);
    noStroke();
    fill(255, 150);
    ellipse(p.x, p.y, size());
    resetBlendMode();
  }
}

class Particle {
  constructor() {
    this.reset();
  }
  
  reset() {
    this.pos = createVector(random(width), random(height));
    this.vel = p5.Vector.random2D().mult(random(1, 3));
    this.acc = createVector(0, 0);
    this.size = random(2, 8);
    this.maxSpeed = random(3, 6);
    this.life = random(100, 255);
  }
  
  update() {
    // Mouse interaction: gentle attraction/repulsion based on proximity
    let mouse = createVector(mouseX, mouseY);
    let dist = p5.Vector.dist(this.pos, mouse);
    
    if (dist < 300) {
      let force = p5.Vector.sub(mouse, this.pos).normalize();
      force.mult(1 / (dist * dist)); // Inverse square law for stronger pull near center
      force.limit(0.2);
      this.applyForce(force);
    }
    
    // Perlin noise influence based on position
    let flow = noise(this.pos.x * 0.005, this.pos.y * 0.005) * 2;
    let noiseVel = p5.Vector.fromAngle(PI/2 + flow).mult(0.3);
    this.applyForce(noiseVel);
    
    // Friction to slow down over time
    this.vel.mult(0.98);
    this.pos.add(this.vel);
    
    // Wrap around screen edges
    if (this.pos.x < 0) this.pos.x = width;
    if (this.pos.x > width) this.pos.x = 0;
    if (this.pos.y < 0) this.pos.y = height;
    if (this.pos.y > height) this.pos.y = 0;
    
    // Pulse size based on velocity magnitude
    let speed = this.vel.mag();
    this.size = map(speed, 0, this.maxSpeed * 2, 1, 15);
  }
  
  applyForce(force) {
    force.mult(0.5);
    this.acc.add(force);
  }
  
  show() {
    // Color shift based on position and speed
    let hueVal = map(this.pos.x, 0, width, 180, 360);
    let satVal = map(speed, 0, 20, 50, 100);
    
    stroke(hueVal + sin(frameCount * 0.01) * 20, satVal, 255, this.life);
    strokeWeight(this.size / 3);
    point(this.pos.x, this.pos.y);
  }
}