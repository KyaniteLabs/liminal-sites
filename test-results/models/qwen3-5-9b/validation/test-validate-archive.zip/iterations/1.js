function setup() {
  createCanvas(windowWidth, windowHeight);
}

function draw() {
  background(20);
  
  let particleCount = 400;
  let particles = [];
  
  for (let i = 0; i < particleCount; i++) {
    particles.push(new Particle());
  }
  
  for (let p of particles) {
    p.update();
    p.show();
    
    // Attract to mouse with decreasing force based on distance
    let d = dist(p.x, p.y, mouseX, mouseY);
    if (d < 200) {
      p.vx += (mouseX - p.x) * 0.01;
      p.vy += (mouseY - p.y) * 0.01;
    }
    
    // Bounce off walls
    if (p.x > width || p.x < 0) p.vx *= -1;
    if (p.y > height || p.y < 0) p.vy *= -1;
  }
}

class Particle {
  constructor() {
    this.pos = createVector(random(width), random(height));
    this.vel = p5.Vector.random2D();
    this.vel.mult(random(1, 3));
    this.acc = createVector(0, 0);
    this.size = random(2, 6);
    this.hue = random(180, 280); // Blue/Purple range
  }
  
  update() {
    this.vel.add(this.acc);
    this.pos.add(this.vel);
    this.acc.mult(0);
    
    // Add some turbulence based on time
    this.vel.x += sin(frameCount * 0.02 + this.pos.x) * 0.1;
    this.vel.y += cos(frameCount * 0.03 + this.pos.y) * 0.1;
    
    this.maxSpeed = 4;
    if (this.vel.mag() > this.maxSpeed) {
      this.vel.setMag(this.maxSpeed);
    }
  }
  
  show() {
    strokeWeight(2);
    stroke(this.hue, 50, 100);
    point(this.pos.x, this.pos.y);
    
    // Add a glow effect by drawing a slightly larger circle with lower alpha
    noStroke();
    fill(this.hue, 50, 80, 30);
    ellipse(this.pos.x, this.pos.y, this.size * 2.5);
  }
}

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
}