let particles = [];
let hue = 0;

function setup() {
  createCanvas(800, 600);
  colorMode(HSB, 360, 100, 100);
  noStroke();
}

function draw() {
  background(240);
  
  for (let i = particles.length - 1; i >= 0; i--) {
    let p = particles[i];
    
    if (p.x > width || p.x < 0 || p.y > height || p.y < 0) {
      particles.splice(i, 1);
      continue;
    }
    
    p.move();
    p.show();
    
    if (p.life <= 0) {
      particles.splice(i, 1);
    }
  }
  
  hue = (hue + 2) % 360;
}

class Particle {
  constructor() {
    this.x = random(width);
    this.y = height / 2;
    this.size = random(5, 15);
    this.speedX = random(-1, 1);
    this.speedY = -random(0.5, 3);
    this.life = 255;
    this.hueOffset = random(60);
  }
  
  move() {
    this.x += this.speedX + sin(frameCount * 0.01) * 0.5;
    this.y += this.speedY;
    
    if (this.y < height / 2 - 50) {
      this.speedY *= 0.98;
    }
    
    this.life -= 2;
  }
  
  show() {
    let c = color(hue + this.hueOffset, 80, 100);
    noStroke();
    fill(c);
    ellipse(this.x, this.y, this.size);
    
    if (this.life > 255) this.life = 255;
  }
}

function mousePressed() {
  for (let i = 0; i < 10; i++) {
    particles.push(new Particle());
  }
}