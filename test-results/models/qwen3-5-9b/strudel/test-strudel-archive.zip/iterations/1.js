$: s("bd*4, sd~4").speed(1.05),
  $: s("~ hh ~ hh").every(4, rev).gain(0.6)