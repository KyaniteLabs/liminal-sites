$: s("bd*4").gain(0.9).room(0.4)
$: s("~ sd ~ sd").speed(2).every(4, rev).gain(0.7).room(0.3)
$: s("cp*8").pan([1,-1,1,-1]).delay(0.2).gain(0.5)

stack(
  $: note("c4 e4 g4 c5").s("square").every(32).gain(0.6),