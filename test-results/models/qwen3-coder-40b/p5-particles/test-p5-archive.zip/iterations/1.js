let particles = [];
const trailLength = 20;

function setup() {
  createCanvas(windowWidth, windowHeight);
  background(10);
  for (let i = 0; i < 300; i++) {
    particles.push(new Particle());
  }
}

function draw() {
  fill(10, 5); // semi-transparent background for trails
  rect(0, 0, width, height);

  for (let p of particles) {
    p.update();
    p.show();
  }
}

class Particle {
  constructor() {
    this.x = random(width);
    this.y = random(height);
    this.vx = random(-2, 2);
    this.vy = random(-2, 2);
    this.history = [];
  }

  update() {
    // Store current position in history
    this.history.push({x: this.x, y: this.y});
    if (this.history.length > trailLength) {
      this.history.shift();
    }

    // Update position
    this.x += this.vx;
    this.y += this.vy;

    // Wrap around screen
    if (this.x < 0) this.x = width;
    if (this.x > width) this.x = 0;
    if (this.y < 0) this.y = height;
    if (this.y > height) this.y = 0;

    // Slight random acceleration for interesting motion
    this.vx += random(-0.1, 0.1);
    this.vy += random(-0.1, 0.1);

    // Keep speed not too fast
    let speed = sqrt(this.vx * this.vx + this.vy * this.vy);
    if (speed > 4) {
      this.vx *= 0.9;
      this.vy *= 0.9;
    }
  }

  show() {
    stroke(60, 150, 255, map(this.history.length, 0, trailLength, 30, 200));
    strokeWeight(2);
    
    // Draw trails
    for (let i = 0; i < this.history.length - 1; i++) {
      let pos = this.history[i];
      let alpha = map(i, 0, this.history.length, 0, 150);
      stroke(60, 120, 255, alpha);
      line(pos.x, pos.y, this.x, this.y);
    }

    // Draw particle head
    noStroke();
    fill(80, 200, 255, 200);
    circle(this.x, this.y, 4);
  }
}

function resizeCanvas() {
  resizeCanvas(windowWidth, windowHeight);
}