let particles = [];
const NUM_PARTICLES = 200;

function setup() {
  createCanvas(windowWidth, windowHeight);
  background(0);
}

function draw() {
  // Create trails by drawing a semi-transparent black rectangle over the canvas
  fill(0, 15);
  noStroke();
  rect(0, 0, width, height);

  for (let i = 0; i < particles.length; i++) {
    let p = particles[i];
    p.update();
    p.show();

    // Remove particle if it goes off screen or fades out
    if (p.lifetime <= 0 || p.pos.x < 0 || p.pos.x > width || p.pos.y < 0 || p.pos.y > height) {
      particles.splice(i, 1);
      i--;
    }
  }

  // Add new particles periodically for continuous flow
  if (particles.length < NUM_PARTICLES && random() < 0.3) {
    let pos = createVector(random(width), random(height));
    let vel = p5.Vector.random2D().mult(random(1, 4));
    particles.push(new Particle(pos, vel));
  }
}

class Particle {
  constructor(pos, vel) {
    this.pos = pos.copy();
    this.vel = vel.copy();
    this.lifetime = 255;
    this.size = random(3, 8);
    // Pure blue color: (0, 0, 255)
    this.blueColor = [0, 0, 255];
  }

  update() {
    this.pos.add(this.vel);
    this.lifetime -= 3; // Fade out over time
    this.size *= 0.98; // Shrink slowly
  }

  show() {
    noStroke();
    fill(this.blueColor[0], this.blueColor[1], this.blueColor[2], this.lifetime);
    circle(this.pos.x, this.pos.y, this.size);
  }
}

// Handle window resizing
function resizeCanvas() {
  if (canvas) {
    canvas.remove();
  }
  createCanvas(windowWidth, windowHeight);
  background(0);
}