let particles = [];
const NUM_PARTICLES = 300;

function setup() {
  createCanvas(windowWidth, windowHeight);
  background(10, 20, 40);
}

function draw() {
  // Create trails by drawing a semi-transparent black rectangle over the canvas
  fill(5, 10, 20, 40);
  noStroke();
  rect(0, 0, width, height);

  for (let i = 0; i < particles.length; i++) {
    let p = particles[i];
    p.update();
    p.show();

    // Remove particle if it goes off screen or fades out
    if (p.lifetime <= 0 || p.pos.x < -50 || p.pos.x > width + 50 || 
        p.pos.y < -50 || p.pos.y > height + 50) {
      particles.splice(i, 1);
      i--;
    }
  }

  // Add new particles
  if (particles.length < NUM_PARTICLES) {
    particles.push(new Particle());
  }
}

class Particle {
  constructor() {
    this.pos = createVector(random(width), random(height));
    this.vel = p5.Vector.random2D().mult(random(1, 4));
    this.acc = createVector(0, 0);
    this.lifetime = 255;
    this.size = random(3, 8);
    this.hueValue = map(this.pos.x, 0, width, 190, 220); // Blue range
  }

  update() {
    // Add some wandering motion
    let noiseScale = 0.01;
    let time = frameCount * 0.05;
    let angle = noise(time, this.pos.x * noiseScale, this.pos.y * noiseScale) * TWO_PI * 2;
    this.acc = p5.Vector.fromAngle(angle).mult(0.1);
    
    this.vel.add(this.acc);
    this.pos.add(this.vel);
    this.lifetime -= 3; // Fade out
  }

  show() {
    let alpha = map(this.lifetime, 0, 255, 0, 1);
    colorMode(HSB);
    fill(this.hueValue, 70, 80, alpha);
    noStroke();
    circle(this.pos.x, this.pos.y, this.size);
    
    // Draw a small trail line
    let trailLen = 20;
    stroke(this.hueValue, 60, 90, alpha * 0.5);
    strokeWeight(1);
    line(this.pos.x - this.vel.x * 3, this.pos.y - this.vel.y * 3, 
         this.pos.x, this.pos.y);
  }
}