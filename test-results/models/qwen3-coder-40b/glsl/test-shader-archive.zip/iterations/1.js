precision highp float;
uniform vec2 u_resolution;
uniform float u_time;
uniform vec2 u_mouse;

#define PI 3.14159265358979323846

vec3 palette(float t) {
    vec3 a = vec3(0.5, 0.5, 0.5);
    vec3 b = vec3(0.5, 0.5, 0.5);
    vec3 c = vec3(0.5, 0.5, 0.5);
    vec3 d = vec3(0.263, 0.467, 0.867);
    return a + b * cos(PI * (c + t * d));
}

void main() {
    vec2 uv = (gl_FragCoord.xy - 0.5 * u_resolution.xy) / min(u_resolution.x, u_resolution.y);
    vec2 m = u_mouse / u_resolution;
    float mx = (m.x - 0.5) * u_resolution.x / min(u_resolution.x, u_resolution.y);
    float my = -(m.y - 0.5) * u_resolution.y / min(u_resolution.x, u_resolution.y);

    vec3 col = vec3(0.0);
    float t = u_time * 0.8;

    for (int i = 0; i < 4; i++) {
        float angle = float(i) * PI * 2.0 / 3.0 + t;
        float dist = length(uv - vec2(cos(angle), sin(angle)) * 1.5);
        float wave = sin(dist * 6.0 - t * 2.0) * 0.1;
        float neon = clamp(0.4 / (dist - wave + 0.05), 0.0, 1.0);

        vec3 color = palette(t + float(i) * 0.3);
        col += neon * color;

        // Add secondary wave interference
        float dist2 = length(uv - vec2(mx, my) - vec2(cos(angle * 1.5), sin(angle * 1.5)) * 2.0);
        float wave2 = cos(dist2 * 8.0 + t * 3.0) * 0.1;
        float neon2 = clamp(0.6 / (dist2 - wave2 + 0.07), 0.0, 1.2);
        col += neon2 * color * 0.5;
    }

    // Add radial plasma effect
    float r = length(uv);
    float angle = atan2(uv.y, uv.x) + t;
    float plasma = sin(r * 8.0 - t * 3.0 + sin(angle * 4.0)) * 0.25;
    col += clamp(plasma + 0.7, 0.0, 1.0) * vec3(0.9, 0.6, 0.9);

    // Neon glow accumulation
    float glow = 1.0 / (length(uv) + 0.1);
    col += glow * vec3(0.8, 0.2, 0.9) * 0.3;

    gl_FragColor = vec4(col, 1.0);
}