import React from 'react';
import {useCurrentFrame, interpolate, AbsoluteFill, spring, useVideoConfig} from 'remotion';

const HydraPattern: React.FC<{
  pattern: 'circles' | 'grid' | 'waves' | 'kaleidoscope' | 'noise';
  color1: string;
  color2: string;
  scale: number;
  offset: number;
  blendMode?: string;
}> = ({pattern, color1, color2, scale, offset, blendMode = 'screen'}) => {
  const frame = useCurrentFrame();
  const {width, height} = useVideoConfig();

  const opacity = interpolate(frame, [0, 150], [0.3, 1]);

  const renderPattern = () => {
    switch (pattern) {
      case 'circles':
        return (
          <svg width={width} height={height} style={{position: 'absolute', top: 0, left: 0}}>
            <defs>
              <radialGradient id={`grad-${pattern}`} cx="50%" cy="50%" r="50%">
                <stop offset="0%" stopColor={color1} />
                <stop offset="100%" stopColor={color2} />
              </radialGradient>
            </defs>
            {Array.from({length: 12}).map((_, i) => {
              const x = (width / 2) + Math.cos(frame * 0.05 + i * 0.5) * (150 + i * 20) * scale;
              const y = (height / 2) + Math.sin(frame * 0.07 + i * 0.7) * (100 + i * 25) * scale;
              const r = 30 + Math.sin(frame * 0.1 + i) * 20;
              return (
                <circle
                  key={i}
                  cx={x}
                  cy={y}
                  r={r}
                  fill={`url(#grad-${pattern})`}
                  opacity={opacity - i * 0.02}
                />
              );
            })}
          </svg>
        );

      case 'grid':
        const gridSize = 60 * scale;
        return (
          <svg width={width} height={height} style={{position: 'absolute', top: 0, left: 0}}>
            {Array.from({length: Math.ceil(width / gridSize) + 1}).map((_, col) =>
              Array.from({length: Math.ceil(height / gridSize) + 1}).map((_, row) => {
                const x = col * gridSize + Math.sin(frame * 0.03 + col * 0.2) * 20;
                const y = row * gridSize + Math.cos(frame * 0.04 + row * 0.3) * 20;
                const size = gridSize * (0.3 + Math.sin(frame * 0.08 + col + row) * 0.3);
                const hue = (frame * 2 + col * 15 + row * 20) % 360;
                return (
                  <rect
                    key={`${col}-${row}`}
                    x={x - size / 2}
                    y={y - size / 2}
                    width={size}
                    height={size}
                    fill={`hsl(${hue}, 80%, 60%)`}
                    opacity={opacity * 0.7}
                  />
                );
              })
            )}
          </svg>
        );

      case 'waves':
        return (
          <svg width={width} height={height} style={{position: 'absolute', top: 0, left: 0}}>
            {Array.from({length: 20}).map((_, i) => {
              const yOffset = (height / 20) * i + Math.sin(frame * 0.05 + i * 0.3) * 30;
              const amplitude = 20 + i * 3;
              const points = Array.from({length: 50}).map((_, j) => {
                const x = (width / 50) * j;
                const y = yOffset + Math.sin(frame * 0.08 + j * 0.1 + i * 0.5) * amplitude;
                return `${x},${y}`;
              }).join(' ');
              const hue = (frame * 3 + i * 18) % 360;
              return (
                <polyline
                  key={i}
                  points={points}
                  fill="none"
                  stroke={`hsl(${hue}, 90%, ${50 + Math.sin(frame * 0.1 + i) * 30}%)`}
                  strokeWidth={2 + Math.sin(frame * 0.06 + i) * 1.5}
                  opacity={opacity * 0.8}
                />
              );
            })}
          </svg>
        );

      case 'kaleidoscope':
        const cx = width / 2 + offset;
        const cy = height / 2 + offset * 0.5;
        const segments = 8;
        return (
          <svg width={width} height={height} style={{position: 'absolute', top: 0, left: 0}}>
            <defs>
              <clipPath id="kaleido-clip">
                <polygon
                  points={Array.from({length: segments + 1}).map((_, i) => {
                    const angle = (i / segments) * Math.PI * 2 + frame * 0.02;
                    const r = 400 * scale;
                    return `${cx + Math.cos(angle) * r},${cy + Math.sin(angle) * r}`;
                  }).join(' ')}
                />
              </clipPath>
            </defs>
            <g clipPath="url(#kaleido-clip)">
              <rect x={0} y={0} width={width} height={height} fill={color1} opacity={opacity} />
              {Array.from({length: 6}).map((_, i) => (
                <circle
                  key={i}
                  cx={cx + Math.cos(frame * 0.04 + i * 1.2) * 100}
                  cy={cy + Math.sin(frame * 0.06 + i * 0.8) * 80}
                  r={60 + i * 30 + Math.sin(frame * 0.1) * 20}
                  fill={color2}
                  opacity={opacity * 0.6}
                />
              ))}
            </g>
          </svg>
        );

      case 'noise':
        return (
          <div style={{
            position: 'absolute',
            top: 0,
            left: 0,
            width: '100%',
            height: '100%',
            background: `linear-gradient(${frame * 2}deg, ${color1}, ${color2})`,
            opacity: opacity * 0.5,
          }} />
        );

      default:
        return null;
    }
  };

  return (
    <div style={{
      position: 'absolute',
      top: 0,
      left: 0,
      width: '100%',
      height: '100%',
      mixBlendMode: blendMode as any,
    }}>
      {renderPattern()}
    </div>
  );
};

const FeedbackLayer: React.FC<{iteration: number}> = ({iteration}) => {
  const frame = useCurrentFrame();
  const {width, height} = useVideoConfig();

  const offsetX = Math.sin(frame * 0.03 + iteration) * 20 * iteration;
  const offsetY = Math.cos(frame * 0.04 + iteration) * 15 * iteration;

  return (
    <div style={{
      position: 'absolute',
      top: offsetY,
      left: offsetX,
      width: '100%',
      height: '100%',
      opacity: 0.15 - iteration * 0.02,
      transform: `scale(${1 - iteration * 0.02})`,
      mixBlendMode: 'screen',
    }}>
      <HydraPattern
        pattern="circles"
        color1={`hsl(${(frame + iteration * 60) % 360}, 90%, 60%)`}
        color2={`hsl(${(frame + 180 + iteration * 60) % 360}, 80%, 50%)`}
        scale={1}
        offset={0}
      />
    </div>
  );
};

const Scanlines: React.FC = () => {
  const {height} = useVideoConfig();
  const frame = useCurrentFrame();

  return (
    <div style={{
      position: 'absolute',
      top: 0,
      left: 0,
      width: '100%',
      height: '100%',
      background: `repeating-linear-gradient(
        0deg,
        transparent,
        transparent 2px,
        rgba(0, 0, 0, ${0.1 + Math.sin(frame * 0.2) * 0.05}) 2px,
        rgba(0, 0, 0, ${0.1 + Math.sin(frame * 0.2) * 0.05}) 4px
      )`,
      pointerEvents: 'none',
    }} />
  );
};

const Vignette: React.FC = () => {
  const {width, height} = useVideoConfig();
  const frame = useCurrentFrame();
  const intensity = 0.4 + Math.sin(frame * 0.05) * 0.1;

  return (
    <div style={{
      position: 'absolute',
      top: 0,
      left: 0,
      width: '100%',
      height: '100%',
      background: `radial-gradient(ellipse at center, transparent 30%, rgba(0,0,0,${intensity}) 100%)`,
      pointerEvents: 'none',
    }} />
  );
};

const GlowEffect: React.FC<{children: React.ReactNode}> = ({children}) => {
  return (
    <div style={{
      position: 'absolute',
      top: 0,
      left: 0,
      width: '100%',
      height: '100%',
      filter: 'blur(8px) brightness(1.2)',
      mixBlendMode: 'screen',
    }}>
      {children}
    </div>
  );
};

export const HydraVideoSynth: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();

  const masterHue = (frame * 2) % 360;
  const masterHue2 = (frame * 2 + 120) % 360;
  const masterHue3 = (frame * 2 + 240) % 360;

  return (
    <AbsoluteFill style={{backgroundColor: '#000', overflow: 'hidden'}}>
      <GlowEffect>
        <HydraPattern
          pattern="circles"
          color1={`hsl(${masterHue}, 90%, 60%)`}
          color2={`hsl(${masterHue + 60}, 80%, 50%)`}
          scale={1.5}
          offset={0}
        />
      </GlowEffect>

      <HydraPattern
        pattern="grid"
        color1={`hsl(${masterHue2}, 85%, 55%)`}
        color2={`hsl(${masterHue2 + 90}, 75%, 45%)`}
        scale={0.8}
        offset={0}
        blendMode="overlay"
      />

      <HydraPattern
        pattern="waves"
        color1={`hsl(${masterHue3}, 95%, 60%)`}
        color2={`hsl(${masterHue3 + 180}, 85%, 50%)`}
        scale={1}
        offset={0}
        blendMode="color-dodge"
      />

      <HydraPattern
        pattern="kaleidoscope"
        color1={`hsl(${(masterHue + 30) % 360}, 100%, 70%)`}
        color2={`hsl(${(masterHue + 210) % 360}, 90%, 40%)`}
        scale={1.2}
        offset={Math.sin(frame * 0.08) * 50}
        blendMode="lighten"
      />

      {[0, 1, 2, 3].map(i => (
        <FeedbackLayer key={i} iteration={i} />
      ))}

      <div style={{
        position: 'absolute',
        top: '50%',
        left: '50%',
        transform: 'translate(-50%, -50%)',
        width: '60%',
        height: '60%',
        border: `${2 + Math.sin(frame * 0.1) * 1}px solid`,
        borderColor: `hsl(${masterHue}, 100%, 70%)`,
        opacity: 0.3 + Math.sin(frame * 0.08) * 0.1,
        boxShadow: `0 0 30px hsl(${masterHue}, 100%, 50%), inset 0 0 30px hsl(${masterHue}, 100%, 50%)`,
      }} />

      <div style={{
        position: 'absolute',
        top: '50%',
        left: '50%',
        transform: `translate(-50%, -50%) rotate(${frame * 0.5}deg)`,
        width: '80%',
        height: '80%',
        border: `${1}px solid`,
        borderColor: `hsl(${masterHue2}, 100%, 60%)`,
        opacity: 0.2,
      }} />

      <div style={{
        position: 'absolute',
        top: '50%',
        left: '50%',
        transform: `translate(-50%, -50%) rotate(-${frame * 0.3}deg)`,
        width: '40%',
        height: '40%',
        border: `${3}px solid`,
        borderColor: `hsl(${masterHue3}, 100%, 70%)`,
        opacity: 0.4 + Math.sin(frame * 0.12) * 0.2,
        boxShadow: `0 0 20px hsl(${masterHue3}, 100%, 50%)`,
      }} />

      <Scanlines />
      <Vignette />

      <div style={{
        position: 'absolute',
        bottom: 40,
        right: 40,
        color: `hsl(${masterHue}, 100%, 80%)`,
        fontFamily: 'monospace',
        fontSize: 14,
        opacity: 0.6,
        letterSpacing: 2,
      }}>
        {`HYDRA::SYNTH // FRAME:${frame.toString().padStart(3, '0')}`}
      </div>

      <div style={{
        position: 'absolute',
        top: 0,
        left: 0,
        width: '100%',
        height: '100%',
        background: `linear-gradient(
          ${45 + frame * 0.1}deg,
          transparent 0%,
          rgba(${Math.sin(frame * 0.05) * 50 + 100}, ${Math.cos(frame * 0.07) * 50 + 100}, ${Math.sin(frame * 0.03) * 50 + 150}, 0.1) 50%,
          transparent 100%
        )`,
        mixBlendMode: 'overlay',
      }} />
    </AbsoluteFill>
  );
};