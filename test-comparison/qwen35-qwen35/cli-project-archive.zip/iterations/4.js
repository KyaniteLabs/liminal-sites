<think>
The user wants me to create an immersive underwater scene shader with:
1. Light rays/caustics
2. Rising bubbles
3. Swaying aquatic plant life

I'll create this using:
- Procedural caustics using noise functions
- Ray-like light beams from above
- Particle-like bubbles rising
- Animated seaweed/plant shapes

Let me write a comprehensive fragment shader that creates this underwater atmosphere.

I need to:
1. Create caustic patterns using layered noise
2. Add god rays/light beams from the surface
3. Simulate rising bubbles with animation
4. Create swaying plant life at the bottom
5. Add depth fog for underwater atmosphere
6. Include blue-green color grading

Let me write this as a single fragment shader.
</think>

precision highp float;

uniform vec2 u_resolution;
uniform float u_time;
uniform vec2 u_mouse;

#define PI 3.14159265359
#define TAU 6.28318530718
#define MAX_BUBBLES 12
#define MAX_PLANTS 5

float hash(float n) { return fract(sin(n) * 43758.5453123); }
float hash2(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }

vec3 hash3(vec2 p) {
    vec3 q = vec3(dot(p, vec2(127.1, 311.7)), dot(p, vec2(269.5, 183.3)), dot(p, vec2(419.2, 371.9)));
    return fract(sin(q) * 43758.5453);
}

float noise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    float a = hash2(i);
    float b = hash2(i + vec2(1.0, 0.0));
    float c = hash2(i + vec2(0.0, 1.0));
    float d = hash2(i + vec2(1.0, 1.0));
    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}

float fbm(vec2 p) {
    float f = 0.0;
    float amp = 0.5;
    for(int i = 0; i < 4; i++) {
        f += amp * noise(p);
        p *= 2.0;
        amp *= 0.5;
    }
    return f;
}

float voronoi(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    float minDist = 1.0;
    for(int y = -1; y <= 1; y++) {
        for(int x = -1; x <= 1; x++) {
            vec2 neighbor = vec2(float(x), float(y));
            vec2 point = hash2(i + neighbor) * vec2(1.0);
            vec2 diff = neighbor + point - f;
            float dist = length(diff);
            minDist = min(minDist, dist);
        }
    }
    return minDist;
}

float caustics(vec2 uv, float time) {
    float c = 0.0;
    vec2 p1 = uv * 4.0 + vec2(time * 0.1, time * 0.15);
    vec2 p2 = uv * 6.0 - vec2(time * 0.12, time * 0.08);
    vec2 p3 = uv * 8.0 + vec2(time * 0.05, -time * 0.1);
    
    c += pow(voronoi(p1), 2.0) * 0.5;
    c += pow(voronoi(p2), 2.0) * 0.3;
    c += pow(voronoi(p3), 2.0) * 0.2;
    
    c = pow(c, 1.5);
    return c * 0.8;
}

float godRay(vec2 uv, float time, float angle) {
    vec2 rayDir = vec2(cos(angle), sin(angle));
    float ray = 0.0;
    float brightness = 1.0;
    
    for(int i = 0; i < 5; i++) {
        float depth = float(i) * 0.15;
        vec2 offset = rayDir * depth * (0.5 + 0.5 * sin(time * 0.3 + float(i)));
        float rayWidth = 0.02 + 0.01 * sin(time + float(i) * 2.0);
        float dist = abs(uv.x + offset.x - 0.5);
        ray += smoothstep(rayWidth, 0.0, dist) * brightness;
        brightness *= 0.7;
    }
    
    return ray * (1.0 - uv.y);
}

vec3 bubble(vec2 uv, vec2 pos, float size, float time, float phase) {
    float dist = length(uv - pos);
    float outer = smoothstep(size, size * 0.9, dist);
    float inner = smoothstep(size * 0.3, size * 0.35, dist);
    
    float highlight = smoothstep(size * 0.5, size * 0.1, length(uv - pos - vec2(-size * 0.25, -size * 0.25)));
    
    vec3 bubbleColor = vec3(0.6, 0.8, 1.0) * (outer - inner) * 0.4;
    bubbleColor += vec3(1.0) * highlight * 0.6;
    
    float reflection = inner * (0.3 + 0.2 * sin(time * 2.0 + phase));
    bubbleColor += vec3(0.8, 0.9, 1.0) * reflection;
    
    return bubbleColor;
}

float plantSegment(vec2 uv, float x, float baseY, float height, float sway, float time, float id) {
    float segmentY = baseY + height;
    float swayAmount = sway * sin(time * 1.5 + id * 2.0 + uv.y * 3.0);
    swayAmount += sway * 0.5 * sin(time * 0.7 + id);
    
    float plantX = x + swayAmount * (uv.y - baseY) / height;
    
    float thickness = 0.01 + 0.008 * (uv.y - baseY) / height;
    thickness *= smoothstep(baseY, baseY + 0.05, uv.y);
    
    float d = abs(uv.x - plantX);
    float plant = smoothstep(thickness, thickness * 0.5, d);
    plant *= smoothstep(baseY, baseY + 0.02, uv.y);
    plant *= smoothstep(segmentY, segmentY - 0.1, uv.y);
    
    return plant;
}

float plant(vec2 uv, float x, float time, float id) {
    float baseY = 0.0;
    float h = 0.25 + hash(id) * 0.2;
    float sway = 0.03 + hash(id + 10.0) * 0.04;
    
    float p = plantSegment(uv, x, baseY, h * 0.4, sway, time, id);
    p += plantSegment(uv, x, baseY + h * 0.35, h * 0.35, sway * 1.2, time, id + 1.0);
    p += plantSegment(uv, x, baseY + h * 0.65, h * 0.4, sway * 1.5, time, id + 2.0);
    
    return p;
}

float seaweed(vec2 uv, float x, float time, float id) {
    float baseY = 0.0;
    float height = 0.2 + hash(id) * 0.15;
    
    float wave1 = sin(uv.y * 15.0 - time * 2.0 + id * 3.0) * 0.02;
    float wave2 = sin(uv.y * 8.0 - time * 1.5 + id * 2.0) * 0.015;
    float wave3 = sin(uv.y * 20.0 - time * 2.5) * 0.01;
    
    float sway = wave1 + wave2 + wave3;
    sway *= (uv.y - baseY) / height;
    
    float plantX = x + sway;
    
    float thickness = 0.008 * (0.5 + 0.5 * sin(uv.y * 10.0 + id));
    
    float d = abs(uv.x - plantX);
    float seaweed = smoothstep(thickness, thickness * 0.3, d);
    seaweed *= smoothstep(baseY, baseY + 0.01, uv.y);
    seaweed *=