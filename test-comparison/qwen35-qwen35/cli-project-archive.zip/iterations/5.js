<think>
The user wants an immersive underwater scene with:
1. Light rays (god rays/caustics)
2. Rising bubbles
3. Aquatic plant life swaying

I'll create a comprehensive fragment shader that includes:
- Volumetric light rays from above
- Caustic patterns on the "floor"
- Procedural bubbles rising
- Swaying aquatic plants/kelp
- Color gradient for depth
- Subtle noise for organic feel

Let me write this as a single fragment shader with all the necessary components.
</think>

precision highp float;

uniform vec2 u_resolution;
uniform float u_time;
uniform vec2 u_mouse;

#define PI 3.14159265359
#define TAU 6.28318530718

float hash(vec2 p) {
    return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
}

float hash21(vec2 p) {
    return fract(sin(dot(p, vec2(234.5, 672.3))) * 6743.23);
}

float noise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    
    float a = hash(i);
    float b = hash(i + vec2(1.0, 0.0));
    float c = hash(i + vec2(0.0, 1.0));
    float d = hash(i + vec2(1.0, 1.0));
    
    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}

float fbm(vec2 p) {
    float value = 0.0;
    float amplitude = 0.5;
    for(int i = 0; i < 4; i++) {
        value += amplitude * noise(p);
        p *= 2.0;
        amplitude *= 0.5;
    }
    return value;
}

mat2 rot(float a) {
    float c = cos(a), s = sin(a);
    return mat2(c, -s, s, c);
}

float caustics(vec2 uv, float time) {
    vec2 p = uv * 8.0;
    float c = 0.0;
    
    for(int i = 0; i < 3; i++) {
        float t = time * 0.5 + float(i) * 1.3;
        vec2 offset = vec2(sin(t * 0.7), cos(t * 0.9)) * 0.5;
        c += sin(p.x * 3.0 + t + sin(p.y * 2.5 + t * 1.2)) * 0.5 + 0.5;
        c += sin(p.y * 4.0 - t * 0.8 + sin(p.x * 3.5 + t * 0.6)) * 0.5 + 0.5;
        p *= 1.5;
        p *= rot(0.5);
    }
    
    c = c / 6.0;
    c = pow(c, 2.0);
    
    return c;
}

float bubbles(vec2 uv, float time) {
    float b = 0.0;
    
    for(int i = 0; i < 8; i++) {
        float fi = float(i);
        vec2 pos = vec2(
            hash(vec2(fi, 0.0)) * 2.0 - 1.0,
            mod(hash(vec2(fi, 1.0)) - time * (0.1 + hash(vec2(fi, 2.0)) * 0.15), 2.0) - 1.0
        );
        
        pos.x += sin(time * 2.0 + fi * 1.5) * 0.05;
        
        float size = 0.01 + hash(vec2(fi, 3.0)) * 0.02;
        float d = length(uv - pos);
        float bubble = smoothstep(size, size * 0.5, d);
        bubble *= smoothstep(1.5, 0.8, abs(uv.x));
        
        float highlight = smoothstep(size * 0.3, 0.0, length(uv - pos - vec2(size * 0.3, -size * 0.3)));
        
        b += bubble * 0.5 + highlight * 0.8;
    }
    
    return b;
}

float lightRays(vec2 uv, float time) {
    float rays = 0.0;
    vec2 p = vec2(uv.x * 3.0, uv.y * 0.5);
    
    for(int i = 0; i < 5; i++) {
        float fi = float(i);
        float offset = fi * 1.3 + hash(vec2(fi, 0.0)) * 2.0;
        float sway = sin(time * 0.3 + fi) * 0.3;
        
        float rayX = sin(p.x * 2.0 + offset + time * 0.2 + sway) * 0.5 + 0.5;
        rayX = pow(rayX, 3.0);
        
        float rayY = pow(max(0.0, uv.y + 0.5), 2.0);
        rayY = 1.0 - rayY;
        
        rays += rayX * rayY * 0.3;
    }
    
    return rays;
}

float plant(vec2 uv, float x, float height, float time, float seed) {
    float sway = sin(time * 1.5 + seed * TAU) * 0.1 * (height - uv.y);
    sway += sin(time * 2.3 + seed * 3.0) * 0.05 * (height - uv.y);
    
    float px = x + sway;
    float width = 0.02 + sin(uv.y * 15.0 + seed * TAU) * 0.008;
    width *= smoothstep(0.0, 0.3, uv.y);
    
    float plant = smoothstep(width, 0.0, abs(uv.x - px));
    plant *= smoothstep(-0.8, -0.8 + height, uv.y);
    plant *= step(-0.8, uv.y);
    
    float leaves = 0.0;
    for(int i = 0; i < 3; i++) {
        float fi = float(i);
        float ly = -0.6 + fi * 0.25 + height * 0.3;
        float lsway = sin(time * 2.0 + fi + seed * TAU) * 0.15;
        
        if(uv.y > ly && uv.y < ly + 0.2) {
            float side = mod(fi, 2.0) * 2.0 - 1.0;
            float lx = px + side * 0.15 + lsway;
            float lw = 0.1 * (1.0 - (uv.y - ly) * 2.0);
            leaves += smoothstep(lw, 0.0, abs(uv.x - lx));
        }
    }
    
    return plant + leaves * 0.7;
}

float plants(vec2 uv, float time) {
    float p = 0.0;
    
    for(int i = 0; i < 6; i++) {
        float fi = float(i);
        float x = -0.8 + fi * 0.32;
        float h = 0.4 + hash(vec2(fi, 0.0)) * 0.4;
        p += plant(uv, x, h, time, fi * 0.5);
    }
    
    return p;
}

float fish(vec2 uv, float time) {
    float f = 0.0;
    
    for(int i = 0; i < 3; i++) {
        float fi = float(i);
        float speed = 0.15 + hash(vec2(fi, 0.0)) * 0.1;
        float dir = hash(vec2(fi, 1.0)) > 0.5 ? 1.0 : -1.0;
        
        vec2 pos = vec2(
            mod(hash(vec2(fi, 2.0)) + time * speed * dir, 3.0) - 1.5,
            0.3 + hash(vec2(fi, 3.0)) * 0.3
        );
        
        if(abs(pos.x) > 1.2) continue;
        
        vec2 luv = uv - pos;
        luv.x *= dir;
        
        float body = smoothstep(0.08, 0.0, length(luv * vec2(1.0, 1.5)) - 0.05);
        body += smoothstep(0.05, 0.0, length(luv - vec2(0.08, 0.0)) - 0