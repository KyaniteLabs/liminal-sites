const Tone = require('tonal');

let bpm = 120;
let transport;
let synth;
let reverb;
let visualElement;

document.addEventListener('DOMContentLoaded', () => {
  const bpmInput = document.getElementById('bpm');
  const playButton = document.getElementById('playButton');
  const stopButton = document.getElementById('stopButton');

  if (!bpmInput) {
    console.error("bpm input element not found");
    return;
  }

  bpmInput.addEventListener('input', () => {
    bpm = parseInt(bpmInput.value);
    Tone.Transport.bpm.value = bpm;
  });

  const startAudio = async () => {
    if (Tone.masterTrack.isPlaying()) {
      console.warn("Audio already playing");
      return;
    }

    Tone.start();
    transport = new Tone.Transport();
    transport.bpm.value = bpm;

    synth = new Tone.Synth('sine').toDestination();
    reverb = new Tone.ReverbNode(0.8).toDestination();
    synth.connect(reverb);

    const notes = ['C4', 'D4', 'E4', 'G4', 'A4'];

    const sequence = new Tone.Sequence(
      (note) => synth.play(note, { detune: 0.1 }),
      notes,
      4,
      0.5
    );

    sequence.start();
    Tone.masterTrack.volume.rampTo(-10, 1);
    visualElement = document.getElementById('visual');
    if (visualElement) {
      visualElement.style.backgroundColor = 'black';
    }

  };

  const stopAudio = () => {
    if (!Tone.masterTrack.isPlaying()) {
      console.log("Audio not playing");
      return;
    }
    sequence.stop();
    Tone.masterTrack.volume.rampTo(0, 1);
    Tone.stop();
  };

  playButton.addEventListener('click', startAudio);
  stopButton.addEventListener('click', stopAudio);

  //Initial setup
  startAudio();
});