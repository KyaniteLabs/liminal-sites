import React from 'react';
import {useCurrentFrame, interpolate, AbsoluteFill} from 'remotion';

export const TypingComposition: React.FC = ({ fps = 30, durationInFrames = 150, width = 1920, height = 1080 }) => {
  const frame = useCurrentFrame();
  const text = "Hello, Remotion!";
  const textLength = text.length;
  const animationDelay = 1000 / fps; // Adjust for desired typing speed

  const animation = interpolate(
    frame,
    [0, durationInFrames - 1],
    [0, textLength - 1]
  );

  return (
    <AbsoluteFill
      style={{
        backgroundColor: '#000',
        overflow: 'hidden',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
      }}
    >
      <text
        style={{
          fontSize: '60px',
          color: '#fff',
          fontSizeAnimation: {
            transform: `translateY(${animation}px)`,
          },
        }}
      >
        {text.split('').map((char, index) => (
          <span key={index} style={{
            display: 'inline-block',
            opacity: animation[index],
            transition: 'opacity 0.5s ease-in-out',
          }}>
            {char}
          </span>
        ))}
      </text>
    </AbsoluteFill>
  );
};