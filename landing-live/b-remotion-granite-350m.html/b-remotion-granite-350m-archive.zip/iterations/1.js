const VideoComp = () => {
  const fps = 30;
  return (
    <video width={1920} height={1080}
      muted autoplay loop>
      <Img src="https://via.placeholder.com/600x300.png?text=Animation">
        {/* visual elements */}
      </Img>
    </video>
  );
};