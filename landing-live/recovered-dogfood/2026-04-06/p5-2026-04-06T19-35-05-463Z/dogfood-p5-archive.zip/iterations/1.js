let jellyfish = [];
let plankton = [];
let caustics = [];
let depthLayers = [];

function setup() {
  createCanvas(windowWidth, windowHeight);
  colorMode(HSB, 360, 100, 100, 1);
  
  // Create depth layers
  for (let i = 0; i < 5; i++) {
    depthLayers.push({
      offset: i * 0.15,
      speed: 0.001 + i * 0.0005
    });
  }
  
  // Create jellyfish
  for (let i = 0; i < 6; i++) {
    jellyfish.push(new Jellyfish(
      random(width),
      random(height * 0.3, height * 0.7),
      random(30, 60)
    ));
  }
  
  // Create plankton
  for (let i = 0; i < 150; i++) {
    plankton.push({
      x: random(width),
      y: random(height),
      vx: random(-0.5, 0.5),
      vy: random(-0.5, 0.5),
      size: random(1, 4),
      brightness: random(0.3, 0.8),
      hue: random(180, 280),
      life: random(100, 300)
    });
  }
  
  // Create caustic sources
  for (let i = 0; i < 8; i++) {
    caustics.push({
      x: random(width),
      y: random(height * 0.6),
      phase: random(TWO_PI),
      speed: random(0.01, 0.03),
      size: random(80, 150)
    });
  }
}

function draw() {
  // Deep ocean background gradient
  background(220, 80, 8);
  
  // Draw multiple depth layers
  for (let layer of depthLayers) {
    drawDepthLayer(layer);
  }
  
  // Draw caustics
  drawCaustics();
  
  // Draw plankton
  updateAndDrawPlankton();
  
  // Draw jellyfish
  for (let jf of jellyfish) {
    jf.update();
    jf.display();
  }
  
  // Overlay particles
  drawFloatingParticles();
}

function drawDepthLayer(layer) {
  push();
  let yOffset = frameCount * layer.speed * 100;
  for (let y = 0; y < height + 50; y += 50) {
    let alpha = map(sin(frameCount * 0.01 + y * 0.01 + layer.offset), -1, 1, 0.02, 0.06);
    stroke(220, 60, 15, alpha);
    strokeWeight(1);
    noFill();
    beginShape();
    for (let x = 0; x < width; x += 20) {
      let offset = noise(x * 0.005, y * 0.01 + yOffset) * 30;
      curveVertex(x, y + offset);
    }
    endShape();
  }
  pop();
}

function drawCaustics() {
  blendMode(ADD);
  for (let c of caustics) {
    c.phase += c.speed;
    let x = c.x + sin(c.phase) * 100;
    let y = c.y + cos(c.phase * 0.7) * 50;
    
    for (let i = 0; i < 3; i++) {
      let spread = c.size + noise(c.phase + i) * 50;
      let alpha = map(i, 0, 3, 0.15, 0.02);
      
      noStroke();
      fill(180, 100, 80, alpha);
      
      beginShape();
      for (let a = 0; a < TWO_PI; a += 0.2) {
        let r = spread * (0.5 + noise(c.phase + a * 2, i) * 0.5);
        let px = x + cos(a) * r;
        let py = y + sin(a) * r;
        curveVertex(px, py);
      }
      endShape(CLOSE);
    }
  }
  blendMode(BLEND);
}

function updateAndDrawPlankton() {
  for (let p of plankton) {
    // Mouse interaction
    let d = dist(mouseX, mouseY, p.x, p.y);
    if (d < 150) {
      let angle = atan2(p.y - mouseY, p.x - mouseX);
      let force = map(d, 0, 150, 3, 0);
      p.vx += cos(angle) * force * 0.1;
      p.vy += sin(angle) * force * 0.1;
    }
    
    // Subtle movement
    p.vx += random(-0.1, 0.1);
    p.vy += random(-0.1, 0.1);
    
    // Damping
    p.vx *= 0.98;
    p.vy *= 0.98;
    
    p.x += p.vx;
    p.y += p.vy;
    
    // Wrap
    if (p.x < 0) p.x = width;
    if (p.x > width) p.x = 0;
    if (p.y < 0) p.y = height;
    if (p.y > height) p.y = 0;
    
    // Glow effect
    let glow = noise(p.x * 0.01, p.y * 0.01, frameCount * 0.02) * 0.5 + 0.5;
    
    noStroke();
    fill(p.hue, 80, 100, p.brightness * glow);
    ellipse(p.x, p.y, p.size);
    
    // Inner bright core
    fill(p.hue, 40, 100, p.brightness * glow * 1.5);
    ellipse(p.x, p.y, p.size * 0.5);
    
    p.life--;
    if (p.life <= 0) {
      p.x = random(width);
      p.y = random(height);
      p.life = random(100, 300);
    }
  }
}

function drawFloatingParticles() {
  blendMode(ADD);
  for (let i = 0; i < 50; i++) {
    let x = noise(i * 0.5, frameCount * 0.005) * width;
    let y = noise(i * 0.3, frameCount * 0.003 + 100) * height;
    let size = noise(i * 0.2, frameCount * 0.01) * 3;
    
    noStroke();
    fill(200, 100, 70, 0.1);
    ellipse(x, y, size);
  }
  blendMode(BLEND);
}

class Jellyfish {
  constructor(x, y, size) {
    this.x = x;
    this.y = y;
    this.size = size;
    this.baseY = y;
    this.pulsePhase = random(TWO_PI);
    this.pulseSpeed = random(0.03, 0.06);
    this.driftAngle = random(TWO_PI);
    this.hue = random(180, 260);
    
    // Tentacles with verlet physics
    this.tentacles = [];
    let numTentacles = floor(random(5, 8));
    for (let i = 0; i < numTentacles; i++) {
      let startX = this.x + sin(i / numTentacles * TWO_PI) * this.size * 0.6;
      let segs = floor(random(12, 20));
      this.tentacles.push(this.createTentacle(startX, this.y + this.size * 0.5, segs));
    }
  }
  
  createTentacle(x, y, segments) {
    let segs = [];
    for (let i = 0; i < segments; i++) {
      segs.push({
        x: x,
        y: y + i * 5,
        oldX: x,
        oldY: y + i * 5
      });
    }
    return segs;
  }
  
  update() {
    this.pulsePhase += this.pulseSpeed;
    
    // Gentle drift
    this.driftAngle += random(-0.02, 0.02);
    this.x += sin(this.driftAngle) * 0.5;
    this.y = this.baseY + sin(frameCount * 0.02) * 20;
    this.baseY += sin(frameCount * 0.005) * 0.2;
    
    // Update tentacle physics
    for (let tentacle of this.tentacles) {
      let anchorX = this.x + sin(this.driftAngle + tentacle[0].angle) * this.size * 0.4;
      let anchorY = this.y + this.size * 0.4;
      
      // First segment follows bell
      tentacle[0].x = anchorX + sin(this.pulsePhase) * 5;
      tentacle[0].y = anchorY + cos(this.pulsePhase * 2) * 3;
      
      // Verlet integration
      for (let i = 1; i < tentacle.length; i++) {
        let seg = tentacle[i];
        let vx = (seg.x - seg.oldX) * 0.98;
        let vy = (seg.y - seg.oldY) * 0.98;
        
        seg.oldX = seg.x;
        seg.oldY = seg.y;
        
        seg.x += vx;
        seg.y += vy + 0.05; // slight gravity
        
        // Current constraint
        let dx = seg.x - tentacle[i - 1].x;
        let dy = seg.y - tentacle[i - 1].y;
        let dist = sqrt(dx * dx + dy * dy);
        let targetDist = 8;
        
        if (dist > 0) {
          let diff = (dist - targetDist) / dist;
          seg.x -= dx * diff * 0.5;
          seg.y -= dy * diff * 0.5;
        }
        
        // Water current influence
        seg.x += noise(i * 0.3, frameCount * 0.02) * 0.3;
        seg.y += sin(frameCount * 0.03 + i * 0.5) * 0.1;
      }
    }
  }
  
  display() {
    let pulse = sin(this.pulsePhase);
    let bellSize = this.size * (1 + pulse * 0.15);
    
    // Outer glow
    noStroke();
    for (let i = 5; i > 0; i--) {
      let alpha = map(i, 5, 0, 0.05, 0.2);
      let glowSize = bellSize + i * 15;
      fill(this.hue, 80, 70, alpha);
      ellipse(this.x, this.y, glowSize * 2);
    }
    
    // Bell body
    fill(this.hue, 60, 40, 0.6);
    beginShape();
    for (let a = 0; a < PI; a += 0.1) {
      let r = bellSize * (1 - a / PI);
      let x = this.x + cos(PI + a) * r;
      let y = this.y - sin(a) * bellSize * 0.8;
      curveVertex(x, y);
    }
    endShape(CLOSE);
    
    // Inner membrane
    fill(this.hue, 40, 80, 0.4 + pulse * 0.3);
    ellipse(this.x, this.y - bellSize * 0.2, bellSize * 1.2, bellSize * 0.8);
    
    // Pulsing core
    fill(this.hue, 20, 100, 0.5 + pulse * 0.3);
    let coreSize = bellSize * 0.4 * (0.8 + pulse * 0.4);
    ellipse(this.x, this.y - bellSize * 0.3, coreSize);
    
    // Radiating lines
    stroke(this.hue, 60, 90, 0.3);
    strokeWeight(1);
    for (let i = 0; i < 8; i++) {
      let angle = PI + i * (PI / 8);
      let len = bellSize * 0.8;
      let x1 = this.x + cos(angle) * 5;
      let y1 = this.y + sin(angle) * 10;
      let x2 = this.x + cos(angle) * len;
      let y2 = this.y + sin(angle) * len * 0.6;
      line(x1, y1, x2, y2);
    }
    
    // Tentacles
    blendMode(ADD);
    for (let tentacle of this.tentacles) {
      noFill();
      
      // Glow layer
      strokeWeight(6);
      stroke(this.hue, 70, 60, 0.05);
      beginShape();
      for (let seg of tentacle) {
        curveVertex(seg.x, seg.y);
      }
      endShape();
      
      // Main tentacle
      strokeWeight(3);
      stroke(this.hue, 50, 80, 0.4);
      beginShape();
      for (let seg of tentacle) {
        curveVertex(seg.x, seg.y);
      }
      endShape();
      
      // Core bright line
      strokeWeight(1);
      stroke(this.hue, 30, 100, 0.6 + pulse * 0.3);
      beginShape();
      for (let seg of tentacle) {
        curveVertex(seg.x, seg.y);
      }
      endShape();
      
      // Nodes along tentacle
      noStroke();
      for (let i = 0; i < tentacle.length; i += 3) {
        let seg = tentacle[i];
        let nodePulse = sin(this.pulsePhase + i * 0.3) * 0.5 + 0.5;
        fill(this.hue, 40, 100, 0.4 * nodePulse);
        ellipse(seg.x, seg.y, 4 + nodePulse * 3);
      }
    }
    blendMode(BLEND);
  }
}

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
}