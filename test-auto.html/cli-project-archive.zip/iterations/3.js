precision highp float;

uniform vec2 u_resolution;
uniform float u_time;
uniform vec2 u_mouse;

#define MAX_STEPS 80
#define MAX_DIST 100.0
#define SURF_DIST 0.001
#define FOG_STEPS 32
#define PI 3.14159265359

mat2 rot2D(float a) {
    float s = sin(a), c = cos(a);
    return mat2(c, -s, s, c);
}

float hash(float n) { return fract(sin(n) * 43758.5453); }
float hash2(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }

float noise(vec3 x) {
    vec3 p = floor(x);
    vec3 f = fract(x);
    f = f * f * (3.0 - 2.0 * f);
    float n = p.x + p.y * 157.0 + 113.0 * p.z;
    return mix(
        mix(mix(hash(n + 0.0), hash(n + 1.0), f.x),
            mix(hash(n + 157.0), hash(n + 158.0), f.x), f.y),
        mix(mix(hash(n + 113.0), hash(n + 114.0), f.x),
            mix(hash(n + 270.0), hash(n + 271.0), f.x), f.y), f.z);
}

float fbm(vec3 p) {
    float f = 0.0;
    float amp = 0.5;
    float freq = 1.0;
    for(int i = 0; i < 5; i++) {
        f += amp * noise(p * freq);
        amp *= 0.5;
        freq *= 2.0;
    }
    return f;
}

float terrain(vec2 p) {
    float h = 0.0;
    float amp = 1.0;
    float freq = 0.2;
    for(int i = 0; i < 6; i++) {
        h += amp * (noise(vec3(p * freq, 0.0)) * 2.0 - 1.0);
        amp *= 0.4;
        freq *= 2.2;
    }
    return h * 3.0;
}

float sdFractal(vec3 p) {
    vec2 q = p.xz;
    float ground = p.y - terrain(q);
    
    vec3 z = p;
    z.y -= 1.0;
    float scale = 1.5;
    float offset = 1.0;
    float iter = 0.0;
    
    for(int i = 0; i < 6; i++) {
        z.xz = abs(z.xz);
        if(z.x < z.z) z.xz = z.zx;
        z.xz -= 0.5 * offset;
        z *= scale;
        z.y -= 1.0;
        iter += 1.0;
    }
    
    float fractal = (length(z) - 1.5) / pow(scale, iter);
    return min(ground * 0.7, fractal);
}

float map(vec3 p) {
    return sdFractal(p);
}

vec3 calcNormal(vec3 p) {
    vec2 e = vec2(0.01, 0.0);
    return normalize(vec3(
        map(p + e.xyy) - map(p - e.xyy),
        map(p + e.yxy) - map(p - e.yxy),
        map(p + e.yyx) - map(p - e.yyx)
    ));
}

float rayMarch(vec3 ro, vec3 rd, out float fog) {
    float t = 0.0;
    fog = 0.0;
    for(int i = 0; i < MAX_STEPS; i++) {
        vec3 p = ro + rd * t;
        float d = map(p);
        float fogDensity = exp(-length(p - ro) * 0.03) * (1.0 - smoothstep(-2.0, 4.0, p.y)) * 0.5;
        fog += fogDensity * 0.1;
        if(d < SURF_DIST) return t;
        if(t > MAX_DIST) break;
        t += d * 0.8;
    }
    return -1.0;
}

vec3 volumetricFog(vec3 ro, vec3 rd, float maxDist) {
    vec3 fogColor = vec3(0.6, 0.7, 0.85);
    vec3 sunDir = normalize(vec3(0.5, 0.8, 0.3));
    float fogAmount = 0.0;
    float stepSize = maxDist / float(FOG_STEPS);
    
    for(int i = 0; i < FOG_STEPS; i++) {
        float t = stepSize * float(i);
        vec3 p = ro + rd * t;
        float heightFog = exp(-max(p.y + 1.0, 0.0) * 0.3);
        float density = heightFog * (1.0 + 0.5 * noise(p * 0.5 + u_time * 0.1));
        float lightDist = rayMarchLight(p, sunDir);
        float scattering = exp(-lightDist * 0.1);
        fogAmount += density * scattering * stepSize;
    }
    
    return fogColor * fogAmount;
}

float rayMarchLight(vec3 ro, vec3 rd) {
    float t = 0.0;
    for(int i = 0; i < 32; i++) {
        float d = map(ro + rd * t);
        if(d < 0.01) return t;
        t += d;
        if(t > 50.0) break;
    }
    return 50.0;
}

vec3 palette(float t) {
    vec3 a = vec3(0.5, 0.5, 0.5);
    vec3 b = vec3(0.5, 0.5, 0.5);
    vec3 c = vec3(1.0, 1.0, 1.0);
    vec3 d = vec3(0.0, 0.33, 0.67);
    return a + b * cos(2.0 * PI * (c * t + d));
}

void main() {
    vec2 uv = (gl_FragCoord.xy - 0.5 * u_resolution.xy) / u_resolution.y;
    
    float mouseX = u_mouse.x * 2.0 - 1.0;
    float mouseY = u_mouse.y;
    
    vec3 ro = vec3(0.0, 4.0 + sin(u_time * 0.1) * 2.0, -6.0);
    ro.xz *= rot2D(u_time * 0.05 + mouseX * PI);
    ro.y += mouseY * 3.0;
    
    vec3 ta = vec3(0.0, 0.0, 0.0);
    vec3 forward = normalize(ta - ro);
    vec3 right = normalize(cross(vec3(0.0, 1.0, 0.0), forward));
    vec3 up = cross(forward, right);
    
    vec3 rd = normalize(forward + uv.x * right + uv.y * up);
    
    float fogAccum;
    float d = rayMarch(ro, rd, fogAccum);
    
    vec3 col = vec3(0.1, 0.15, 0.2);
    col += vec3(0.3, 0.2, 0.4) * (1.0 - length(uv)) * 0.3;
    
    if(d > 0.0) {
        vec3 p = ro + rd * d;
        vec3 n = calcNormal(p);
        
        vec3 lightDir = normalize(vec3(0.5, 0.8, 0.3));
        vec3 lightCol = vec3(1.0, 0.95, 0.8);
        
        float diff = max(dot(n, lightDir), 0.0);
        float spec = pow(max(dot(reflect(-lightDir, n), -rd), 0.0), 32.0);
        float ao = 1.0 - map(p + n * 0.5) * 2.0;
        
        float height = p.y;
        vec3 terrainCol = mix(
            vec3(0.1, 0.3, 0.1),
            vec3(0.6, 0.5, 0.4),
            smoothstep(-2.0, 2.0, height)
        );
        terrainCol = mix(terrainCol, vec3(0.8, 0.85, 0.9), smoothstep(3.0, 5.0, height));
        
        float fractalMask = smoothstep(0.0, 0.5, map(p));
        float colorShift = fbm(p * 0.3 + u_time * 0.05);
        vec3 fractalCol = palette(colorShift * 0.5 + 0.3);
        terrainCol = mix(terrainCol, fractalCol, fractalMask);
        
        col = terrainCol * diff * lightCol * ao;
        col += vec3(1.0, 0.9, 0.7) * spec * 0.5;
        col += vec3(0.1, 0.2, 0.3) * (1.0 - diff) * 0.3;
        
        float fogFactor = exp(-d * 0.02);
        vec3 fogColor = vec3(0.6, 0.7, 0.85);
        col = mix(fogColor, col, fogFactor);
    }
    
    vec3 volFog = volumetricFog(ro, rd, d > 0.0 ? d : MAX_DIST);
    col += volFog * 0.4;
    
    col = pow(col, vec3(0.4545));
    col = col * 1.2 - 0.1;
    col = mix(col, vec3(dot(col, vec3(0.33))), -0.2);
    
    gl_FragColor = vec4(col, 1.0);
}