precision highp float;

#define MAX_STEPS 100
#define MAX_DIST 50.0
#define SURF_DIST 0.001
#define FOG_DENSITY 0.04
#define TIME u_time

uniform vec2 u_resolution;
uniform float u_time;
uniform vec2 u_mouse;

float hash(vec2 p) {
    return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
}

float noise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    float a = hash(i);
    float b = hash(i + vec2(1.0, 0.0));
    float c = hash(i + vec2(0.0, 1.0));
    float d = hash(i + vec2(1.0, 1.0));
    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}

float fbm(vec2 p) {
    float value = 0.0;
    float amplitude = 0.5;
    float frequency = 1.0;
    for(int i = 0; i < 5; i++) {
        value += amplitude * noise(p * frequency);
        amplitude *= 0.5;
        frequency *= 2.0;
    }
    return value;
}

float sdPlane(vec3 p, float h) {
    return p.y - h;
}

float fractalTerrain(vec2 p) {
    float h = 0.0;
    float a = 1.0;
    float f = 1.0;
    for(int i = 0; i < 6; i++) {
        h += a * noise(p * f);
        a *= 0.5;
        f *= 2.1;
    }
    return h * 3.0 - 1.5;
}

float sceneSDF(vec3 p) {
    float terrain = sdPlane(p, -0.5) + fractalTerrain(p.xz * 0.3);
    float detail = fbm(p.xz * 2.0) * 0.15;
    return terrain + detail;
}

vec3 calcNormal(vec3 p) {
    vec2 e = vec2(0.001, 0.0);
    return normalize(vec3(
        sceneSDF(p + e.xyy) - sceneSDF(p - e.xyy),
        sceneSDF(p + e.yxy) - sceneSDF(p - e.yxy),
        sceneSDF(p + e.yyx) - sceneSDF(p - e.yyx)
    ));
}

float rayMarch(vec3 ro, vec3 rd, out float totalDist) {
    float d = 0.0;
    totalDist = 0.0;
    for(int i = 0; i < MAX_STEPS; i++) {
        vec3 p = ro + rd * d;
        float ds = sceneSDF(p);
        if(ds < SURF_DIST) return d;
        if(d > MAX_DIST) break;
        d += ds * 0.7;
        totalDist += ds * 0.7;
    }
    return -1.0;
}

vec3 applyFog(vec3 col, float dist, vec3 fogColor, vec3 rayDir) {
    float fogAmount = 1.0 - exp(-dist * FOG_DENSITY);
    float sunAmount = max(dot(rayDir, normalize(vec3(0.8, 0.4, 0.2))), 0.0);
    vec3 fog = mix(fogColor, fogColor + vec3(0.8, 0.6, 0.3) * pow(sunAmount, 8.0), 0.5);
    return mix(col, fog, fogAmount);
}

float volumetricFog(vec3 ro, vec3 rd, float maxDist) {
    float fog = 0.0;
    float stepSize = 0.3;
    int fogSteps = 20;
    
    for(int i = 0; i < 20; i++) {
        float t = float(i) * stepSize;
        if(t > maxDist) break;
        vec3 p = ro + rd * t;
        float h = max(0.0, p.y + 1.0);
        float density = exp(-h * 0.8) * (1.0 - t / maxDist);
        float noiseVal = fbm(p.xz * 0.5 + vec2(TIME * 0.1));
        density *= (0.5 + 0.5 * noiseVal);
        fog += density * stepSize;
    }
    return fog;
}

void main() {
    vec2 uv = (gl_FragCoord.xy - 0.5 * u_resolution.xy) / u_resolution.y;
    
    vec3 ro = vec3(0.0, 2.0 + sin(TIME * 0.2) * 0.5, -5.0);
    vec3 rd = normalize(vec3(uv, 1.0));
    
    float angle = TIME * 0.15;
    mat2 rot = mat2(cos(angle), -sin(angle), sin(angle), cos(angle));
    rd.xz = rot * rd.xz;
    
    vec3 lightPos = vec3(5.0, 8.0, -3.0);
    vec3 lightDir = normalize(lightPos);
    
    vec3 fogColor = vec3(0.4, 0.45, 0.55);
    
    float totalDist;
    float d = rayMarch(ro, rd, totalDist);
    
    vec3 col;
    
    if(d > 0.0) {
        vec3 p = ro + rd * d;
        vec3 n = calcNormal(p);
        
        float diff = max(dot(n, lightDir), 0.0);
        float amb = 0.2;
        
        vec3 viewDir = normalize(ro - p);
        vec3 reflDir = reflect(-lightDir, n);
        float spec = pow(max(dot(viewDir, reflDir), 0.0), 32.0);
        
        float slope = 1.0 - n.y;
        vec3 terrainColor = mix(
            vec3(0.15, 0.35, 0.1),
            vec3(0.4, 0.3, 0.2),
            smoothstep(0.3, 0.8, slope)
        );
        terrainColor = mix(terrainColor, vec3(0.6, 0.6, 0.65), smoothstep(1.0, 2.5, p.y));
        
        col = terrainColor * (diff + amb) + vec3(0.3) * spec;
        
        float volFog = volumetricFog(ro, rd, d);
        vec3 fogCol = mix(fogColor, vec3(0.9, 0.85, 0.7), volFog * 0.3);
        col = mix(col, fogCol, smoothstep(5.0, 30.0, d) * 0.5);
        
    } else {
        col = fogColor + vec3(0.15, 0.1, 0.05) * max(rd.y, 0.0);
    }
    
    float horizonFog = volumetricFog(ro, rd, MAX_DIST);
    vec3 finalFogColor = mix(
        vec3(0.5, 0.55, 0.6),
        vec3(0.9, 0.7, 0.5),
        pow(max(rd.y + 0.2, 0.0), 2.0)
    );
    col = mix(col, finalFogColor, horizonFog * 0.3);
    
    col = pow(col, vec3(0.4545));
    
    col *= 0.8 + 0.2 * sin(uv.y * 100.0 + TIME);
    
    gl_FragColor = vec4(col, 1.0);
}