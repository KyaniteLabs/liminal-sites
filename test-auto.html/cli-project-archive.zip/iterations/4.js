precision highp float;

uniform vec2 u_resolution;
uniform float u_time;
uniform vec2 u_mouse;

#define MAX_STEPS 80
#define MAX_DIST 100.0
#define SURF_DIST 0.001
#define FOG_STEPS 32
#define FOG_DENSITY 0.04

#define PI 3.14159265359

mat2 rot2D(float a) {
    float s = sin(a), c = cos(a);
    return mat2(c, -s, s, c);
}

float hash(vec2 p) {
    return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
}

float hash3(vec3 p) {
    return fract(sin(dot(p, vec3(127.1, 311.7, 74.7))) * 43758.5453);
}

float noise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    
    float a = hash(i);
    float b = hash(i + vec2(1.0, 0.0));
    float c = hash(i + vec2(0.0, 1.0));
    float d = hash(i + vec2(1.0, 1.0));
    
    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}

float noise3D(vec3 p) {
    vec3 i = floor(p);
    vec3 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    
    float n = mix(
        mix(mix(hash3(i), hash3(i + vec3(1,0,0)), f.x),
            mix(hash3(i + vec3(0,1,0)), hash3(i + vec3(1,1,0)), f.x), f.y),
        mix(mix(hash3(i + vec3(0,0,1)), hash3(i + vec3(1,0,1)), f.x),
            mix(hash3(i + vec3(0,1,1)), hash3(i + vec3(1,1,1)), f.x), f.y),
        f.z
    );
    return n;
}

float fbm(vec2 p) {
    float value = 0.0;
    float amplitude = 0.5;
    float frequency = 1.0;
    
    for (int i = 0; i < 6; i++) {
        value += amplitude * noise(p * frequency);
        amplitude *= 0.5;
        frequency *= 2.0;
    }
    return value;
}

float fbm3D(vec3 p) {
    float value = 0.0;
    float amplitude = 0.5;
    
    for (int i = 0; i < 4; i++) {
        value += amplitude * noise3D(p);
        amplitude *= 0.5;
        p *= 2.0;
    }
    return value;
}

float sdSphere(vec3 p, float r) {
    return length(p) - r;
}

float sdBox(vec3 p, vec3 b) {
    vec3 q = abs(p) - b;
    return length(max(q, 0.0)) + min(max(q.x, max(q.y, q.z)), 0.0);
}

float sdMenger(vec3 p, float scale) {
    float d = sdBox(p, vec3(1.0));
    float s = 1.0;
    
    for (int i = 0; i < 4; i++) {
        vec3 a = mod(p * s, 2.0) - 1.0;
        s *= scale;
        vec3 r = abs(1.0 - 3.0 * abs(a));
        
        float da = max(r.x, r.y);
        float db = max(r.y, r.z);
        float dc = max(r.z, r.x);
        float c = (min(da, min(db, dc)) - 1.0) / s;
        
        d = max(d, c);
    }
    return d;
}

float terrain(vec2 p) {
    float h = fbm(p * 0.15) * 3.0;
    h += fbm(p * 0.3 + 100.0) * 1.5;
    h += fbm(p * 0.6 + 200.0) * 0.75;
    
    float detail = fbm(p * 2.0 + u_time * 0.1) * 0.1;
    h += detail * (1.0 + 0.5 * sin(u_time * 0.5));
    
    return h;
}

float scene(vec3 p) {
    float ground = p.y + terrain(p.xz);
    
    vec3 mp = p;
    mp.y -= 2.0 + sin(u_time * 0.3) * 0.5;
    mp.xz *= rot2D(u_time * 0.2);
    float menger = sdMenger(mp * 0.5, 3.0);
    menger = max(menger, -sdSphere(mp * vec3(1, 2, 1), 1.5));
    
    vec3 crystalPos = p - vec3(0.0, -3.0, 5.0);
    crystalPos.xz *= rot2D(u_time * 0.1);
    float crystal = sdBox(crystalPos, vec3(0.5, 2.0, 0.5)) - 0.1;
    
    return min(ground, min(menger, crystal));
}

float raymarch(vec3 ro, vec3 rd) {
    float d = 0.0;
    
    for (int i = 0; i < MAX_STEPS; i++) {
        vec3 p = ro + rd * d;
        float ds = scene(p);
        d += ds * 0.8;
        if (ds < SURF_DIST || d > MAX_DIST) break;
    }
    
    return d;
}

vec3 getNormal(vec3 p) {
    vec2 e = vec2(0.001, 0.0);
    return normalize(vec3(
        scene(p + e.xyy) - scene(p - e.xyy),
        scene(p + e.yxy) - scene(p - e.yxy),
        scene(p + e.yyx) - scene(p - e.yyx)
    ));
}

float calcAO(vec3 p, vec3 n) {
    float occ = 0.0;
    float sca = 1.0;
    
    for (int i = 0; i < 5; i++) {
        float h = 0.01 + 0.12 * float(i);
        float d = scene(p + h * n);
        occ += (h - d) * sca;
        sca *= 0.95;
    }
    
    return clamp(1.0 - 3.0 * occ, 0.0, 1.0);
}

float softShadow(vec3 ro, vec3 rd, float mint, float maxt, float k) {
    float res = 1.0;
    float t = mint;
    
    for (int i = 0; i < 24; i++) {
        float h = scene(ro + rd * t);
        res = min(res, k * h / t);
        t += clamp(h, 0.02, 0.2);
        if (h < 0.001 || t > maxt) break;
    }
    
    return clamp(res, 0.0, 1.0);
}

vec3 fogColor(vec3 p) {
    float height = clamp(p.y * 0.1 + 0.5, 0.0, 1.0);
    float animatedNoise = fbm3D(p * 0.2 + vec3(u_time * 0.1, 0.0, u_time * 0.05));
    
    vec3 colorA = vec3(0.4, 0.15, 0.6);
    vec3 colorB = vec3(0.1, 0.3, 0.5);
    vec3 colorC = vec3(0.6, 0.2, 0.3);
    
    vec3 baseFog = mix(colorA, colorB, height);
    baseFog = mix(baseFog, colorC, animatedNoise * 0.5);
    
    return baseFog;
}

float volumetricFog(vec3 ro, vec3 rd, float maxDist) {
    float fogAccum = 0.0;
    float stepSize = maxDist / float(FOG_STEPS);
    float t = stepSize * hash(rd.xy * 1000.0 + u_time);
    
    for (int i = 0; i < FOG_STEPS; i++) {
        if (t > maxDist) break;
        
        vec3 p = ro + rd * t;
        float density = 0.0;
        
        float heightFalloff = exp(-max(p.y + 2.0, 0.0) * 0.3);
        density += FOG_DENSITY * heightFalloff;
        
        float noiseVal = fbm3D(p * 0.3 + vec3(u_time * 0.1, u_time * 0.05, 0.0));
        density *= 0.5 + noiseVal;
        
        float cloudNoise = fbm(p.xz * 0.1 + u_time * 0.02);
        density *= 1.0 + cloudNoise * 2.0;
        
        density *= stepSize;
        fogAccum += density * (1.0 - fogAccum);
        
        t += stepSize;
    }
    
    return fogAccum;
}

vec3 render(vec2 uv) {
    vec3 col = vec3(0.0);
    
    float mouseX = u_mouse.x * 2.0 - 1.0;
    float mouseY = u_mouse.y;
    
    vec3 ro = vec3(0.0, 4.0, -8.0);
    ro.xz *= rot2D(mouseX * PI);
    ro.y += mouseY * 3.0;
    
    vec3 ta = vec3(0.0, 0.0, 0.0);
    vec3 ww = normalize(ta - ro);
    vec3 uu = normalize(cross(vec3(0.0, 1.0, 0.0), ww));
    vec3 vv = cross(ww, uu);
    vec3 rd = normalize(uv.x * uu + uv.y * vv + 2.0 * ww);
    
    float d = raymarch(ro, rd);
    
    vec3 lightPos = vec3(5.0, 8.0, -3.0);
    lightPos.xz *= rot2D(u_time * 0.1);
    
    float fogDensity = volumetricFog(ro, rd, min(d, MAX_DIST));
    vec3 fog = fogColor(ro + rd * d * 0.5);
    
    if (d < MAX_DIST) {
        vec3 p = ro + rd * d;
        vec3 n = getNormal(p);
        
        vec3 lightDir = normalize(lightPos - p);
        float diff = max(dot(n, lightDir), 0.0);
        float shadow = softShadow(p + n * 0.02, lightDir, 0.1, 20.0, 16.0);
        
        vec3 viewDir = normalize(ro - p);
        vec3 halfDir = normalize(lightDir + viewDir);
        float spec = pow(max(dot(n, halfDir), 0.0), 32.0);
        
        float ao = calcAO(p, n);
        
        float height = (terrain(p.xz) - terrain(vec2(0.0))) * 0.3 + 0.5;
        
        vec3 rock = vec3(0.3, 0.25, 0.2);
        vec3 grass = vec3(0.2, 0.4, 0.15);
        vec3 snow = vec3(0.9, 0.95, 1.0);
        
        float grassAmount = smoothstep(-1.0, 0.0, height) * smoothstep(0.8, 0.5, height);
        float snowAmount = smoothstep(0.6, 0.9, height);
        
        vec3 albedo = mix(rock, grass, grassAmount);
        albedo = mix(albedo, snow, snowAmount);
        
        float detail = fbm3D(p * 5.0) * 0.2 + 0.9;
        albedo *= detail;
        
        vec3 ambient = vec3(0.15, 0.1, 0.2);
        vec3 litColor = albedo * (ambient + diff * shadow * vec3(1.0, 0.9, 0.8));
        litColor += spec * shadow * vec3(1.0, 0.9, 0.7) * 0.5;
        litColor *= ao;
        
        float fresnel = pow(1.0 - max(dot(n, viewDir), 0.0), 5.0);
        litColor += fresnel * vec3(0.2, 0.3, 0.5) * 0.3;
        
        col = litColor;
    }
    
    col = mix(col, fog, fogDensity);
    
    float sunFog = pow(max(dot(rd, normalize(lightPos)), 0.0), 8.0);
    col += sunFog * vec3(1.0, 0.8, 0.5) * fogDensity * 2.0;
    
    vec3 stars = vec3(0.0);
    float starNoise = hash(floor(rd.xy * 500.0));
    if (starNoise > 0.995) {
        float twinkle = 0.5 + 0.5 * sin(u_time * 3.0 + starNoise * 100.0);
        stars = vec3(0.8, 0.9, 1.0) * twinkle * (1.0 - fogDensity);
    }
    col += stars;
    
    return col;
}

void main() {
    vec2 uv = (gl_FragCoord.xy - 0.5 * u_resolution) / u_resolution.y;
    
    vec3 col = render(uv);
    
    col = col / (col + vec3(1.0));
    col = pow(col, vec3(0.4545));
    
    col += (hash(uv + u_time) - 0.5) * 0.02;
    
    gl_FragColor = vec4(col, 1.0);
}