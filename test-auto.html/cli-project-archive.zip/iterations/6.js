precision highp float;

uniform vec2 u_resolution;
uniform float u_time;
uniform vec2 u_mouse;

#define PI 3.14159265359
#define TAU 6.28318530718

float hash(vec2 p) {
    return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453123);
}

float noise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    
    float a = hash(i);
    float b = hash(i + vec2(1.0, 0.0));
    float c = hash(i + vec2(0.0, 1.0));
    float d = hash(i + vec2(1.0, 1.0));
    
    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}

float fbm(vec2 p) {
    float value = 0.0;
    float amplitude = 0.5;
    float frequency = 1.0;
    
    for (int i = 0; i < 5; i++) {
        value += amplitude * noise(p * frequency);
        amplitude *= 0.5;
        frequency *= 2.0;
    }
    return value;
}

vec2 warp(vec2 p, float t) {
    vec2 q = vec2(
        fbm(p + vec2(0.0, 0.0) + 0.15 * t),
        fbm(p + vec2(5.2, 1.3) + 0.12 * t)
    );
    
    vec2 r = vec2(
        fbm(p + 4.0 * q + vec2(1.7, 9.2) + 0.1 * t),
        fbm(p + 4.0 * q + vec2(8.3, 2.8) + 0.08 * t)
    );
    
    return r;
}

void main() {
    vec2 uv = gl_FragCoord.xy / u_resolution.xy;
    vec2 p = (gl_FragCoord.xy - 0.5 * u_resolution.xy) / min(u_resolution.x, u_resolution.y);
    
    float t = u_time * 0.3;
    
    vec2 offset = (u_mouse - 0.5) * 0.5;
    p += offset;
    
    p *= 2.5;
    
    vec2 w = warp(p, t);
    
    float pattern = fbm(p + 4.0 * w);
    
    float radial = length(p) * 0.8;
    pattern = mix(pattern, sin(pattern * TAU + t * 2.0) * 0.5 + 0.5, 0.3);
    
    float colorShift = pattern + t * 0.2;
    vec3 col = vec3(0.5) + 0.5 * cos(TAU * (vec3(0.0, 0.33, 0.67) + colorShift));
    
    float glow = pow(pattern, 2.0) * 1.5;
    col += glow * vec3(0.2, 0.4, 0.6);
    
    float edge = smoothstep(0.3, 0.7, pattern);
    col *= 0.7 + 0.3 * edge;
    
    float vignette = 1.0 - length(uv - 0.5) * 0.8;
    col *= vignette;
    
    col = pow(col, vec3(0.9));
    
    gl_FragColor = vec4(col, 1.0);
}