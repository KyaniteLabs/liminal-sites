precision highp float;

uniform vec2 u_resolution;
uniform float u_time;
uniform vec2 u_mouse;

#define MAX_STEPS 80
#define MAX_DIST 100.0
#define SURF_DIST 0.001
#define FOG_STEPS 32
#define PI 3.14159265359

float hash(vec2 p) {
    return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
}

float noise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    float a = hash(i);
    float b = hash(i + vec2(1.0, 0.0));
    float c = hash(i + vec2(0.0, 1.0));
    float d = hash(i + vec2(1.0, 1.0));
    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}

float fbm(vec2 p) {
    float value = 0.0;
    float amplitude = 0.5;
    float frequency = 1.0;
    for(int i = 0; i < 5; i++) {
        value += amplitude * noise(p * frequency);
        frequency *= 2.0;
        amplitude *= 0.5;
    }
    return value;
}

float terrain(vec2 p) {
    float height = fbm(p * 0.3 + u_time * 0.05) * 3.0;
    height += fbm(p * 0.8 + u_time * 0.02) * 1.0;
    return p.y - height;
}

float map(vec3 p) {
    return terrain(p.xz);
}

vec3 calcNormal(vec3 p) {
    vec2 e = vec2(0.01, 0.0);
    return normalize(vec3(
        map(p + e.xyy) - map(p - e.xyy),
        2.0 * e.x,
        map(p + e.yyx) - map(p - e.yyx)
    ));
}

float raymarch(vec3 ro, vec3 rd) {
    float t = 0.0;
    for(int i = 0; i < MAX_STEPS; i++) {
        vec3 p = ro + rd * t;
        float d = map(p);
        if(d < SURF_DIST || t > MAX_DIST) break;
        t += d * 0.5;
    }
    return t;
}

float fogDensity(vec3 p) {
    float base = fbm(p.xz * 0.1 + vec2(u_time * 0.1));
    float height = exp(-p.y * 0.3);
    return base * height * 0.5;
}

vec3 volumetricFog(vec3 ro, vec3 rd, float t) {
    vec3 fogColor = vec3(0.6, 0.7, 0.85);
    vec3 sunDir = normalize(vec3(0.5, 0.8, 0.3));
    float fogAmount = 0.0;
    float lightAmount = 0.0;
    float stepSize = min(t, MAX_DIST) / float(FOG_STEPS);
    
    for(int i = 0; i < FOG_STEPS; i++) {
        if(fogAmount > 0.95) break;
        float dist = float(i) * stepSize;
        if(dist > t) break;
        vec3 p = ro + rd * dist;
        float density = fogDensity(p);
        fogAmount += density * stepSize;
        float lightDensity = fogDensity(p + sunDir * 0.5);
        lightAmount += lightDensity * stepSize;
    }
    
    fogAmount = 1.0 - exp(-fogAmount * 2.0);
    lightAmount = exp(-lightAmount * 3.0);
    vec3 color = mix(fogColor, fogColor * vec3(1.2, 1.0, 0.8), lightAmount * 0.5);
    return color * fogAmount;
}

vec3 lighting(vec3 p, vec3 n, vec3 rd) {
    vec3 sunDir = normalize(vec3(0.5, 0.8, 0.3));
    vec3 sunColor = vec3(1.0, 0.95, 0.8);
    vec3 ambient = vec3(0.2, 0.25, 0.35);
    
    float diff = max(dot(n, sunDir), 0.0);
    float spec = pow(max(dot(reflect(-sunDir, n), -rd), 0.0), 32.0);
    
    vec3 col = ambient * 0.5;
    col += diff * sunColor * 0.7;
    col += spec * sunColor * 0.3;
    
    float slope = 1.0 - n.y;
    vec3 grassColor = vec3(0.2, 0.4, 0.15);
    vec3 rockColor = vec3(0.35, 0.3, 0.25);
    vec3 terrainColor = mix(grassColor, rockColor, smoothstep(0.3, 0.7, slope));
    
    return col * terrainColor;
}

void main() {
    vec2 uv = (gl_FragCoord.xy - 0.5 * u_resolution.xy) / u_resolution.y;
    vec2 mouse = u_mouse * 2.0 - 1.0;
    mouse.x *= u_resolution.x / u_resolution.y;
    
    float camHeight = 4.0 + sin(u_time * 0.2) * 1.0;
    float camDist = 8.0;
    float angle = u_time * 0.15 + mouse.x * 2.0;
    
    vec3 ro = vec3(sin(angle) * camDist, camHeight, cos(angle) * camDist);
    vec3 lookAt = vec3(0.0, 1.0, 0.0);
    
    vec3 forward = normalize(lookAt - ro);
    vec3 right = normalize(cross(vec3(0.0, 1.0, 0.0), forward));
    vec3 up = cross(forward, right);
    
    vec3 rd = normalize(forward + uv.x * right + uv.y * up);
    
    float t = raymarch(ro, rd);
    vec3 col = vec3(0.53, 0.81, 0.92);
    
    if(t < MAX_DIST) {
        vec3 p = ro + rd * t;
        vec3 n = calcNormal(p);
        col = lighting(p, n, rd);
    }
    
    vec3 fog = volumetricFog(ro, rd, t);
    col = mix(col, fog, 0.6);
    
    col = pow(col, vec3(0.4545));
    col = col * 0.6 + 0.4 * col * col * (3.0 - 2.0 * col);
    
    gl_FragColor = vec4(col, 1.0);
}