let particles = [];
const particleCount = 200;
let targetX, targetY;

function setup() {
  createCanvas(800, 600);
  pixelDensity(1);
  
  // Seed the noise function for consistent organic patterns
  noiseSeed(42);
}

function draw() {
  background(35, 50, 70);

  targetX = width / 2;
  targetY = height / 2;

  for (let i = 0; i < particleCount; i++) {
    particles[i].update();
    particles[i].show();
  }
}

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
}

class Particle {
  constructor() {
    this.pos = createVector(random(width), random(height));
    this.vel = p5.Vector.random2D().mult(0.5);
    this.acc = createVector(0, 0);
    this.maxSpeed = 3;
    
    // Create a range of blue shades for organic variation
    const shadeVariation = noise(random(particleCount)) * 10 + 180; 
    this.color = color(shadeVariation, 120 - random(50), 240);
  }

  update() {
    // Use Perlin noise to create a gentle flow field
    let xIndex = (this.pos.x * 0.01) % 1;
    let yIndex = (this.pos.y * 0.01) % 1;
    
    // Smoothly interpolate direction towards center using noise
    let targetAngle = map(noise(xIndex, yIndex), 0, 1, 0, TWO_PI);
    
    this.vel.setMag(this.maxSpeed);
    this.vel.heading(targetAngle);
    this.acc = p5.Vector.sub(this.vel.copy(), this.vel);
    
    // Apply gentle acceleration towards center with noise modulation
    let distToCenter = dist(targetX, targetY, this.pos.x, this.pos.y);
    let forceMag = map(distToCenter, 0, width * 0.5, -2, 0.5) + noise(xIndex + 100, yIndex + 100);
    
    if (distToCenter > 10) {
      this.acc.add(p5.Vector.sub(createVector(targetX, targetY), this.pos).normalize().mult(forceMag));
    }
    
    // Add some organic noise to position
    let xNoise = noise(xIndex + 200, yIndex + 200);
    let yNoise = noise(xIndex + 300, yIndex + 300);
    
    this.pos.x += this.vel.x;
    this.pos.y += this.vel.y;
    
    // Wrap around edges smoothly
    if (this.pos.x > width) { this.pos.x = 0; }
    else if (this.pos.x < 0) { this.pos.x = width; }
    if (this.pos.y > height) { this.pos.y = 0; }
    else if (this.pos.y < 0) { this.pos.y = height; }
    
    // Add a tiny bit of random jitter using Math.random() for discrete variation
    this.vel.x += random(-0.1, 0.1);
    this.vel.y += random(-0.1, 0.1);
  }

  show() {
    stroke(this.color);
    noFill();
    // Draw small particles that form the larger circle shape collectively
    ellipse(this.pos.x, this.pos.y, map(dist(targetX, targetY, this.pos.x, this.pos.y), 0, width/2, 4, 1));
  }
}