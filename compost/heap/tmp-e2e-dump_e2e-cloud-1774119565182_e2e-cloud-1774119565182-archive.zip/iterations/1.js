const text = "COLLISION";

function setup() {
  createCanvas(800, 600);
  pixelDensity(1);
  background(255);
}

function draw() {
  translate(width / 2, height / 2);

  for (let i = 0; i < text.length(); i++) {
    let charCode = text.charAt(i).charCodeAt(0);

    // Use noise to create organic flow field based on character position and time
    let n = noise(charCode * 0.01, frameCount * 0.02 + i) * 6;
    
    // Rotate the entire system slightly per character for variety
    rotate(n);
    
    push();
    
    // Position particles in a spiral based on the text index and noise
    let r = map(i, 0, text.length(), 50, width / 2 - 50);
    let theta = map(noise(charCode * 0.01 + frameCount * 0.01), 0, 1, PI, TWO_PI);
    
    translate(r * cos(theta), r * sin(theta));
    
    // The simple blue circle from the prompt
    noStroke();
    fill(30, 144, 255);
    ellipse(0, 0, map(i, 0, text.length(), 8, 20));
    
    pop();
  }

  // Draw a subtle background noise overlay
  strokeWeight(1);
  noFill();
  stroke(200);
  for (let x = -width/2; x < width; x += 5) {
    for (let y = -height/2; y < height; y += 5) {
      let nVal = noise(x * 0.01, y * 0.01, frameCount * 0.01);
      if (nVal > 0.98) {
        point(x + width/2, y + height/2);
      }
    }
  }
}

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
}