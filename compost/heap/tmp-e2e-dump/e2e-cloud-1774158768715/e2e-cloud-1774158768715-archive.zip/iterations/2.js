let particles = [];
const particleCount = 300;
const baseRadius = 25;
const textChars = "TEXT+CODE=COLLISION";
const fontSize = 16;

function setup() {
  pixelDensity(1);
  createCanvas(windowWidth, windowHeight);
  
  // Seed the noise function for organic movement patterns
  noiseSeed(42);
  
  for (let i = 0; i < particleCount; i++) {
    particles.push(new Particle());
  }
}

function draw() {
  background(15, 30, 60); // Deep dark blue background
  
  let x = width / 2;
  let y = height / 2;
  
  // Use noise for a subtle pulsing effect on the main circle radius
  let pulse = map(noise(frameCount * 0.1), 0, 1, baseRadius - 5, baseRadius + 10);
  
  // Draw the "simple blue circle" using noise-based organic variation
  noStroke();
  fill(65, 140, 255); // Soft periwinkle blue
  ellipse(x, y, pulse * 2);
  
  // Calculate text position based on frame count and noise for subtle drift
  let driftX = map(noise(frameCount * 0.02) + 1, 0, 2, -50, 50);
  let driftY = map(noise(frameCount * 0.03) + 1, 0, 2, -50, 50);
  
  push();
  translate(x + driftX, y + driftY);
  textAlign(CENTER, CENTER);
  fill(240, 248, 255); // Very light blue text for contrast
  textSize(fontSize * 3);
  textStyle(BOLD);
  noStroke();
  
  // Draw the text that represents "collision" with code
  text(textChars, 0, 0);
  pop();
  
  // Update and display particles (optional decoration)
  for (let i = 0; i < particleCount; i++) {
    particles[i].update();
    particles[i].show(x, y);
  }
}

class Particle {
  constructor() {
    this.pos = createVector(random(width), random(height));
    this.vel = p5.Vector.random2D().mult(random(0.5, 1.5));
    this.acc = createVector();
    this.maxSpeed = 4;
    this.size = random(1, 3);
  }
  
  apply(force) {
    this.acc.add(force);
  }
  
  update() {
    this.vel.add(this.acc);
    this.vel.limit(this.maxSpeed);
    this.pos.add(this.vel);
    this.acc.mult(0);
    
    // Bounce off edges
    if (this.pos.x > width || this.pos.x < 0) this.vel.x *= -1;
    if (this.pos.y > height || this.pos.y < 0) this.vel.y *= -1;
  }
  
  show(cx, cy) {
    // Attract particles gently towards the center circle using noise-modulated gravity
    let dx = cx - this.pos.x;
    let dy = cy - this.pos.y;
    let dist = sqrt(dx*dx + dy*dy);
    
    if (dist < 200) {
      let force = map(dist, 0, 200, 0.01, 0.05);
      this.apply(createVector(dx, dy).mult(force));
    }
    
    noStroke();
    fill(96, 184, 220); // Lighter blue for particles
    ellipse(this.pos.x, this.pos.y, this.size * 2);
  }
}