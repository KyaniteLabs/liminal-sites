let particles = [];
let words = ["COMPOST", "CREATE", "NOISE", "FLOW", "GENERIC"];
let wordIndex = 0;
let currentWord = "";

function setup() {
  pixelDensity(1);
  createCanvas(windowWidth, windowHeight);
  background(255);
  
  // Seed noise for organic movement
  noiseSeed(42);
  
  // Create initial particles based on the collision theme
  for (let i = 0; i < 300; i++) {
    let x = random(width);
    let y = random(height);
    
    // Push away from center to simulate explosion/collision aftermath
    let dx = x - width / 2;
    let dy = y - height / 2;
    let dist = sqrt(dx * dx + dy * dy);
    let angle = atan2(dy, dx);
    
    particles.push({
      x: x,
      y: y,
      vx: (dx / dist) * random(1, 3),
      vy: (dy / dist) * random(1, 3),
      size: random(3, 8),
      hue: 200 + random(50), // Blue range
      age: random(255),
      speed: random(-2, 2),
      decay: random(0.5, 1.5)
    });
  }
}

function draw() {
  background(245, 250, 255); // Very light blue background
  
  // Update and display particles
  for (let i = particles.length - 1; i >= 0; i--) {
    let p = particles[i];
    
    // Move particle
    p.x += p.vx * p.speed;
    p.y += p.vy * p.speed;
    
    // Friction to slow down
    p.vx *= 0.96;
    p.vy *= 0.96;
    
    // Wrap around edges
    if (p.x < 0) p.x = width;
    if (p.x > width) p.x = 0;
    if (p.y < 0) p.y = height;
    if (p.y > height) p.y = 0;
    
    // Color variation based on noise for organic feel
    let n = noise(p.x * 0.01, p.y * 0.01, frameCount * 0.01);
    let hueVar = map(n, 0, 1, -20, 20);
    
    // Draw the blue circle/particle
    noStroke();
    fill(195 + random(-30), 220 + random(-40), 255);
    
    // Use ellipse for the "simple circle" requirement but with organic variation
    // The size varies slightly based on noise
    let r = p.size * (0.8 + n * 0.4);
    
    drawCircle(p.x, p.y, r, hueVar);
    
    // If particle is moving very slowly and faded out, remove it to prevent lag
    if (abs(p.vx) < 0.1 && abs(p.vy) < 0.1 && p.age > 250) {
      particles.splice(i, 1);
    }
    
    // Slowly increase age factor for color shift over time
    p.age += p.decay;
  }

  // Text collision effect
  updateText();
}

function drawCircle(x, y, r, hueOffset) {
  // Create a subtle gradient effect using noise
  let gx = x + random(-10, 10);
  let gy = y + random(-10, 10);
  let n = noise(gx * 0.02, gy * 0.02, frameCount * 0.05);
  
  // Simple blue circle with slight organic color shift
  stroke(200, 230, 255);
  strokeWeight(r / 10);
  fill(hueOffset + n * 40);
  ellipse(x, y, r * 2, r * 2);
}

function updateText() {
  // Cycle through words randomly to simulate text collision/impact
  if (frameCount % 60 === 0) {
    wordIndex = random(5);
    currentWord = words[wordIndex];
  }
  
  textSize(random(80, 120));
  textAlign(CENTER, CENTER);
  fill(100);
  noStroke();
  
  // Text fades in and out like a collision impact
  let alpha = map(noise(frameCount * 0.05), 0, 1, 0, 255);
  stroke(0);
  strokeWeight(1);
  textSize(40);
  text(currentWord, width / 2 + random(-30, 30), height / 2 + random(-30, 30));
  
  // Draw a small "shockwave" circle behind the text occasionally
  if (frameCount % 180 === 0) {
    push();
    translate(width/2, height/2);
    noStroke();
    fill(180, 200, 255, 20);
    ellipse(0, 0, width * 0.8, height * 0.6);
    pop();
  }
}

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
  background(245, 250, 255);
  
  // Re-init particles on resize to maintain density
  for (let i = particles.length - 1; i >= 0; i--) {
    let p = particles[i];
    
    // Push away from new center
    let dx = p.x - width / 2;
    let dy = p.y - height / 2;
    let dist = sqrt(dx * dx + dy * dy);
    let angle = atan2(dy, dx);
    
    particles[i].vx = (dx / dist) * random(1, 3);
    particles[i].vy = (dy / dist) * random(1, 3);
  }
}