let particles = [];
const particleCount = 60;
let noiseOffsetX = 0;
let noiseOffsetY = 0;

class Particle {
  constructor() {
    this.pos = createVector(random(width), random(height));
    this.vel = p5.Vector.random2D();
    this.acc = createVector(0, 0);
    this.maxSpeed = map(noise(particleCount + noiseOffsetX), 0, 1, 1, 3);
    this.radius = map(noise(particleCount + noiseOffsetY) * 10, 2, 8);
    this.baseColor = color(59, 130, 246); // Blue
  }

  applyForce(force) {
    this.acc.add(force);
  }

  update() {
    this.vel.add(this.acc);
    let speed = this.vel.mag();
    if (speed > this.maxSpeed) {
      this.vel.setMag(this.maxSpeed);
    }
    this.pos.add(this.vel);
    
    // Bounce off walls
    if (this.pos.x < 0 || this.pos.x > width) this.vel.x *= -1;
    if (this.pos.y < 0 || this.pos.y > height) this.vel.y *= -1;
    
    this.acc.mult(0);
  }

  show() {
    let x = constrain(this.pos.x, 0, width);
    let y = constrain(this.pos.y, 0, height);
    
    // Calculate color based on noise for smooth gradients
    let hue = map(noise(x * 0.01 + y * 0.01 + frameCount * 0.002), 0, 1, 195, 240); // Blue to Light Blue range
    let saturation = 80;
    let lightness = map(noise(x * 0.02 + y * 0.02), 0, 1, 50, 70);
    
    fill(hue, saturation, lightness);
    noStroke();
    circle(x, y, this.radius);
  }
}

function setup() {
  createCanvas(windowWidth, windowHeight);
  pixelDensity(1);
  
  noiseSeed(429876);
  
  // Initialize particles with random positions and velocities
  for (let i = 0; i < particleCount; i++) {
    particles.push(new Particle());
  }
}

function draw() {
  background(15, 23, 42); // Dark blue background
  
  noiseOffsetX += 0.001;
  noiseOffsetY += 0.001;
  
  for (let i = 0; i < particles.length; i++) {
    let p = particles[i];
    
    // Apply repulsion forces from other particles (Collision avoidance)
    for (let j = i + 1; j < particles.length; j++) {
      let other = particles[j];
      let distVec = p5.Vector.sub(other.pos, p.pos);
      let distSq = distVec.magSq();
      
      // Simple collision detection logic: if too close, push apart
      let minDist = 100; 
      if (distSq < minDist * minDist) {
        let forceMag = map(distSq, 0, minDist * minDist, 0.5, 2);
        distVec.setMag(1 / sqrt(distSq)); // Normalize
        distVec.mult(forceMag);
        
        p.applyForce(p5.Vector.copy(distVec).mult(-0.5));
        other.applyForce(p5.Vector.copy(distVec).mult(0.5));
      }
    }
    
    p.update();
    p.show();
  }
}

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
}