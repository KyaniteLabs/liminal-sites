let particles;
let hueOffset = 200; // Base blue-ish hue

function setup() {
  createCanvas(800, 600);
  pixelDensity(1);
  background(0);
  
  // Initialize particle system for the organic circle effect
  let cols = int(width / 5);
  particles = [];
  for (let i = 0; i < cols; i++) {
    particles[i] = [];
    for (let j = 0; j < height; j++) {
      particles[i][j] = 0;
    }
  }
  
  // Seed noise for a specific, reproducible organic pattern
  noiseSeed(1337);
}

function draw() {
  noStroke();
  
  // Use Perlin noise to create an organic "blue circle" shape
  // We map the distance from center using noise values
  
  let r = width / 2;
  let c = height / 2;
  
  for (let i = 0; i < cols; i++) {
    for (let j = 0; j < rows; j++) {
      // Create a radial gradient effect using noise
      // The x and y coordinates are normalized to create circular symmetry
      let nx = map(i, 0, cols, -1.5, 1.5);
      let ny = map(j, 0, rows, -2, 2);
      
      // Use a combination of noise values to define the radius
      // This creates soft, organic edges instead of hard geometric circles
      
      // Combine noise at different scales for depth
      let val1 = noise(nx * 0.5 + frameCount * 0.002, ny * 0.5 + frameCount * 0.002);
      let val2 = noise(nx * 3, ny * 3);
      
      // Create a circular mask based on distance from center combined with noise
      // We want the area where the "blue" is dominant to form a circle shape
      
      // Distance from center (normalized)
      let dist = dist(i + r/2, j + c/2, r, c);
      let maxDist = sqrt(pow(cols, 2) + pow(rows, 2));
      
      // The "circle" logic: if the noise value is high enough within a certain radius range
      let threshold = val1 * val2;
      
      // Create a soft circle using smoothstep on distance and noise influence
      let alpha = map(val1, 0.5, 0.95, 0, 1);
      
      // Color based on blue hue with organic variation
      let h = (hueOffset + val2 * 60) % 360;
      let s = map(val1, 0.5, 0.95, 70, 90);
      let l = map(dist/maxDist, 0.8, 0, 40, 80); // Darker edges, lighter center
      
      if (alpha > 0) {
        fill(hue(h), s, l);
        rect(i * 5, j, 5, 5);
      }
    }
  }
  
  // Add a subtle glow using blending mode
  blendMode(BLEND);
  fill(200);
  noStroke();
  ellipse(width/2, height/2, width * 1.5);
  blendMode(BLEND);
}

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
  cols = int(width / 5);
  rows = int(height / 5); // Assuming square pixels for simplicity in this loop structure
}