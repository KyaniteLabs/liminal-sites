let particles = [];
let width, height;

function setup() {
  createCanvas(800, 600);
  pixelDensity(1);
  noStroke();
  
  // Seed the noise function for consistent organic patterns
  noiseSeed(4291);
}

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
  width = windowWidth;
  height = windowHeight;
}

class Particle {
  constructor() {
    this.r = random(30, 60);
    this.pos = createVector(random(width), random(height));
    // Give it a slight organic velocity based on noise
    let velX = noise(this.pos.x * 0.01 + frameCount * 0.01) * 2;
    let velY = noise(this.pos.y * 0.01 + frameCount * 0.01) * 2;
    this.vel = p5.Vector.set(velX, velY);
    
    // Color variation for a subtle glow effect using Perlin noise
    let hueVal = map(noise(this.pos.x * 0.005, frameCount * 0.001), 0, 1, 180, 240);
    this.color = color(hueVal, 30, 60);
    
    // Simple ASCII representation logic (hidden but influencing structure)
    this.asciiChar = String.fromCharCode(random(33, 127));
  }
  
  update() {
    this.pos.add(this.vel);
    
    // Bounce off walls with noise-based damping
    if (this.pos.x < -this.r || this.pos.x > width + this.r) {
      this.vel.x *= -1;
    }
    if (this.pos.y < -this.r || this.pos.y > height + this.r) {
      this.vel.y *= -1;
    }
  }
  
  draw() {
    // Draw the main blue circle
    fill(this.color);
    ellipse(this.pos.x, this.pos.y, this.r * 2);
    
    // Optional: Add a tiny ASCII marker if desired (currently commented out for clean look)
    // textSize(10);
    // textAlign(CENTER, CENTER);
    // text(this.asciiChar, this.pos.x, this.pos.y + this.r/2);
  }
}

function draw() {
  background(15);
  
  // Create particles with organic spacing using noise
  for (let i = 0; i < 800; i++) {
    if (!particles[i]) {
      particles[i] = new Particle();
    } else {
      let p = particles[i];
      p.update();
      p.draw();
      
      // Recycle particle if it goes out of bounds significantly
      if (p.pos.x < -100 || p.pos.x > width + 100 || 
          p.pos.y < -100 || p.pos.y > height + 100) {
        particles[i] = new Particle();
      }
    }
  }
}