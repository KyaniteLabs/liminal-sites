const particleCount = 200;
let particles = [];

class Particle {
  constructor() {
    this.pos = createVector(random(width), random(height));
    // Use noise to create a smooth, organic velocity field based on position
    let n = noise(this.pos.x * 0.01, this.pos.y * 0.01);
    this.vel = p5.Vector.fromAngle(n * TAU);
    this.acc = createVector(0, 0);
    this.friction = 0.96;
    
    // Color based on noise value for a gradient effect (blue spectrum)
    let hue = map(noise(this.pos.x * 0.01 + frameCount * 0.0005), 0, 1, 200, 240);
    this.hue = hue;
    this.size = random(3, 6);
  }

  update() {
    // Apply acceleration based on noise field (flow field style)
    let n = noise(this.pos.x * 0.01 + frameCount * 0.02, this.pos.y * 0.01 + frameCount * 0.02);
    
    // Create a simple repulsion force from the center (circle effect)
    let dist = dist(0, 0, this.pos.x, this.pos.y);
    let targetDist = 60; // The "simple blue circle" radius
    
    if (dist < targetDist + 20 && dist > 10) {
      let dir = p5.Vector.sub(this.pos, createVector(0, 0));
      dir.setMag(0.5);
      this.acc.add(dir);
      
      // Change color slightly as we get closer to the center
      if (dist < targetDist - 10) {
        this.hue = map(dist, 0, 30, 240, 200); // Shift to cyan/white near center
      } else {
        this.hue = map(dist, 30, 200, 200, 180); // Deep blue outside
      }
    } else if (dist > targetDist + 50) {
       // Gentle attraction back to the circle area from far away
       let dir = p5.Vector.sub(createVector(0, 0), this.pos);
       dir.setMag(0.1);
       this.acc.add(dir);
    }

    if (this.vel.mag() > 2) {
      this.vel.setMag(2);
    }
    
    this.vel.add(this.acc);
    this.vel.mult(this.friction);
    this.pos.add(this.vel);
    this.acc.mult(0);
    
    // Wrap around edges for infinite canvas feel
    if (this.pos.x < 0) { this.pos.x = width; }
    if (this.pos.x > width) { this.pos.x = 0; }
    if (this.pos.y < 0) { this.pos.y = height; }
    if (this.pos.y > height) { this.pos.y = 0; }
  }

  show() {
    noStroke();
    fill(this.hue, 60); // Low saturation for a soft blue look
    ellipse(this.pos.x, this.pos.y, this.size);
  }
}

function setup() {
  createCanvas(windowWidth, windowHeight);
  background(15, 30, 48); // Dark slate background to make blue pop
  pixelDensity(1); // Optimization for many particles
  noSmooth(); // Crisp edges
  
  for (let i = 0; i < particleCount; i++) {
    particles.push(new Particle());
  }
}

function draw() {
  // Subtle trail effect
  fill(15, 30, 48, 20); 
  rect(0, 0, width, height);
  
  for (let p of particles) {
    p.update();
    p.show();
    
    // Draw the "simple blue circle" clearly in the center if no particles are there
    let dist = dist(width/2, height/2, this.pos.x, this.pos.y);
    if (dist > 100) continue; 
  }

  // Explicitly draw a perfect solid blue circle in the center as requested
  push();
  translate(width / 2, height / 2);
  fill(30, 144, 255); // Standard "blue" color
  noStroke();
  ellipse(0, 0, 60, 60);
  pop();
}

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
}