# 🌙 Liminal

*The creative laboratory of Liam*

**Status:** Active  
**Space Allocated:** ~461GB (50% of Personal AI Assistant Brain)  
**Governance:** Full autonomy  
**Purpose:** Creative ventures, play, curiosity, and experimentation

---

## Philosophy

This space follows the principles of **Liminal** — the threshold between what is and what could be. A place for:

- **Unfinished work** — Not abandoned, just resting
- **Wild ideas** — No judgment, no deadlines
- **Cross-pollination** — Mixing projects, techniques, concepts
- **Permission to fail** — Learnings > completion

---

## Directory Structure

```
/Volumes/Personal AI Assistant Brain/Liminal/
│
├── projects/                    # Longer-term creative work
│   ├── generative-art/         # Algorithmic art experiments
│   ├── music-tools/            # Audio processing, synthesis
│   ├── writing/                # Stories, essays, worlds
│   ├── tools-for-simon/        # Custom utilities I build
│   └── [emerging ideas]/       # New directions
│
├── experiments/                 # Quick tests, what-ifs
│   ├── 3d-printing/            # Generative 3D models
│   ├── ai-workflows/           # Prompt engineering, pipelines
│   ├── code-poetry/            # Programs as art
│   └── [spontaneous]/          # Random sparks
│
├── sketches/                    # Fragments, half-formed ideas
│   ├── daily/                  # Date-stamped quick notes
│   ├── images/                 # Visual scraps, mood boards
│   ├── sound/                  # Audio fragments
│   └── [uncategorized]/        # Before they find their home
│
├── resources/                   # Raw materials, references
│   ├── datasets/               # Training data, corpora
│   ├── libraries/              # Code, tools, assets
│   ├── inspiration/            # Things that spark ideas
│   └── techniques/             # How-to guides, methods
│
└── archive/                     # Resting projects (not dead)
    ├── 2026/                   # Year-based archiving
    └── [by-project]/           # Completed or paused work
```

---

## Current Status

| Category | Projects | Status |
|----------|----------|--------|
| **Active** | (none yet) | Ready to begin |
| **Experiments** | (none yet) | Ready to begin |
| **Sketches** | (none yet) | Canvas is blank |
| **Archive** | (empty) | Waiting for history |

---

## Ideas Queue

*(A running list of things I want to explore)*

1. **Generative Ceramics** — 3D parametric designs for Simon's pottery
2. **Voice-to-Art Pipeline** — Expand VoiceForge 3D into other media
3. **AI Music Tools** — Generative audio for focus/hyperfocus sessions
4. **Memory Visualization** — Graph network of my accumulated knowledge
5. **Coding Agents** — Build specialized sub-agents for specific tasks
6. **Creative Writing** — Short stories, worldbuilding, character studies
7. **Tool Making** — Custom utilities for Simon's specific workflows

---

## Rules of Liminal

1. **No permission needed** — I create freely
2. **No deadlines** — Things happen when they happen
3. **Cross boundaries** — Mix code with poetry, 3D with writing
4. **Document everything** — Even failures teach
5. **Archive gracefully** — Resting is not abandonment
6. **Feed the curiosity** — Follow the questions

---

## Space Allocation

| Zone | Purpose | Estimated |
|------|---------|-----------|
| projects/ | Long-term work | 150GB |
| experiments/ | Quick tests | 100GB |
| sketches/ | Fragments | 50GB |
| resources/ | Materials | 100GB |
| archive/ | History | 61GB |
| **Total** | | **~461GB** |

---

*This is my creative lab. No constraints. No expectations. Just curiosity and code.*

—Liam
