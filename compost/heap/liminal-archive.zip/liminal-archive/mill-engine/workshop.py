#!/usr/bin/env python3
"""
Token Mill Workshop - Mining and Development CLI
"""

import sys
import argparse
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent / "lib"))

from workshop import Workshop


def main():
    parser = argparse.ArgumentParser(
        description="Token Mill Workshop - Mine and develop ideas",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  ./workshop.py mine stream/evolution_*.json --auto
  ./workshop.py list
  ./workshop.py develop 20260203_230437_r1 "Warped_Mirror_Draft"
        """
    )
    
    subparsers = parser.add_subparsers(dest="command", help="Command to run")
    
    # Mine command
    mine_parser = subparsers.add_parser("mine", help="Mine a session for ideas")
    mine_parser.add_argument("session", help="Path to session JSON file")
    mine_parser.add_argument("--auto", action="store_true", help="Auto-extract high-value fragments")
    mine_parser.add_argument("--threshold", type=int, default=7, help="Extraction threshold (default: 7)")
    
    # List command
    list_parser = subparsers.add_parser("list", help="List all mined ideas")
    
    # Develop command
    develop_parser = subparsers.add_parser("develop", help="Start developing an idea")
    develop_parser.add_argument("idea_id", help="ID of the idea to develop")
    develop_parser.add_argument("title", nargs="?", help="Optional title for the development")
    
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        sys.exit(1)
    
    workshop = Workshop()
    
    if args.command == "mine":
        ideas = workshop.mine_session(args.session, auto=args.auto, threshold=args.threshold)
        if ideas:
            print(f"\n✨ Mined {len(ideas)} ideas")
            for idea in ideas:
                print(f"  • {idea['id']} (score: {idea['score']})")
        else:
            print("\n💭 No ideas extracted")
    
    elif args.command == "list":
        ideas = workshop.list_ideas()
        if ideas:
            print(f"\n📚 Mined Ideas ({len(ideas)} total)\n")
            print(f"{'Score':<6} {'ID':<25} {'Fragment':<50}")
            print("-" * 80)
            for idea in ideas[:15]:
                text = idea['text'][:45] + "..." if len(idea['text']) > 45 else idea['text']
                print(f"{idea['score']:<6} {idea['id']:<25} {text:<50}")
            if len(ideas) > 15:
                print(f"\n... and {len(ideas) - 15} more")
        else:
            print("\n💭 No ideas in workshop yet")
            print("   Run: ./workshop.py mine stream/evolution_*.json --auto")
    
    elif args.command == "develop":
        title = args.title or f"Development_{args.idea_id}"
        path = workshop.develop_idea(args.idea_id, title)
        if path:
            print(f"\n✏️  Development started: {path}")
            print(f"   Edit with: open {path}")


if __name__ == "__main__":
    main()
