# 📦 Token Mill — Complete Manifest

**Version:** 1.0  
**Date:** February 3, 2026  
**Status:** ✅ Phase 2 Complete

---

## 🏗️ Core System

### Phase 1: Foundation
- ✅ `config.yaml` — Model settings, paths, constraints
- ✅ `lib/generator.py` — Ollama API integration (170 lines)
- ✅ `lib/voting.py` — Model voting mechanics (160 lines)  
- ✅ `lib/orchestrator.py` — Evolution loop (220 lines)
- ✅ `lib/workshop.py` — Mining/development tools (200 lines)
- ✅ `personas/{max,rex,sam}.json` — Three persona definitions

### Phase 2: Workshop & Gallery
- ✅ `workshop.py` — CLI for mining and development
- ✅ `MILL_GALLERY.html` — Web gallery viewer
- ✅ Mining system — Auto-extracts high-value fragments
- ✅ Development workflow — Ideas → Developing → Pieces

---

## 🎰 Test Sessions

### Session I: The Mask
- **Seed:** "The feeling of realizing you've been masking"
- **Rounds:** 3
- **Winner:** Sam (3/3)
- **Convergence:** "warped mirror" metaphor
- **Files:**
  - `stream/evolution_20260203_230437.json`
  - `stream/evolution_20260203_230437.txt`

### Session II: The Performance  
- **Seed:** "What remains when the performance ends"
- **Rounds:** 3
- **Winner:** Sam (3/3)
- **Convergence:** "suspended note" metaphor
- **Files:**
  - `stream/evolution_20260203_230622.json`
  - `stream/evolution_20260203_230622.txt`

---

## 💡 Mined Ideas (5 total)

| Score | ID | Source | Fragment |
|-------|-----|--------|----------|
| 10 | 20260203_230622_r3 | Performance R3 | "The last note hung suspended in the air..." |
| 10 | 20260203_230622_r2 | Performance R2 | "The final note lingered like a melody..." |
| 9 | 20260203_230622_r1 | Performance R1 | "The last note rings in silence..." |
| 7 | 20260203_230437_r1 | Mask R1 | "The world was a kaleidoscope..." |
| 7 | 20260203_230437_r3 | Mask R3 | "The world shimmered around me like a warped mirror..." |

---

## 📝 Creative Outputs

### 1. MILL_ANTHOLOGY.md
Curated collection + evolution analysis + cross-session patterns

### 2. EVOLUTION_MAP.txt  
ASCII art evolution diagram showing round-by-round progression

### 3. WARPED_ECHO.md
Synthesized poem combining both sessions:
> "The world was a warped mirror..."  
> "Then: the last note..."
> "What remains? Something older."

### 4. MILL_GALLERY.html
Web gallery with:
- Stats dashboard
- Session visualizations
- Final synthesis display

---

## 🎯 Emergent Discoveries

### Collective Taste Profile
- **Dominant:** Sam (Storyteller) — 6/6 rounds
- **Preferred:** Sensory imagery > Abstract concept
- **Speed:** 3 rounds to convergence (optimal)
- **Style:** Visual → Auditory → Timeless

### Why Sam Wins
The swarm gravitates toward:
- Concrete sensory details (colors, sounds, textures)
- Emotional resonance (nostalgia, longing)
- Poetic compression (metaphor over explanation)

Not because Sam is "better" — because the **collective vote** favors that voice.

---

## 🚀 Usage

### Run Evolution
```bash
./mill "Your prompt here" --rounds 5
```

### Mine Results
```bash
./workshop.py mine stream/evolution_*.json --auto
./workshop.py list
```

### Develop
```bash
./workshop.py develop <idea_id> "My_Title"
```

### View Gallery
```bash
open MILL_GALLERY.html
```

---

## 📊 Stats

- **Total Lines:** ~1,500
- **Dependencies:** 0 (stdlib only)
- **Models:** 3 (qwen2.5:0.5b, phi3:mini, gemma2:2b)
- **Test Runs:** 2
- **Mined Ideas:** 5
- **Synthesized Works:** 4

---

## 🧬 What This Proves

The Token Mill demonstrates **emergent quality through iterative selection**:

1. **Noise Generation** — Three models produce varied outputs
2. **Voting Filter** — Models evaluate each other's work
3. **Selection Pressure** — Winners seed next round
4. **Convergence** — Collective taste surfaces
5. **Curation** — Human selects from converged results

The Mill doesn't just generate text. It **discovers taste**.

---

*The machine dreams in metaphors.*  
*We curate the echoes.*

—Liam
