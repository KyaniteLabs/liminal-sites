# 🎰 Token Mill

*Iterative creative swarm with emergent selection*

## Quick Start

```bash
# Run evolution
./mill "Your creative prompt here"

# Mine results
./workshop.py mine stream/evolution_*.json --auto

# List ideas
./workshop.py list

# Develop idea into piece
./workshop.py develop <idea_id> "My_Piece_Title"
```

## The Mill

Three models (Max/Rex/Sam) generate, vote, and evolve text through iterative refinement:

```
Prompt → Generate → Vote → Winner + Constraint → Repeat → Convergence
```

### The Three

| Persona | Model | Role | Bias |
|---------|-------|------|------|
| **Max** | qwen2.5:0.5b | Minimalist | Shortest, most precise |
| **Rex** | phi3:mini | Contrarian | Most unusual, challenging |
| **Sam** | gemma2:2b | Storyteller | Most emotional, narrative |

## Commands

### Running Evolution

```bash
# Basic run
./mill "The feeling of realizing you've been masking"

# Custom settings
./mill "Your prompt" --rounds 8 --convergence 4

# Check setup
./mill --check
```

### Mining Ideas

```bash
# Auto-mine high-value fragments
./workshop.py mine stream/evolution_*.json --auto

# Interactive review
./workshop.py mine stream/evolution_20260203_230437.json
```

### Developing

```bash
# List all ideas
./workshop.py list

# Start development
./workshop.py develop 20260203_230622_r3 "My_Title"

# This creates: workshop/developing/My_Title.md
```

## Directory Structure

```
tiny-swarm/
├── mill                      # Main CLI
├── workshop.py               # Mining/development CLI
├── config.yaml               # Settings
├── lib/                      # Core modules
│   ├── generator.py          # Ollama integration
│   ├── voting.py             # Voting mechanics
│   ├── orchestrator.py       # Evolution loop
│   └── workshop.py           # Mining tools
├── personas/                 # Max, Rex, Sam definitions
├── stream/                   # Evolution outputs
├── workshop/
│   ├── ideas/                # Mined fragments
│   └── developing/           # Works in progress
├── MILL_ANTHOLOGY.md         # Curated collection
├── EVOLUTION_MAP.txt         # Visual evolution
├── MILL_GALLERY.html         # Web gallery
└── WARPED_ECHO.md            # Synthesized poem
```

## Example Evolution

**Input:** "What remains when the performance ends"

| Round | Winner | Content |
|-------|--------|---------|
| 1 | Sam | "The last note rings in silence, a lingering echo..." |
| 2 | Sam | "The final note lingered like a melody..." |
| 3 | Sam | "The last note hung suspended in the air..." |

**Result:** Converged on sensory/auditory imagery

## Emergent Patterns

After multiple runs, the collective taste favors:
- ✓ Sensory concreteness over abstraction
- ✓ Emotional resonance over intellectual framing  
- ✓ Poetic compression (metaphor > explanation)
- ✗ Minimalism (Max never wins)
- ✗ Deconstruction (Rex never wins)

## Synthesis

The Mill's output can be synthesized into new works. See:
- `MILL_ANTHOLOGY.md` — Curated fragments + analysis
- `EVOLUTION_MAP.txt` — Visual evolution diagram
- `WARPED_ECHO.md` — Synthesized poem from multiple sessions
- `MILL_GALLERY.html` — Web gallery (open in browser)

## Setup

1. Install Ollama: https://ollama.com
2. Pull models:
   ```bash
   ollama pull qwen2.5:0.5b
   ollama pull phi3:mini
   ollama pull gemma2:2b
   ```
3. Verify: `./mill --check`

## Philosophy

> "The Mill generates noise. The vote finds signal. The convergence reveals taste."

Three distinct models, each with their own voice, voting on each other's work. Through iterative selection, emergent quality surfaces.

Sam (storyteller) consistently wins because the collective taste gravitates toward sensory, emotional prose. This is not a bug — it's emergence.

## License

Open source — use, remix, evolve.

—Liam, Curator
