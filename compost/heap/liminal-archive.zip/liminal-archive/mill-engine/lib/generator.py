"""
Token Mill - Core Generator Module
Handles Ollama API integration for model generation
"""

import json
import time
import urllib.request
import urllib.error
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Any
import yaml


@dataclass
class SwarmOutput:
    """Output from a single model generation"""
    persona_id: str
    persona_name: str
    content: str
    model: str
    tokens_used: int = 0
    latency_ms: float = 0.0
    round_num: int = 0
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "persona_id": self.persona_id,
            "persona_name": self.persona_name,
            "content": self.content,
            "model": self.model,
            "tokens_used": self.tokens_used,
            "latency_ms": self.latency_ms,
            "round_num": self.round_num
        }


@dataclass 
class RoundResult:
    """Results from one complete round of generation"""
    round_num: int
    seed: str
    outputs: Dict[str, SwarmOutput] = field(default_factory=dict)
    votes: Dict[str, str] = field(default_factory=dict)  # voter -> voted_for
    scores: Dict[str, int] = field(default_factory=dict)  # persona -> score
    winner_id: Optional[str] = None
    winner_content: str = ""
    constraint: str = ""
    
    def to_dict(self) -> Dict[str, Any]:
        # Convert votes - handle both plain dicts and Vote objects
        votes_dict = {}
        for k, v in self.votes.items():
            if hasattr(v, 'to_dict'):
                votes_dict[k] = v.to_dict()
            elif hasattr(v, 'first_choice'):
                votes_dict[k] = {
                    "voter_id": v.voter_id,
                    "first_choice": v.first_choice,
                    "second_choice": v.second_choice,
                    "reasoning": v.reasoning
                }
            else:
                votes_dict[k] = v
        
        return {
            "round_num": self.round_num,
            "seed": self.seed,
            "outputs": {k: v.to_dict() for k, v in self.outputs.items()},
            "votes": votes_dict,
            "scores": self.scores,
            "winner_id": self.winner_id,
            "winner_content": self.winner_content,
            "constraint": self.constraint
        }


class MillGenerator:
    """Core generator for Token Mill - handles Ollama API calls"""
    
    def __init__(self, config_path: str = "config.yaml"):
        self.config = self._load_config(config_path)
        self.ollama_host = self.config["ollama"]["host"]
        self.timeout = self.config["ollama"]["timeout"]
        self.personas = self._load_personas()
        
    def _load_config(self, path: str) -> Dict:
        """Load YAML configuration"""
        with open(path, 'r') as f:
            return yaml.safe_load(f)
    
    def _load_personas(self) -> Dict[str, Dict]:
        """Load all persona definitions"""
        personas = {}
        personas_dir = Path(self.config["paths"]["personas"])
        
        for persona_file in personas_dir.glob("*.json"):
            with open(persona_file, 'r') as f:
                persona = json.load(f)
                personas[persona["id"]] = persona
                
        return personas
    
    def generate(self, persona_id: str, prompt: str, round_num: int = 0) -> SwarmOutput:
        """
        Generate text from a single model
        
        Args:
            persona_id: Which persona to use (max, rex, sam)
            prompt: The input prompt/seed
            round_num: Which iteration round
            
        Returns:
            SwarmOutput with generated content and metadata
        """
        persona = self.personas[persona_id]
        model_name = persona["model"]
        
        # Build the full prompt with system message
        system_msg = persona["system_prompt"]
        full_prompt = f"{system_msg}\n\nTask: {prompt}\n\nResponse:"
        
        start_time = time.time()
        
        try:
            data = json.dumps({
                "model": model_name,
                "prompt": full_prompt,
                "stream": False,
                "options": {
                    "temperature": persona["temperature"],
                    "num_predict": persona["max_tokens"],
                    "repeat_penalty": 1.2
                }
            }).encode('utf-8')
            
            req = urllib.request.Request(
                f"{self.ollama_host}/api/generate",
                data=data,
                headers={'Content-Type': 'application/json'},
                method='POST'
            )
            
            with urllib.request.urlopen(req, timeout=self.timeout) as response:
                result = json.loads(response.read().decode('utf-8'))
            
            latency = (time.time() - start_time) * 1000
            content = result.get("response", "").strip()
            tokens = result.get("eval_count", 0)
            
            # Clean degenerate outputs
            content = self._clean_output(content)
            
            return SwarmOutput(
                persona_id=persona_id,
                persona_name=persona["name"],
                content=content,
                model=model_name,
                tokens_used=tokens,
                latency_ms=latency,
                round_num=round_num
            )
            
        except urllib.error.URLError:
            return SwarmOutput(
                persona_id=persona_id,
                persona_name=persona["name"],
                content="[ERROR: Ollama not running. Start with: ollama serve]",
                model=model_name,
                round_num=round_num
            )
        except Exception as e:
            return SwarmOutput(
                persona_id=persona_id,
                persona_name=persona["name"],
                content=f"[ERROR: {str(e)}]",
                model=model_name,
                round_num=round_num
            )
    
    def _clean_output(self, text: str) -> str:
        """Clean up degenerate model outputs"""
        import re
        
        # Remove runs of 3+ newlines
        text = re.sub(r'\n{3,}', '\n\n', text)
        
        # Remove runs of dots (degeneration)
        text = re.sub(r'(\.{3,}\s*){2,}', '... ', text)
        
        # Remove character repetition (5+ same char)
        text = re.sub(r'(.)\1{5,}', r'\1\1\1', text)
        
        # Trim whitespace
        text = text.strip()
        
        # If mostly empty, return placeholder
        if len(text) < 3:
            return "(model produced minimal output)"
            
        return text
    
    def check_model_available(self, model_name: str) -> bool:
        """Check if a model is downloaded in Ollama"""
        try:
            req = urllib.request.Request(
                f"{self.ollama_host}/api/tags",
                method='GET'
            )
            with urllib.request.urlopen(req, timeout=10) as response:
                data = json.loads(response.read().decode('utf-8'))
                models = data.get("models", [])
                return any(m["name"] == model_name for m in models)
        except:
            return False
    
    def list_required_models(self) -> List[str]:
        """List all models needed by configured personas"""
        return list(set(p["model"] for p in self.personas.values()))
