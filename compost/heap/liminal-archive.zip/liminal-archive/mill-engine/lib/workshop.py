"""
Token Mill - Workshop Module
Mining, development, and curation tools
"""

import json
import re
from pathlib import Path
from typing import Dict, List, Optional
from datetime import datetime


class Workshop:
    """Workshop for mining and developing ideas"""
    
    def __init__(self, base_path: str = "."):
        self.base_path = Path(base_path)
        self.ideas_dir = self.base_path / "workshop" / "ideas"
        self.developing_dir = self.base_path / "workshop" / "developing"
        self.liminal_projects = self.base_path / ".." / "liminal" / "projects"
        
        # Ensure dirs exist
        self.ideas_dir.mkdir(parents=True, exist_ok=True)
        self.developing_dir.mkdir(parents=True, exist_ok=True)
    
    def mine_session(self, session_file: str, auto: bool = False, threshold: int = 7) -> List[Dict]:
        """
        Mine a session file for interesting fragments
        
        Args:
            session_file: Path to evolution JSON
            auto: Auto-extract high-scoring fragments
            threshold: Score threshold for auto-extraction
            
        Returns:
            List of extracted idea dicts
        """
        session_path = Path(session_file)
        if not session_path.exists():
            print(f"❌ Session not found: {session_file}")
            return []
        
        with open(session_path, 'r') as f:
            session = json.load(f)
        
        ideas = []
        mode = session.get("mode", "competitive")
        
        # Extract from each round
        for round_data in session.get("rounds", []):
            round_num = round_data.get("round_num", 0)
            winner_id = round_data.get("winner_id", "")
            winner_content = round_data.get("winner_content", "")
            
            # 1. Base Score
            score = 5  # Base for being winner
            
            # 2. Persona Bonus
            persona_bonuses = {
                "eve": 2,    # Oracle bonus for abstraction
                "kai": 1,    # Systems bonus for structure
                "rex": 1,    # Contrarian bonus for friction
                "ben": 1     # Scholar bonus for depth
            }
            score += persona_bonuses.get(winner_id, 0)
            
            # 3. Mode Bonus
            if mode == "hybrid":
                score += 1   # Hybridization often yields more interesting 'DNA'
            
            # 4. Content Analysis
            # Bonus for sensory words
            sensory_words = ['color', 'sound', 'light', 'shadow', 'scent', 'taste', 'touch', 'warmth', 'cold', 'texture', 'shimmer']
            for word in sensory_words:
                if word in winner_content.lower():
                    score += 1
            
            # Bonus for metaphor/emergence
            metaphor_words = ['like', 'as if', 'became', 'was a', 'were', 'emerged', 'folded', 'echoed']
            for word in metaphor_words:
                if word in winner_content.lower():
                    score += 1
            
            # 5. Length Constraint (Emergence favors compression)
            if 50 < len(winner_content) < 300:
                score += 2
            
            if auto and score >= threshold:
                idea = {
                    "id": f"{session['session_id']}_r{round_num}",
                    "text": winner_content[:500] + "..." if len(winner_content) > 500 else winner_content,
                    "source": str(session_path),
                    "round": round_num,
                    "persona": winner_id,
                    "score": score,
                    "mode": mode,
                    "tags": [winner_id, mode],
                    "session_prompt": session.get("rounds", [{}])[0].get("seed", "")[:100],
                    "extracted_at": datetime.now().isoformat()
                }
                ideas.append(idea)
                self._save_idea(idea)
        
        if not auto:
            # Interactive mode - show all and let user choose
            print(f"\n📁 Session: {session['session_id']}")
            print(f"Rounds: {len(session.get('rounds', []))}")
            print("\n📝 Extractable fragments:\n")
            
            for i, round_data in enumerate(session.get("rounds", []), 1):
                content = round_data.get("winner_content", "")
                winner = round_data.get("winner_id", "")
                print(f"  [{i}] {winner}: \"{content[:100]}...\"\n")
        
        return ideas
    
    def _save_idea(self, idea: Dict):
        """Save an idea to the workshop"""
        filepath = self.ideas_dir / f"{idea['id']}.json"
        with open(filepath, 'w') as f:
            json.dump(idea, f, indent=2)
        print(f"  💡 Mined: {idea['id']} (score: {idea['score']})")
    
    def list_ideas(self) -> List[Dict]:
        """List all saved ideas"""
        ideas = []
        for idea_file in self.ideas_dir.glob("*.json"):
            with open(idea_file, 'r') as f:
                ideas.append(json.load(f))
        return sorted(ideas, key=lambda x: x.get("score", 0), reverse=True)
    
    def develop_idea(self, idea_id: str, title: str = None) -> str:
        """
        Start developing an idea into a full piece
        
        Returns:
            Path to the developing file
        """
        idea_file = self.ideas_dir / f"{idea_id}.json"
        if not idea_file.exists():
            print(f"❌ Idea not found: {idea_id}")
            return None
        
        with open(idea_file, 'r') as f:
            idea = json.load(f)
        
        # Create developing file
        if not title:
            title = f"Development_of_{idea_id}"
        
        dev_file = self.developing_dir / f"{title}.md"
        
        content = f"""# {title}

*Developing from Mill evolution*

## Source Fragment

> {idea['text']}

- **Session:** {idea['source']}
- **Round:** {idea['round']}
- **Winning Persona:** {idea['persona']}
- **Mined:** {idea['extracted_at']}

## Development Notes

*[Add your notes here]*

## Draft

*[Write your piece here, incorporating the fragment]*

---

*Work in Progress*
"""
        
        with open(dev_file, 'w') as f:
            f.write(content)
        
        print(f"💾 Development started: {dev_file}")
        return str(dev_file)


if __name__ == "__main__":
    # CLI interface
    import sys
    
    workshop = Workshop()
    
    if len(sys.argv) < 2:
        print("Usage:")
        print("  python workshop.py mine <session.json> [--auto]")
        print("  python workshop.py list")
        print("  python workshop.py develop <idea_id> [title]")
        sys.exit(1)
    
    cmd = sys.argv[1]
    
    if cmd == "mine":
        if len(sys.argv) < 3:
            print("Usage: python workshop.py mine <session.json> [--auto]")
            sys.exit(1)
        session_file = sys.argv[2]
        auto = "--auto" in sys.argv
        ideas = workshop.mine_session(session_file, auto=auto)
        print(f"\n💡 Mined {len(ideas)} ideas")
    
    elif cmd == "list":
        ideas = workshop.list_ideas()
        print(f"📚 Saved ideas: {len(ideas)}")
        for idea in ideas[:10]:
            print(f"  [{idea['score']}] {idea['id']}: {idea['text'][:60]}...")
    
    elif cmd == "develop":
        if len(sys.argv) < 3:
            print("Usage: python workshop.py develop <idea_id> [title]")
            sys.exit(1)
        idea_id = sys.argv[2]
        title = sys.argv[3] if len(sys.argv) > 3 else None
        workshop.develop_idea(idea_id, title)
    
    else:
        print(f"Unknown command: {cmd}")
