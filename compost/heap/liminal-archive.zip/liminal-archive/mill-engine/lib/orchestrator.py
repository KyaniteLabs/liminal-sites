"""
Token Mill - Orchestrator Module
Manages iterative generation rounds with voting
"""

import json
import asyncio
from datetime import datetime
from pathlib import Path
from typing import List, Dict, Optional
from dataclasses import asdict

from lib.generator import MillGenerator, RoundResult, SwarmOutput
from lib.voting import VotingEngine


class TokenMillOrchestrator:
    """Orchestrates the full Token Mill workflow"""
    
    def __init__(self, config_path: str = "config.yaml"):
        self.generator = MillGenerator(config_path)
        self.voting = VotingEngine(self.generator)
        self.config = self.generator.config
        
        self.rounds: List[RoundResult] = []
        self.current_seed: str = ""
        self.session_id: str = datetime.now().strftime("%Y%m%d_%H%M%S")

    def _shuffle_musical_chairs(self):
        """Randomly reassign model hardware to personas"""
        import random
        print("\n🎵 MUSICAL CHAIRS: Shuffling roles...")
        
        persona_ids = list(self.generator.personas.keys())
        # Get all model names from the personas
        models = [p["model"] for p in self.generator.personas.values()]
        random.shuffle(models)
        
        for i, pid in enumerate(persona_ids):
            old_model = self.generator.personas[pid]["model"]
            new_model = models[i]
            self.generator.personas[pid]["model"] = new_model
            print(f"   🪑 {pid.upper()} is now played by: {new_model} (was {old_model})")
        print("")
        
    async def run_round(self, seed: str, round_num: int, mode: str = "competitive") -> RoundResult:
        """
        Run a single generation and voting round
        
        Args:
            seed: The prompt/seed for this round
            round_num: Which round number
            mode: competitive, hybrid, ring, mesh
            
        Returns:
            RoundResult with all outputs, votes, and winner
        """
        print(f"\n🔄 Round {round_num} [{mode.upper()}]")
        print(f"Seed: {seed[:80]}..." if len(seed) > 80 else f"Seed: {seed}")
        
        # Phase 1: All models generate
        print("  Generating...")
        
        if mode == "ring":
            # Sequential ring: each model sees the previous one's output
            outputs = {}
            current_chain = seed
            for persona_id in self.generator.personas.keys():
                print(f"    {persona_id}...", end=" ", flush=True)
                output = self.generator.generate(persona_id, current_chain[-300:], round_num)
                outputs[persona_id] = output
                current_chain += f"\n\n{output.content}"
                print(f"({len(output.content)} chars)")
        else:
            # Parallel or competitive: all generate from same seed
            tasks = []
            for persona_id in self.generator.personas.keys():
                tasks.append(self._generate_async(persona_id, seed, round_num))
            
            completed_outputs = await asyncio.gather(*tasks)
            outputs = {o.persona_id: o for o in completed_outputs}

        # Phase 2: Voting
        print("  Voting...")
        scores, winner_id, votes = self.voting.conduct_voting_round(outputs, round_num)
        
        # Get winner content
        winner_content = outputs[winner_id].content if winner_id in outputs else ""
        
        # Determine constraint for next round
        constraint = self.voting.get_constraint(round_num)
        
        # Build result
        result = RoundResult(
            round_num=round_num,
            seed=seed,
            outputs=outputs,
            votes=votes,
            scores=scores,
            winner_id=winner_id,
            winner_content=winner_content,
            constraint=constraint
        )
        
        # Display results
        print(f"\n  📊 Scores:")
        for pid, score in sorted(scores.items(), key=lambda x: -x[1]):
            marker = " 🏆" if pid == winner_id else ""
            print(f"     {pid}: {score} points{marker}")
        
        print(f"\n  🏆 Winner: {winner_id}")
        print(f"     \"{winner_content[:100]}...\"" if len(winner_content) > 100 else f"     \"{winner_content}\"")
        
        return result

    async def _generate_async(self, persona_id: str, prompt: str, round_num: int) -> SwarmOutput:
        """Helper for parallel generation"""
        print(f"    {persona_id} starting...", flush=True)
        # Run in executor to not block async loop if generator is synchronous
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self.generator.generate, persona_id, prompt, round_num)
    
    async def run_evolution(
        self, 
        initial_prompt: str,
        max_rounds: int = 10,
        convergence_threshold: int = 3,
        mode: str = "hybrid"
    ) -> List[RoundResult]:
        """
        Run full iterative evolution
        
        Args:
            initial_prompt: Starting prompt
            max_rounds: Maximum rounds to run
            convergence_threshold: Stop if same winner N times
            mode: competitive, hybrid, ring, mesh
            
        Returns:
            List of all RoundResults
        """
        self.current_seed = initial_prompt
        self.rounds = []
        
        print(f"\n{'='*60}")
        print(f"🎰 TOKEN MILL - Evolution Session {self.session_id}")
        print(f"{'='*60}")
        print(f"Initial prompt: {initial_prompt}")
        print(f"Mode: {mode}")
        print(f"Max rounds: {max_rounds}")
        
        # MUSICAL CHAIRS
        if self.config.get("swarm", {}).get("musical_chairs"):
            self._shuffle_musical_chairs()
        
        consecutive_wins = 0
        last_winner = None
        
        for round_num in range(1, max_rounds + 1):
            # Run round
            result = await self.run_round(self.current_seed, round_num, mode=mode)
            self.rounds.append(result)
            
            # Check convergence (only in competitive/hybrid)
            if mode in ["competitive", "hybrid"]:
                if result.winner_id == last_winner:
                    consecutive_wins += 1
                    print(f"\n  📈 Convergence: {consecutive_wins}/{convergence_threshold}")
                else:
                    consecutive_wins = 1
                    last_winner = result.winner_id
                
                if consecutive_wins >= convergence_threshold:
                    print(f"\n✅ Convergence reached! {result.winner_id} won {consecutive_wins} times in a row.")
                    break
            
            # Prepare next round seed
            if mode == "hybrid":
                # SYNTHESIS: Top 2-3 models contribute to the next prompt
                sorted_scores = sorted(result.scores.items(), key=lambda x: -x[1])
                top_outputs = [result.outputs[pid].content for pid, score in sorted_scores[:2]]
                combined = "\n\n---\n\n".join(top_outputs)
                self.current_seed = f"Synthesize and evolve these ideas into one cohesive piece:\n\n{combined}\n\nConstraint: {result.constraint}"
            else:
                self.current_seed = f"Rewrite this: {result.winner_content}\n\nConstraint: {result.constraint}"
        
        # Save session
        self._save_session()
        
        return self.rounds
    
    def _save_session(self):
        """Save full session to stream/ directory"""
        stream_dir = Path(self.config["paths"]["stream"])
        stream_dir.mkdir(parents=True, exist_ok=True)
        
        # Build session data
        session_data = {
            "session_id": self.session_id,
            "timestamp": datetime.now().isoformat(),
            "total_rounds": len(self.rounds),
            "final_output": self.rounds[-1].winner_content if self.rounds else "",
            "rounds": [r.to_dict() for r in self.rounds]
        }
        
        # Save JSON
        filepath = stream_dir / f"evolution_{self.session_id}.json"
        with open(filepath, 'w') as f:
            json.dump(session_data, f, indent=2)
        
        print(f"\n💾 Session saved: {filepath}")
        
        # Also save human-readable version
        txt_path = stream_dir / f"evolution_{self.session_id}.txt"
        with open(txt_path, 'w') as f:
            f.write(f"Token Mill Evolution Session\n")
            f.write(f"============================\n")
            f.write(f"Session: {self.session_id}\n")
            f.write(f"Rounds: {len(self.rounds)}\n\n")
            
            for r in self.rounds:
                f.write(f"\n--- Round {r.round_num} ---\n")
                f.write(f"Winner: {r.winner_id}\n")
                f.write(f"Content: {r.winner_content}\n")
                f.write(f"Constraint for next: {r.constraint}\n")
        
        print(f"💾 Text version: {txt_path}")
    
    def check_setup(self) -> bool:
        """Check if Ollama and required models are available"""
        print("Checking setup...")
        
        # Check Ollama
        try:
            import urllib.request
            import json
            req = urllib.request.Request(
                f"{self.generator.ollama_host}/api/tags",
                method='GET'
            )
            with urllib.request.urlopen(req, timeout=5) as response:
                data = json.loads(response.read().decode('utf-8'))
                available_models = [m["name"] for m in data.get("models", [])]
        except Exception as e:
            print(f"❌ Cannot connect to Ollama: {e}")
            print("   Start Ollama with: ollama serve")
            return False
        
        print(f"✅ Ollama connected")
        
        # Check required models
        required = self.generator.list_required_models()
        missing = []
        
        for model in required:
            if model not in available_models:
                missing.append(model)
                print(f"❌ Model not found: {model}")
                print(f"   Download with: ollama pull {model}")
            else:
                print(f"✅ Model available: {model}")
        
        if missing:
            print(f"\n⚠️  Missing {len(missing)} model(s). Run:")
            for m in missing:
                print(f"   ollama pull {m}")
            return False
        
        print("\n✅ Setup complete!")
        return True
