"""
Token Mill - Voting Module
Handles voting mechanics where models evaluate each other's work
"""

import json
import re
from dataclasses import dataclass, field
from typing import Dict, List, Tuple, Optional
from collections import defaultdict

from lib.generator import SwarmOutput


@dataclass
class Vote:
    """A single vote from one model"""
    voter_id: str
    first_choice: str  # persona_id
    second_choice: str  # persona_id
    reasoning: str = ""

    def to_dict(self) -> dict:
        return {
            "voter_id": self.voter_id,
            "first_choice": self.first_choice,
            "second_choice": self.second_choice,
            "reasoning": self.reasoning
        }


class VotingEngine:
    """Engine for conducting voting rounds between models"""
    
    def __init__(self, generator):
        """
        Args:
            generator: MillGenerator instance for calling models
        """
        self.generator = generator
        self.personas = generator.personas
        
    def conduct_voting_round(
        self, 
        outputs: Dict[str, SwarmOutput],
        round_num: int
    ) -> Tuple[Dict[str, int], str, Dict[str, str]]:
        """
        Have all models vote on the outputs
        
        Args:
            outputs: Dict of persona_id -> SwarmOutput
            round_num: Current round number
            
        Returns:
            Tuple of (scores dict, winner_id, votes dict)
        """
        votes = {}
        model_configs = self.generator.config.get("models", {})
        
        # Each model votes
        for voter_id in outputs.keys():
            vote = self._get_model_vote(voter_id, outputs)
            votes[voter_id] = vote
        
        # Tally scores: 
        # (voting_power * 2) for 1st choice
        # (voting_power * 1) for 2nd choice
        scores = defaultdict(int)
        for voter_id, vote in votes.items():
            # Get the power of the model that is currently acting as this persona
            power = model_configs.get(voter_id, {}).get("voting_power", 1)
            
            if vote.first_choice:
                scores[vote.first_choice] += (power * 2)
            if vote.second_choice:
                scores[vote.second_choice] += (power * 1)
        
        # Determine winner
        if scores:
            winner_id = max(scores.keys(), key=lambda k: scores[k])
        else:
            winner_id = list(outputs.keys())[0]
            
        return dict(scores), winner_id, votes
    
    def _get_model_vote(
        self, 
        voter_id: str, 
        outputs: Dict[str, SwarmOutput]
    ) -> Vote:
        """
        Have a single model cast its vote
        
        Args:
            voter_id: Which model is voting
            outputs: All outputs to choose from
            
        Returns:
            Vote object with choices and reasoning
        """
        voter_persona = self.personas[voter_id]
        
        # Build voting prompt
        candidates = []
        candidate_map = {}
        
        for idx, (pid, output) in enumerate(outputs.items()):
            letter = chr(65 + idx)  # A, B, C
            candidate_map[letter] = pid
            candidates.append(f"Piece {letter} ({pid}): {output.content}")
        
        candidates_text = "\n\n".join(candidates)
        
        # Get voting bias for this persona
        voting_bias = voter_persona.get("voting_bias", "")
        taste_desc = voter_persona.get("thinking_style", "")
        
        voting_prompt = f"""You are {voter_id}, {voter_persona['display_name']}. {taste_desc}

Your voting criteria: {voting_bias}

Review these pieces and pick your 1st and 2nd favorite:

{candidates_text}

Cast your vote:
1st choice: [A/B/C]
2nd choice: [A/B/C]
Briefly explain why (1 sentence):"""

        # Generate vote
        vote_output = self.generator.generate(
            voter_id, 
            voting_prompt,
            round_num=0
        )
        
        vote_text = vote_output.content
        
        # Parse the vote
        num_candidates = len(outputs)
        max_letter = chr(64 + num_candidates)
        first, second, reasoning = self._parse_vote(vote_text, candidate_map, max_letter)
        
        return Vote(
            voter_id=voter_id,
            first_choice=first,
            second_choice=second,
            reasoning=reasoning
        )
    
    def _parse_vote(
        self, 
        vote_text: str, 
        candidate_map: Dict[str, str],
        max_letter: str = 'G'
    ) -> Tuple[Optional[str], Optional[str], str]:
        """
        Parse vote text to extract choices
        
        Args:
            vote_text: Raw text from model
            candidate_map: Letter -> persona_id mapping
            max_letter: Max candidate letter (A-G)
            
        Returns:
            Tuple of (first_choice, second_choice, reasoning)
        """
        # Look for patterns like "1st: A" or "first choice: B"
        regex = f'[A-{max_letter}]'
        first_match = re.search(fr'1st(?:\s*choice)?[:\s]+({regex})', vote_text, re.IGNORECASE)
        second_match = re.search(fr'2nd(?:\s*choice)?[:\s]+({regex})', vote_text, re.IGNORECASE)
        
        first = None
        second = None
        
        if first_match:
            first = candidate_map.get(first_match.group(1).upper())
        
        if second_match:
            second = candidate_map.get(second_match.group(1).upper())
        
        # Fallback: if no parsed votes, try to find any A-G in the text
        if not first:
            for i in range(ord('A'), ord(max_letter) + 1):
                letter = chr(i)
                if letter in vote_text.upper():
                    first = candidate_map.get(letter)
                    break
        
        # Extract reasoning (everything after choices or last sentence)
        lines = vote_text.strip().split('\n')
        reasoning = lines[-1] if lines else ""
        
        # Clean up reasoning
        reasoning = re.sub(r'^(1st|2nd|first|second)\s*[:\s]+.*$', '', reasoning, flags=re.IGNORECASE).strip()
        
        if not reasoning or len(reasoning) < 3:
            reasoning = "No reasoning provided"
        
        return first, second, reasoning
    
    def get_constraint(self, round_num: int) -> str:
        """Get a random constraint for this round's refinement"""
        import random
        constraints = self.generator.config.get("refinement", {}).get("constraints", [])
        if constraints:
            return random.choice(constraints)
        return "Rewrite with focus"
