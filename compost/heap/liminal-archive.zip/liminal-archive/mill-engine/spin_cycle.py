#!/usr/bin/env python3
import subprocess
import glob
import os
import time
import re

def get_latest_output():
    files = glob.glob("stream/evolution_*.txt")
    if not files:
        return None
    latest_file = max(files, key=os.path.getctime)
    
    with open(latest_file, 'r') as f:
        content = f.read()
        
    # Extract the content of the last round (Winner: ...)
    # Look for "Winner: .*\nContent: (.*)"
    # The format in the file is:
    # --- Round 1 ---
    # Winner: ben
    # Content: [The text...]
    # Constraint for next: ...
    
    parts = content.split("--- Round 1 ---")
    if len(parts) < 2:
        return None
    
    section = parts[1]
    match = re.search(r"Content: (.*?)(?=\nConstraint for next:|$)", section, re.DOTALL)
    if match:
        return match.group(1).strip()
    return None

def main():
    current_prompt = "The machine began to hum, not with electricity, but with a swarm of voices trying to remember a song."
    
    for i in range(1, 6): # Run 5 loops
        print(f"\n🌀 SPIN CYCLE ROUND {i}")
        print(f"   Input: {current_prompt[:100]}...")
        
        # Run mill (Musical Chairs happens on launch)
        cmd = ["./mill", current_prompt, "--rounds", "1"]
        result = subprocess.run(cmd, capture_output=True, text=True)
        
        if result.returncode != 0:
            print("❌ Error running mill")
            print(result.stderr)
            break
            
        # Parse output for next round
        winner_text = get_latest_output()
        if winner_text:
            print(f"   ✅ Winner: {winner_text[:100]}...")
            current_prompt = winner_text
        else:
            print("❌ Could not extract winner text")
            break
            
        time.sleep(2)

if __name__ == "__main__":
    main()
