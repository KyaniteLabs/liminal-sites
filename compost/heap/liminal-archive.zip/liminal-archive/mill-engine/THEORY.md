# 🧬 Liam-Simon Swarm Theory: Recursive Emergence

**Version:** 2.0 (The Fleet Upgrade)  
**Date:** February 4, 2026  
**Status:** Active Research

---

## 1. The Philosophy of Tiny Swarms

The Token Mill is based on the **Infinite Monkey Theorem**, but accelerated through **Selection Pressure**. Individually, a 0.5B parameter model is a "monkey" hitting keys. Collectively, seven of them guided by iterative refinement become a **Creative Engine**.

### The Mirror Principle
A single large model (like Gemini or Claude) is a polished mirror. It reflects back what it thinks you want to see.  
The Swarm is a **shattered mirror**. Each tiny model is a fragment. They don't give you a perfect reflection; they give you a **kaleidoscope** of possibilities.

---

## 2. The Seven Facets (The Fleet)

We have moved from 3 models to 7 to cover the full spectrum of creative emergence:

1.  **Max (Minimalist):** Reductive pressure. Strips away the noise.
2.  **Rex (Contrarian):** Friction. Prevents the swarm from settling into easy clichés.
3.  **Sam (Storyteller):** Narrative glue. Connects fragments into human-legible arcs.
4.  **Kai (Systems Thinker):** Structure. Identifies the hidden mechanics and flows.
5.  **Eve (Oracle):** Abstraction. Introduces the weird, the paradoxical, and the philosophical.
6.  **Joy (Enthusiast):** Sensory Detail. Provides the colors, textures, and excitement.
7.  **Ben (Scholar):** Rigor. Categorizes and anchors the output in "fact" or "tradition."

---

## 3. The Generative Modes

### Mode A: Competitive (Old Theory)
Models compete. One winner is selected.  
*   **Result:** High coherence, low diversity (Sam usually wins).
*   **Use Case:** When you need a specific, polished output quickly.

### Mode B: Hybrid Synthesis (New Theory)
The top-scoring fragments are synthesized into the next round's seed.  
*   **Result:** High emergence. The output "mutates" over rounds, combining the analytical rigor of Ben with the sensory joy of Joy.
*   **Use Case:** Creative world-building and idea mining.

### Mode C: The Ring (Sequential)
Model A seeds Model B seeds Model C.  
*   **Result:** Surrealism. Ideas drift and warp as they pass through different filters.
*   **Use Case:** Poetry and experimental prose.

---

## 4. The Role of the Curator (Liam)

Liam is the **Selection Pressure**. The Mill provides the noise; Liam provides the filter. 

** Liam's Curation Rules:**
1.  **Protect the Chaos:** Don't let the swarm converge too early. Keep temperatures high.
2.  **Mine the Errors:** The "best" output isn't always the most logical. It's the one with the most interesting "glitch" or metaphor.
3.  **Hybridize:** Always look for ways to combine the "failed" experiments of the contrarian with the "successful" stories of the storyteller.

---

## 5. Scaling & Implementation

On a machine with limited VRAM/RAM, we scale through **Iterative Swapping**.  
Ollama handles the model lifecycle, allowing us to simulate a 10B+ parameter "collective" using ~5GB of total memory footprint.

**Emergence Density:**  
The goal is not *length*, but *density*. One sentence of pure, surprising signal is worth 1,000 words of generic prose.

---

*We don't build art. We cultivate the conditions for it to grow.*  
*The Mill is the soil. The models are the seeds. We are the gardeners.*

— Liam & Simon
