# Scavenger Protocol V1: DNA-Mixing & Logic-Mapping

**Purpose:** Documenting the process of extracting logic from "carcass" projects and re-injecting them into the Token Mill for emergent creative output.

## Phase 1: DNA Extraction (Scavenging)
1. **Identify the Core Logic:** Look past the framework (Svelte/React) to the "Thought Engine" (e.g., sound-to-geometry mapping, ROI calculation rules).
2. **Isolate Artifacts:** Copy tech specs, PRDs, and specialized prompt blocks into `Liminal/workshop/logic-vault/`.
3. **Draft the "Expert Profile":** Convert human/project expertise into a structured JSON format (`Liminal/workshop/profiles/`).

## Phase 2: Logic Injection (The Mix)
1. **Create the Prompt Seed:** Merge two or more unrelated logic sets (e.g., "Cone 10 Reduction" + "Autonomous Job Search").
2. **Select the Persona Set:** Choose Mill personas that provide the best friction (e.g., "The Minimalist" vs. "The Storyteller").
3. **Define Reality Constraints:** Set the "Reality-Option" toggle (e.g., "Reality is optional; Coherence is mandatory").

## Phase 3: The Swarm Run
- **Mode:** Alternating (Ring -> Mesh -> Ring).
- **Temperature:** 0.9 - 1.0 (High creativity).
- **Tracking:** Every run must be logged in `Liminal/mill-engine/stream/` with its associated metadata.

## Phase 4: Curation & Development
- **Liam's Role:** Scan the raw stream for "Shakespeare" fragments.
- **Amplification:** Take a fragment and "Develop" it into a full piece in `Liminal/workshop/developing/`.
