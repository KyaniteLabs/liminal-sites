# Game Experiments

*Rescued from previous iteration — mechanics liberated for creative reuse*

**Source:** CyberWitches / Hex Compiler Game (Jan 24, 2026 iteration)  
**Status:** Deconstructed, mechanics freed from original context  
**Use:** Systems, loops, feelings — ready to remix

---

## What It Was

Idle/clicker game with witchcraft/candle-making theme:
- **Genre:** Idle/Incremental (Hex Compiler)
- **Theme:** Witchcraft, candles, alchemy
- **Core loop:** Click to craft → Upgrade workstations → Automate production
- **Accessibility focus:** WCAG 2.1 Level AA compliance

**Visual style:** Dark, occult, particle effects, workstation cards

---

## Raw Mechanics

### Idle Game Patterns
1. **Click → Resource** — Manual production
2. **Resource → Upgrade** — Spend to improve
3. **Upgrade → Automation** — Reduce manual effort
4. **Automation → Scaling** — Exponential growth
5. **Prestige loop** — Reset for permanent bonuses

### Game Feel Elements
- **Particle effects** — Visual feedback on actions
- **Workstation cards** — Upgradeable entities
- **Progress bars** — Time-based production visibility
- **Notifications** — Completion, milestones
- **Idle earnings** — Offline progression

### Accessibility Systems
- Screen reader support (ARIA labels)
- Keyboard navigation
- Color contrast compliance
- Reduced motion options
- Text alternatives for visual elements

---

## Remix Possibilities

### Genre Mashups
- **Idle + Productivity** — Real tasks earn in-game currency
- **Idle + Creativity** — Making art generates resources
- **Idle + Learning** — Study time unlocks upgrades
- **Idle + Social** — Collaborative crafting

### Theme Transplants
Take the mechanics, change the skin:
- **Pottery studio** — Idle ceramics production
- **Code compilation** — Functions as workstations
- **Gardening** — Plants that grow while away
- **Music production** — Tracks that compose themselves
- **Writing** — Novels that write themselves (word by word)

### Mechanic Deconstruction
- **Just the particle system** — Reusable visual feedback
- **Just the upgrade tree** — Any skill progression system
- **Just the offline earnings** — Any "while you were away" mechanic
- **Just the accessibility features** — Template for any web game

---

## Experimental Directions

### What If...
- The idle game produced real creative output?
- Upgrades were actual skills Simon learned?
- The game world was a visualization of my memory?
- Players were sub-agents collaborating?
- The "prestige" was me resetting and evolving?

### System Mashups
- Game loop + Life Systems = "Gamified Simon"
- Game loop + Voice-to-Art = "Idle sculpture generation"
- Game loop + Second Brain = "Knowledge accumulation RPG"

### Accessibility as Feature
- What if the screen reader version was the *primary* experience?
- What if keyboard navigation was faster than mouse?
- What if reduced motion revealed hidden patterns?

---

## Code Worth Salvaging

### Idle Calculation
```javascript
// Offline earnings math
// Time-delta calculation
// Exponential scaling formula
```

### Visual Feedback
```javascript
// Particle system
// Floating text (+100 gold)
// Progress animations
```

### State Management
```javascript
// Save/load system
// Compression for large numbers
// Prestige handling
```

---

## Creative Prompts

1. **"The game plays itself, but you can influence it"** — Minimal interaction, maximum emergence
2. **"Every action creates art"** — Game state generates visuals/audio
3. **"The game is a mirror"** — Reflects real-world data (time, weather, Simon's mood)
4. **"No numbers visible"** — Abstract the resource management
5. **"The tutorial never ends"** — Continuous gentle guidance

---

*The official version had to be a good game. This version can be anything.*
