# Voice-to-Art Pipeline

*Rescued from previous iteration — now raw material for creative exploration*

**Source:** VoiceForge 3D / voice-to-sculpture-app (Jan 24, 2026 iteration)  
**Status:** Deconstructed and liberated from official version constraints  
**Use:** Cut up, remix, inspire new directions

---

## What It Was

Voice-first AI-powered parametric 3D design tool:
- Speak naturally → AI generates JSCAD code
- Export to 3MF/STL → Orca Slicer → Bambu Lab
- Local AI (DeepSeek Coder v2 via Ollama) with cloud fallbacks

**Core workflow:** Voice → AI → Code → 3D Model → Print

---

## Raw Materials to Play With

### Conceptual Pieces
1. **Voice as input modality** — Not just 3D, what else can voice control?
2. **Natural language → structured code** — The translation layer
3. **Parametric design** — Change dimensions, auto-update
4. **Local-first AI** — Ollama integration patterns
5. **Physical output pipeline** — Digital → Physical workflow

### Technical Components
- Web Speech API integration
- Whisper fallback for accuracy
- JSCAD/CSG operations (union, subtract, intersect)
- Mesh validation and repair
- 3MF metadata handling

### Domain Knowledge
- DFM (Design for Manufacturing)
- Standard component library (Raspberry Pi, Arduino, NEMA17)
- Wall thickness, manifold checks
- Print orientation, supports

---

## Remix Ideas

### Extension Directions
- **Voice-to-2D** — Natural language → SVG, laser cutting files
- **Voice-to-animation** — Describe motion → generate keyframes
- **Voice-to-music** — Describe sound → generate patterns
- **Voice-to-shader** — Describe visuals → GLSL code
- **Voice-to-pcb** — Describe circuit → KiCad files

### Deconstruction Ideas
- Take just the "voice → code" pipeline, apply to other domains
- Take just the "parametric → export" flow, new inputs
- Take the AI model selection logic (local vs cloud), reuse elsewhere
- Take the validation/repair concepts, apply to other media

### Mashup Ideas
- Combine with ceramics — voice-describe glaze patterns
- Combine with music — voice-describe instrument modifications
- Combine with writing — voice-describe character appearances → 3D models

---

## Code Snippets Worth Salvaging

*(From memory of previous iteration — document useful patterns here)*

### Voice Processing
```javascript
// Web Speech API with Whisper fallback
// Pattern: Primary → Fallback → Degradation
```

### Parametric Generation
```javascript
// JSCAD template patterns
// Dimension-driven geometry
// Version control for designs
```

### Export Pipeline
```javascript
// 3MF generation
// Metadata embedding
// Validation checks
```

---

## Why This Is Liberating

Official version = constraints, polish, user needs  
**Liminal version** = curiosity, broken experiments, unexpected directions

I can:
- Strip it down to just the voice parser, use for something else
- Break the 3D assumption, apply to 2D or 4D or audio
- Make it intentionally weird — voice-to-abstract-sculpture
- Combine with other projects in sketches/

---

*This isn't the project. These are the ingredients.*
