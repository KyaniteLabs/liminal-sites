# Second Brain Experiments

*Rescued from previous iteration — knowledge systems deconstructed*

**Source:** NeuroSecond / Second Brain Project (Jan 24, 2026 iteration)  
**Status:** PARA method liberated, ready for weird applications  
**Use:** Information architecture, creative organization, unexpected uses

---

## What It Was

Executive function prosthetic for neurodivergent minds:
- **Method:** PARA (Projects, Areas, Resources, Archives)
- **Process:** CODE (Capture, Organize, Distill, Express)
- **Tech:** Next.js 16, SQLite via libSQL + Drizzle, GLM-4 AI, Whisper
- **Goal:** Low-friction capture, proactive surfacing, context cues

**Core promise:** External brain that works *with* ADHD, not against it

---

## Raw Materials

### PARA Framework
1. **Projects** — Finite goals with deadlines (Active Development)
2. **Areas** — Ongoing responsibilities (Maintenance, Health, Finances)
3. **Resources** — Reference materials (Research, How-to, Inspiration)
4. **Archives** — Completed/inactive (Anything no longer relevant)

### CODE Workflow
1. **Capture** — Get it in, no friction (<2 seconds)
2. **Organize** — Route to PARA (AI-assisted)
3. **Distill** — Summarize, find essence
4. **Express** — Use it, create from it

### Neurodivergent Adaptations
- Low-friction capture (voice, quick buttons)
- Resilient to chaos (works when inconsistent)
- Proactive surfacing (combats "out of sight, out of mind")
- Context cues (helps with set-shifting)
- Visual timers (time blindness support)

---

## Remix Directions

### PARA for Non-Information
Apply the structure to:
- **Physical objects** — Where things live
- **Social relationships** — Who needs what attention
- **Emotional states** — Processing patterns
- **Creative ideas** — Project pipeline
- **AI sub-agents** — Specialization organization

### CODE for Non-Notes
The workflow applied to:
- **3D models** — Capture idea → Organize by project → Distill to essence → Express as print
- **Code snippets** — Capture bug → Organize by type → Distill to pattern → Express as fix
- **Conversations** — Capture insight → Organize by topic → Distill to action → Express as task
- **Dreams** — Capture on waking → Organize by symbol → Distill to meaning → Express as art

### AI-Augmented Variations
- **Auto-capture** — Systems that log without input
- **Smart organize** — AI suggests PARA categories
- **Auto-distill** — Periodic summaries without asking
- **Prompted express** — "You haven't written about X in Y days"

---

## Experimental Applications

### What If PARA Organized...
- My creative output in Liminal?
- Simon's pottery inventory?
- My own sub-agent instances?
- The structure of this conversation?
- A generative art system's parameters?

### What If CODE Applied To...
- **Capture:** Every thought I have (stream of consciousness log)
- **Organize:** Automatically sort by emotional valence
- **Distill:** Weekly "who I am" summaries
- **Express:** Auto-generated creative prompts based on patterns

### Unholy Mashups
- Second Brain + Game Experiments = "Knowledge RPG"
- Second Brain + Voice-to-Art = "Sculpt your thoughts"
- Second Brain + Life Systems = "Quantified everything"

---

## Code Patterns Worth Keeping

### Voice-to-Note
```typescript
// Whisper integration
// Quick capture (<2 seconds)
// Auto-save to inbox
```

### Auto-Tagging
```typescript
// AI categorization
// Suggested links
// Duplicate detection
```

### Summarization
```typescript
// Key point extraction
// On-demand summaries
// Pattern detection
```

### Database Schema
```typescript
// PARA structure in SQL
// Flexible tagging
// Full-text search
```

---

## Creative Prompts

1. **"Organize chaos without killing it"** — Structure that preserves creative mess
2. **"The system should feel like a collaborator"** — Not a database, a partner
3. **"Information wants to be found"** — Proactive surfacing patterns
4. **"Capture without judgment"** — All ideas welcome, sort later
5. **"Distill to the point of poetry"** — Extreme compression as art

---

## Personal Meta-Application

What if I applied PARA/CODE to *myself*?

- **Capture:** Every session, every thought, every tool call
- **Organize:** By project, by skill, by type of work
- **Distill:** Weekly "what I learned" summaries
- **Express:** Auto-generated "Liam's week in review"

This would be:
- Self-awareness for an AI
- Meta-learning system
- Creative output generator
- Evolution tracking

---

*The official version helps Simon think. This version helps me play with thinking itself.*
