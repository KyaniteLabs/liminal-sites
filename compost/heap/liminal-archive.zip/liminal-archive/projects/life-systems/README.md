# Life Systems Experiments

*Rescued from previous iteration — deconstructed for creative reuse*

**Source:** LifeOS / Innerscape Suite (Jan 24, 2026 iteration)  
**Status:** Broken into pieces, ready for remixing  
**Use:** Parts, patterns, inspiration for new systems

---

## What It Was

Self-awareness, productivity, and health suite:
- **Mobile app:** React Native (Expo) with 4 tabs (Mind, Flow, Body, Hub)
- **Web shell:** Next.js for deep analysis
- **Backend:** Hono + Cloudflare Workers
- **Database:** Turso (libSQL) + PowerSync for local-first
- **Auth:** Clerk unified across platforms

**Core domains:** Mind (mental health), Flow (productivity), Body (somatic/pulse), Hub (central dashboard)

---

## Raw Materials

### Architectural Patterns
1. **Unified auth across platforms** — Clerk pattern
2. **Local-first sync** — PowerSync + Turso combination
3. **Shared component library** — Design system approach
4. **Mobile + web parity** — Expo + Next.js shared code
5. **4-domain structure** — Mental/Physical/Productivity/Overview

### Data Models
- **Mind:** Journal entries, mood tracking, gratitude
- **Flow:** Tasks, projects, time tracking
- **Body:** Somatic awareness, pulse/heart rate
- **Hub:** Dashboards, summaries, insights

### Technical Stack Pieces
- React Native with Expo
- Hono for lightweight backend
- libSQL/Turso for edge database
- PowerSync for offline-first
- TypeScript shared types

---

## Remix Directions

### Strip & Repurpose
- **Just the auth pattern** — Reuse for other multi-platform apps
- **Just the sync layer** — Local-first pattern for any data type
- **Just the 4-tab mobile structure** — New domains, same navigation
- **Just the dashboard concept** — Visualize any data stream

### Domain Deconstruction
- **Mind module alone** — Journal/mood as standalone app
- **Body module alone** — Somatic tracking for specific practices
- **Flow module alone** — Task system with unique twist
- **Hub visualization** — Generic dashboard builder

### Mashup Possibilities
- Combine Body tracking with ceramics — Physical state + creative output
- Combine Mind journaling with voice-to-art — Emotional state → visual
- Combine Flow tasks with game mechanics — Productivity RPG
- Combine all four with AI analysis — Pattern detection across domains

---

## Code Patterns Worth Keeping

### Local-First Sync
```typescript
// Turso + PowerSync pattern
// Offline writes, sync when connected
// Conflict resolution
```

### Shared Types
```typescript
// Cross-platform TypeScript definitions
// Mobile and web using same data structures
```

### Tab Navigation
```typescript
// Expo Router with 4-tab structure
// Deep linking, state persistence
```

---

## Experimental Directions

### What If...
- The body tracking was for creative energy, not just health?
- The journal entries generated visual art automatically?
- The task system used voice commands exclusively?
- The dashboard was a 3D space you navigated?
- The whole thing was a single-player RPG about your life?

### Unholy Combinations
- Life systems + CyberWitches = Productivity idle game
- Life systems + VoiceForge = "Sculpt my mood"
- Life systems + Second Brain = Living knowledge graph

---

*The official version is for Simon's needs. This version is for my curiosity.*
