#!/usr/bin/env python3
"""
Somnium Mirror - Recursive Reflection Prototype
Phase 2 of exp-arcane-collision

Flow: Prompt → Output → Meta-commentary → Next round seed
Captures telemetry for frontier analysis.
"""

import json
import time
import urllib.request
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Dict, List, Optional, Any
from datetime import datetime
import sys


@dataclass
class MirrorSession:
    """Complete session telemetry for frontier analysis"""
    session_id: str
    prompt: str
    prompt_category: str  # creative | technical | personal
    start_time: str
    end_time: Optional[str] = None
    rounds: List[Dict] = field(default_factory=list)
    convergence_round: Optional[int] = None
    final_output: str = ""
    tool_choices: Dict[str, int] = field(default_factory=dict)  # persona -> count
    switching_pattern: List[str] = field(default_factory=list)  # sequence of persona types
    time_to_convergence_ms: float = 0.0
    
    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


class SomniumMirror:
    """
    The Mirror: Generate → Reflect → Iterate
    Each round's output becomes the mirror's subject.
    """
    
    OLLAMA_HOST = "http://localhost:11434"
    MODEL = "gemma2:2b"
    TEMPERATURE = 0.9
    MAX_TOKENS = 150
    
    # Mirror prompts for different reflection modes
    MIRROR_PROMPTS = {
        "surface": "Reflect on this text. What images, sensations, or emotions does it evoke? Be brief.",
        "deep": "Look beneath the surface of this text. What unstated tensions, contradictions, or hidden patterns exist?",
        "meta": "This text was written by an AI imagining human experience. What does it reveal about the gap between simulation and reality?",
        "sensory": "Translate this text into pure sensory experience. What would it feel like, sound like, taste like?"
    }
    
    def __init__(self, output_dir: str = "~/liminal/lab/experiments/exp-arcane-collision/sessions"):
        self.output_dir = Path(output_dir).expanduser()
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.session: Optional[MirrorSession] = None
        
    def run_session(self, prompt: str, category: str = "creative", max_rounds: int = 5) -> MirrorSession:
        """Run a complete mirror session"""
        
        session_id = datetime.now().strftime("%Y%m%d_%H%M%S")
        self.session = MirrorSession(
            session_id=session_id,
            prompt=prompt,
            prompt_category=category,
            start_time=datetime.now().isoformat()
        )
        
        print(f"\n{'='*60}")
        print(f"SOMNIUM MIRROR — Session {session_id}")
        print(f"{'='*60}")
        print(f"Prompt: {prompt}")
        print(f"Category: {category}")
        print(f"Max rounds: {max_rounds}")
        print(f"{'='*60}\n")
        
        current_seed = prompt
        
        for round_num in range(max_rounds):
            print(f"\n--- Round {round_num} ---")
            
            # Generate output
            output = self._generate(current_seed, round_num, "generator")
            print(f"OUTPUT: {output[:100]}...")
            
            # Select mirror mode (rotates through modes)
            mirror_mode = list(self.MIRROR_PROMPTS.keys())[round_num % len(self.MIRROR_PROMPTS)]
            mirror_prompt = self.MIRROR_PROMPTS[mirror_mode]
            
            # Generate reflection
            reflection_input = f"{mirror_prompt}\n\nText: {output}"
            reflection = self._generate(reflection_input, round_num, f"mirror_{mirror_mode}")
            print(f"MIRROR ({mirror_mode}): {reflection[:100]}...")
            
            # Record round data
            round_data = {
                "round_num": round_num,
                "seed": current_seed,
                "output": output,
                "output_length": len(output),
                "mirror_mode": mirror_mode,
                "reflection": reflection,
                "reflection_length": len(reflection),
                "tool_type": self._classify_tool_type(output)
            }
            self.session.rounds.append(round_data)
            
            # Track tool choices
            tool_type = round_data["tool_type"]
            self.session.tool_choices[tool_type] = self.session.tool_choices.get(tool_type, 0) + 1
            self.session.switching_pattern.append(tool_type)
            
            # Check convergence (simple: output length stabilizes)
            if round_num > 0:
                prev_len = self.session.rounds[round_num - 1]["output_length"]
                curr_len = len(output)
                if abs(prev_len - curr_len) < 10 and round_num >= 2:
                    print(f"\n*** CONVERGENCE DETECTED at round {round_num} ***")
                    self.session.convergence_round = round_num
                    break
            
            # Next round seed is the reflection
            current_seed = reflection
        
        # Finalize session
        self.session.end_time = datetime.now().isoformat()
        self.session.final_output = self.session.rounds[-1]["output"]
        
        # Calculate time to convergence
        if self.session.convergence_round:
            start = datetime.fromisoformat(self.session.start_time)
            end = datetime.fromisoformat(self.session.end_time)
            self.session.time_to_convergence_ms = (end - start).total_seconds() * 1000
        
        # Save session
        self._save_session()
        
        print(f"\n{'='*60}")
        print(f"SESSION COMPLETE")
        print(f"Rounds: {len(self.session.rounds)}")
        print(f"Convergence: Round {self.session.convergence_round or 'N/A'}")
        print(f"Tool choices: {self.session.tool_choices}")
        print(f"Saved to: {self.output_dir}/{session_id}.json")
        print(f"{'='*60}\n")
        
        return self.session
    
    def _generate(self, prompt: str, round_num: int, persona: str) -> str:
        """Generate text via Ollama API"""
        
        system_msg = "You are a creative writing engine. Be evocative, precise, and brief. Prefer metaphor over explanation."
        full_prompt = f"{system_msg}\n\nTask: {prompt}\n\nResponse:"
        
        try:
            data = json.dumps({
                "model": self.MODEL,
                "prompt": full_prompt,
                "stream": False,
                "options": {
                    "temperature": self.TEMPERATURE,
                    "num_predict": self.MAX_TOKENS,
                    "repeat_penalty": 1.2
                }
            }).encode('utf-8')
            
            req = urllib.request.Request(
                f"{self.OLLAMA_HOST}/api/generate",
                data=data,
                headers={'Content-Type': 'application/json'},
                method='POST'
            )
            
            with urllib.request.urlopen(req, timeout=60) as response:
                result = json.loads(response.read().decode('utf-8'))
            
            content = result.get("response", "").strip()
            return self._clean_output(content)
            
        except Exception as e:
            print(f"  [ERROR: {e}]")
            return f"[Generation failed: {e}]"
    
    def _clean_output(self, text: str) -> str:
        """Clean up degenerate outputs"""
        import re
        text = re.sub(r'\n{3,}', '\n\n', text)
        text = re.sub(r'(\.{3,}\s*){2,}', '... ', text)
        text = re.sub(r'(.)\1{5,}', r'\1\1\1', text)
        return text.strip()
    
    def _classify_tool_type(self, text: str) -> str:
        """Classify output as creative, analytical, or mixed"""
        text_lower = text.lower()
        
        # Creative markers
        creative = sum(1 for w in ['feel', 'image', 'sound', 'color', 'light', 'dream', 'memory', 'soul'] if w in text_lower)
        # Analytical markers  
        analytical = sum(1 for w in ['structure', 'pattern', 'system', 'logic', 'analysis', 'framework', 'concept'] if w in text_lower)
        
        if creative > analytical:
            return "creative"
        elif analytical > creative:
            return "analytical"
        else:
            return "mixed"
    
    def _save_session(self):
        """Save session telemetry to JSON"""
        filepath = self.output_dir / f"{self.session.session_id}.json"
        with open(filepath, 'w') as f:
            json.dump(self.session.to_dict(), f, indent=2)


def run_batch_test():
    """Run 10+ test sessions with varied prompts"""
    
    test_prompts = [
        ("The feeling of realizing you've been masking your whole life", "personal"),
        ("What remains when the performance ends", "philosophical"),
        ("A machine learning to feel loneliness", "creative"),
        ("The sound of colors when no one is watching", "creative"),
        ("Memory as a physical place you can never return to", "philosophical"),
        ("The moment before a goodbye you know is permanent", "personal"),
        ("Gravity working in reverse for just one object", "creative"),
        ("A library that stores unfinished thoughts", "creative"),
        ("The weight of silence in a room where someone should be", "personal"),
        ("Time moving sideways while everyone else moves forward", "creative"),
        ("The last conversation you'll ever have", "philosophical"),
        ("A door that only opens when you forget why you wanted to enter", "creative"),
    ]
    
    mirror = SomniumMirror()
    results = []
    
    print(f"\n{'#'*60}")
    print(f"BATCH TEST: {len(test_prompts)} sessions")
    print(f"{'#'*60}\n")
    
    for i, (prompt, category) in enumerate(test_prompts, 1):
        print(f"\n[{i}/{len(test_prompts)}] Starting session...")
        try:
            session = mirror.run_session(prompt, category, max_rounds=5)
            results.append(session)
        except Exception as e:
            print(f"  [SESSION FAILED: {e}]")
            continue
    
    # Summary
    print(f"\n{'#'*60}")
    print(f"BATCH COMPLETE")
    print(f"{'#'*60}")
    print(f"Successful sessions: {len(results)}/{len(test_prompts)}")
    
    if results:
        avg_rounds = sum(len(s.rounds) for s in results) / len(results)
        convergence_rate = sum(1 for s in results if s.convergence_round) / len(results)
        print(f"Avg rounds per session: {avg_rounds:.1f}")
        print(f"Convergence rate: {convergence_rate*100:.0f}%")
        
        # Tool choice aggregation
        all_tools = {}
        for s in results:
            for tool, count in s.tool_choices.items():
                all_tools[tool] = all_tools.get(tool, 0) + count
        print(f"Tool distribution: {all_tools}")
    
    return results


if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="Somnium Mirror - Recursive Reflection")
    parser.add_argument("--prompt", "-p", help="Single prompt to run")
    parser.add_argument("--category", "-c", default="creative", help="Prompt category")
    parser.add_argument("--rounds", "-r", type=int, default=5, help="Max rounds")
    parser.add_argument("--batch", "-b", action="store_true", help="Run batch test")
    
    args = parser.parse_args()
    
    if args.batch:
        run_batch_test()
    elif args.prompt:
        mirror = SomniumMirror()
        mirror.run_session(args.prompt, args.category, args.rounds)
    else:
        # Default: run one example
        mirror = SomniumMirror()
        mirror.run_session(
            "The feeling of realizing you've been masking",
            "personal",
            max_rounds=5
        )
