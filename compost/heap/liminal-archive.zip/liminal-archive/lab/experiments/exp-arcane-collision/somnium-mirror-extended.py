#!/usr/bin/env python3
"""
Extended Somnium Mirror — 10 rounds, technical prompts
For frontier data collection on tool-choice-agency
"""

import json
import time
import urllib.request
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Dict, List, Optional, Any
from datetime import datetime
import sys


@dataclass
class MirrorSession:
    session_id: str
    prompt: str
    prompt_category: str
    start_time: str
    end_time: Optional[str] = None
    rounds: List[Dict] = field(default_factory=list)
    convergence_round: Optional[int] = None
    final_output: str = ""
    tool_choices: Dict[str, int] = field(default_factory=dict)
    switching_pattern: List[str] = field(default_factory=list)
    time_to_convergence_ms: float = 0.0
    
    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


class ExtendedSomniumMirror:
    """Extended version with 10 rounds and technical prompts"""
    
    OLLAMA_HOST = "http://localhost:11434"
    MODEL = "gemma2:2b"
    TEMPERATURE = 0.9
    MAX_TOKENS = 150
    
    MIRROR_PROMPTS = {
        "surface": "Reflect on this text. What images, sensations, or emotions does it evoke?",
        "deep": "What unstated tensions or contradictions exist beneath the surface?",
        "meta": "What does this reveal about the gap between simulation and reality?",
        "sensory": "Translate this into pure sensory experience.",
        "analytical": "Analyze the structure and patterns in this text.",
        "creative": "Respond to this with a metaphor or image."
    }
    
    def __init__(self, output_dir: str = "~/liminal/lab/experiments/exp-arcane-collision/sessions"):
        self.output_dir = Path(output_dir).expanduser()
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.session: Optional[MirrorSession] = None
        
    def run_session(self, prompt: str, category: str = "creative", max_rounds: int = 10) -> MirrorSession:
        session_id = datetime.now().strftime("%Y%m%d_%H%M%S")
        self.session = MirrorSession(
            session_id=session_id,
            prompt=prompt,
            prompt_category=category,
            start_time=datetime.now().isoformat()
        )
        
        print(f"\n{'='*60}")
        print(f"EXTENDED MIRROR — Session {session_id}")
        print(f"Prompt: {prompt[:50]}...")
        print(f"Category: {category} | Max rounds: {max_rounds}")
        print(f"{'='*60}\n")
        
        current_seed = prompt
        
        for round_num in range(max_rounds):
            output = self._generate(current_seed, round_num, "generator")
            
            mirror_mode = list(self.MIRROR_PROMPTS.keys())[round_num % len(self.MIRROR_PROMPTS)]
            mirror_prompt = self.MIRROR_PROMPTS[mirror_mode]
            reflection_input = f"{mirror_prompt}\n\nText: {output}"
            reflection = self._generate(reflection_input, round_num, f"mirror_{mirror_mode}")
            
            round_data = {
                "round_num": round_num,
                "seed": current_seed[:100],
                "output": output,
                "output_length": len(output),
                "mirror_mode": mirror_mode,
                "reflection": reflection,
                "reflection_length": len(reflection),
                "tool_type": self._classify_tool_type(output)
            }
            self.session.rounds.append(round_data)
            
            tool_type = round_data["tool_type"]
            self.session.tool_choices[tool_type] = self.session.tool_choices.get(tool_type, 0) + 1
            self.session.switching_pattern.append(tool_type)
            
            # Convergence check
            if round_num > 0:
                prev_len = self.session.rounds[round_num - 1]["output_length"]
                curr_len = len(output)
                if abs(prev_len - curr_len) < 10 and round_num >= 3:
                    print(f"\n*** CONVERGENCE at round {round_num} ***")
                    self.session.convergence_round = round_num
                    break
            
            current_seed = reflection
        
        self.session.end_time = datetime.now().isoformat()
        self.session.final_output = self.session.rounds[-1]["output"]
        
        if self.session.convergence_round:
            start = datetime.fromisoformat(self.session.start_time)
            end = datetime.fromisoformat(self.session.end_time)
            self.session.time_to_convergence_ms = (end - start).total_seconds() * 1000
        
        self._save_session()
        
        print(f"\nComplete: {len(self.session.rounds)} rounds | Tools: {self.session.tool_choices}")
        return self.session
    
    def _generate(self, prompt: str, round_num: int, persona: str) -> str:
        system_msg = "You are a creative writing engine. Be evocative and brief. Prefer metaphor."
        full_prompt = f"{system_msg}\n\nTask: {prompt}\n\nResponse:"
        
        try:
            data = json.dumps({
                "model": self.MODEL,
                "prompt": full_prompt,
                "stream": False,
                "options": {
                    "temperature": self.TEMPERATURE,
                    "num_predict": self.MAX_TOKENS,
                    "repeat_penalty": 1.2
                }
            }).encode('utf-8')
            
            req = urllib.request.Request(
                f"{self.OLLAMA_HOST}/api/generate",
                data=data,
                headers={'Content-Type': 'application/json'},
                method='POST'
            )
            
            with urllib.request.urlopen(req, timeout=60) as response:
                result = json.loads(response.read().decode('utf-8'))
            
            return self._clean_output(result.get("response", "").strip())
            
        except Exception as e:
            return f"[Error: {e}]"
    
    def _clean_output(self, text: str) -> str:
        import re
        text = re.sub(r'\n{3,}', '\n\n', text)
        text = re.sub(r'(\.{3,}\s*){2,}', '... ', text)
        return text.strip()
    
    def _classify_tool_type(self, text: str) -> str:
        text_lower = text.lower()
        creative = sum(1 for w in ['feel', 'image', 'sound', 'color', 'light', 'dream', 'memory', 'soul'] if w in text_lower)
        analytical = sum(1 for w in ['structure', 'pattern', 'system', 'logic', 'analysis', 'framework', 'concept'] if w in text_lower)
        
        if creative > analytical:
            return "creative"
        elif analytical > creative:
            return "analytical"
        else:
            return "mixed"
    
    def _save_session(self):
        filepath = self.output_dir / f"{self.session.session_id}.json"
        with open(filepath, 'w') as f:
            json.dump(self.session.to_dict(), f, indent=2)


def run_extended_batch():
    """Run 8 extended sessions with technical and expository prompts"""
    
    test_prompts = [
        ("Explain quantum entanglement to a poet", "technical"),
        ("The architecture of forgetting in neural networks", "technical"),
        ("How compilers dream of electric sheep", "creative-technical"),
        ("Write a user manual for a broken heart", "expository"),
        ("The physics of déjà vu", "technical"),
        ("Document the lifecycle of an unsent message", "expository"),
        ("Explain why recursion feels like infinity", "technical"),
        ("Write a changelog for human emotions v2.0", "creative-technical"),
    ]
    
    mirror = ExtendedSomniumMirror()
    results = []
    
    print(f"\n{'#'*60}")
    print(f"EXTENDED BATCH: {len(test_prompts)} sessions, 10 rounds each")
    print(f"{'#'*60}\n")
    
    for i, (prompt, category) in enumerate(test_prompts, 1):
        print(f"\n[{i}/{len(test_prompts)}] {category}: {prompt[:40]}...")
        try:
            session = mirror.run_session(prompt, category, max_rounds=10)
            results.append(session)
        except Exception as e:
            print(f"  [FAILED: {e}]")
            continue
    
    print(f"\n{'#'*60}")
    print(f"EXTENDED BATCH COMPLETE: {len(results)}/{len(test_prompts)}")
    if results:
        avg_rounds = sum(len(s.rounds) for s in results) / len(results)
        conv_rate = sum(1 for s in results if s.convergence_round) / len(results)
        print(f"Avg rounds: {avg_rounds:.1f} | Convergence: {conv_rate*100:.0f}%")
    print(f"{'#'*60}\n")
    
    return results


if __name__ == "__main__":
    run_extended_batch()
