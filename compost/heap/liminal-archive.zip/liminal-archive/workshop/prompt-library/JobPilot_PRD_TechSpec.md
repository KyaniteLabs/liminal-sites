# JobPilot (JobHire.ai Clone) – Full PRD & Technical Specification

> **Goal:** This document defines an end‑to‑end Product Requirements Document (PRD) and Technical Specification for building a JobHire.ai‑style product: an AI‑powered job search assistant that optimizes resumes, generates cover letters, finds jobs, auto‑applies, and tracks applications.

This markdown file is the **single source of truth** for your coding agent. If something is unspecified here, your agent may choose a reasonable default but must **not** contradict what is defined here.

---

## 1. Product Overview

**Working Product Name:** `JobPilot` (you can rename later)

**One‑sentence value proposition:**  
> “An AI assistant that searches for relevant jobs, tailors your resume and cover letters, auto‑applies to high‑match roles, and tracks every application in one dashboard.”

### 1.1 Primary Outcomes

1. User spends **< 15 minutes** creating an account, uploading a resume, and setting preferences.
2. System **continuously finds and filters jobs** by match score and user preferences.
3. System **auto‑applies** to jobs above a configurable match score threshold, up to a **plan‑based daily cap**.
4. User gets a **clear dashboard** with:
   - Number of applications sent
   - Match scores
   - Status (queued, submitted, interview, offer, rejected, etc.)
5. User can manually request:
   - Resume optimization
   - Job‑specific resume tailoring
   - AI‑generated cover letters

### 1.2 In‑Scope for v1

- Web application (desktop‑first, responsive).
- Single user type: **job seekers**.
- AI capabilities:
  - Resume optimization
  - Job‑specific tailoring
  - Cover letter generation
  - Resume & job match scoring
- Auto‑Apply engine with:
  - Daily application cap per subscription plan
  - Match score threshold per user
- Job Application Tracker:
  - Timeline, status, notes
- Basic analytics:
  - Applications per time period
  - Interviews, offers, conversion rates
- Subscription billing with Stripe.
- Minimal admin panel.

### 1.3 Out‑of‑Scope for v1 (Explicitly Excluded)

- Native mobile apps (iOS/Android).
- Recruiter / employer‑side portal.
- Multi‑user teams or enterprise features.
- Complex email integration beyond basic webhook/polling (optional Gmail integration may be added later).
- Browser extensions and heavy scraping automations (future work).

---

## 2. Single Authoritative Tech Stack

Unless changed explicitly later, your coding agent **must** use this stack:

### 2.1 Frontend

- Framework: **Next.js 15** (App Router) with **TypeScript**
- Library: **React 19**
- Styling: **Tailwind CSS**
- Forms: React Hook Form + Zod (for validation)
- Authentication on frontend: NextAuth (communicating with backend REST API)

### 2.2 Backend

- Runtime: **Node.js 22**
- Framework: **Express.js** (TypeScript)
- ORM: **Prisma**
- Database: **PostgreSQL 15+**
- Cache & queues: **Redis** using **BullMQ**
- Authentication:
  - **JWT** based: access + refresh tokens
  - Access token TTL: 15 minutes
  - Refresh token TTL: 30 days

### 2.3 AI / LLM

- Provider: any **OpenAI‑compatible / Chat Completions** API
- Default model: `gpt-4.1-mini` (or equivalent) – configurable via environment variable
- All AI calls must be **wrapped** in a service layer with strict JSON contracts.

### 2.4 Billing

- Payment provider: **Stripe**
- Billing model: Monthly subscriptions
- Webhooks: Manage subscription lifecycle, plan changes, and status updates.

### 2.5 Infrastructure & Deployment

- Frontend (Next.js):
  - Deployed on **Vercel** (or equivalent serverless platform).
- Backend API + Worker:
  - Dockerized Node.js services
  - Deployed on any VM / container platform (e.g., Fly.io, Render, AWS ECS).
- Database:
  - Managed PostgreSQL (e.g., Supabase, RDS, Railway).
- Redis:
  - Managed Redis instance (e.g., Upstash, Elasticache).

### 2.6 Global Conventions

- Primary keys: **UUID v4**
- Timestamps: **UTC**, stored as ISO‑8601 (`timestamptz` in Postgres)
- APIs: **JSON REST** under `/v1/...`
- All dates/times returned in UTC and clearly labeled.

---

## 3. Core User Flows & Functional Requirements

This section defines user‑visible behavior. Implementation details appear later.

### 3.1 Sign Up & Onboarding

**Goal:** Collect enough data to let the system start applying on the user’s behalf.

**Flow:**

1. User visits `/signup`.
2. Fills form with: `name`, `email`, `password`.
3. System:
   - Creates user
   - Sends optional email verification
   - Issues access & refresh tokens
4. On first login, redirect to **Onboarding Wizard**:

**Wizard Steps:**

1. **Resume upload or paste:**
   - Upload PDF or DOCX ¬or¬ paste text.
   - Backend:
     - Stores file in object storage (e.g., S3).
     - Extracts text and stores `content_text`.
   - After success, move to next step.

2. **Job preferences:**
   - Desired titles (tags)
   - Locations (cities / countries)
   - Remote preference: `onsite | hybrid | remote | any`
   - Salary range (optional; numeric)
   - Industries (tags)
   - Include keywords (tags)
   - Exclude keywords (tags)

3. **Score threshold & auto‑apply settings:**
   - Default `resume_score_threshold = 80` (0–100).
   - Toggle `auto_apply_enabled` (default OFF for safety).
   - Explain daily limit & plan.

4. **Plan selection & billing:**
   - Show **Starter**, **Pro**, **Pro+** (see section 7).
   - If user selects a paid plan:
     - Create Stripe Checkout Session.
     - After success, mark subscription as active.

**Completion criteria:**

- User has:
  - At least 1 resume
  - At least 1 job_preferences record
  - A subscription (trial or paid)
- `users.onboarding_complete = true`

---

### 3.2 Resume Management

**Capabilities:**

- Upload new resumes (max N per plan).
- View/edit resume title.
- Download original file.
- Mark 1 resume as **primary**.
- Delete resumes (only if not linked to submitted applications).

**System Behavior on Upload:**

1. Accept PDF or DOCX.
2. Store file to object storage.
3. Extract text via server‑side utility.
4. Create `resumes` record with:
   - `source_type = 'upload'`
   - `file_url`
   - `content_text`
5. If user has no primary resume yet:
   - Set this as primary.

---

### 3.3 AI Resume Optimization

**User Action:**

- On resume detail page, click **“Optimize with AI”**.

**Backend Steps:**

1. Wrap the base resume text and user’s target titles/industries into an LLM request.
2. LLM must return **strict JSON** with keys:
   - `optimized_resume_markdown` (string)
   - `change_summary` (array of strings)
3. Backend:
   - Validates JSON; on failure retries once with stricter instructions.
   - Stores new `resumes` record:
     - `source_type = 'ai_generated'`
     - `content_text = optimized_resume_markdown`
   - Links `ai_runs` record for observability.
4. Frontend:
   - Shows side‑by‑side or switch view of original vs optimized.
   - User can **“Set as Primary”**.

**Constraint:** AI must **not invent** work experience or education.

---

### 3.4 AI Cover Letter Generation

**User Action:**

- On job detail or application drafting screen, click **“Generate Cover Letter”**.

**Inputs to Backend:**

- `job_post_id`
- Optional: `resume_id` (default to primary)
- Optional: `user_note` (short description of unique situation)

**Backend Steps:**

1. Load job description, title, company, and resume text.
2. Call LLM with strict JSON contract:

   ```json
   {
     "cover_letter_markdown": "<string>",
     "tone": "<string>"
   }
   ```

3. Save new `cover_letters` record with:
   - `source_type = 'ai_generated'`
   - `user_id`, `job_post_id`, `content_text`
4. Return content to frontend.

---

### 3.5 AI Resume Tailoring (Per Job)

**User Action:**

- On job detail page, user clicks **“Tailor Resume”**.

**Backend Steps:**

1. Load base resume (primary or chosen) and job description.
2. Call LLM with context and contract:

   ```json
   {
     "tailored_resume_markdown": "<string>",
     "match_score": 0,
     "reasoning": "<string>"
   }
   ```

3. Save new `resumes` record:
   - `source_type = 'job_tailored'`
   - `job_post_id` set
4. Save or update related `job_matches` row with `match_score`.
5. Return tailored resume and match score to frontend.

---

### 3.6 Job Search & Matching

For v1, we define **two job sources**:

1. **Manual/Internal Jobs:**
   - User can paste job URL and description.
   - Stored as `job_posts` with `source = 'internal'`.

2. **Generic Feed Connector:**
   - Reads a JSON/CSV feed imported by you (owner).
   - Not user‑managed; system uses this feed to suggest jobs.

**Matching Logic (Baseline):**

For each candidate job `J` against user `U`:

- Compute `match_score` (0–100):
  - 50% keyword overlap between resume and job description.
  - 20% title similarity (string similarity / simple heuristics).
  - 20% location & remote preference alignment.
  - 10% salary & seniority alignment if available.

This can be:

- **Deterministic** algorithm implemented in code **OR**
- AI‑assisted scoring via LLM contract:

  ```json
  {
    "match_score": 0,
    "reasoning": "<string>",
    "missing_keywords": ["<string>"]
  }
  ```

**Storage:**

- For each match considered, create a `job_matches` row with:
  - `user_id`
  - `job_post_id`
  - `match_score`
  - `decision = 'pending'`

---

### 3.7 Auto‑Apply Engine

**User Controls:**

- Global toggle: `auto_apply_enabled` (per user).
- Score threshold: `resume_score_threshold` (0–100).
- Daily caps per plan:
  - Starter: 10 apps/day
  - Pro: 30 apps/day
  - Pro+: 60 apps/day

**Worker Scheduling:**

- A scheduled job runs every **15 minutes**.
- For each user with `auto_apply_enabled = true`:
  1. Determine plan and `daily_auto_apply_cap`.
  2. Count `job_applications` created today.
  3. If count ≥ cap, skip user.
  4. Compute `remaining = cap − applied_today`.
  5. Fetch up to `remaining` `job_matches` where:
     - `match_score >= user.resume_score_threshold`
     - There is no existing application for that `job_post_id` & user.
     - `job_posts.is_active = true`.

- For each selected match, queue `auto_apply` job.

**Auto‑Apply Job Processing (Deterministic):**

1. Load `job_match`, `job_post`, `user`, `preferences`.
2. Select base resume (primary).
3. Optionally call AI to tailor resume & generate cover letter.
4. Choose job connector based on `job_post.source`.
5. Call `submitApplication(...)` on connector.
6. Create `job_applications` record with:
   - `status = 'submitted'` on success or `'failed'` on error.
   - `applied_at` timestamp.
7. Create `application_events` entry describing the outcome.

**JobBoardConnector Interface:**

```ts
interface JobBoardConnector {
  provider: string; // 'internal', 'generic_feed', etc.

  searchJobs(
    userId: string,
    preferences: JobPreferences,
    options: { limit: number; offset: number }
  ): Promise<JobPost[]>;

  submitApplication(input: {
    user: User;
    jobPost: JobPost;
    resumePdfUrl: string;
    coverLetterText?: string;
  }): Promise<{
    externalApplicationId?: string;
    applicationUrl?: string;
  }>;
}
```

For v1, **only `internal` and `generic_feed` are required**.  
These connectors **do not** have to perform real external submissions – they may treat “submitted” as a logged internal event, which you can later extend.

---

### 3.8 Job Application Tracker

**Features:**

1. **Applications List View**
   - Columns:
     - Job title
     - Company
     - Location
     - Source
     - Match score
     - Status
     - Applied date
   - Filters:
     - Status (`queued | submitted | interview | offer | rejected | withdrawn | failed`)
     - Date range (`applied_at`)
     - Match score range
     - Source

2. **Application Detail View**
   - Job info: title, company, description, link.
   - Resume used (view and download).
   - Cover letter used (view).
   - Timeline (from `application_events`):
     - Events such as “Application submitted”, “Status changed to interview”.
   - User notes:
     - Create simple text notes as `application_events` of type `note`.

3. **Analytics widgets:**
   - # applications last 7 / 30 days.
   - # interviews, # offers.
   - Conversion rates.

---

### 3.9 Notifications

**Email:**

- Send transactional emails when:
  - First batch of auto‑applications is submitted for a user.
  - Optional daily summary (configurable later).

**In‑App:**

- Use simple toast notifications for immediate actions.
- Optional bell icon showing unread events.

---

### 3.10 Admin Panel (v1 Minimal)

- Admin user can:
  - View list of users.
  - View subscriptions and plans.
  - View AI usage logs (`ai_runs`).
  - Manually disable auto‑apply for a problematic user.

---

## 4. Data Model (PostgreSQL, via Prisma)

Types: `uuid`, `text`, `int`, `boolean`, `timestamptz`, `jsonb`, `text[]`.

### 4.1 users

- `id` (uuid, PK)
- `email` (text, unique)
- `password_hash` (text)
- `name` (text)
- `role` (`'user' | 'admin'`)
- `onboarding_complete` (boolean, default `false`)
- `primary_resume_id` (uuid, nullable, FK -> `resumes.id`)
- `resume_score_threshold` (int, 0–100, default `80`)
- `auto_apply_enabled` (boolean, default `false`)
- `created_at` (timestamptz)
- `updated_at` (timestamptz)

### 4.2 subscription_plans

- `id` (uuid, PK)
- `code` (`'starter' | 'pro' | 'pro_plus'`, unique)
- `name` (text)
- `price_monthly_cents` (int)
- `daily_auto_apply_cap` (int)
- `max_resumes` (int)
- `includes_cover_letters` (boolean)
- `created_at`
- `updated_at`

### 4.3 subscriptions

- `id` (uuid, PK)
- `user_id` (uuid, FK -> `users.id`)
- `plan_id` (uuid, FK -> `subscription_plans.id`)
- `status` (`'trialing' | 'active' | 'past_due' | 'canceled'`)
- `stripe_customer_id` (text)
- `stripe_subscription_id` (text)
- `current_period_end` (timestamptz)
- `created_at`
- `updated_at`

### 4.4 resumes

- `id` (uuid, PK)
- `user_id` (uuid, FK)
- `title` (text)
- `source_type` (`'upload' | 'text' | 'ai_generated' | 'job_tailored'`)
- `file_url` (text, nullable)
- `content_text` (text)
- `job_post_id` (uuid, nullable, FK -> `job_posts.id`)
- `created_at`
- `updated_at`

### 4.5 cover_letters

- `id` (uuid, PK)
- `user_id` (uuid, FK)
- `job_post_id` (uuid, nullable, FK -> `job_posts.id`)
- `source_type` (`'ai_generated' | 'user_written'`)
- `content_text` (text)
- `created_at`
- `updated_at`

### 4.6 job_preferences

- `id` (uuid, PK)
- `user_id` (uuid, FK)
- `titles` (text[])
- `locations` (text[])
- `remote_preference` (`'onsite' | 'hybrid' | 'remote' | 'any'`)
- `salary_min` (int, nullable)
- `salary_max` (int, nullable)
- `industries` (text[])
- `keywords_include` (text[])
- `keywords_exclude` (text[])
- `job_types` (text[])
- `created_at`
- `updated_at`

### 4.7 job_posts

- `id` (uuid, PK)
- `external_id` (text, nullable)
- `source` (text) // `'internal' | 'generic_feed' | 'linkedin' | 'indeed' | ...`
- `url` (text)
- `title` (text)
- `company_name` (text)
- `location` (text)
- `salary_text` (text, nullable)
- `description_text` (text)
- `posted_at` (timestamptz, nullable)
- `scraped_at` (timestamptz)
- `is_active` (boolean, default `true`)

### 4.8 job_matches

- `id` (uuid, PK)
- `user_id` (uuid, FK)
- `job_post_id` (uuid, FK)
- `match_score` (int, 0–100)
- `decision` (`'pending' | 'accepted' | 'rejected'`)
- `decision_reason` (text, nullable)
- `created_at`
- `updated_at`

### 4.9 job_applications

- `id` (uuid, PK)
- `user_id` (uuid, FK)
- `job_post_id` (uuid, FK)
- `job_match_id` (uuid, nullable, FK)
- `status` (`'queued' | 'submitting' | 'submitted' | 'failed' | 'interview' | 'offer' | 'rejected' | 'withdrawn'`)
- `resume_id` (uuid, FK -> `resumes.id`)
- `cover_letter_id` (uuid, nullable, FK -> `cover_letters.id`)
- `source_account_id` (uuid, nullable, FK -> `job_board_accounts.id`)
- `external_application_id` (text, nullable)
- `application_url` (text, nullable)
- `applied_at` (timestamptz, nullable)
- `last_status_change_at` (timestamptz)
- `created_at`
- `updated_at`

### 4.10 application_events

- `id` (uuid, PK)
- `application_id` (uuid, FK -> `job_applications.id`)
- `type` (`'status_change' | 'note' | 'email_received' | 'error'`)
- `payload` (jsonb) // arbitrary details
- `created_at`

### 4.11 job_board_accounts

- `id` (uuid, PK)
- `user_id` (uuid, FK)
- `provider` (text) // `'internal' | 'generic_feed' | ...`
- `auth_data` (jsonb)
- `created_at`
- `updated_at`

### 4.12 ai_runs

- `id` (uuid, PK)
- `user_id` (uuid, FK)
- `type` (`'resume_optimize' | 'resume_tailor' | 'cover_letter' | 'job_match_score' | 'resume_score'`)
- `input` (jsonb)
- `output` (jsonb)
- `model` (text)
- `tokens_used` (int, nullable)
- `success` (boolean)
- `created_at`

---

## 5. REST API Design (Key Endpoints)

Base URL: `https://api.yourdomain.com/v1`  
All requests except `/auth/*` require header:

```http
Authorization: Bearer <access_token>
```

### 5.1 Auth

#### POST /auth/signup

- **Body:** `{ "email": string, "password": string, "name": string }`
- **Response:** `{ "user": UserDTO, "access_token": string, "refresh_token": string }`

#### POST /auth/login

- **Body:** `{ "email": string, "password": string }`
- **Response:** same as signup.

#### POST /auth/refresh

- **Body:** `{ "refresh_token": string }`
- **Response:** `{ "access_token": string, "refresh_token": string }`

### 5.2 User & Preferences

#### GET /me

- Returns: `UserDTO`.

#### PUT /me

- Updates: name and simple fields (not password).

#### GET /me/preferences

- Returns `JobPreferencesDTO`.

#### PUT /me/preferences

- **Body:** matches `job_preferences` fields.

### 5.3 Resumes

#### GET /resumes

- List user resumes.

#### POST /resumes

- Multipart for file upload, or JSON `{ "content_text": string, "title": string }`.
- Returns `ResumeDTO`.

#### PUT /resumes/:id

- Update `title` only (content changes should go through AI or re‑upload).

#### DELETE /resumes/:id

- Fail if used by any `job_applications` with status not `failed` or `withdrawn`.

#### POST /resumes/:id/optimize

- Triggers AI optimization.
- Returns new `ResumeDTO` (optimized).

#### POST /resumes/:id/set-primary

- Sets the given resume as `primary_resume_id` for the user.

### 5.4 Jobs & Matching

#### GET /jobs

Query params:

- `source`, `search`, `page`, `page_size`, `min_score`, etc. (v1 can keep minimal).

#### POST /jobs

- For manual job creation.
- Body: `{ title, company_name, url, location, description_text, source? }`.

#### GET /jobs/:id

- Returns full job details.

#### POST /jobs/:id/match

- Computes match_score for current user and saves/returns `job_match`.

#### POST /jobs/:id/tailor-resume

- Calls AI tailor pipeline. Returns new `ResumeDTO` + match_score.

#### POST /jobs/:id/cover-letter

- Calls AI cover letter pipeline. Returns `CoverLetterDTO`.

### 5.5 Auto‑Apply

#### GET /me/auto-apply-settings

- Returns: `{ auto_apply_enabled, resume_score_threshold }`.

#### PUT /me/auto-apply-settings

- Body: `{ auto_apply_enabled?: boolean, resume_score_threshold?: number }`.

#### POST /me/auto-apply/run-once

- Debug/ops: immediately enqueue an auto‑apply pass.

### 5.6 Applications

#### GET /applications

Query params:

- `status`, `from`, `to`, `source`, `min_score`, `max_score`, `page`, `page_size`.

#### GET /applications/:id

- Returns full application detail, including events, resume, and cover letter references.

#### PUT /applications/:id/status

- Body: `{ status: ApplicationStatus }`.

#### POST /applications/:id/notes

- Body: `{ text: string }` -> creates an `application_events` of type `note`.

### 5.7 Billing

#### GET /billing/plans

- Returns list of subscription plans & features.

#### POST /billing/create-checkout-session

- Body: `{ plan_code: string, success_url: string, cancel_url: string }`.
- Response: `{ checkout_url: string }`.

#### POST /billing/webhooks/stripe

- Stripe webhook endpoint; validates signature and updates `subscriptions`.

---

## 6. AI Prompt Contracts (LLM Specs)

All LLM responses **must** be valid JSON with no additional text.

### 6.1 Resume Optimization

**System message:**

> You are an expert resume editor. Improve resumes for ATS and human recruiters without inventing any facts. Do not fabricate degrees, companies, job titles, or dates.

**User JSON input:**

```json
{
  "resume_text": "<string>",
  "target_titles": ["Product Manager", "Growth PM"],
  "target_industries": ["SaaS", "Fintech"]
}
```

**Expected JSON output:**

```json
{
  "optimized_resume_markdown": "<string>",
  "change_summary": ["<string>", "<string>"]
}
```

### 6.2 Cover Letter

**Expected JSON output:**

```json
{
  "cover_letter_markdown": "<string>",
  "tone": "<string>"
}
```

### 6.3 Job Match Score

**Expected JSON output:**

```json
{
  "match_score": 0,
  "reasoning": "<string>",
  "missing_keywords": ["<string>"]
}
```

### 6.4 Job‑Specific Resume Tailoring

**Expected JSON output:**

```json
{
  "tailored_resume_markdown": "<string>",
  "match_score": 0,
  "reasoning": "<string>"
}
```

The backend **validates JSON** before saving; on failure, it retries once with a system prompt reminding the model to output strict JSON only.

---

## 7. Subscription Plans (Business Logic)

For v1, define three plans in the `subscription_plans` table:

1. **Starter**
   - `daily_auto_apply_cap = 10`
   - `max_resumes = 3`
   - `includes_cover_letters = true`

2. **Pro**
   - `daily_auto_apply_cap = 30`
   - `max_resumes = 5`
   - `includes_cover_letters = true`

3. **Pro+**
   - `daily_auto_apply_cap = 60`
   - `max_resumes = 10`
   - `includes_cover_letters = true`

**Enforcement:**

- Middleware on backend checks active subscription for every request that:
  - Creates resumes
  - Triggers auto‑apply
- If user exceeds max_resumes, block new uploads and provide meaningful error code.

---

## 8. Non‑Functional Requirements

### 8.1 Security

- HTTPS required everywhere.
- Passwords hashed via **bcrypt** (cost factor 12).
- JWT access token signed with `HS256` using secret key.
- Refresh tokens stored in DB with `revoked` flag.
- Rate limiting: 60 requests/min per IP/user.

### 8.2 Performance

- API endpoints (excluding AI calls) must typically respond in **< 300 ms**.
- AI heavy operations are:
  - Either invoked explicitly by the user, or
  - Executed via async workers (auto‑apply, massive matching).

### 8.3 Logging & Observability

- Log format: JSON lines.
- Log:
  - Incoming requests (path, status, user_id).
  - Worker job start/end (queue, jobId, result).
  - AI calls stored in `ai_runs` for debugging.

### 8.4 Error Handling

- API error format:

  ```json
  {
    "error_code": "STRING_CONSTANT",
    "message": "Human‑readable explanation"
  }
  ```

- Never leak internal stack traces or provider secrets.

---

## 9. High‑Level Implementation Phases

Your coding agent can follow this sequence:

1. **Phase 1 – Backend Foundation**
   - Set up Node/Express project with TypeScript.
   - Configure Prisma schema for core tables (`users`, `resumes`, `job_preferences`, etc.).
   - Implement auth (`/auth/signup`, `/auth/login`, `/auth/refresh`).

2. **Phase 2 – Frontend Shell**
   - Next.js app with auth pages and basic dashboard layout.
   - Connect to backend API for login/signup/me.

3. **Phase 3 – Resume & Preferences**
   - Implement resume upload + text extraction.
   - Implement preferences UI + API.

4. **Phase 4 – AI Services**
   - Wrap OpenAI‑compatible client in service.
   - Implement endpoints for:
     - `POST /resumes/:id/optimize`
     - `POST /jobs/:id/match`
     - `POST /jobs/:id/tailor-resume`
     - `POST /jobs/:id/cover-letter`

5. **Phase 5 – Job Ingestion**
   - Manual job creation.
   - Generic feed connector ingestion script.

6. **Phase 6 – Auto‑Apply & Worker**
   - Configure Redis + BullMQ queues.
   - Implement auto‑apply scheduler & worker logic.
   - Wire up application creation and tracking.

7. **Phase 7 – Tracker & Analytics**
   - Application list and detail views.
   - Simple metrics on the dashboard.

8. **Phase 8 – Billing**
   - Integrate Stripe Checkout and webhooks.
   - Enforce plan features.

9. **Phase 9 – Admin Panel & Polish**
   - Minimal admin pages.
   - UX improvements, mobile responsiveness.

---

## 10. Source of Truth

- If there is any conflict between code comments and this document, **this document wins**.
- All additional features must be additive and must not contradict the models, flows, and contracts described above.

---

_End of PRD & Technical Specification._
