# JobPilot – PRD & Technical Specification (v2, Auto Job Ingestion)

> **This document is the single source of truth for your coding agent.**  
> If any other doc or comment conflicts with this file, **this file wins**.

---

## 0. Non‑Negotiable Requirements

1. **Automatic job ingestion is mandatory.**  
   The system must automatically fetch and store job postings from at least **one external job API provider**, via a connector called `public_api`.

2. **No “empty dashboard”.**  
   After a user completes onboarding and sets job preferences, a background worker must regularly fetch jobs for that user. The user must see real jobs in the UI **without** pasting job descriptions.

3. **No ToS‑breaking instructions here.**  
   This spec does **not** prescribe scraping or ToS‑violating behavior. If you later add scraping or browser automation, that is outside this PRD and must follow legal guidance.

4. **Conflict resolution order:**  
   If any instructions conflict, follow this priority:
   1. Section 0 (Non‑Negotiables)
   2. Section 3.6 (Job Search & Ingestion)
   3. Connector / worker descriptions
   4. All other content

---

## 1. Product Overview

**Working name:** JobPilot  
**Value prop:**  
> “An AI assistant that searches live job data, tailors your resume & cover letters, auto‑applies to high‑match roles, and tracks everything in one dashboard.”

### 1.1 Outcomes

- User can complete onboarding in < 15 minutes.
- System continuously finds jobs from external sources and scores them.
- System can auto‑apply to good matches (above user’s threshold, under daily cap).
- User can see:
  - Jobs list
  - Applications, match scores, statuses
  - Basic stats (apps / interviews / offers).

### 1.2 In Scope (v1)

- Web app, desktop‑first, responsive.
- Single user type: job seeker.
- AI features: resume optimization, tailoring, cover letters, match scoring.
- Automatic job ingestion from at least one job API.
- Auto‑apply engine with daily caps and match-score threshold.
- Application tracker & basic analytics.
- Stripe subscriptions.
- Minimal admin panel.

### 1.3 Out of Scope (v1)

- Mobile apps.
- Employer/recruiter portal.
- Teams / org accounts.
- Complex multi‑provider email parsing.
- Browser extensions and aggressive scraping.

---

## 2. Tech Stack (Authoritative)

### 2.1 Frontend

- **Next.js 15** (App Router, TypeScript)
- **React 19**
- **Tailwind CSS**
- Forms: React Hook Form + Zod
- Frontend auth: NextAuth (using backend JWTs)

### 2.2 Backend

- **Node.js 22**
- **Express.js** (TypeScript)
- **Prisma** ORM
- **PostgreSQL 15+**
- **Redis + BullMQ** for queues
- Auth: JWT
  - Access token: 15 min TTL
  - Refresh token: 30 days TTL

### 2.3 AI

- Any OpenAI‑compatible chat completions API
- Default model: `gpt-4.1-mini` (configurable)
- All calls go through an internal AI service with strict JSON contracts.

### 2.4 Billing & Infra

- Billing: Stripe (Checkout + Webhooks)
- Frontend: Vercel or equivalent
- Backend + worker: Docker containers on any VM/container host
- DB: managed Postgres
- Redis: managed Redis

### 2.5 Conventions

- IDs: UUID v4
- Time: UTC, `timestamptz`
- APIs: JSON REST under `/v1`

---

## 3. Core Flows & Features

### 3.1 Sign‑Up & Onboarding

1. `/signup` → user enters `name`, `email`, `password`.
2. Backend creates user, hashes password (bcrypt cost 12), returns JWTs.
3. On first login, show onboarding wizard:

Wizard steps:

1. **Resume** – upload PDF/DOCX or paste text.  
   - Store file in object storage.
   - Extract text to `resumes.content_text`.
   - Create `resumes` record; if none primary, set as primary.

2. **Job Preferences** – user sets:
   - `titles` (string[])
   - `locations` (string[])
   - `remote_preference` = `onsite | hybrid | remote | any`
   - `salary_min` / `salary_max` (optional)
   - `industries` (string[])
   - `keywords_include` / `keywords_exclude` (string[])
   - `job_types` (string[]; e.g. `["full_time","contract"]`)

3. **Auto‑apply settings**
   - `resume_score_threshold` (0–100, default 80)
   - `auto_apply_enabled` (default false)

4. **Plan selection**
   - Choose Starter/Pro/Pro+.
   - Stripe checkout; on success → create `subscriptions` entry.

Completion:

- `onboarding_complete = true`
- User is eligible for job ingestion worker (3.6).

---

### 3.2 Resume Management

- Upload new resume (enforce `max_resumes` by plan).
- View / rename.
- Download original file.
- Set as primary.
- Delete only if not used by any non‑failed, non‑withdrawn application.

Resume upload behavior:

1. Validate file type.
2. Store file.
3. Extract text.
4. Insert into `resumes` table.
5. Optionally set as primary.

---

### 3.3 AI Resume Optimization

- Endpoint: `POST /resumes/:id/optimize`
- Input: resume id, optional target titles / industries.
- LLM contract (output must be valid JSON):

```json
{
  "optimized_resume_markdown": "<string>",
  "change_summary": ["<string>", "<string>"]
}
```

- Backend validates JSON; on success:
  - Creates new `resumes` row with `source_type = 'ai_generated'`.
  - Stores AI call in `ai_runs`.

---

### 3.4 AI Cover Letter Generation

- Endpoint: `POST /jobs/:id/cover-letter`
- Input: `job_post_id`, optional `resume_id`, optional `user_note`.
- LLM output JSON:

```json
{
  "cover_letter_markdown": "<string>",
  "tone": "<string>"
}
```

- Saves `cover_letters` row (`source_type = 'ai_generated'`), returns content.

---

### 3.5 AI Resume Tailoring per Job

- Endpoint: `POST /jobs/:id/tailor-resume`
- LLM output JSON:

```json
{
  "tailored_resume_markdown": "<string>",
  "match_score": 0,
  "reasoning": "<string>"
}
```

- Saves new `resumes` row with `source_type = 'job_tailored'` + `job_post_id`.
- Creates or updates `job_matches` with `match_score`.

---

### 3.6 Job Search & Automatic Ingestion (MANDATORY)

This section defines how the system **actually pulls in jobs**.

#### 3.6.1 Connector Pattern

We use a connector interface so multiple sources can co‑exist:

```ts
interface JobBoardConnector {
  provider: string; // 'public_api', 'remote_feeds', 'internal', etc.

  searchJobs(
    user: User,
    preferences: JobPreferences,
    options: { limit: number; offset: number }
  ): Promise<JobPost[]>;

  submitApplication(input: {
    user: User;
    jobPost: JobPost;
    resumePdfUrl: string;
    coverLetterText?: string;
  }): Promise<{
    externalApplicationId?: string;
    applicationUrl?: string;
  }>;
}
```

#### 3.6.2 Normalized JobPost

```ts
type JobPost = {
  external_id: string;
  source: string;      // 'public_api', 'remote_feeds', 'internal', etc.
  url: string;
  title: string;
  company_name: string;
  location: string;
  salary_text?: string;
  description_text: string;
  posted_at?: Date | null;
};
```

#### 3.6.3 Connectors in v1

- `public_api` **(REQUIRED)**  
  - Uses a real job search API provider (e.g., aggregator/remote job API with documented endpoints and ToS).
  - Maps `JobPreferences` → provider’s query params.
  - Implements `searchJobs` to return normalized `JobPost[]`.

- `remote_feeds` **(optional)**  
  - Polls RSS/JSON feeds that publish jobs (e.g., remote boards with feeds).

- `internal` **(optional)**  
  - Allows manual job creation.

> The system is **not considered done** unless `public_api` is implemented and returns real jobs in production.

#### 3.6.4 Job Ingestion Worker (job_search)

- Runs every **30 minutes**.
- For each user with:
  - `onboarding_complete = true`
  - Active or trial subscription

The worker executes:

```ts
async function runJobSearchForUser(userId: string) {
  const user = await db.users.findById(userId);
  const prefs = await db.job_preferences.findByUserId(userId);
  if (!prefs) return;

  const connector = getConnector('public_api');

  const jobs = await connector.searchJobs(user, prefs, {
    limit: 50,
    offset: 0,
  });

  for (const job of jobs) {
    const jobPost = await upsertJobPost(job);

    const alreadyMatched = await db.job_matches.findFirst({
      where: { user_id: userId, job_post_id: jobPost.id },
    });
    if (alreadyMatched) continue;

    const matchScore = await computeMatchScore(user, jobPost);

    await db.job_matches.create({
      data: {
        user_id: userId,
        job_post_id: jobPost.id,
        match_score: matchScore,
        decision: 'pending',
      },
    });
  }
}
```

**`upsertJobPost` rules:**

- Use `(source, external_id)` as a natural unique key.
- If exists, update fields (title, description, posted_at, etc.).
- If not, insert new row.

#### 3.6.5 Match Score Calculation

- Implement `computeMatchScore(user, jobPost)` as either:
  - Deterministic function over keywords/title/location, or
  - AI call that returns JSON:

```json
{
  "match_score": 0,
  "reasoning": "<string>",
  "missing_keywords": ["<string>"]
}
```

- Store result in `job_matches.match_score` (0–100).

#### 3.6.6 Guarantee

Within ≤ 30 minutes after onboarding (for users with reasonable preferences and if the job API has relevant jobs), `/jobs` for that user should list jobs pulled automatically from `public_api` (and optionally other connectors).

---

### 3.7 Auto‑Apply Engine

#### 3.7.1 User Controls

- `auto_apply_enabled` (boolean)
- `resume_score_threshold` (0–100)
- Plan‑dependent `daily_auto_apply_cap`

#### 3.7.2 Auto‑Apply Scheduler

Runs every **15 minutes**:

```ts
async function runAutoApplyForUser(userId: string) {
  const user = await db.users.findById(userId);
  if (!user.auto_apply_enabled) return;

  const plan = await getActivePlanForUser(userId);
  if (!plan) return;
  const cap = plan.daily_auto_apply_cap;

  const appliedToday = await countApplicationsToday(userId);
  if (appliedToday >= cap) return;

  const remaining = cap - appliedToday;

  const candidates = await getPendingJobMatchesAboveThreshold(
    userId,
    user.resume_score_threshold,
    remaining
  );

  for (const match of candidates) {
    enqueueAutoApplyJob(match.id);
  }
}
```

#### 3.7.3 Auto‑Apply Job Processing

For each job_match:

1. Load match, job_post, user, preferences.
2. Choose base resume (primary);
   - Optionally tailor resume and generate cover letter.
3. Select connector by `job_post.source`.
4. Call `submitApplication()`.
5. Create/update `job_applications` row:
   - On success: `status = 'submitted'`, set `applied_at`, store `external_application_id`/`application_url` if available.
   - On failure: `status = 'failed'`, create `application_events` with error info.

For v1, `submitApplication` is allowed to be “soft submit” (generate tailored docs and log the intent / application link) instead of fully automating external website form fills.

---

### 3.8 Application Tracker & Analytics

- `/applications` list with filters:
  - Status, date range, source, match score range.
- Application detail:
  - Job info, resume used, cover letter used, timeline (`application_events`), notes.
- Simple stats: apps in last 7/30 days, interviews, offers, conversion rates.

---

### 3.9 Notifications & Admin

- Optional email and in‑app notifications.
- Admin UI for viewing users, subscriptions, AI usage, and toggling auto‑apply per user.

---

## 4. Data Model (Summary)

Tables (Postgres via Prisma):

- `users` – account info, primary_resume_id, auto_apply_enabled, resume_score_threshold, role.
- `subscription_plans` – Starter/Pro/Pro+ with caps.
- `subscriptions` – user↔plan, status, Stripe IDs.
- `resumes` – user resumes; source_type, file_url, content_text, optional job_post_id.
- `cover_letters` – per user/per job, source_type, content_text.
- `job_preferences` – titles, locations, remote_preference, salary_min/max, etc.
- `job_posts` – normalized jobs from connectors; source, external_id, url, title, company_name, description_text, posted_at, is_active.
- `job_matches` – user↔job match_score, decision.
- `job_applications` – user↔job application records, status, resume_id, cover_letter_id, applied_at.
- `application_events` – timeline events per application.
- `job_board_accounts` – connector auth/config (if needed).
- `ai_runs` – logs AI calls for debugging and analytics.

All IDs are UUID v4; timestamps are `timestamptz`.

---

## 5. REST API (Key Endpoints, Summary)

- `/auth/signup`, `/auth/login`, `/auth/refresh`
- `/me`, `/me/preferences`, `/me/auto-apply-settings`
- `/resumes`, `/resumes/:id/optimize`, `/resumes/:id/set-primary`
- `/jobs`, `/jobs/:id`, `/jobs/:id/tailor-resume`, `/jobs/:id/cover-letter`
- `/applications`, `/applications/:id`, `/applications/:id/status`, `/applications/:id/notes`
- `/billing/plans`, `/billing/create-checkout-session`, `/billing/webhooks/stripe`

All responses: JSON, uniform error shape:

```json
{ "error_code": "STRING_CONSTANT", "message": "Human-readable message" }
```

---

## 6. AI Prompt Contracts

All LLM responses **must** be valid JSON, no extra text.

- Resume optimization → `{ optimized_resume_markdown, change_summary[] }`
- Cover letter → `{ cover_letter_markdown, tone }`
- Match scoring → `{ match_score, reasoning, missing_keywords[] }`
- Resume tailoring → `{ tailored_resume_markdown, match_score, reasoning }`

Backend must validate JSON and may retry once on parse errors.

---

## 7. Plans & Limits (Business Rules)

Three plans (example values):

- Starter: `daily_auto_apply_cap = 10`, `max_resumes = 3`
- Pro: `daily_auto_apply_cap = 30`, `max_resumes = 5`
- Pro+: `daily_auto_apply_cap = 60`, `max_resumes = 10`

Middleware must enforce:
- `max_resumes` on upload/creation.
- Disallow auto‑apply if no active/trial subscription.

---

## 8. Non‑Functional Requirements

- HTTPS everywhere.
- Bcrypt password hashing (cost 12).
- JWT (HS256) for access/refresh tokens.
- Rate limiting: 60 requests/min per user/IP.
- Typical non‑AI endpoint latency < 300 ms.
- Structured JSON logging; AI usage stored in `ai_runs`.

---

## 9. Implementation Priority (For Devs/Agents)

1. Implement DB schema + JWT auth.
2. Implement `public_api` connector to a real job API.
3. Implement `job_search` worker + `job_matches` creation.
4. Implement auto‑apply worker + `job_applications` tracking.
5. Implement resume upload + AI services.
6. Implement UI (dashboard, jobs, applications, settings).
7. Integrate Stripe and enforce plan caps.
8. Add admin tools and polish.

---

**End of JobPilot PRD & Technical Specification (v2, auto job ingestion).**
