
# Voice-to-Sculpture Tool — Technical Specification  
**Version:** 1.0  
**Date:** November 19, 2025  

## 0. Purpose & Overview

This document defines everything needed to build a browser-based creative tool that:

1. Lets a user **record or import multiple sung melodies**.  
2. Extracts **rich audio features** (pitch, loudness, timbre, temporal structure).  
3. Maps those features into one or more **3D “sculptures”** (conceptual ceramic forms).  
4. Renders the sculpture(s) interactively in the browser using **three.js**.  
5. Exports a **set of high-resolution images** from multiple fixed viewpoints (no 3D model export).  
6. Includes a **calibration wizard** to adapt to each user’s vocal range and recording environment.  
7. Includes an **embedded AI assistant** that can modify sculpture mappings and shapes from natural language.

The spec assumes implementation **in the browser** with **TypeScript** and **SvelteKit**, and is written with the expectation that an AI coding assistant (or human dev) will implement it.

There should be **no ambiguity or contradictions**; if something is not clearly specified here, it is considered out of scope for v1.

---

## 1. High-Level Architecture

### 1.1. Components

- **Frontend application**
  - Framework: **SvelteKit** (TypeScript).
  - Responsibilities:
    - UI (wizard, recording/import, mapping controls, 3D preview, AI chat).
    - Audio capture (mic) and file upload.
    - Audio analysis (real-time and offline) using Web Audio + libraries.
    - Data modeling: melodies, analysis summaries, sculpture definitions, mapping presets.
    - Three.js scene management, geometry generation, rendering.
    - Image export (multi-view high-res renders).
    - Integration with AI assistant endpoint.

- **Backend (lightweight)**
  - Platform: SvelteKit endpoints (Node runtime) or equivalent.
  - Responsibilities:
    - Single AI endpoint that:
      - Accepts current JSON state + user instruction.
      - Calls an LLM API.
      - Returns updated JSON.
    - No persistent DB required for v1 (state can be stored client-side).

No additional backend services are required for v1 beyond the LLM API.

---

## 2. Tech Stack (Final)

### 2.1. Core

- **Language:** TypeScript (strict mode recommended).
- **App framework:** SvelteKit (latest stable as of November 2025).
- **Package manager:** pnpm or npm (any is fine; pick one and use consistently).

### 2.2. Audio & Music

- **Browser APIs**
  - `navigator.mediaDevices.getUserMedia` — microphone access.
  - Web Audio API:
    - `AudioContext`
    - `MediaStreamAudioSourceNode`
    - `AudioBuffer`
    - Worklet or ScriptProcessorNode for streaming analysis.

- **Libraries**
  - **ml5.js**
    - Use: `PitchDetection` with the **CREPE** model.
    - Role: Real-time **pitch detection (fundamental frequency)** from live mic input.
    - Scope: **Mic-based recording only**.
  - **Meyda**
    - Use: Audio feature extraction (RMS, spectral centroid, rolloff, flatness, chroma, MFCC, ZCR, etc.).
    - Role:
      - Real-time analysis from mic stream.
      - Offline analysis from uploaded files (via `AudioBuffer`).
  - **Essentia.js** (optional but recommended for v1.1+)
    - Use: More advanced descriptors and music-specific features (key, tempo, melody contour).
    - Role: Offline analysis for richer summaries.
    - Implementation: Run in a WebWorker to avoid blocking UI.

- **Music Theory**
  - **tonal.js**
    - Use:
      - Frequency ↔ note name mapping.
      - Scale & key estimation helpers.
      - Interval, degree, and pitch-class logic.

### 2.3. 3D & Rendering

- **three.js**
  - Use:
    - Scene, camera, renderer.
    - Lighting, materials.
    - Geometry generation:
      - `LatheGeometry` for vase/bowl-like shapes.
      - Custom `BufferGeometry` for totems or lattices.
  - Export:
    - No 3D format export in v1.
    - Use `renderer.domElement.toDataURL("image/png")` for image export.

### 2.4. UI & Styling

- **SvelteKit** components for layout and controls.
- **Tailwind CSS** for styling.
- **Simple HTML inputs** (sliders, selects, buttons) where possible.

### 2.5. AI Assistant

- **LLM API** (provider-agnostic in this spec).
- SvelteKit endpoint:
  - Receives structured JSON.
  - Sends prompt + JSON to LLM.
  - Returns updated JSON.

---

## 3. Data Models

All state is modeled explicitly. Use TypeScript types or interfaces as defined below.

### 3.1. UserProfile

```ts
type UserProfile = {
  lowPitchHz: number;     // Lowest comfortable pitch detected during calibration
  highPitchHz: number;    // Highest comfortable pitch detected during calibration
  midPitchHz: number;     // Typical (median) comfortable pitch
  noiseFloorRms: number;  // Estimated RMS background noise level
};
```

### 3.2. FrameFeature

Single frame of audio analysis at time `t`.

```ts
type FrameFeature = {
  timeSec: number;

  // Pitch
  pitchHz: number | null;      // null if no reliable pitch
  pitchConfidence: number;     // 0..1

  // Loudness
  rms: number;                 // root mean square

  // Spectral / timbre
  spectralCentroid: number;    // Hz or normalized [0..1], be consistent
  spectralRolloff: number;
  spectralFlatness: number;
  mfcc: number[];              // typical length 13
  chroma: number[];            // length 12, pitch class energies
  zcr: number;                 // zero crossing rate

  // Derived flags
  isOnset: boolean;            // true if onset detected at this frame
};
```

### 3.3. NoteEvent

Processed musical abstraction derived from `FrameFeature[]`.

```ts
type NoteEvent = {
  step: number;               // Discrete time step (0..N-1)
  noteName: string;           // e.g. "G3"
  midi: number;               // MIDI note number
  freq: number;               // Fundamental frequency in Hz

  velocity: number;           // 0..1 (from RMS)
  brightness: number;         // 0..1 (from spectralCentroid normalized)
  timbreVec: number[];        // e.g. normalized MFCC subset

  sourceId: string;           // ID of the Melody this event belongs to
};
```

### 3.4. AnalysisSummary

High-level summary for a melody.

```ts
type AnalysisSummary = {
  durationSec: number;

  // Pitch range
  minPitchHz: number | null;
  maxPitchHz: number | null;
  medianPitchHz: number | null;

  // Loudness stats
  meanRms: number;
  rmsStdDev: number;

  // Brightness stats
  meanCentroid: number;
  centroidStdDev: number;

  // Pitch movement
  meanIntervalSemitones: number;   // average absolute interval size
  contourType: "rising" | "falling" | "arch" | "descending_arch" | "flat";

  // Music theory
  estimatedKey: string | null;     // e.g. "C minor"
  estimatedScale: string | null;   // e.g. "natural minor", "dorian"
};
```

### 3.5. Melody

```ts
type Melody = {
  id: string;                    // UUID or incremented ID
  name: string;                  // User-facing name
  noteEvents: NoteEvent[];       // Derived note events
  frameFeatures: FrameFeature[]; // Raw frame-level data
  analysisSummary: AnalysisSummary;
};
```

### 3.6. SculptureDefinition

Core, geometry-agnostic description of a single sculpture.

```ts
type ProfilePoint = {
  stepIndex: number;    // 0..(N-1)
  heightNorm: number;   // 0..1 along vertical axis
  radius: number;       // unitless, scaled later
  twist: number;        // local twist offset (radians)
  roughness: number;    // 0..1, used in shader / vertex noise
  grooveDepth: number;  // 0..1, used for carved ridges
};

type SculptureDefinition = {
  mode: "vase" | "totem" | "bowl" | "lattice";

  profile: ProfilePoint[];    // vertical profile / structure spec
  crossSectionShape: "circle" | "polygon" | "organic";

  symmetry: number;           // e.g. 3, 4, 6, 8
  globalTwist: number;        // total twist over full height in radians

  colorStrategy: "none" | "pitch" | "loudness" | "timbre";

  worldScale: {
    height: number;           // e.g. 1.0, treat as abstract units
    radius: number;           // same units as height
  };

  metadata: {
    detectedKey: string | null;
    detectedScale: string | null;
    audioDurationSec: number;
    description: string;
  };
};
```

### 3.7. MappingPreset

Configuration for mapping audio features → SculptureDefinition.

```ts
type CombinationMode = "layered" | "multi_part";

type MelodyRole = "body" | "base" | "rim" | "detail";

type MappingPreset = {
  id: string;
  name: string;
  mode: "vase" | "totem" | "bowl" | "lattice";

  // Feature weights
  pitchToRadiusWeight: number;        // 0..1
  loudnessToHeightWeight: number;     // 0..1
  brightnessToRoughnessWeight: number;// 0..1
  intervalToGrooveWeight: number;     // 0..1
  vibratoToTwistWeight: number;       // 0..1

  // Combination of multiple melodies
  combinationMode: CombinationMode;
  melodyRoles: { [melodyId: string]: MelodyRole | undefined };

  // Smoothing (0..1, where 0 = no smoothing, 1 = maximum)
  smoothing: {
    temporal: number;
    spatial: number;
  };

  // Symmetry logic
  symmetryOptions: {
    stableSymmetry: number;   // e.g. 8
    chaoticSymmetry: number;  // e.g. 4
  };
};
```

### 3.8. ProjectState

Top-level in-app state.

```ts
type ProjectState = {
  userProfile: UserProfile | null;

  melodies: Melody[];
  activeMelodyIds: string[];         // subset of melodies used in mapping

  mappingPreset: MappingPreset;
  sculptureDefinition: SculptureDefinition | null;

  ui: {
    selectedMelodyId: string | null;
    selectedViewId: "front" | "side" | "top" | "perspective";
  };
};
```

---

## 4. Calibration Wizard

### 4.1. Purpose

- Adapt pitch mapping to each user’s vocal range.
- Measure background noise.
- Improve reliability of pitch detection and feature interpretation.

### 4.2. Flow

Run on first launch or when user clicks “Recalibrate”:

1. **Mic Selection & Level Check**
   - Display available audio input devices.
   - User picks one.
   - Show real-time level meter (`rms`) from Meyda on a simple bar.
   - Prompt: “Sing a comfortable note and adjust your microphone so the bar stays mostly in the green zone.”

2. **Lowest Comfortable Note**
   - Instructions: “Sing your lowest comfortable note and hold it for ~3 seconds.”
   - System:
     - Collect pitch frames from ml5.
     - Filter frames by pitchConfidence ≥ threshold (e.g., 0.8).
     - Compute median pitchHz over valid frames.
     - Store as `userProfile.lowPitchHz`.

3. **Highest Comfortable Note**
   - Instructions: “Sing your highest comfortable note and hold it for ~3 seconds.”
   - System:
     - Same process as above, store median as `userProfile.highPitchHz`.

4. **Mid-range Estimation**
   - Instructions: “Sing in your most comfortable range for a few seconds.”
   - System:
     - Collect pitch frames.
     - Filter by confidence.
     - Compute median as `userProfile.midPitchHz`.

5. **Noise Floor**
   - Instructions: “Stay silent for 3 seconds.”
   - System:
     - Use Meyda to compute RMS.
     - Average RMS over silent period as `userProfile.noiseFloorRms`.

6. **Save & Continue**
   - Store `UserProfile` in:
     - In-memory `ProjectState`.
     - `localStorage` (or equivalent) so calibration persists.

### 4.3. Usage of UserProfile

- **Pitch normalization:**

```ts
function normalizePitch(pitchHz: number, userProfile: UserProfile): number {
  const min = userProfile.lowPitchHz;
  const max = userProfile.highPitchHz;
  if (max <= min) return 0.5;
  const clamped = Math.min(Math.max(pitchHz, min), max);
  return (clamped - min) / (max - min); // 0..1
}
```

- **Noise filtering:**
  - Discard frames where `rms < userProfile.noiseFloorRms * 1.2` (for example).
  - Discard pitch estimates with low confidence or outside `[lowPitchHz - margin, highPitchHz + margin]`.

This makes pitch detection robust to environment and voice differences.

---

## 5. Audio Capture & Feature Extraction

### 5.1. Mic-based Recording

Steps:

1. Request mic permission with `getUserMedia({ audio: true })`.
2. Create `AudioContext`.
3. Create `MediaStreamAudioSourceNode` from the media stream.
4. Feed this node into:
   - ml5 PitchDetection (CREPE model).
   - Meyda analyzer for per-frame audio features.

#### Frame Timing

- Use a consistent frame rate, e.g. every 23 ms (~1024 samples at 44.1kHz).
- Store each frame as a `FrameFeature` instance.

### 5.2. Pitch Detection with ml5.js

- Initialize ml5 PitchDetection with:
  - CREPE model URL.
  - The audio context / stream source.
- At each callback:
  - Receive `frequency` (Hz) and `probability` (confidence 0..1).
  - Map into `FrameFeature.pitchHz` and `FrameFeature.pitchConfidence`.

### 5.3. Feature Extraction with Meyda

- Set up Meyda analyzer:
  - Input: same audio source node.
  - Buffer size: 1024 or 2048 (trade-off between time resolution and quality).
  - Features to extract:
    - `rms`
    - `spectralCentroid`
    - `spectralRolloff`
    - `spectralFlatness`
    - `mfcc`
    - `chroma`
    - `zcr`
- For each frame:
  - Combine ml5 pitch data and Meyda feature data into a `FrameFeature` object.

### 5.4. Uploaded Audio File Flow

- User selects an audio file (WAV, MP3, etc.).
- Use `FileReader` to get `ArrayBuffer`.
- Use `audioContext.decodeAudioData` to get `AudioBuffer`.
- Process `AudioBuffer` offline:
  - Use Meyda’s offline mode or manual framing:
    - Slice the buffer into overlapping windows.
    - Extract features with `Meyda.extract()` for each window.
  - Optional: Use Essentia.js for more advanced pitch/key/tempo features.
- Build `FrameFeature[]` in the same format as mic-based recording.

---

## 6. Building NoteEvents from FrameFeatures

### 6.1. Pitch Tracking & Quantization

1. **Select frames** with valid pitch:
   - `frame.pitchHz !== null`
   - `frame.pitchConfidence ≥ threshold`
   - `frame.rms > userProfile.noiseFloorRms * 1.2`

2. **Convert frequency → note + MIDI** using tonal.js:

```ts
import { Midi } from "@tonaljs/midi";
import { Note } from "@tonaljs/note";

function pitchHzToNote(pitchHz: number): { noteName: string; midi: number } {
  const midi = Math.round(Midi.freqToMidi(pitchHz)); // or equivalent tonal.js helper
  const noteName = Note.fromMidi(midi);
  return { noteName, midi };
}
```

3. **Time discretization:**
   - Decide on N steps, e.g. 32 or 64 across the duration.
   - For frame at `timeSec`, compute `step = floor(timeSec / durationSec * N)`.

4. **Aggregation per step & melody:**
   - For each step (0..N-1), and for each melody, collect all frames that fall into that step.
   - Compute:
     - Pitch: median of `pitchHz`.
     - Loudness: mean `rms`.
     - Brightness: mean `spectralCentroid`.
     - TimbreVec: mean of MFCC vectors (element-wise).
   - Convert pitchHz to `noteName` and `midi`.

### 6.2. Creating NoteEvents

For each step where we have enough frames:

```ts
const noteEvent: NoteEvent = {
  step,
  noteName,
  midi,
  freq: pitchHz,
  velocity: normalizedRms,        // map from [minRms,maxRms] to 0..1
  brightness: normalizedCentroid, // map according to feature range
  timbreVec: normalizedMfcc,      // e.g., 3–5 leading coefficients
  sourceId: melody.id,
};
```

Store this in `Melody.noteEvents`.

---

## 7. Multi-Melody Handling

### 7.1. Data

- `ProjectState.melodies: Melody[]`
- `ProjectState.activeMelodyIds: string[]` — subset of melodies used in current sculpture.

### 7.2. Combination Modes

#### Mode 1: `layered` (default)

- Treat all active melodies as contributing to **one continuous profile**.
- For each step:

```ts
const stepEvents = allNoteEvents.filter(
  e => e.step === step && activeMelodyIds.includes(e.sourceId)
);

if (stepEvents.length === 0) continue;

// Aggregate features, e.g.:
const pitchHz = median(stepEvents.map(e => e.freq));
const velocity = mean(stepEvents.map(e => e.velocity));
const brightness = mean(stepEvents.map(e => e.brightness));
// etc.
```

This aggregated `stepFeature` is then used to drive `ProfilePoint` values.

#### Mode 2: `multi_part`

- Assign roles via `MappingPreset.melodyRoles`.

Example:

```ts
melodyRoles = {
  "melody1": "body",
  "melody2": "base",
  "melody3": "rim"
};
```

- Logic:
  - *Body* melody influences main vertical profile (radius vs height).
  - *Base* melody adds additional geometry at lower height range.
  - *Rim* melody modifies upper range (e.g., lip of vase).
  - *Detail* melodies contribute to fine roughness/groove parameters.

Implementation detail (for v1): focus on `layered` as default and implement a basic `multi_part` later.

---

## 8. Mapping to SculptureDefinition

### 8.1. Overview

Use a single function:

```ts
function mapMelodiesToSculpture(
  melodies: Melody[],
  activeMelodyIds: string[],
  userProfile: UserProfile,
  mappingPreset: MappingPreset
): SculptureDefinition;
```

This function:

1. Gathers relevant `NoteEvent`s according to `activeMelodyIds`.
2. Aggregates them per step according to `combinationMode`.
3. Computes `ProfilePoint[]`.
4. Computes global parameters: `symmetry`, `globalTwist`, etc.
5. Returns a complete `SculptureDefinition`.

### 8.2. Example Mapping: “Vase” Mode (Layered)

Assume:

- N steps (same N used when building `NoteEvent`).
- For each step `s` (0..N-1), we compute a `ProfilePoint`.

#### Radius

1. Normalize pitch with user profile:

```ts
const pitchNorm = normalizePitch(stepPitchHz, userProfile); // 0..1
```

2. Map to radius:

```ts
const baseRadius = 0.3 + pitchNorm * 0.7; // 0.3..1.0
const radius = lerp(0.5, baseRadius, mappingPreset.pitchToRadiusWeight);
```

#### Height

`heightNorm = s / (N - 1)`.

Optionally modify by loudness:

```ts
const loudnessNorm = normalize(stepRms, minRms, maxRms);
const heightWarp = 1 + (loudnessNorm - 0.5) * 0.2 * mappingPreset.loudnessToHeightWeight;
const adjustedHeightNorm = clamp(heightNorm * heightWarp, 0, 1);
```

#### Roughness

```ts
const brightnessNorm = normalize(stepCentroid, minCentroid, maxCentroid);
const roughness = brightnessNorm * mappingPreset.brightnessToRoughnessWeight;
```

#### GrooveDepth

Use interval size from `AnalysisSummary` (or per-step difference):

```ts
const intervalNorm = clamp(meanAbsIntervalSemitones / 12, 0, 1);
const grooveDepth = intervalNorm * mappingPreset.intervalToGrooveWeight;
```

#### Twist

Use vibrato or pitch variance (per-step or global):

```ts
const vibratoNorm = clamp(vibratoDepth / maxVibratoDepth, 0, 1);
const twist = vibratoNorm * mappingPreset.vibratoToTwistWeight * Math.PI * 0.25;
```

#### Smoothing

After computing raw `ProfilePoint[]`, apply smoothing:

- Temporal smoothing (over `stepIndex`).
- Spatial smoothing (reducing abrupt radius/height changes).

Simple approach: moving average over radius, twist, roughness fields with window width derived from `mappingPreset.smoothing.temporal`.

#### Symmetry

Use pitch variance:

```ts
const pitchVarianceNorm = clamp(globalPitchStdDev / maxStdDev, 0, 1);
const symmetry = pitchVarianceNorm < 0.5
  ? mappingPreset.symmetryOptions.stableSymmetry
  : mappingPreset.symmetryOptions.chaoticSymmetry;
```

### 8.3. Setting SculptureDefinition fields

After computing `ProfilePoint[]` and global parameters:

```ts
const sculpture: SculptureDefinition = {
  mode: mappingPreset.mode,
  profile: smoothedProfilePoints,
  crossSectionShape: "circle",   // for vase preset
  symmetry,
  globalTwist: computedGlobalTwist,
  colorStrategy: "none",         // or "pitch", etc., for shader use
  worldScale: { height: 1.0, radius: 1.0 },
  metadata: {
    detectedKey: globalEstimatedKey,
    detectedScale: globalEstimatedScale,
    audioDurationSec: combinedDuration,
    description: "Generated from X melodies in vase mode"
  }
};
```

---

## 9. three.js Geometry & Rendering

### 9.1. Scene Setup

- One `THREE.Scene`.
- Camera:
  - Perspective camera, FOV ~45°, near=0.1, far=100.
  - Default position something like `[0, 1.5, 4]`.

- Lights:
  - One `HemisphereLight` (ambient).
  - One or two `DirectionalLight`s for highlights.

- Renderer:
  - `WebGLRenderer` with antialiasing.
  - Size attached to viewport container.

### 9.2. Building Geometry from SculptureDefinition

For vase mode:

1. Convert `ProfilePoint[]` into a set of 2D points:

```ts
const points: THREE.Vector2[] = profile.map(p => {
  const y = p.heightNorm;              // 0..1
  const r = p.radius;                  // apply worldScale.radius if needed
  return new THREE.Vector2(r, y);
});
```

2. Use `LatheGeometry(points, segments)`:
   - `segments` can be `symmetry * k`, e.g. 64.

3. Apply global twist:
   - Either via a custom vertex shader, or:
     - Iterate vertices and rotate them around Y axis by `(yNormalized * globalTwist)`.

4. Apply roughness & grooveDepth:
   - Modify vertex positions using simple procedural noise where `roughness`/`grooveDepth` are > 0.
   - Use consistent random seed per export.

5. Create a mesh:

```ts
const material = new THREE.MeshStandardMaterial({
  color: new THREE.Color(0.8, 0.75, 0.7),
  roughness: 0.8,
  metalness: 0.0
});

const mesh = new THREE.Mesh(geometry, material);
mesh.castShadow = true;
mesh.receiveShadow = true;
```

6. Clear old sculpture, add new mesh to the scene.

### 9.3. Multi-View Camera Presets

Define constants:

```ts
type ViewId = "front" | "side" | "top" | "perspective";

type ViewPreset = {
  id: ViewId;
  label: string;
  cameraPosition: [number, number, number];
  cameraTarget: [number, number, number];
};

const VIEW_PRESETS: ViewPreset[] = [
  {
    id: "front",
    label: "Front",
    cameraPosition: [0, 1.0, 4],
    cameraTarget: [0, 1.0, 0]
  },
  {
    id: "side",
    label: "Side",
    cameraPosition: [4, 1.0, 0],
    cameraTarget: [0, 1.0, 0]
  },
  {
    id: "top",
    label: "Top",
    cameraPosition: [0, 5.0, 0],
    cameraTarget: [0, 0.5, 0]
  },
  {
    id: "perspective",
    label: "3/4 View",
    cameraPosition: [3, 1.5, 3],
    cameraTarget: [0, 1.0, 0]
  }
];
```

Use these positions both for interactive camera presets and for export.

---

## 10. Image Export (Multi-View, Default Behavior)

### 10.1. Export Resolution

- Default export resolution: e.g. **3000×3000** (square).
- Allow configuration later, but default MUST be high-res.

### 10.2. Export Process

When user clicks “Export Image Set”:

1. Store:
   - Current renderer size (width, height).
   - Current camera position & target.

2. For each `ViewPreset` in `VIEW_PRESETS`:

   - Set camera position & target.
   - Resize renderer to export resolution:
     - `renderer.setSize(3000, 3000, false);`
     - Update camera aspect ratio accordingly (1:1).
   - Render scene.
   - Call `renderer.domElement.toDataURL("image/png")`.
   - Save the dataURL plus view ID.

3. Restore:
   - Renderer size to original.
   - Camera to original position & target.

4. Download:
   - Either trigger four individual downloads:
     - `sculpture_front.png`
     - `sculpture_side.png`
     - `sculpture_top.png`
     - `sculpture_perspective.png`
   - Or create a ZIP client-side (with a JS zip library) and download as a single file.

This multi-view export is **mandatory** for v1.

---

## 11. UX Flows

### 11.1. First Launch

1. App opens.
2. If no `UserProfile` in localStorage:
   - Show Calibration Wizard.
3. After calibration:
   - Navigate to Main Screen (Record/Import).

### 11.2. Main Screens

1. **Calibration Wizard**
   - Accessible via “Settings → Calibration” anytime.
   - Flow defined in Section 4.

2. **Record / Import Screen**
   - List of existing melodies with:
     - Name, duration, range, estimated key.
     - Controls:
       - Mute/solo toggle per melody.
       - Delete, rename.
   - Buttons:
     - “Record new melody”
       - Opens mic record flow.
     - “Import audio file”
       - Opens file picker and processes offline.

3. **Analysis View**
   - Shows:
     - Pitch curve vs. time.
     - Loudness curve.
     - Brightness curve.
   - Simple timeline UI.
   - Display `AnalysisSummary` metrics for selected melody.

4. **Mapping Screen**
   - Controls:
     - MappingPreset selector (e.g. “Vase (Layered)”, “Totem”, “Bowl”).
     - Sliders bound to numeric fields in `MappingPreset`:
       - pitchToRadiusWeight
       - loudnessToHeightWeight
       - brightnessToRoughnessWeight
       - intervalToGrooveWeight
       - vibratoToTwistWeight
       - smoothing.temporal
       - smoothing.spatial
     - CombinationMode selection (Layered / Multi-part).
     - Melody role assignment UI (for Multi-part).
   - Optional 2D profile preview.

5. **3D Preview Screen**
   - Shows sculpture in three.js canvas.
   - Controls:
     - View selector: Front / Side / Top / 3/4.
     - “Remap from audio” (rebuild sculpture with updated mapping).
     - “Export Image Set” (multi-view high-res images).

6. **AI Assistant Panel**
   - Chat UI anchored on the side.
   - Textarea + send button.
   - System prompts like:
     - “Make the top thinner and more twisted.”
     - “Use the second melody only for subtle details.”

---

## 12. AI Assistant Integration

### 12.1. API Contract

Frontend sends to backend:

```ts
type AISculptureRequest = {
  userInstruction: string;
  projectState: {
    mappingPreset: MappingPreset;
    sculptureDefinition: SculptureDefinition | null;
    analysisSummaries: AnalysisSummary[]; // one per melody
    melodyIds: string[];                  // order corresponds to analysisSummaries
  };
};
```

Backend sends to LLM with a system message like:

> You are a sculptural-mapping assistant.  
> The user will describe changes to a 3D sculpture generated from sung melodies.  
> You can only respond with valid JSON matching this TypeScript interface:
> 
> ```ts
> type AIResponse = {
>   mappingPreset?: MappingPreset;
>   sculptureDefinition?: SculptureDefinition;
> };
> ```
> 
> Do not include comments or explanations, only JSON.

Backend returns:

```ts
type AIResponse = {
  mappingPreset?: MappingPreset;
  sculptureDefinition?: SculptureDefinition;
};
```

Frontend:

1. Validates JSON against schemas (e.g., using Zod).
2. Applies updated `mappingPreset` and/or `sculptureDefinition`.
3. Rebuilds three.js geometry as needed.

### 12.2. Failure Handling

- If AI response validation fails:
  - Show user a friendly error (“AI response invalid, please try again or rephrase”).
  - Do not change state.

---

## 13. Implementation Phases (Summary)

1. **Phase 1 – App Skeleton & three.js**
   - Set up SvelteKit + Tailwind.
   - Implement basic scene with a dummy mesh.
   - Implement multi-view image export (four angles).

2. **Phase 2 – Calibration Wizard**
   - Implement audio capture pipeline with Web Audio + Meyda.
   - Implement voice calibration steps.
   - Store `UserProfile`.

3. **Phase 3 – Audio Recording & Single-Melody Mapping**
   - Implement mic recording flow.
   - Integrate ml5 PitchDetection + Meyda.
   - Build `FrameFeature[]` and `NoteEvent[]`.
   - Implement minimal “Vase (Layered)” mapping and SculptureDefinition.
   - Generate and render a basic sculpture from a single melody.

4. **Phase 4 – Multi-Melody & Full MappingPreset**
   - Add Melody list, multiple recordings.
   - Implement layered combination mode.
   - Implement Mapping screen UI, binding all MappingPreset parameters.
   - Enhance mapping logic (loudness, brightness, roughness, groove, twist).

5. **Phase 5 – AI Assistant**
   - Implement SvelteKit endpoint for AI.
   - Define JSON schemas and TypeScript types in shared code.
   - Add chat UI, integrate AI responses.

6. **Phase 6 – Polish & Ceramics-Oriented Tweaks**
   - Refine clay-like material and lighting.
   - Tweak default mapping presets for aesthetically pleasing results.
   - Improve calibration UX and add help text/tooltips.

---

## 14. Non-Goals for v1

To avoid scope creep, the following are **explicitly out of scope for v1**:

- Exporting 3D model files (GLTF, OBJ, STL, etc.).
- Actual 3D printing / fabrication workflow integration.
- Multi-user collaboration or networking.
- Persistent cloud storage of projects (beyond local browser storage).
- Advanced AI generation of audio (singing) itself.

---

This specification provides enough structure to implement the full pipeline from recording to multi-view image export, with calibration and AI-assisted mapping, without ambiguity or contradictions.
