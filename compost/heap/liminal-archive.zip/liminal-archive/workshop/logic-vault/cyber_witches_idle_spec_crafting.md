# Cyber Witches: Idle Coven — **Make/Craft/Gather** Spec (Godot 4.5+, Portrait-First Web)

> **Theme Shift:** Players **make, craft, or gather** everything (no “buying” items). Candles, crystals, ingredients and stations are **crafted** from gathered components. The economy centers on **recipes**, **workstations**, and **ingredients**, not storefront purchases.

---

## 0) Targets & Tech (unchanged)

- **Primary:** Web (portrait-first). Secondary: Android/iOS/Desktop.  
- **Engine:** Godot 4.5+. Saves in `user://save.json` (IndexedDB).  
- **Accessibility:** Colorblind universal palette + shape/pattern cues; UI scale; Reduced FX.

---

## 1) Game Loops (updated verbs)

### 1.1 Core Loop (Crafting-first)
- **Forage/Channel** via **Cast()** to gather **base ingredients** (e.g., **Wax Bits**, **Wick Fiber**, **Crystal Dust**, **Aether Essence**).
- Use ingredients to **craft Workstations** (formerly “producers”) like **Digital Candle Farms**, **Crystal Rigs**, etc.  
- Workstations passively **output ingredients** and/or **Arcane Bits (AB)** over time.  
- Craft **Inscriptions** (upgrades) using ingredients to multiply/augment outputs.

### 1.2 Meta Loop — **Ascension (Prestige)**
- Reset a run to earn **Eldritch Keys (EK)** (permanent boons).

### 1.3 Offline Progression — **Ritual Drift**
- On load, compute elapsed time, award outputs; show Welcome Back. **Cap:** 12h.

### 1.4 Daily Rituals (kept in v1)
- 3 tasks/day that focus on **gathering** and **crafting**, not buying (see examples below).

---

## 2) Economy Model — From “Cost” to **Recipes**

- **No gold shop.** Instead of paying AB to acquire things, players **craft** them from ingredients.
- **Ingredients tiers:**
  - **Tier 0 (Forage):** Wax Bits, Wick Fiber, Crystal Dust, Aether Essence (from Cast() + basic Workstations).
  - **Tier 1 (Refined):** Wax Blocks, Braided Wick, Shaped Crystal, Distilled Aether (crafted from Tier 0).
  - **Tier 2 (Artifacts):** **Digital Candle**, **Sigil Core**, **Daemon Collar**, **Quantum Alembic** (crafted from T0/T1; many act as Workstations).
- **Arcane Bits (AB):** your “score/energy” produced by certain Stations (e.g., Digital Candles) and used for **prestige previews**; **not** a general currency for buying.

---

## 3) Data Model Changes

### 3.1 New Resource Types

`resources/IngredientData.gd`
```gdscript
extends Resource
class_name IngredientData
@export var id: String        # "wax_bits", "wick_fiber", "crystal_dust", "aether_ess"
@export var display_name: String
@export var tier: int         # 0,1,2...
@export var stack_limit: int = 0  # 0 = unlimited (practically capped by design)
```

### 3.2 Extend Producers → **Workstations** with **recipes**

`resources/ProducerData.gd` (add recipe & outputs)
```gdscript
extends Resource
class_name ProducerData
@export var id: String
@export var display_name: String
@export var unlock_at_ab: float = 0.0   # optional soft gate
@export var recipe: Dictionary          # {ingredient_id: amount} to CRAFT one unit (instead of base_cost)
@export var growth: float = 1.10        # per additional unit, recipe scales by growth
@export var outputs: Dictionary         # {ingredient_id: per_sec}  (can include "ab": per_sec)
```

### 3.3 Extend Upgrades (**Inscriptions**) to have recipes

`resources/UpgradeData.gd` (swap cost → recipe)
```gdscript
extends Resource
class_name UpgradeData
@export var id: String
@export var display_name: String
@export var description: String
@export var affects: String             # "global" | "producer:<id>"
@export var type: String                # "multiplier" | "additive" | "interval"
@export var value: float
@export var recipe: Dictionary          # {ingredient_id: amount}
@export var unlock_at_ab: float = 0.0
```

### 3.4 Prestige Bonuses unchanged (may add starting ingredients later)

---

## 4) Example Ingredient Set (v1)

| id            | Name             | Tier |
|---------------|------------------|-----:|
| wax_bits      | Wax Bits         | 0 |
| wick_fiber    | Wick Fiber       | 0 |
| crystal_dust  | Crystal Dust     | 0 |
| aether_ess    | Aether Essence   | 0 |
| wax_block     | Wax Block        | 1 |
| braided_wick  | Braided Wick     | 1 |
| shaped_crys   | Shaped Crystal   | 1 |
| dist_aether   | Distilled Aether | 1 |
| dig_candle    | **Digital Candle** (artifact) | 2 |

---

## 5) Workstations (Craftable Producers)

> Players **craft** a workstation using a **recipe**. Each additional unit requires ~10% more of each ingredient (tunable via `growth`).  
> Some stations output **ingredients**, others output **Arcane Bits (AB)** directly.

| id          | Workstation              | recipe (per unit)                                        | growth | outputs per sec (base)                | unlock_at_ab |
|-------------|--------------------------|-----------------------------------------------------------|-------:|---------------------------------------|-------------:|
| ws_melter   | **Wax Melter**           | 10×wax_bits                                              | 1.10   | 0.30×wax_block                         | 0 |
| ws_spinner  | **Wick Spinner**         | 10×wick_fiber                                            | 1.10   | 0.30×braided_wick                      | 0 |
| ws_shaper   | **Crystal Shaper**       | 10×crystal_dust                                          | 1.12   | 0.20×shaped_crys                       | 25 |
| ws_still    | **Aether Still**         | 10×aether_ess                                            | 1.12   | 0.20×dist_aether                       | 50 |
| ws_candle   | **Digital Candle Farm**  | 5×wax_block + 1×braided_wick + 2×dist_aether            | 1.14   | 1.0×ab                                 | 100 |
| ws_crystal  | **Crystal Rig**          | 2×shaped_crys + 2×dist_aether                            | 1.14   | 0.15×ab + 0.05×crystal_dust (feedback) | 250 |
| ws_cauldron | **Quantum Cauldron**     | 3×shaped_crys + 3×dist_aether + 1×dig_candle             | 1.16   | 2.5×ab                                 | 1500 |

> **Digital Candle** (`dig_candle`) can be both an artifact ingredient *and* a crafted item produced from Wax Block + Braided Wick + Distilled Aether (see recipe). You may award a **Digital Candle** when crafting the first `ws_candle` as a tutorial reward.

---

## 6) Inscriptions (Upgrades) — Recipe Costs

| id              | Name                      | affects           | type       | value | recipe                                      |
|-----------------|---------------------------|-------------------|------------|------:|---------------------------------------------|
| u_global_1      | **Hex Compiler v1**       | global            | multiplier | 1.5  | 2×wax_block + 2×braided_wick + 1×shaped_crys |
| u_candle_1      | **Wax Algorithm**         | producer:ws_candle| multiplier | 2.0  | 3×wax_block + 1×dist_aether                  |
| u_crystal_1     | **Quantum Faceting**      | producer:ws_crystal| multiplier| 2.0  | 2×shaped_crys + 1×dist_aether                |
| u_click_1       | **Sigil Stroke**          | global (click)    | additive   | 1.0  | 10×wick_fiber                                |
| u_cauldron_1    | **Brew Daemon**           | producer:ws_cauldron| multiplier| 1.8  | 2×shaped_crys + 2×dist_aether + 1×dig_candle |
| u_global_2      | **Sigil Cache**           | global            | multiplier | 1.8  | 3×wax_block + 2×shaped_crys + 2×dist_aether  |

> UI should **strike out** missing ingredients and show a **Craft** button instead of **Buy**.

---

## 7) Daily Rituals (Gather/Craft-focused)

**Examples**
- **Kindle the Grid** — *Craft* 3 **Wax Melters** → reward `ab:5000`  
- **Crystal Song** — *Own* 3 **Crystal Rigs** → `buff:abps:+0.10:900`  
- **Rite of Flow** — *Channel (Cast())* 150 times → `ek_frag:1`  
- **Threads of Fate** — *Craft* 20 **Braided Wick** (aggregate from outputs) → `ab:8000`  
- **Aether Alchemy** — *Distill* 10 **Distilled Aether** → `buff:abps:+0.15:600`

All tracked as conditions like `craft:workstation:ws_melter:3`, `own:workstation:ws_crystal:3`, `forage_taps:150`, `craft_item:braided_wick:20`, `craft_item:dist_aether:10`.

---

## 8) UI/Copy Changes

- Buttons: **Craft ×1 / ×10 / ×Max**, **Install**, **Inscribe**, **Ascend**, **Collect**  
- Producers tab label → **Workstations**  
- Display **Recipe cards** with ingredient icons, counts, and **Have/Need** indicators.  
- Show **Inventory** panel (collapsed) listing ingredient totals.  
- When crafting, play a short **forge/compile** animation (pixel sparks / neon glow).

---

## 9) Systems & Code Notes

- **Inventory:** `GameState.inventory: Dictionary {ingredient_id: float}` (floats ok for per-sec).  
- **Crafting check:** verify `inventory[ing] >= need` for each recipe entry; subtract on success.  
- **Scaling:** when crafting Nth unit of a workstation, multiply each ingredient in `recipe` by `pow(growth, owned)`.  
- **Outputs:** per-tick add to `inventory` (`ingredients`) and/or `currency` (`ab`).  
- **UI affordance:** gray out **Craft** if short on any ingredient; tooltip shows deficit.  
- **Drops from Cast():** small random bundle of Tier 0 ingredients per tap, scaled by global multipliers; keep taps meaningful even late game.

**Sample helpers (pseudocode/GDScript-ish):**
```gdscript
func can_craft(recipe: Dictionary, owned: int, growth: float) -> bool:
    for id in recipe.keys():
        var need := recipe[id] * pow(growth, owned)
        if inventory.get(id, 0.0) < need:
            return false
    return true

func craft(recipe: Dictionary, owned: int, growth: float) -> void:
    for id in recipe.keys():
        var need := recipe[id] * pow(growth, owned)
        inventory[id] -= need
```

---

## 10) Prestige & Boons (unchanged mechanics, new flavor)

- **Coven’s Oath** (global multiplier), **Seeded Spellbook** (starting AB), and producer-specific boons remain.  
- Optional future boon: **Starter Kit** — start runs with small stacks of Tier 0 ingredients.

**Prestige calc (unchanged):**
```gdscript
static var prestige_scale := 1_200_000.0
static func prestige_points_for(lifetime_earned: float) -> int:
    return int(floor(sqrt(max(lifetime_earned, 0.0) / prestige_scale)))
```

---

## 11) Acceptance Criteria (delta)

- [ ] **Workstations** are crafted via **recipes** (no AB costs).  
- [ ] **Ingredients** accumulate from **Cast()** and Workstation outputs.  
- [ ] **Inscriptions** consume ingredient recipes.  
- [ ] UI shows **Have/Need** counts and disables **Craft** when short.  
- [ ] Daily Rituals use **gather/craft** verbs and conditions.  
- [ ] Prestige loop and boons function as before.

---

## 12) Portrait-First Layout (reminder)

- **Top:** AB + AB/s (Ritual Throughput) + Ascend badge.  
- **Tabs:** **Workstations** | **Inscriptions** | **Boons** | **Dailies** | **Inventory**  
- **Bottom:** big **Cast()** rune.  
- **Colorblind mode:** single universal palette + shape cues.

---

### Example: Candle Path (end-to-end “make” flow)

1) **Cast()** to gather **Wax Bits** and **Wick Fiber**.  
2) **Craft** a **Wax Melter** → it outputs **Wax Block** over time.  
3) **Craft** a **Wick Spinner** → outputs **Braided Wick**.  
4) **Craft** a **Digital Candle Farm** (recipe uses Wax Block + Braided Wick + Distilled Aether).  
5) **Digital Candle Farm** outputs **Arcane Bits (AB)** passively.  
6) **Inscribe “Wax Algorithm”** to double Candle output (costs Wax Block + Distilled Aether).

*Everything is gathered or crafted—nothing is “bought.”*

---

*Updated to encourage **making, crafting, and gathering** at every step while preserving idle-game pacing and prestige depth.*
