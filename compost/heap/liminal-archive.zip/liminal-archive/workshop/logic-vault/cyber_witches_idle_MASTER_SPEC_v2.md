# CYBER WITCHES: IDLE COVEN — **ONE-FILE MASTER SPEC (v2)** (Godot 4.5+, Portrait-First Web)

> **This file is self-contained.** It includes **all mechanics, data models, code skeletons, content tables, UI/UX, dailies, prestige, persistence**, and the **Spellcoding (SigilScript)** system with **explicit, concrete examples** ready for your agent to implement.

---

## 0) Targets & Tech

- **Primary:** Web (HTML5), **portrait-first**. Secondary: Android/iOS/Desktop from same codebase.
- **Engine:** Godot 4.5+ (Forward+ renderer; Mobile renderer fallback).
- **Save location:** `user://save.json` (IndexedDB on web).
- **Perf guardrails:** 60 FPS target; sprite batching; minimal post-FX; lightweight shaders.
- **Accessibility:** Colorblind universal palette + pattern/shape cues; UI Scale; Reduced FX.

---

## 1) Game Loops

### 1.1 Core Loop — **Gather → Craft → Automate**
- **Cast()** channels ambient magic to gather **Tier‑0 ingredients** (Wax Bits, Wick Fiber, Crystal Dust, Aether Essence).
- **Craft Workstations** (formerly “producers”) from **recipes**. Workstations passively produce **ingredients** and/or **Arcane Bits (AB)**.
- **Inscribe Upgrades** using recipes to multiply/augment outputs.

### 1.2 Meta Loop — **Ascension (Prestige)**
- Reset a run to earn **Eldritch Keys (EK)**. Spend EK on **Boons** (permanent multipliers, starting AB, producer boosts).

### 1.3 Offline Progression — **Ritual Drift**
- On load, compute elapsed time since last save; award outputs; show a Welcome Back modal. **Cap:** 12h (configurable).

### 1.4 Daily Rituals (in v1)
- 3 tasks/day focused on **gathering** and **crafting**, with AB bursts, temporary AB/s buffs, or EK fragments.

### 1.5 **Spellcoding System** (SigilScript)
- Players **code spells together** (compose spell “snippets”) to **transform ingredients into artifacts** or **augment workstation behavior** and **apply buffs**.

---

## 2) “What’s Normal” Benchmarks

- **First Ascension**: common range **20–60 min**; target **~30–40 min**.
- **Run-to-run speedup**: ~**20%** faster after each Ascension (via EK boons + starting AB).
- **Offline cap**: **12h** (typical range 8–24h).
- **Early-game cadence**: upgrade/craft every **10–30s**, then minutes/hours later.

---

## 3) Project Structure

```
/scenes
  Main.tscn
  UI_HUD.tscn               # portrait-first tabs
  UI_WelcomeBack.tscn
  UI_Prestige.tscn
  UI_DailyRituals.tscn
  UI_Spellcode.tscn         # spellcoding IDE
  UI_Settings.tscn
/scripts
  GameState.gd (autoload)   # economy, tick, inventory, save/load, offline, prestige
  Balance.gd   (autoload)   # curves, formulas, prestige calc
  Crafting.gd  (autoload)   # recipes, scaling, helpers
  DailyRituals.gd           # select/track/claim/reset
  Spellcode.gd              # parse/execute SigilScript
  Persistence.gd (autoload) # JSON save utils
  Format.gd (autoload)      # big-number formatting
/resources
  IngredientData.gd | ProducerData.gd | UpgradeData.gd | PrestigeBonusData.gd | DailyTaskData.gd | SpellRecipeData.gd
/data
  ingredients.tres | producers.tres | upgrades.tres | prestige_bonuses.tres | daily_tasks_pool.tres | spell_recipes.tres
/assets
  /pixel  /icons  /sfx  /fonts
/theme
  colors.md  ui_tokens.tres
```
**Autoloads:** `GameState`, `Balance`, `Crafting`, `Format`, `Persistence`.

---

## 4) Data Models (FINAL)

### 4.1 Ingredients
`resources/IngredientData.gd`
```gdscript
extends Resource
class_name IngredientData
@export var id: String
@export var display_name: String
@export var tier: int
@export var stack_limit: int = 0  # 0 = practically unlimited
```

### 4.2 Workstations (Craftable Producers)
`resources/ProducerData.gd`
```gdscript
extends Resource
class_name ProducerData
@export var id: String
@export var display_name: String
@export var unlock_at_ab: float = 0.0
@export var recipe: Dictionary           # {ingredient_id: amount} to craft one unit
@export var growth: float = 1.10         # recipe scales ~growth^owned
@export var outputs: Dictionary          # {ingredient_id_or_"ab": per_sec}
```

### 4.3 Inscriptions (Upgrades) — Recipe-based
`resources/UpgradeData.gd`
```gdscript
extends Resource
class_name UpgradeData
@export var id: String
@export var display_name: String
@export var description: String
@export var affects: String             # "global" | "producer:<ws_id>" | "click"
@export var type: String                # "multiplier" | "additive" | "interval"
@export var value: float
@export var recipe: Dictionary          # {ingredient_id: amount}
@export var unlock_at_ab: float = 0.0
```

### 4.4 Boons (Prestige Bonuses)
`resources/PrestigeBonusData.gd`
```gdscript
extends Resource
class_name PrestigeBonusData
@export var id: String
@export var display_name: String
@export var description: String
@export var base_cost_pp: float
@export var cost_growth: float = 1.5
@export var type: String        # "global_mult" | "producer_mult" | "starting_currency" | "start_ingredient"
@export var param: String = ""  # producer id or ingredient id
@export var value: float
```

### 4.5 Daily Rituals
`resources/DailyTaskData.gd`
```gdscript
extends Resource
class_name DailyTaskData
@export var id: String
@export var display_name: String
@export var description: String
@export var condition: String   # "craft:workstation:ws_melter:3", "tap:150", ...
@export var reward_type: String # "ab", "buff", "ek_frag"
@export var reward_value: float # amount or seconds for buff
@export var icon: String = ""
```

### 4.6 Spellcoding (SigilScript recipes)
`resources/SpellRecipeData.gd`
```gdscript
extends Resource
class_name SpellRecipeData
@export var id: String
@export var display_name: String
@export var description: String
@export var dsl: String         # SigilScript source (see §8 concrete examples)
@export var unlock_at_ab: float = 0.0
```

### 4.7 Save Schema (JSON)
```json
{
  "version": 2,
  "timestamp": 1730640000,
  "ab": 123456.0,
  "ab_total": 456789.0,
  "inventory": {"wax_bits": 120, "wick_fiber": 60},
  "workstations": {"ws_melter": 2, "ws_spinner": 1},
  "upgrades": {"u_global_1": true},
  "prestige": {
    "points": 15,
    "lifetime_earned": 1.2e9,
    "bonuses": {"pp_global_1": 2}
  },
  "dailies": {
    "day_key": "2025-11-03",
    "active_ids": ["d_kindlel", "d_song", "d_flow"],
    "progress": {"d_flow": 73},
    "claimed": {"d_kindlel": true}
  },
  "spells": {
    "unlocked": ["sp_candle_compile"],
    "compiled_cache": {}
  }
}
```

---

## 5) Content (v1 Defaults)

### 5.1 Ingredients
| id            | Name             | Tier |
|---------------|------------------|-----:|
| wax_bits      | Wax Bits         | 0 |
| wick_fiber    | Wick Fiber       | 0 |
| crystal_dust  | Crystal Dust     | 0 |
| aether_ess    | Aether Essence   | 0 |
| wax_block     | Wax Block        | 1 |
| braided_wick  | Braided Wick     | 1 |
| shaped_crys   | Shaped Crystal   | 1 |
| dist_aether   | Distilled Aether | 1 |
| dig_candle    | Digital Candle   | 2 |

### 5.2 Workstations
| id          | Workstation              | recipe (per unit)                                        | growth | outputs per sec (base)                | unlock_at_ab |
|-------------|--------------------------|-----------------------------------------------------------|-------:|---------------------------------------|-------------:|
| ws_melter   | Wax Melter               | 10×wax_bits                                              | 1.10   | 0.30×wax_block                         | 0 |
| ws_spinner  | Wick Spinner             | 10×wick_fiber                                            | 1.10   | 0.30×braided_wick                      | 0 |
| ws_shaper   | Crystal Shaper           | 10×crystal_dust                                          | 1.12   | 0.20×shaped_crys                       | 25 |
| ws_still    | Aether Still             | 10×aether_ess                                            | 1.12   | 0.20×dist_aether                       | 50 |
| ws_candle   | Digital Candle Farm      | 5×wax_block + 1×braided_wick + 2×dist_aether            | 1.14   | 1.0×ab                                 | 100 |
| ws_crystal  | Crystal Rig              | 2×shaped_crys + 2×dist_aether                            | 1.14   | 0.15×ab + 0.05×crystal_dust (feedback) | 250 |
| ws_cauldron | Quantum Cauldron         | 3×shaped_crys + 3×dist_aether + 1×dig_candle             | 1.16   | 2.5×ab                                 | 1500 |

### 5.3 Inscriptions (Upgrades)
| id              | Name                      | affects              | type       | value | recipe                                      |
|-----------------|---------------------------|----------------------|------------|------:|---------------------------------------------|
| u_global_1      | Hex Compiler v1           | global               | multiplier | 1.5  | 2×wax_block + 2×braided_wick + 1×shaped_crys |
| u_candle_1      | Wax Algorithm             | producer:ws_candle   | multiplier | 2.0  | 3×wax_block + 1×dist_aether                  |
| u_crystal_1     | Quantum Faceting          | producer:ws_crystal  | multiplier | 2.0  | 2×shaped_crys + 1×dist_aether                |
| u_click_1       | Sigil Stroke              | click                | additive   | 1.0  | 10×wick_fiber                                |
| u_cauldron_1    | Brew Daemon               | producer:ws_cauldron | multiplier | 1.8  | 2×shaped_crys + 2×dist_aether + 1×dig_candle |
| u_global_2      | Sigil Cache               | global               | multiplier | 1.8  | 3×wax_block + 2×shaped_crys + 2×dist_aether  |

### 5.4 Boons (Prestige)
| id               | Name                  | type              | param       | value | base_cost_pp | growth |
|------------------|-----------------------|-------------------|-------------|------:|-------------:|-------:|
| pp_global_1      | Coven’s Oath          | global_mult       | ""          | 0.10 | 10           | 1.5    |
| pp_start_bits    | Seeded Spellbook      | starting_currency | ""          | 1000 | 5            | 1.5    |
| pp_candle_mult   | Wax Moon              | producer_mult     | ws_candle   | 0.05 | 8            | 1.5    |
| pp_crystal_mult  | Facet Star            | producer_mult     | ws_crystal  | 0.05 | 10           | 1.5    |
| pp_cauldron_mult | Crucible Pact         | producer_mult     | ws_cauldron | 0.05 | 12           | 1.5    |
| pp_start_ingred  | Pocket Satchel        | start_ingredient  | wax_bits    | 100  | 6            | 1.5    |

### 5.5 Daily Rituals (examples)
- **Kindle the Grid** — `craft:workstation:ws_melter:3` → `ab:5000`
- **Crystal Song** — `own:workstation:ws_crystal:3` → `buff:abps:+0.10:900`
- **Rite of Flow** — `tap:150` → `ek_frag:1`
- **Threads of Fate** — `craft_item:braided_wick:20` → `ab:8000`
- **Aether Alchemy** — `craft_item:dist_aether:10` → `buff:abps:+0.15:600`

---

## 6) Prestige & Balancing

**Prestige calculation**
```gdscript
# Balance.gd
static var prestige_scale := 1_200_000.0   # first Ascension ~30–40 min
static func prestige_points_for(lifetime_earned: float) -> int:
    return int(floor(sqrt(max(lifetime_earned, 0.0) / prestige_scale)))
```

**Targets**
- First Ascension ~30–40 min (±10).  
- ~20% faster per Ascension via EK spend + starting AB.  
- Offline cap 12h.

---

## 7) Systems & Code (Skeletons)

**Included:** `Balance.gd`, `Crafting.gd`, `Spellcode.gd`, `Format.gd`, `Persistence.gd`, `GameState.gd` — **identical to v1 master file** (omitted here for brevity).  
> Your agent should copy the skeletons from this file’s earlier v1 (or I can re-paste them if needed).

---

## 8) **Spellcoding (SigilScript) — Concrete Examples**

> Paste these **exact** blocks into `/data/spell_recipes.tres` entries (as `dsl` strings).

### 8.1 Crafting/Combining (items from ingredients)
**ID:** `sp_wax_block_bulk`  
**DSL:**
```
# Convert raw wax into refined blocks
combine wax_bits:50 -> wax_block:5
```
**Effect:** Consumes 50 Wax Bits, creates 5 Wax Blocks.

**ID:** `sp_braid_wick`  
**DSL:**
```
# Braid fibers into wicks
combine wick_fiber:30 -> braided_wick:3
```
**Effect:** Consumes 30 Wick Fiber, creates 3 Braided Wick.

**ID:** `sp_distill_aether`  
**DSL:**
```
# Distill essence into stable aether
combine aether_ess:40 -> dist_aether:4
```
**Effect:** Consumes 40 Aether Essence, creates 4 Distilled Aether.

**ID:** `sp_candle_compile`  
**DSL:**
```
# Assemble a Digital Candle artifact
combine wax_block:5, braided_wick:1, dist_aether:2 -> dig_candle:1
```
**Effect:** Produces 1 Digital Candle from refined parts.

### 8.2 Buffs (temporary effects)
**ID:** `sp_flux_overclock`  
**DSL:**
```
# Boost overall AB/s for 10 minutes
buff abps +0.20 for 600s
```
**Effect:** +20% AB/s for 600 seconds (stack multiplicatively with other buffs).

### 8.3 Augments (workstation output tweaks)
**ID:** `sp_crystal_feedback`  
**DSL:**
```
# Crystal Rigs now shed extra dust passively
augment ws_crystal output crystal_dust +0.05
```
**Effect:** Adds +0.05 crystal_dust/sec to each Crystal Rig owned (before multipliers).

**ID:** `sp_candle_glow`  
**DSL:**
```
# Digital Candle Farms burn brighter
augment ws_candle output ab +0.10
```
**Effect:** Adds +0.10 AB/sec to each Candle Farm (pre-multiplier).

> **Execution Model:** The IDE shows **Have/Need** per `combine` line; if all are satisfied, **Run** applies all ops atomically. Buffs store in `GameState.buffs`; augments in `GameState.ws_augments` keyed by `"ws_id:ing_or_ab"`.

---

## 9) UI & UX

- **Portrait-first tabs:** **Workstations** | **Inscriptions** | **Boons** | **Dailies** | **Inventory** | **Spellcoding**
- **Workstations:** **Craft ×1/×10/×Max**, recipe cards (Have/Need), owned count.  
- **Inscriptions:** recipe grid; **Inscribe** button; disabled with deficits.  
- **Boons:** EK count; preview “Ascend for +X EK”; boon shop.  
- **Dailies:** 3 tasks; progress bars; claim buttons; refresh timer to midnight.  
- **Inventory:** totals for all ingredients; tier filters.  
- **Spellcoding IDE:** list of spells; editor pane (read‑only v1), **Run**, log output.

**Style:** Cozy Neon Pixel (palette: #0E0E12, #FF2DAA, #22E3FF, #FFDB6E, #3CE3C5, #C9A0FF).  
**Accessibility:** colorblind palette + pattern/shape cues; UI scale; Reduced FX.  
**Audio:** Ambience/lo‑fi loop; craft/inscribe chimes; Ascend woosh; volume sliders + Mute.

---

## 10) Acceptance Criteria (v1)

**Gameplay**
- [ ] Cast() grants tier‑0 ingredients; Workstations output ingredients/AB; Inscriptions apply.  
- [ ] Crafting/Inscribing consume recipes; Have/Need UI; bulk craft works.  
- [ ] AB/s reflects multipliers, buffs, augments.

**Offline**
- [ ] Save/Load; Ritual Drift awards capped time; Welcome Back modal.

**Prestige**
- [ ] EK preview; Ascend resets run; Boons persist and apply.

**Daily Rituals**
- [ ] 3 tasks/day; progress tracked; rewards granted; refresh at midnight.  
- [ ] EK fragments auto-combine (5 → +1 EK).

**Spellcoding**
- [ ] SigilScript parsing; preview; execution (combine/buff/augment).  
- [ ] Example spells above run and produce expected effects.

**UX/Accessibility**
- [ ] Portrait-first tabs; landscape works.  
- [ ] Colorblind mode + cues; UI scale; Reduced FX; audio sliders.

**Web**
- [ ] 60 FPS on typical laptop/phone; IndexedDB persistence verified.

---

## 11) Implementation Checklist (Agent)

1. Create Godot project; set HTML5 export; **Autoloads** (`GameState`, `Balance`, `Crafting`, `Format`, `Persistence`).  
2. Add **Resource classes**; create `/data/*.tres` from tables (ingredients/producers/upgrades/boons/dailies/spells).  
3. Implement **Balance.gd**, **Crafting.gd**, **Spellcode.gd** (use skeletons).  
4. Implement **GameState.gd**: tick, inventory, craft/inscribe, buffs/augments, offline, prestige, dailies, save/load.  
5. Build UI scenes: HUD tabs; WelcomeBack; Prestige; Dailies; Inventory; Spellcoding.  
6. Wire **Format.short** for all numbers; add **Accessibility toggles**.  
7. Balance for **30–40 min** to first Ascension and **~20%** per‑run speedup.  
8. Stub **rewarded-only** hooks (Welcome Back +50%, reroll one Daily).  
9. Export HTML5; test on desktop + mobile browsers.

---

## 12) Example Flow — Candle Path (Gather/Craft/Code)

1) **Cast()** → gain Wax Bits + Wick Fiber.  
2) **Craft** **Wax Melter** → generates Wax Block.  
3) **Craft** **Wick Spinner** → generates Braided Wick.  
4) **Run Spell** `sp_candle_compile` in **Spellcoding IDE**:  
   ```
   combine wax_block:5, braided_wick:1, dist_aether:2 -> dig_candle:1
   ```
5) **Craft** **Digital Candle Farm** workstation → generates **AB**.  
6) **Inscribe** **Wax Algorithm** (producer:ws_candle ×2).

**Everything is gathered, crafted, or coded—never purchased.**

---

*End of master spec (v2).*
