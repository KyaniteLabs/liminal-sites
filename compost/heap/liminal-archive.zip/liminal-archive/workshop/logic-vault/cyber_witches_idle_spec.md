# Cyber Witches: Idle Coven — Build Spec (Godot 4.5+, Portrait-First Web)

> **Vision:** A cozy-neon **pixel-art** idle game where **cyber witches** craft **digital spells** using candles, crystals, familiars, and quantum cauldrons. Beautiful, soothing, and accessible.  
> **Orientation:** **Portrait-first** (web + mobile). Landscape is supported but secondary.

---

## 0) Targets & Tech

- **Primary:** Web (HTML5, portrait). **Secondary:** Android/iOS/Desktop from same codebase.  
- **Engine:** Godot 4.5+ (Forward+ renderer; Mobile renderer fallback on low-end).  
- **Save location:** `user://save.json` (IndexedDB on web).  
- **Perf guardrails:** 60 FPS target; batched sprites; minimal post-FX; lightweight shaders.  
- **Accessibility:** Colorblind Mode (single universal palette) + pattern/shape cues; UI Scale; Reduced FX.

---

## 1) Game Loops

### 1.1 Core Loop
- Tap **Cast()** to mint **Arcane Bits (AB)**.  
- Buy **Synthesizers** (producers) to auto-generate **Ritual Throughput** (AB/s).  
- Buy **Inscriptions** (upgrades) to multiply/augment production.

### 1.2 Meta Loop — **Ascension (Prestige)**
- Reset a run to earn **Eldritch Keys (EK)**.  
- Spend EK on **Boons** (permanent bonuses): global multipliers, producer boosts, starting AB.

### 1.3 Offline Progression — **Ritual Drift**
- On load, compute elapsed time, award AB; show a **Welcome Back** summary.  
- **Offline cap**: 12h (configurable).

### 1.4 **Daily Rituals** (included in v1)
- A small rotating task list (3 per day) that nudges variety and gives steady bonuses.  
- Tasks refresh at local midnight; rewards: AB bursts, temporary 10–20 min buffs, or tiny EK fragments (optional).  
- Examples:
  - **Kindle the Grid:** Buy 10 Digital Candles → +5,000 AB  
  - **Crystal Song:** Own 3 Crystal Rigs → +10% AB/s for 15 min  
  - **Rite of Flow:** Cast() 100 times → +1 EK fragment (collect 5 = +1 EK)

---

## 2) “What’s Normal” Benchmarks

- **First Ascension:** many idle games aim for **20–60 min**; we’ll target **~30–40 min**.  
- **Run-to-run speedup:** **~20%** faster after each Ascension (your preference).  
- **Offline cap:** **12h** to start (typical range 8–24h).  
- **Early-game cadence:** upgrades every **10–30s**, then minutes, then hours.

---

## 3) Pacing Targets

- **First session:** Ascend in ~30–40 min (±10).  
- **Each Ascension:** ~**20%** faster (via EK boons + starting AB).  
- **Midgame:** 3–5 producers unlocked, an inscription every 2–5 minutes.  
- **Late v1:** introduce a couple deeper boons or a Tier-2 hook (stubbed).

---

## 4) Project Structure

```
/scenes
  Main.tscn
  UI_HUD.tscn               # portrait-first tabbed HUD
  UI_WelcomeBack.tscn
  UI_Prestige.tscn
  UI_DailyRituals.tscn
  UI_Settings.tscn
/scripts
  GameState.gd (autoload)   # economy, tick, save/load, offline, prestige
  Balance.gd   (autoload)   # curves, formulas, PP calc
  DailyRituals.gd           # generation, claim, refresh at midnight
  Persistence.gd (autoload) # JSON save utils
  Format.gd (autoload)      # big-number formatting
/resources
  ProducerData.gd | UpgradeData.gd | PrestigeBonusData.gd | DailyTaskData.gd
/data
  producers.tres | upgrades.tres | prestige_bonuses.tres | daily_tasks_pool.tres
/assets
  /pixel  /icons  /sfx  /fonts
/theme
  colors.md  ui_tokens.tres
```

**Autoloads:** `GameState`, `Balance`, `Format`, `Persistence`.

---

## 5) Data Models (APIs unchanged; themed content)

### 5.1 Terms
- **Arcane Bits (AB)** – primary currency  
- **Ritual Throughput** – AB/s  
- **Eldritch Keys (EK)** – prestige currency  
- **Synthesizers** – producers  
- **Inscriptions** – upgrades  
- **Boons** – prestige bonuses  
- **Ritual Drift** – offline earnings  
- **Daily Rituals** – rotating tasks

### 5.2 Synthesizers (Producers v1)

| id          | Name                    | base_cost | growth | base_cps | unlock_at |
|-------------|-------------------------|----------:|-------:|---------:|----------:|
| p_click     | **Sigil: CAST()**       | 0         | 1.00   | 0.0      | 0         |
| p_candle    | **Digital Candle Farm** | 25        | 1.15   | 0.5      | 10        |
| p_crystal   | **Crystal Rig**         | 250       | 1.15   | 5.0      | 100       |
| p_familiar  | **Daemon Familiar**     | 2,500     | 1.16   | 28.0     | 600       |
| p_cauldron  | **Quantum Cauldron**    | 25,000    | 1.16   | 165.0    | 3,500     |

### 5.3 Inscriptions (Upgrades v1)

| id              | Name                         | Affects             | type        | value | cost   |
|-----------------|------------------------------|---------------------|-------------|------:|-------:|
| u_global_1      | **Hex Compiler v1**          | global              | multiplier  | 1.5  | 100    |
| u_candle_1      | **Wax Algorithm**            | producer:p_candle   | multiplier  | 2.0  | 250    |
| u_crystal_1     | **Quantum Faceting**         | producer:p_crystal  | multiplier  | 2.0  | 2,000  |
| u_click_1       | **Sigil Stroke**             | producer:p_click    | additive    | 1.0  | 50     |
| u_familiar_1    | **Daemon Optimizer**         | producer:p_familiar | multiplier  | 1.8  | 12,000 |
| u_cauldron_1    | **Brew Daemon**              | producer:p_cauldron | multiplier  | 1.8  | 60,000 |
| u_global_2      | **Sigil Cache**              | global              | multiplier  | 1.8  | 90,000 |
| u_click_2       | **Auto-Trace Rune**          | producer:p_click    | additive    | 2.0  | 500    |

### 5.4 Boons (Prestige Bonuses v1)

| id               | Name                  | type            | param     | value | base_cost_pp | growth |
|------------------|-----------------------|-----------------|-----------|------:|-------------:|-------:|
| pp_global_1      | **Coven’s Oath**      | global_mult     | ""        | 0.10 | 10           | 1.5    |
| pp_start_bits    | **Seeded Spellbook**  | starting_currency| ""       | 1,000| 5            | 1.5    |
| pp_candle_mult   | **Wax Moon**          | producer_mult   | p_candle  | 0.05 | 8            | 1.5    |
| pp_crystal_mult  | **Facet Star**        | producer_mult   | p_crystal | 0.05 | 10           | 1.5    |
| pp_daemon_mult   | **Unbound Familiar**  | producer_mult   | p_familiar| 0.05 | 12           | 1.5    |

**Prestige formula (v1):**
```gdscript
# Balance.gd
static var prestige_scale := 1_200_000.0   # aims first Ascension ~30–40 min
static func prestige_points_for(lifetime_earned: float) -> int:
    return int(floor(sqrt(max(lifetime_earned, 0.0) / prestige_scale)))
```

### 5.5 **Daily Rituals** Data

`resources/DailyTaskData.gd`
```gdscript
extends Resource
class_name DailyTaskData
@export var id: String
@export var display_name: String
@export var description: String
@export var condition: String   # e.g., "buy:producer:p_candle:10", "own:producer:p_crystal:3", "tap:100"
@export var reward_type: String # "ab", "buff", "ek_frag"
@export var reward_value: float # AB amount or seconds for buff, or fragments count
@export var icon: String = ""
```

`/data/daily_tasks_pool.tres` (Array[DailyTaskData]) includes:
- **Kindle the Grid** — `buy:producer:p_candle:10` → `ab:5000`
- **Crystal Song** — `own:producer:p_crystal:3` → `buff:abps:+0.10:900` *(+10% AB/s for 900s)*
- **Rite of Flow** — `tap:100` → `ek_frag:1`

**Fragments:** collect 5 fragments → auto-convert to +1 EK.

---

## 6) UX & Art Direction

### 6.1 Portrait-First Layout (web & mobile)
- **Top sticky bar:**  
  - **AB** counter, **AB/s** (“Ritual Throughput”), **Ascend** button with EK badge.  
- **Middle tabs (large, comfy):** **Producers** | **Inscriptions** | **Boons** | **Dailies**  
  - **Producers:** list with **Buy ×1 / ×10 / ×Max**.  
  - **Inscriptions:** upgrade grid.  
  - **Boons:** EK count, Prestige preview, boon shop.  
  - **Dailies:** 3 tasks, progress bars, claim buttons, timer to refresh.  
- **Bottom sticky:** **Cast()** rune (big thumb target).

### 6.2 Landscape (secondary)
- Two-pane: left Producers, right (Inscriptions/Boons/Dailies via tabs), top bar same.

### 6.3 Visual Style — **Cozy Neon Pixel**
- **Palette:** Deep void `#0E0E12`, neon magenta `#FF2DAA`, cyan `#22E3FF`, gold `#FFDB6E`, teal `#3CE3C5`, lavender `#C9A0FF`.  
- **Micro-animations:** candle flicker, crystal shimmer, familiar hover (<100ms).  
- **Colorblind Mode:** swaps to universal palette variant + adds **shape/pattern cues** on buttons/rarities/progress; avoids color-only signals.  
- **UI Scale:** 0.8×–1.4×.  
- **Reduced FX:** disables bloom, lowers particles.

### 6.4 Audio
- **Ambience/lo-fi** bed (45–90s loop), soft chime on purchase, airy “woosh” on Ascend.  
- **Settings:** Music/SFX sliders + Mute.

---

## 7) Systems & Code (summary)

- **Tick:** time-based; use `Timer` or `_process` accumulator.  
- **Autosave:** every ~10s and on major actions; save `timestamp`.  
- **Offline:** on load, `elapsed = now - timestamp`; cap 12h; award; show modal.  
- **Data-driven:** producers/upgrades/boons/dailies in `.tres`.  
- **DailyRituals.gd:**  
  - Picks 3 unique tasks from pool each day.  
  - Tracks progress; grants rewards; stores day key `YYYY-MM-DD`.  
  - Resets at local midnight; unclaimed rewards persist 24h.

---

## 8) Monetization (planning)

**You asked what “rewarded vs interstitial” means:**
- **Rewarded ads:** Player opts in to watch an ad to get a bonus (e.g., +50% to offline earnings). Best UX; player-friendly.  
- **Interstitial ads:** Full-screen ads that appear at milestones (e.g., after Ascension). Higher friction; can annoy players.

**Default for v1:** **Rewarded-only** hooks (clean, cozy vibe).  
- Hooks: **Welcome Back +50%**, optional “reroll one Daily task” (cooldown).

---

## 9) Acceptance Criteria (v1)

**Gameplay**
- [ ] Cast(), producers, inscriptions work; AB/s accurate.  
- [ ] Costs scale; unlock thresholds work.  
- [ ] Big-number formatting (K, M, B, T, Qa, Qi…).

**Offline**
- [ ] Save/Load; Ritual Drift awards capped time; Welcome Back modal.

**Prestige**
- [ ] EK preview & Ascend; run resets; Boons persist & apply.

**Daily Rituals**
- [ ] 3 tasks appear daily; track progress; rewards grant; timer to refresh.  
- [ ] EK fragments auto-combine (5 → +1 EK).  
- [ ] Optional “reroll one task” (baseline free every 24h; ad-boosted reroll later).

**UX/Accessibility**
- [ ] Portrait-first tabs; landscape works.  
- [ ] Colorblind mode (single palette + cues).  
- [ ] UI scale; Reduced FX; audio sliders.

**Web**
- [ ] 60 FPS on common laptop/phone; IndexedDB persistence across sessions.

---

## 10) Implementation Checklist (AI Agent)

1. Create project + HTML5 export; set **Autoloads** (`GameState`, `Balance`, `Format`, `Persistence`).  
2. Implement **Resource classes** (Producer/Upgrade/PrestigeBonus/DailyTask).  
3. Create `/data/*.tres` using tables above (plus a small Daily pool).  
4. Implement **Balance.gd** (cost/CPS/prestige; `prestige_scale=1_200_000`).  
5. Implement **GameState.gd** (tick, buy, upgrades, boons, save/load, offline, prestige).  
6. Implement **DailyRituals.gd** (select, progress, claim, midnight reset, fragments→EK).  
7. Build **UI scenes**: Portrait-first tabbed HUD; WelcomeBack; Prestige; Dailies; Settings.  
8. Add **Format.short** everywhere numbers display.  
9. Add **Accessibility toggles** (Colorblind Mode switch applies palette+shape presets; UI Scale; Reduced FX).  
10. Balance to hit **~30–40 min** to first Ascension and **~20%** per-run speedup.  
11. Wire **rewarded-only** integration points (stub functions for web; real SDK later).  
12. Export HTML5; test desktop/mobile browsers.

---

## Appendix — Example Conditions & Rewards (Daily Rituals)

- `buy:producer:<id>:N` — purchases of a producer today  
- `own:producer:<id>:N` — reach ownership threshold  
- `tap:N` — total Cast() taps today  
- Rewards:
  - `ab:<amount>` — grant AB immediately  
  - `buff:abps:+<mult>:<seconds>` — temporary AB/s multiplier  
  - `ek_frag:<count>` — Eldritch Key fragments

---

*Prepared for implementation. Portrait-first, cozy-neon pixel aesthetic, with Daily Rituals in v1 and rewarded-only ad hooks.*
