# Generative Score Lab – Design (v2, with AI-Agent-Friendly Exports)

_Last updated: Nov 2025_

This version adds three key constraints:

1. **Exports must be easy to feed into AI coding agents.**
2. **Target users:** indie devs and non-technical composers.
3. **AI assistant must support both cloud and local LLM backends.


## 1. Target users & UX implications

### 1.1 Indie devs

- Comfortable with JSON, TypeScript, and game engines (Unity, Godot, web).
- Want **clear, documented formats** they can parse and manipulate with code (or with their own AI assistants).
- Prefer small, composable files and **version-controllable artifacts**.

### 1.2 Non-technical composers

- Don’t want to see code by default.
- Need **musical language** in the UI: scenes, intensity, mood, key, scale, groove.
- Want to express changes in plain language: “make this calmer”, “change key to G minor”, “add a gentle high pad”.

**Design consequence:**

- Provide a **visual, scene-based UI** and **natural-language assistant** for composers.
- Provide **transparent, well-typed JSON/TS representations** and exports for devs + AI agents.


## 2. AI-coding-agent-friendly export design

Goal: anything produced in the lab should be directly usable by:

- Cloud coding assistants (ChatGPT-style).
- Local LLMs (LM Studio, Ollama, etc.).

### 2.1 Export structure

Recommended structure per project:

```text
my-game-score/
  project.json           # Main high-level project file
  scenes/
    exploration_day.json
    exploration_night.json
    combat_low.json
    combat_high.json
    boss_phase2.json
  instruments.json       # Optional shared instrument presets
  mappings.json          # Optional shared game-variable → music mappings
  README.md              # Human + AI-targeted instructions
```

**Design rules for AI agents:**

- **Simple JSON**, no code in the data files:
  - No functions, no circular refs, no computed properties.
  - Keys are stable and descriptive.
- **One main file (`project.json`)** that references others by ID or name:
  - Easy entry point for an agent to understand the whole score.
- Each scene file is **self-contained** enough for an agent to edit in isolation:
  - Contains key/scale, tempo, tracks, clips, generators, and mappings specific to that scene.

### 2.2 Example `project.json` (simplified)

```jsonc
{
  "schemaVersion": "1.0.0",
  "projectId": "my_game_score",
  "name": "My Game Score",
  "bpm": 110,
  "timeSignature": "4/4",
  "defaultKey": "C",
  "defaultScale": "major",
  "scenes": [
    {
      "id": "exploration_day",
      "file": "scenes/exploration_day.json"
    },
    {
      "id": "exploration_night",
      "file": "scenes/exploration_night.json"
    },
    {
      "id": "combat_low",
      "file": "scenes/combat_low.json"
    }
  ],
  "globalMappingsFile": "mappings.json",
  "instrumentsFile": "instruments.json"
}
```

> Note: Using a `schemaVersion` makes it easier for AI tools and CI tests to validate and migrate files over time.


### 2.3 Example `scenes/exploration_day.json` (simplified)

```jsonc
{
  "sceneId": "exploration_day",
  "name": "Exploration – Day",
  "color": "#7AC9FF",
  "key": "D",
  "scale": "major",
  "bpm": 110,
  "intensityRange": [0.2, 0.7],

  "tracks": [
    {
      "id": "drums_main",
      "name": "Main Drums",
      "role": "drums",
      "instrumentRef": "drum_kit_lofi_01",
      "clips": [
        {
          "id": "drums_groove_a",
          "lengthBars": 4,
          "generator": {
            "type": "euclidean",
            "params": {
              "steps": 16,
              "pulses": 5,
              "rotation": 3,
              "patternRole": "kick_snare_hat"
            }
          },
          "density": 0.6,
          "probability": 1.0,
          "muted": false
        }
      ]
    },

    {
      "id": "bass_main",
      "role": "bass",
      "instrumentRef": "bass_sine_01",
      "clips": [
        {
          "id": "bass_pattern_a",
          "lengthBars": 4,
          "generator": {
            "type": "arp",
            "params": {
              "mode": "up_down",
              "notesPerBeat": 2,
              "octaveRange": 1,
              "followChordProgression": true
            }
          }
        }
      ]
    }
  ],

  "mappings": [
    {
      "source": "player_speed",
      "target": "scene.intensity",
      "inputRange": [0, 10],
      "outputRange": [0.2, 0.7],
      "curve": "linear"
    },
    {
      "source": "time_of_day",
      "target": "track.drums_main.density",
      "inputRange": [0.0, 1.0],
      "outputRange": [0.3, 0.7],
      "curve": "easeInOut"
    }
  ]
}
```

This format is:

- **Descriptive and regular**, so an AI agent can:
  - Read the whole scene,
  - Reason about mappings and generators,
  - Propose patches (“Increase drum density in night scenes”, “Change scale to D Dorian”).

- Easy for your own runtime code to parse and feed into Tone.js, Strudel, or other engines.


### 2.4 README contract for AI agents

Include a short, human+AI-oriented `README.md` in each project:

- Explain the schema in plain language.
- Give examples of “tasks” an AI assistant should perform, e.g.:
  - “Add a new `Boss_Phase3` scene based on `Boss_Phase2` but faster, darker, and more dissonant.”
  - “Reduce low-end overlap in all exploration scenes.”
- Provide example diffs / patches.

This acts as a **contract** for how agents should modify the files.


## 3. Assistant backend: cloud + local LLM

You want both cloud and local options. The key is an abstraction layer:

### 3.1 Interface

```ts
// Pseudocode / TS-like interface
interface AssistantBackend {
  id: "cloud" | "local";
  name: string;

  // Given project subset + natural language request,
  // returns a patch (diff) to apply.
  proposePatch(input: {
    projectSnippet: any;        // JSON subset (scene, track, etc.)
    schemaDescription: string;  // text description of schema & constraints
    userRequest: string;        // natural language
  }): Promise<{
    patch: any;                 // JSON Patch or custom DSL
    explanation?: string;       // optional explanation
  }>;

  // Optional: ask for explanations or documentation
  explain(input: {
    projectSnippet: any;
    question: string;
  }): Promise<string>;
}
```

### 3.2 Cloud backend (example)

- Implementation for OpenAI / similar APIs:
  - Uses HTTPS calls to a hosted LLM.
  - Good for heavy reasoning, large context, and when network is available.

### 3.3 Local backend (example)

- Implementation for **LM Studio / Ollama / other local server**:
  - Uses HTTP to `http://localhost:PORT/v1/chat/completions` (OpenAI-compatible APIs).
  - Model choice is user-configurable (e.g., `local-music-coder-v1`).

### 3.4 Switching backends

- In the app settings:
  - **Radio / dropdown**: `Assistant Backend = Cloud | Local`.
  - Optional per-project override.
- The rest of the app calls the abstract `AssistantBackend` interface, so your UI and logic don’t care which backend is selected.


## 4. Updated TypeScript data model (core entities)

These types are designed to be:

- Simple for devs.
- Descriptive for AI tools.
- Directly serializable as JSON.

```ts
// Global project

export interface Project {
  schemaVersion: string;
  projectId: string;
  name: string;
  bpm: number;
  timeSignature: string; // "4/4", "3/4", etc.
  defaultKey: string;    // "C", "D", etc.
  defaultScale: string;  // "major", "minor", "dorian", etc.
  scenes: SceneRef[];
  globalMappingsFile?: string;
  instrumentsFile?: string;
}

export interface SceneRef {
  id: string;   // sceneId
  file: string; // path to scene JSON
}
```

```ts
// Scene

export interface Scene {
  sceneId: string;
  name: string;
  color?: string;
  bpm?: number;
  key: string;
  scale: string;
  intensityRange: [number, number]; // 0–1

  tracks: Track[];
  mappings: Mapping[];
  transitions?: Transition[];
}

export interface Track {
  id: string;
  name?: string;
  role: "drums" | "bass" | "pad" | "lead" | "fx" | "other";
  instrumentRef: string;
  clips: Clip[];
}

export interface Clip {
  id: string;
  lengthBars: number;
  generator: GeneratorConfig;
  density?: number;     // 0–1
  probability?: number; // 0–1
  muted?: boolean;
}

export interface GeneratorConfig {
  type:
    | "euclidean"
    | "arp"
    | "patternDSL"   // e.g. Strudel/Tidal-like
    | "magenta"
    | "markov"
    | "randomWalk"
    | "audioModelStem";
  params: Record<string, any>; // type-dependent
}

export interface Mapping {
  source: string; // e.g. "player_speed", "enemy_count", "time_of_day"
  target: string; // e.g. "scene.intensity", "track.drums_main.density"
  inputRange: [number, number];
  outputRange: [number, number];
  curve: "linear" | "easeIn" | "easeOut" | "easeInOut";
}

export interface Transition {
  fromSceneId: string;
  toSceneId: string;
  conditions: string;   // simple expression DSL, e.g. "danger > 0.8 && hp < 0.5"
  crossfadeBars: number;
}
```


## 5. UI flow tailored to indie devs + composers

### 5.1 Composer-facing flow

1. **Open project / start from template**
   - Choose a “Game Score Template”: Ambient Exploration, Retro Platformer, etc.
2. **Scene board**
   - Cards for each scene (color-coded, easy names).
3. **Scene edit view**
   - Key/scale selector, tempo, mood/intensity slider.
   - Track list with friendly labels and icons.
   - Simple controls for density, complexity, brightness, etc.
4. **Play & simulation**
   - Play the scene.
   - Optionally open a “Game Simulation” panel with simplified variables (HP, enemies, time-of-day) on sliders or curves.
5. **AI chat sidebar**
   - Type natural language instructions.
   - See the changes applied visually (highlighted tracks/parameters) with Undo/Redo.

### 5.2 Dev-facing flow

1. **Toggle “Dev mode”**
   - Shows a split view: UI + code/JSON preview (read-only by default).
2. **Inspect exports**
   - Button to “Export project” → writes JSON files and a README into a folder.
3. **Integration hints**
   - Dev mode provides quick code snippets (Unity/Godot/Web) for loading and using the Scene Graph JSON.
4. **AI coding agent usage**
   - Dev can use a coding agent (cloud or local) on the exported folder:
     - “Refactor all scenes to 90 BPM, keeping relative differences.”
     - “Generate an additional combat scene with a different key but similar intensity profile.”


## 6. Summary

With these additions, your Generative Score Lab is:

- **Friendly to non-tech composers** through scene-based UI, curated presets, constraints, and a natural-language assistant.
- **Powerful for indie devs** through JSON/TS schemas, exportable scene graphs, and easy integration with engines and middleware.
- **Perfectly suited for AI coding agents**, thanks to:
  - Simple, stable, descriptive JSON structures,
  - Clear schema types,
  - A README contract with examples,
  - And an abstract assistant backend that can be implemented with both cloud and local LLMs.
